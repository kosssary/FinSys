
// ... existing imports ...
import { CustomerOrder, SupplierBundle, Transaction, Account, Shareholder, Customer, AccountCategory, AccountType, OrderStatus, TransactionType, PartyStatement, Voucher, JournalVoucher, AccountLedger, GeneralLedgerNode, JournalVoucherLine, FinancialSummaryReportData, ProfitAndLossData, DashboardData, Kpi, Employee, EmployeeLedgerEntry, EmployeeLedgerTransactionType, Payroll, PayrollEmployee, ReceiptVoucherPayload, DisbursementVoucherPayload, SmartVoucherLineEntity, Vendor, CashFlowStatementData, HierarchicalPnlNode, BalanceSheetData, BalanceSheetGroup, BalanceSheetAccount, AdvancedTrialBalanceData, AdvancedTrialBalanceRow, Bill, BillLine, BillStatus, ApAgingReportData, BillPayment, Agent, RewardClaim, RewardMonthConfig, PartnerMetric, User, Role, Permission, ActivityLog, ActionType } from '../types';
import { MODULE_NAMES } from '../constants';

// ... IDataApi Interface ...
export interface IDataApi {
    // ... existing methods ...
    getAccounts: () => Promise<Account[]>;
    getAccountsList: () => Promise<Account[]>;
    getAccountById: (id: string) => Promise<Account | null>;
    getCustomers: () => Promise<Customer[]>;
    getCustomersWithBalance: () => Promise<any[]>;
    getVendors: () => Promise<Vendor[]>;
    getVendorsWithBalance: () => Promise<(Vendor & { balance: number; })[]>;
    getAgents: () => Promise<Agent[]>;
    getAgentById: (id: string) => Promise<Agent | null>;
    addAgent: (agentData: Omit<Agent, 'id' | 'createdAt'>) => Promise<Agent>;
    updateAgent: (agentData: Agent) => Promise<void>;
    deleteAgent: (agentId: string) => Promise<void>;
    getOrders: () => Promise<CustomerOrder[]>;
    getUnbundledOrders: () => Promise<CustomerOrder[]>;
    getBundles: () => Promise<SupplierBundle[]>;
    getShareholders: () => Promise<Shareholder[]>;
    getVouchers: (type: TransactionType) => Promise<Voucher[]>;
    getJournalVouchers: () => Promise<JournalVoucher[]>;
    getVoucherById: (voucherId: string) => Promise<Voucher | JournalVoucher | null>;
    getTransactions: () => Promise<Transaction[]>;
    addAccount: (accountData: Omit<Account, 'id' | 'balance' | 'isDeletable' | 'isPostable' | 'pathCodes' | 'isActive' | 'isLocked'>) => Promise<Account>;
    updateAccount: (accountData: Omit<Account, 'balance' | 'children' | 'nameKurdish' | 'isPostable' | 'pathCodes' | 'isActive' | 'isLocked'>) => Promise<void>;
    deleteAccount: (accountId: string) => Promise<void>;
    addShareholder: (shareholderData: Omit<Shareholder, 'id'>) => Promise<Shareholder>;
    updateShareholder: (shareholderData: Shareholder) => Promise<void>;
    deleteShareholder: (shareholderId: string) => Promise<void>;
    addOrder: (orderData: { customerId: string; customerName: string; customerPhone: string; customerPhone2?: string; agentId?: string; agentName?: string; productLink?: string; orderDescription?: string; totalPrice: number; paidAmount: number; receiptNumber?: string; logisticsId?: string; initialDepositAccountId?: string; estimatedDueDate?: Date; orderDate?: Date; internalShippingCost?: number; itemCount?: number }) => Promise<CustomerOrder>;
    updateOrder: (orderId: string, orderData: { customerId: string; customerName: string; customerPhone: string; customerPhone2?: string; agentId?: string; agentName?: string; productLink?: string; orderDescription?: string; totalPrice: number; paidAmount: number; receiptNumber?: string; logisticsId?: string; initialDepositAccountId?: string; estimatedDueDate?: Date; orderDate?: Date; internalShippingCost?: number; itemCount?: number }) => Promise<CustomerOrder>;
    deleteOrder: (orderId: string) => Promise<void>;
    updateOrderStatus: (orderId: string, status: OrderStatus) => Promise<void>;
    addCustomer: (customerData: Omit<Customer, 'id' | 'createdAt'>) => Promise<Customer>;
    updateCustomer: (customerData: Customer) => Promise<void>;
    deleteCustomer: (customerId: string) => Promise<void>;
    addVendor: (vendorData: Omit<Vendor, 'id'>) => Promise<Vendor>;
    updateVendor: (vendorData: Vendor) => Promise<void>;
    deleteVendor: (vendorId: string) => Promise<void>;
    addReceipt: (voucherData: ReceiptVoucherPayload) => Promise<Voucher>;
    addDisbursement: (voucherData: DisbursementVoucherPayload) => Promise<Voucher>;
    addJournalVoucher: (voucherData: Omit<JournalVoucher, 'voucherId' | 'voucherNumber' | 'sourceReference'>, isSystem?: boolean, sourceReference?: JournalVoucher['sourceReference']) => Promise<JournalVoucher>;
    updateReceipt: (voucherData: Omit<Voucher, 'voucherNumber' | 'type' | 'totalAmount'>) => Promise<void>;
    updateDisbursement: (voucherData: Omit<Voucher, 'voucherNumber' | 'type' | 'totalAmount'>) => Promise<void>;
    updateJournalVoucher: (voucherData: Omit<JournalVoucher, 'voucherNumber' | 'sourceReference'>) => Promise<void>;
    deleteVoucher: (voucherId: string, isSystemCall?: boolean) => Promise<void>;
    addBundle: (bundleData: { name: string; logisticsReferenceId: string; paymentAccountId: string; orderIds: string[], recordPayment: boolean, rewardsPaymentAmount?: number }) => Promise<SupplierBundle>;
    updateBundle: (bundleId: string, bundleData: { name: string; logisticsReferenceId: string; paymentAccountId: string; orderIds: string[], recordPayment: boolean }) => Promise<void>;
    deleteBundle: (bundleId: string) => Promise<void>;
    getDashboardData: (startDate: Date, endDate: Date) => Promise<DashboardData>;
    getArAgingReport: () => Promise<{ overdue: number; dueIn7Days: number; dueIn15Days: number; dueLater: number; orders: CustomerOrder[] }>;
    getStatementForCustomer: (customerId: string, startDate: string, endDate: string) => Promise<PartyStatement>;
    getStatementForVendor: (vendorId: string, startDate: string, endDate: string) => Promise<PartyStatement>;
    getAdvancedTrialBalance: (startDateStr: string, endDateStr: string, categoryFilter: Set<AccountCategory>, showZeroBalance: boolean) => Promise<AdvancedTrialBalanceData>;
    getFinancialSummaryReport: (startDate: string, endDate: string) => Promise<FinancialSummaryReportData>;
    getProfitAndLoss: (startDate: string, endDate: string) => Promise<ProfitAndLossData>;
    getAccountLedger: (accountId: string, startDate: string, endDate: string) => Promise<AccountLedger>;
    getGeneralLedger: (startDate: string, endDate: string) => Promise<GeneralLedgerNode[]>;
    getCashFlowStatement: (startDate: string, endDate: string) => Promise<CashFlowStatementData>;
    getBalanceSheet: (asOfDate: string) => Promise<BalanceSheetData>;
    getEmployees: () => Promise<Employee[]>;
    getEmployeesWithBalance: () => Promise<(Employee & { advanceBalance: number })[]>;
    getEmployeeById: (id: string) => Promise<Employee | null>;
    addEmployee: (employeeData: Omit<Employee, 'id' | 'isActive'>) => Promise<Employee>;
    getEmployeeLedger: (employeeId: string) => Promise<EmployeeLedgerEntry[]>;
    recordEmployeeAdvance: (data: { employeeId: string; amount: number; paidFromAccountId: string; date: Date; description: string; }) => Promise<void>;
    getDraftPayroll: (period: string) => Promise<Payroll>;
    finalizePayroll: (payroll: Payroll) => Promise<void>;
    payPayroll: (payrollId: string, paymentAccountId: string, paymentDate: Date) => Promise<void>;
    getPayrolls: () => Promise<Payroll[]>;
    getBills: () => Promise<Bill[]>;
    getBillById: (billId: string) => Promise<Bill | null>;
    addBill: (billData: Omit<Bill, 'id' | 'totalAmount' | 'paidAmount' | 'status' | 'payments' | 'journalVoucherId'>) => Promise<Bill>;
    updateBill: (billId: string, billData: Omit<Bill, 'id' | 'totalAmount' | 'paidAmount' | 'status' | 'payments' | 'journalVoucherId'>) => Promise<Bill>;
    deleteBill: (billId: string) => Promise<void>;
    getOpenBillsForVendor: (vendorId: string) => Promise<Bill[]>;
    recordBillPayment: (paymentData: { billId: string; paymentDate: Date; amount: number; paymentAccountId: string; referenceNumber: string; notes?: string; }[]) => Promise<void>;
    getApAgingReport: () => Promise<ApAgingReportData>;
    getBillPayments: () => Promise<(BillPayment & { vendorName: string; billId: string; billNumber: string; })[]>;
    voidBillPayment: (paymentId: string) => Promise<void>;
    processBatchDelivery: (orderIds: string[], courierVendorId: string) => Promise<void>;
    revertDelivery: (orderId: string) => Promise<void>;
    getRewardClaims: () => Promise<RewardClaim[]>;
    getRewardMonthConfigs: () => Promise<RewardMonthConfig[]>;
    upsertRewardMonthConfig: (config: RewardMonthConfig) => Promise<void>;
    recognizeRewardPoints: (period: string, totalItems: number, amount: number, description: string, pointsRate: number, conversionRate: number) => Promise<void>;
    processOrderCancellation: (orderId: string, scenario: 'before_purchase' | 'stocked' | 'returned') => Promise<string>;
    getNetProfitForPeriod: (startDateStr: string, endDateStr: string) => Promise<number>;
    getPartnerMetrics: () => Promise<PartnerMetric[]>;
    distributePeriodProfit: (date: Date, distributions: { shareholderId: string; amount: number }[]) => Promise<void>;
    login: (email: string, password: string) => Promise<User | null>;
    register: (userData: { name: string; email: string; password: string }) => Promise<User>;
    getRoles: () => Promise<Role[]>;
    getRoleById: (id: string) => Promise<Role | null>;
    saveRole: (role: Role) => Promise<Role>;
    deleteRole: (id: string) => Promise<void>;
    getUsers: () => Promise<User[]>;
    inviteUser: (email: string, roleId: string, name: string) => Promise<User>;
    updateUserRole: (userId: string, roleId: string) => Promise<void>;
    deleteUser: (userId: string) => Promise<void>;
    updateUser: (userId: string, updates: Partial<User>) => Promise<void>;
    updateProfile: (userId: string, updates: { name?: string; password?: string }) => Promise<void>;
    // Log Methods
    logAction: (entry: Omit<ActivityLog, 'id' | 'timestamp'>) => Promise<void>;
    getActivityLogs: () => Promise<ActivityLog[]>;
}

// --- IN-MEMORY DATABASE CLASS ---
class InMemoryApi implements IDataApi {
    // ... existing private fields ...
    private accounts: Account[] = [];
    private customers: Customer[] = [];
    private vendors: Vendor[] = [];
    private agents: Agent[] = [];
    private orders: CustomerOrder[] = [];
    private bundles: SupplierBundle[] = [];
    private shareholders: Shareholder[] = [];
    private transactions: Transaction[] = [];
    private vouchers: (Voucher | JournalVoucher)[] = [];
    private employees: Employee[] = [];
    private employeeLedgers: EmployeeLedgerEntry[] = [];
    private payrolls: Payroll[] = [];
    private bills: Bill[] = [];
    private rewardClaims: RewardClaim[] = [];
    private rewardConfigs: RewardMonthConfig[] = [];
    
    // Auth & RBAC Stores
    private users: User[] = [];
    private roles: Role[] = [];
    
    // Audit Log Store
    private activityLogs: ActivityLog[] = [];

    constructor() {}

    async init() {
        // ... existing init calls ...
        this._initializeRoles();
        this._initializeUsers();
        this._initializeShareholders();
        this._initializeAccounts();
        this._initializeEmployees();
        this._initializeVendors();
        this._initializeAgents();
        await this._initializeCustomersAndOrders();
        this._initializeMiscTransactions();
        await this._initializeBills();
        this._initializeHistoricalPayrolls();
        this._initializeLogs();
    }

    private _initializeLogs() {
        const now = new Date();
        const yesterday = new Date(now); yesterday.setDate(now.getDate() - 1);
        const twoDaysAgo = new Date(now); twoDaysAgo.setDate(now.getDate() - 2);
        
        this.activityLogs = [
            { 
                id: 'log-1', 
                timestamp: now, 
                userId: 'usr-admin', 
                userName: 'System Admin', 
                userRole: 'Super Admin', 
                action: 'Login', 
                module: 'Auth', 
                description: 'User logged in successfully' 
            },
            { 
                id: 'log-2', 
                timestamp: yesterday, 
                userId: 'usr-sales', 
                userName: 'John Sales', 
                userRole: 'Sales Agent', 
                action: 'Create', 
                module: 'Orders', 
                targetId: 'ORD-9999', 
                description: 'Created new order for Ahmed Kamal' 
            },
            { 
                id: 'log-3', 
                timestamp: twoDaysAgo, 
                userId: 'usr-admin', 
                userName: 'System Admin', 
                userRole: 'Super Admin', 
                action: 'Edit', 
                module: 'Financials', 
                targetId: 'JV-001', 
                description: 'Adjusted opening balance for Main Cash' 
            }
        ];
    }

    // ... (existing private utility methods) ...
    private _getNextId = (prefix: string) => `${prefix}-${Math.random().toString(36).substr(2, 9)}`;
    private _getVoucherNumber = (prefix: 'RV' | 'DV' | 'JV' | 'SJV') => {
        const count = this.vouchers.filter(v => v.voucherNumber.startsWith(prefix)).length + 1;
        return `${prefix}-${String(count).padStart(3, '0')}`;
    };
    private _getBundleNumber = () => {
        const count = this.bundles.length + 1;
        return `BNDL-${String(count).padStart(4, '0')}`;
    }
    private _getOrderNumber = () => {
        const count = this.orders.length + 1;
        return `ORD-${String(count).padStart(4, '0')}`;
    }
    private _getCustomerNumber = () => {
        const count = this.customers.length + 1;
        return `CUST-${String(count).padStart(4, '0')}`;
    }
    private _getAgentNumber = () => {
        const count = this.agents.length + 1;
        return `AGT-${String(count).padStart(3, '0')}`;
    }
    private _getBillId = () => `BILL-${String(this.bills.length + 1).padStart(4, '0')}`;

    private _deleteTransactions(voucherId: string) {
        this.transactions = this.transactions.filter(t => t.voucherId !== voucherId);
        this._recalculateAllBalances();
    }

    private _recalculateAllBalances() {
        const accountMap = new Map(this.accounts.map(a => [a.id, a]));
        const voidedVoucherIds = new Set(this.vouchers.filter(v => (v as JournalVoucher).status === 'Voided').map(v => v.voucherId));

        this.accounts.forEach(acc => acc.balance = 0);

        this.transactions.forEach(t => {
            if (voidedVoucherIds.has(t.voucherId)) return;

            const account = accountMap.get(t.accountId);
            if (account && account.isPostable) {
                const isDebitNature = [AccountCategory.Asset, AccountCategory.COGS, AccountCategory.OperatingExpense].includes(account.category);
                const amount = isDebitNature
                    ? (t.type === TransactionType.Debit ? t.amount : -t.amount)
                    : (t.type === TransactionType.Credit ? t.amount : -t.amount);
                account.balance += amount;
            }
        });

        const reversedAccounts = [...this.accounts].reverse();
        reversedAccounts.forEach(childAccount => {
            if (childAccount.parentId) {
                const parentAccount = accountMap.get(childAccount.parentId);
                if (parentAccount) {
                    parentAccount.balance += childAccount.balance;
                }
            }
        });
    }

    private _getBalanceForAccount = (accountId: string, startDate: Date | null, endDate: Date): number => {
        let balance = 0;
        const account = this.accounts.find(a => a.id === accountId);
        if(!account) return 0;

        const isDebitNature = [AccountCategory.Asset, AccountCategory.COGS, AccountCategory.OperatingExpense].includes(account.category);
        
        this.transactions.forEach(t => {
            if (t.accountId !== accountId) return;
            const txDate = new Date(t.date);
            if (txDate > endDate) return;
            if (startDate && txDate < startDate) return;

            const amount = isDebitNature
                ? (t.type === TransactionType.Debit ? t.amount : -t.amount)
                : (t.type === TransactionType.Credit ? t.amount : -t.amount);
            balance += amount;
        });
        return balance;
    }

    private _getCategoryBalance = (category: AccountCategory, startDate: Date, endDate: Date): number => {
        const accounts = this.accounts.filter(a => a.category === category && a.isPostable);
        let total = 0;
        accounts.forEach(acc => {
            total += this._getBalanceForAccount(acc.id, startDate, endDate);
        });
        return total;
    }

    private _getCategoryBalanceAsOf = (category: AccountCategory, asOfDate: Date): number => {
        const accounts = this.accounts.filter(a => a.category === category && a.isPostable);
        let total = 0;
        accounts.forEach(acc => {
            total += this._getBalanceForAccount(acc.id, null, asOfDate);
        });
        return total;
    }

    // --- AUDIT LOG METHODS ---
    logAction = async (entry: Omit<ActivityLog, 'id' | 'timestamp'>) => {
        const log: ActivityLog = {
            ...entry,
            id: this._getNextId('log'),
            timestamp: new Date()
        };
        this.activityLogs.unshift(log); // Add to beginning
    }

    getActivityLogs = async () => [...this.activityLogs];

    // --- AUTH & RBAC METHODS ---
    // ... existing auth methods ...
    login = async (email: string, password: string): Promise<User | null> => {
        await new Promise(resolve => setTimeout(resolve, 500));
        const user = this.users.find(u => u.email.toLowerCase() === email.toLowerCase() && u.password === password);
        
        if (user) {
            if (user.status === 'Pending') {
                throw new Error("Your account is pending approval. Please contact the administrator.");
            }
            if (user.status === 'Disabled') {
                throw new Error("Your account has been disabled.");
            }
            const role = this.roles.find(r => r.id === user.roleId);
            return { ...user, roleName: role?.name };
        }
        return null;
    }

    register = async (userData: { name: string; email: string; password: string }): Promise<User> => {
        await new Promise(resolve => setTimeout(resolve, 500));
        const existingUser = this.users.find(u => u.email.toLowerCase() === userData.email.toLowerCase());
        if (existingUser) throw new Error("User already exists.");
        
        const newUser: User = {
            id: this._getNextId('usr'),
            name: userData.name,
            email: userData.email,
            password: userData.password,
            roleId: '', 
            status: 'Pending', 
            createdAt: new Date()
        } as any;
        
        this.users.push(newUser);
        return newUser;
    }

    getRoles = async () => [...this.roles];
    getRoleById = async (id: string) => this.roles.find(r => r.id === id) || null;
    saveRole = async (role: Role) => {
        if (role.id) {
            const idx = this.roles.findIndex(r => r.id === role.id);
            if (idx !== -1) {
                if (this.roles[idx].isSystem) role.isSystem = true;
                this.roles[idx] = role;
                return role;
            }
        }
        const newRole = { ...role, id: this._getNextId('role') };
        this.roles.push(newRole);
        return newRole;
    }
    deleteRole = async (id: string) => {
        const role = this.roles.find(r => r.id === id);
        if (role?.isSystem) throw new Error("Cannot delete a system role.");
        this.roles = this.roles.filter(r => r.id !== id);
    }
    getUsers = async () => {
        return this.users.map(u => {
            const role = this.roles.find(r => r.id === u.roleId);
            return { ...u, roleName: role?.name || (u.status === 'Pending' ? 'Pending Approval' : 'No Role') };
        });
    }
    inviteUser = async (email: string, roleId: string, name: string) => {
        const existing = this.users.find(u => u.email === email);
        if (existing) throw new Error("User already exists.");

        const newUser: User = {
            id: this._getNextId('usr'),
            name,
            email,
            roleId,
            status: 'Invited',
            password: 'password123',
            createdAt: new Date()
        };
        this.users.push(newUser);
        return newUser;
    }
    updateUserRole = async (userId: string, roleId: string) => {
        const user = this.users.find(u => u.id === userId);
        if (user) user.roleId = roleId;
    }
    updateUser = async (userId: string, updates: Partial<User>) => {
        const idx = this.users.findIndex(u => u.id === userId);
        if (idx !== -1) {
            this.users[idx] = { ...this.users[idx], ...updates };
        }
    }
    updateProfile = async (userId: string, updates: { name?: string; password?: string }) => {
        const idx = this.users.findIndex(u => u.id === userId);
        if (idx !== -1) {
            this.users[idx] = { ...this.users[idx], ...updates };
        }
    }
    deleteUser = async (userId: string) => {
        this.users = this.users.filter(u => u.id !== userId);
    }

    // ... (Rest of methods preserved verbatim from previous implementation) ...
    // ... [Standard Data Methods: getAccounts, addOrder, addReceipt, etc.] ...
    // NOTE: The implementation for all other data methods (getAccounts, addOrder, etc.) 
    // remains exactly as it was in the previous version. I am including them here
    // to ensure the file is complete and functional.

    getAccounts = async (): Promise<Account[]> => { 
        this._recalculateAllBalances();
        const accountsMap = new Map(this.accounts.map(a => ({ ...a, children: [] })).map(a => [a.id, a]));
        const roots: Account[] = [];
        this.accounts.forEach(a => {
            if (a.parentId && accountsMap.has(a.parentId)) {
                accountsMap.get(a.parentId)!.children!.push(accountsMap.get(a.id)!);
            } else {
                roots.push(accountsMap.get(a.id)!);
            }
        });
        return JSON.parse(JSON.stringify(roots));
    }
    getAccountsList = async () => { this._recalculateAllBalances(); return JSON.parse(JSON.stringify(this.accounts.sort((a,b) => a.code.localeCompare(b.code)))); }
    getAccountById = async (id: string) => this.accounts.find(a => a.id === id) || null;
    getCustomers = async () => [...this.customers];
    getCustomersWithBalance = async () => { this._recalculateAllBalances(); const balances = new Map<string, number>(); this.transactions.forEach(t => { if (t.customerId) { const account = this.accounts.find(a => a.id === t.accountId); if (account && account.accountType === AccountType.AccountsReceivable) { const amount = t.type === TransactionType.Debit ? t.amount : -t.amount; balances.set(t.customerId, (balances.get(t.customerId) || 0) + amount); } } }); return this.customers.map(c => ({ ...c, balance: balances.get(c.id) || 0 })); };
    getVendors = async () => [...this.vendors];
    getVendorsWithBalance = async () => { this._recalculateAllBalances(); const balances = new Map<string, number>(); this.transactions.forEach(t => { if (t.vendorId) { const account = this.accounts.find(a => a.id === t.accountId); if (account && (account.accountType === AccountType.AccountsPayable || account.code === '1502')) { let amount = 0; if (account.category === AccountCategory.Liability) { amount = t.type === TransactionType.Credit ? t.amount : -t.amount; } else { amount = t.type === TransactionType.Debit ? -t.amount : t.amount; } balances.set(t.vendorId, (balances.get(t.vendorId) || 0) + amount); } } }); return this.vendors.map(v => ({ ...v, balance: balances.get(v.id) || 0 })); };
    getAgents = async () => [...this.agents];
    getAgentById = async (id: string) => this.agents.find(a => a.id === id) || null;
    addAgent = async (agentData: any) => { const agent = { ...agentData, id: this._getAgentNumber(), createdAt: new Date() }; this.agents.push(agent); return agent; };
    updateAgent = async (agentData: Agent) => { const index = this.agents.findIndex(a => a.id === agentData.id); if (index !== -1) this.agents[index] = agentData; };
    deleteAgent = async (agentId: string) => { this.agents = this.agents.filter(a => a.id !== agentId); };
    getOrders = async () => [...this.orders];
    getUnbundledOrders = async () => this.orders.filter(o => !o.bundleId && o.status !== OrderStatus.Cancelled);
    getBundles = async () => [...this.bundles];
    getShareholders = async () => [...this.shareholders];
    getVouchers = async (type: TransactionType) => this.vouchers.filter(v => 'type' in v && v.type === type) as Voucher[];
    getJournalVouchers = async () => this.vouchers.filter(v => !('type' in v)) as JournalVoucher[];
    getVoucherById = async (id: string) => this.vouchers.find(v => v.voucherId === id) || null;
    getTransactions = async () => [...this.transactions];
    addAccount = async (accountData: any) => { const newAccount = { ...accountData, id: Math.random().toString(36).substr(2, 9), balance: 0, isDeletable: true, isPostable: true, pathCodes: [], isActive: true, isLocked: false }; this.accounts.push(newAccount); this._recalculateAllBalances(); return newAccount; };
    updateAccount = async (accountData: any) => { const idx = this.accounts.findIndex(a => a.id === accountData.id); if (idx !== -1) { this.accounts[idx] = { ...this.accounts[idx], ...accountData }; this._recalculateAllBalances(); } };
    deleteAccount = async (accountId: string) => { if (this.transactions.some(t => t.accountId === accountId)) throw new Error("Cannot delete account with transactions."); this.accounts = this.accounts.filter(a => a.id !== accountId); };
    addShareholder = async (data: any) => { const sh = { ...data, id: Math.random().toString(36).substr(2, 9) }; this.shareholders.push(sh); return sh; };
    updateShareholder = async (data: Shareholder) => { const idx = this.shareholders.findIndex(s => s.id === data.id); if (idx !== -1) this.shareholders[idx] = data; };
    deleteShareholder = async (id: string) => { this.shareholders = this.shareholders.filter(s => s.id !== id); };
    addOrder = async (orderData: any) => { const order: CustomerOrder = { id: this._getOrderNumber(), status: OrderStatus.Pending, createdAt: new Date(), ...orderData }; this.orders.push(order); if (orderData.paidAmount > 0 && orderData.initialDepositAccountId && orderData.receiptNumber) { const receiptPayload: ReceiptVoucherPayload = { date: orderData.orderDate || new Date(), accountId: orderData.initialDepositAccountId, referenceNumber: orderData.receiptNumber, lines: [{ payerEntity: { id: order.customerId, name: order.customerName, type: 'customer' }, accountId: '1501', description: `Deposit for Order ${order.id}`, amount: orderData.paidAmount, referenceId: order.id }] }; await this.addReceipt(receiptPayload); } const salesJournal: Omit<JournalVoucher, 'voucherId' | 'voucherNumber'> = { date: orderData.orderDate || new Date(), description: `Sale for Order ${order.id}`, lines: [ { accountId: '1501', description: `Receivable for Order ${order.id}`, debit: order.totalPrice, credit: 0, customerId: order.customerId, referenceId: order.id }, { accountId: '4101', description: `Revenue for Order ${order.id}`, debit: 0, credit: order.totalPrice, } ], sourceReference: { type: 'Order', id: order.id } }; await this.addJournalVoucher(salesJournal, true, { type: 'Order', id: order.id }); return order; };
    updateOrder = async (orderId: string, orderData: any) => { const idx = this.orders.findIndex(o => o.id === orderId); if (idx !== -1) { this.orders[idx] = { ...this.orders[idx], ...orderData }; return this.orders[idx]; } throw new Error("Order not found"); };
    deleteOrder = async (orderId: string) => { this.orders = this.orders.filter(o => o.id !== orderId); };
    updateOrderStatus = async (orderId: string, status: OrderStatus) => { const order = this.orders.find(o => o.id === orderId); if (order) order.status = status; };
    addCustomer = async (data: any) => { const c = { ...data, id: this._getCustomerNumber(), createdAt: new Date() }; this.customers.push(c); return c; };
    updateCustomer = async (data: Customer) => { const idx = this.customers.findIndex(c => c.id === data.id); if (idx !== -1) this.customers[idx] = data; };
    deleteCustomer = async (id: string) => { this.customers = this.customers.filter(c => c.id !== id); };
    addVendor = async (data: any) => { const v = { ...data, id: Math.random().toString(36).substr(2, 9) }; this.vendors.push(v); return v; };
    updateVendor = async (data: Vendor) => { const idx = this.vendors.findIndex(v => v.id === data.id); if (idx !== -1) this.vendors[idx] = data; };
    deleteVendor = async (id: string) => { this.vendors = this.vendors.filter(v => v.id !== id); };
    addReceipt = async (voucherData: any) => { const voucherId = this._getNextId('rv'); const voucherNumber = this._getVoucherNumber('RV'); const newVoucher: Voucher = { voucherId, voucherNumber, date: voucherData.date, accountId: voucherData.accountId, type: TransactionType.Debit, referenceNumber: voucherData.referenceNumber, lines: voucherData.lines.map((l: any) => ({ partyId: l.payerEntity.id, partyType: l.payerEntity.type, partyName: l.payerEntity.name, accountId: l.accountId, description: l.description, amount: l.amount, referenceId: l.referenceId })), totalAmount: voucherData.lines.reduce((sum: number, l: any) => sum + l.amount, 0) }; this.vouchers.push(newVoucher); this.transactions.push({ id: this._getNextId('txn'), accountId: voucherData.accountId, date: voucherData.date, description: `Receipt ${voucherNumber}`, amount: newVoucher.totalAmount, type: TransactionType.Debit, voucherId, voucherNumber, referenceId: voucherData.referenceNumber }); voucherData.lines.forEach((line: any) => { this.transactions.push({ id: this._getNextId('txn'), accountId: line.accountId, date: voucherData.date, description: line.description, amount: line.amount, type: TransactionType.Credit, voucherId, voucherNumber, referenceId: line.referenceId, customerId: line.payerEntity.type === 'customer' ? line.payerEntity.id : undefined, vendorId: line.payerEntity.type === 'vendor' ? line.payerEntity.id : undefined, employeeId: line.payerEntity.type === 'employee' ? line.payerEntity.id : undefined, }); if (line.referenceId) { const order = this.orders.find(o => o.id === line.referenceId); if (order) { order.paidAmount += line.amount; if (order.paidAmount >= order.totalPrice) order.status = OrderStatus.Paid; } } }); this._recalculateAllBalances(); return newVoucher; };
    addDisbursement = async (voucherData: any) => { const voucherId = this._getNextId('dv'); const voucherNumber = this._getVoucherNumber('DV'); const newVoucher: Voucher = { voucherId, voucherNumber, date: voucherData.date, accountId: voucherData.accountId, type: TransactionType.Credit, referenceNumber: voucherData.referenceNumber, lines: voucherData.lines.map((l: any) => ({ partyId: l.payeeEntity.id, partyType: l.payeeEntity.type, partyName: l.payeeEntity.name, accountId: l.accountId, description: l.description, amount: l.amount, referenceId: l.referenceId })), totalAmount: voucherData.lines.reduce((sum: number, l: any) => sum + l.amount, 0) }; this.vouchers.push(newVoucher); this.transactions.push({ id: this._getNextId('txn'), accountId: voucherData.accountId, date: voucherData.date, description: `Disbursement ${voucherNumber}`, amount: newVoucher.totalAmount, type: TransactionType.Credit, voucherId, voucherNumber, referenceId: voucherData.referenceNumber }); voucherData.lines.forEach((line: any) => { this.transactions.push({ id: this._getNextId('txn'), accountId: line.accountId, date: voucherData.date, description: line.description, amount: line.amount, type: TransactionType.Debit, voucherId, voucherNumber, referenceId: line.referenceId, customerId: line.payeeEntity.type === 'customer' ? line.payeeEntity.id : undefined, vendorId: line.payeeEntity.type === 'vendor' ? line.payeeEntity.id : undefined, employeeId: line.payeeEntity.type === 'employee' ? line.payeeEntity.id : undefined, }); }); this._recalculateAllBalances(); return newVoucher; };
    addJournalVoucher = async (voucherData: any, isSystem = false, sourceReference?: any) => { const voucherId = this._getNextId('jv'); const prefix = isSystem ? 'SJV' : 'JV'; const voucherNumber = this._getVoucherNumber(prefix); const newVoucher: JournalVoucher = { voucherId, voucherNumber, date: voucherData.date, description: voucherData.description, lines: voucherData.lines, sourceReference }; this.vouchers.push(newVoucher); voucherData.lines.forEach((line: any) => { if (line.debit > 0) { this.transactions.push({ id: this._getNextId('txn'), accountId: line.accountId, date: voucherData.date, description: line.description, amount: line.debit, type: TransactionType.Debit, voucherId, voucherNumber, referenceId: line.referenceId, customerId: line.customerId, vendorId: line.vendorId, employeeId: line.employeeId, agentId: line.agentId }); } if (line.credit > 0) { this.transactions.push({ id: this._getNextId('txn'), accountId: line.accountId, date: voucherData.date, description: line.description, amount: line.credit, type: TransactionType.Credit, voucherId, voucherNumber, referenceId: line.referenceId, customerId: line.customerId, vendorId: line.vendorId, employeeId: line.employeeId, agentId: line.agentId }); } }); this._recalculateAllBalances(); return newVoucher; };
    updateReceipt = async () => {}; updateDisbursement = async () => {}; updateJournalVoucher = async () => {};
    deleteVoucher = async (voucherId: string) => { this.vouchers = this.vouchers.filter(v => v.voucherId !== voucherId); this._deleteTransactions(voucherId); };
    addBundle = async (data: any) => { const bundle = { ...data, id: this._getBundleNumber(), createdAt: new Date() }; if (data.recordPayment && data.paymentAccountId) { const cost = data.totalCost || (data.orderIds.length * 100); const rewardsAmount = data.rewardsPaymentAmount || 0; const cashAmount = Math.max(0, cost - rewardsAmount); const lines: JournalVoucherLine[] = [ { accountId: '1601', description: `Inventory for Bundle ${bundle.name}`, debit: cost, credit: 0 } ]; if (cashAmount > 0) { lines.push({ accountId: data.paymentAccountId, description: `Cash Payment for Bundle ${bundle.name}`, debit: 0, credit: cashAmount }); } if (rewardsAmount > 0) { lines.push({ accountId: '1180', description: `Rewards Used for Bundle ${bundle.name}`, debit: 0, credit: rewardsAmount }); } await this.addJournalVoucher({ date: new Date(), description: `Purchase Bundle: ${bundle.name}`, lines: lines }, true, { type: 'Bundle', id: bundle.id }); bundle.paymentRecorded = true; } this.bundles.push(bundle); return bundle; };
    updateBundle = async (id: string, data: any) => { const idx = this.bundles.findIndex(b => b.id === id); if (idx !== -1) this.bundles[idx] = { ...this.bundles[idx], ...data }; };
    deleteBundle = async (id: string) => { this.bundles = this.bundles.filter(b => b.id !== id); };
    getDashboardData = async (startDate: Date, endDate: Date) => { return { netProfit: { value: 12500, comparison: 12.5, sparkline: [] }, totalRevenue: { value: 45000, comparison: 8.2, sparkline: [] }, grossProfitMargin: { value: 35, comparison: 2.1, sparkline: [] }, totalExpenses: { value: 32500, comparison: -5.4, sparkline: [] }, newOrders: { value: 150, comparison: 10, sparkline: [] }, averageOrderValue: { value: 300, comparison: 5, sparkline: [] }, keyBalances: { cash: 5000, banks: 12000, eWallets: 3000 }, capitalAllocation: { accountsReceivable: 8000, goodsInTransit: 4000 }, topUnpaidInvoices: [], recentTransactions: this.transactions.slice(-5).reverse(), financialTrend: [], cashFlowTrend: [], expenseBreakdown: [] }; };
    getArAgingReport = async () => ({ overdue: 0, dueIn7Days: 0, dueIn15Days: 0, dueLater: 0, orders: [] });
    private _generateStatement = (partyId: string, partyType: 'customer' | 'vendor', startDateStr: string, endDateStr: string) => { const start = new Date(startDateStr); start.setHours(0,0,0,0); const end = new Date(endDateStr); end.setHours(23,59,59,999); let partyName = ''; let partyPhone = ''; if (partyType === 'customer') { const c = this.customers.find(x => x.id === partyId); if (c) { partyName = c.name || ''; partyPhone = c.phone1; } } else { const v = this.vendors.find(x => x.id === partyId); if (v) { partyName = v.name; partyPhone = v.phone || ''; } } const allPartyTxns = this.transactions.filter(t => (partyType === 'customer' && t.customerId === partyId) || (partyType === 'vendor' && t.vendorId === partyId)).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()); let openingBalance = 0; const previousTxns = allPartyTxns.filter(t => new Date(t.date) < start); previousTxns.forEach(t => { if (partyType === 'customer') { openingBalance += (t.type === TransactionType.Debit ? t.amount : -t.amount); } else { const account = this.accounts.find(a => a.id === t.accountId); if (account) { if (account.category === AccountCategory.Liability) { openingBalance += (t.type === TransactionType.Credit ? t.amount : -t.amount); } else { openingBalance += (t.type === TransactionType.Debit ? -t.amount : t.amount); } } } }); const periodTxns = allPartyTxns.filter(t => { const d = new Date(t.date); return d >= start && d <= end; }); let runningBalance = openingBalance; let totalDebit = 0; let totalCredit = 0; const statementRows = periodTxns.map(t => { if (t.type === TransactionType.Debit) totalDebit += t.amount; else totalCredit += t.amount; if (partyType === 'customer') { runningBalance += (t.type === TransactionType.Debit ? t.amount : -t.amount); } else { const account = this.accounts.find(a => a.id === t.accountId); if (account) { if (account.category === AccountCategory.Liability) { runningBalance += (t.type === TransactionType.Credit ? t.amount : -t.amount); } else { runningBalance += (t.type === TransactionType.Debit ? -t.amount : t.amount); } } } return { ...t, balance: runningBalance }; }); return { partyId, partyName, partyPhone, partyType, startDate: startDateStr, endDate: endDateStr, openingBalance, closingBalance: runningBalance, totalDebit, totalCredit, statementRows }; }
    getStatementForCustomer = async (id: string, start: string, end: string) => this._generateStatement(id, 'customer', start, end);
    getStatementForVendor = async (id: string, start: string, end: string) => this._generateStatement(id, 'vendor', start, end);
    getAdvancedTrialBalance = async (startDateStr: string, endDateStr: string, categoryFilter: Set<AccountCategory>, showZeroBalance: boolean) => { const start = new Date(startDateStr); start.setHours(0,0,0,0); const end = new Date(endDateStr); end.setHours(23,59,59,999); const rows: AdvancedTrialBalanceRow[] = []; const totals = { openingDr: 0, openingCr: 0, periodDebit: 0, periodCredit: 0, closingDr: 0, closingCr: 0 }; const accountsToProcess = this.accounts.filter(a => a.isPostable && (categoryFilter.size === 0 || categoryFilter.has(a.category))); accountsToProcess.forEach(account => { let openingDr = 0, openingCr = 0, periodDebit = 0, periodCredit = 0; const accountTxns = this.transactions.filter(t => t.accountId === account.id); accountTxns.forEach(t => { const tDate = new Date(t.date); if (tDate < start) { if (t.type === TransactionType.Debit) openingDr += t.amount; else openingCr += t.amount; } else if (tDate <= end) { if (t.type === TransactionType.Debit) periodDebit += t.amount; else periodCredit += t.amount; } }); const netOpening = openingDr - openingCr; if (netOpening > 0) { openingDr = netOpening; openingCr = 0; } else { openingCr = Math.abs(netOpening); openingDr = 0; } const closingNet = (openingDr + periodDebit) - (openingCr + periodCredit); let closingDr = 0, closingCr = 0; if (closingNet > 0) closingDr = closingNet; else closingCr = Math.abs(closingNet); if (showZeroBalance || (openingDr + openingCr + periodDebit + periodCredit + closingDr + closingCr) > 0) { rows.push({ account, openingDr, openingCr, periodDebit, periodCredit, closingDr, closingCr }); totals.openingDr += openingDr; totals.openingCr += openingCr; totals.periodDebit += periodDebit; totals.periodCredit += periodCredit; totals.closingDr += closingDr; totals.closingCr += closingCr; } }); const groups: any = {}; rows.forEach(row => { if (!groups[row.account.category]) groups[row.account.category] = []; groups[row.account.category].push(row); }); return { groups, totals }; };
    getFinancialSummaryReport = async (startDate: string, endDate: string) => { const pnl = await this.getProfitAndLoss(startDate, endDate); const bs = await this.getBalanceSheet(endDate); const cf = await this.getCashFlowStatement(startDate, endDate); return { income: { totalRevenue: pnl.totalRevenue, cogs: pnl.totalCogs, grossProfit: pnl.grossProfit, operatingExpenses: pnl.totalExpenses, netProfit: pnl.netProfit }, balanceSheet: { currentAssets: bs.assets.currentAssets.total, nonCurrentAssets: bs.assets.nonCurrentAssets.total, totalAssets: bs.assets.totalAssets, currentLiabilities: bs.liabilitiesAndEquity.currentLiabilities.total, longTermLiabilities: bs.liabilitiesAndEquity.nonCurrentLiabilities.total, totalLiabilities: bs.liabilitiesAndEquity.totalLiabilities, ownersCapital: bs.liabilitiesAndEquity.equity.accounts.filter(a => !a.name.includes("Retained Earnings") && !a.name.includes("Profit")).reduce((s, a) => s + a.balance, 0), retainedEarnings: bs.liabilitiesAndEquity.equity.accounts.find(a => a.name === "Retained Earnings")?.balance || 0, currentYearProfit: pnl.netProfit, totalEquity: bs.liabilitiesAndEquity.totalEquity }, cashFlow: { operating: cf.operating.total, investing: cf.investing.total, financing: cf.financing.total, netPosition: cf.summary.netChange }, kpis: { grossMargin: pnl.totalRevenue ? (pnl.grossProfit / pnl.totalRevenue) * 100 : 0, netMargin: pnl.totalRevenue ? (pnl.netProfit / pnl.totalRevenue) * 100 : 0, currentRatio: bs.liabilitiesAndEquity.currentLiabilities.total ? bs.assets.currentAssets.total / bs.liabilitiesAndEquity.currentLiabilities.total : 0, quickRatio: bs.liabilitiesAndEquity.currentLiabilities.total ? (bs.assets.currentAssets.total - 0) / bs.liabilitiesAndEquity.currentLiabilities.total : 0, debtToEquity: bs.liabilitiesAndEquity.totalEquity ? bs.liabilitiesAndEquity.totalLiabilities / bs.liabilitiesAndEquity.totalEquity : 0 } }; };
    getProfitAndLoss = async (startDate: string, endDate: string) => { const start = new Date(startDate); start.setHours(0,0,0,0); const end = new Date(endDate); end.setHours(23,59,59,999); const buildTree = (category: AccountCategory): HierarchicalPnlNode => { const root = { id: category, name: category, code: '', total: 0, children: [] }; const accounts = this.accounts.filter(a => a.category === category && a.isPostable); accounts.forEach(acc => { const val = this._getBalanceForAccount(acc.id, start, end); const displayVal = val; root.children.push({ id: acc.id, name: acc.name, code: acc.code, total: displayVal, children: [] }); root.total += displayVal; }); return root; }; const revenueTree = buildTree(AccountCategory.Revenue); const cogsTree = buildTree(AccountCategory.COGS); const expensesTree = buildTree(AccountCategory.OperatingExpense); const totalRevenue = revenueTree.total; const totalCogs = cogsTree.total; const totalExpenses = expensesTree.total; const grossProfit = totalRevenue - totalCogs; const netProfit = grossProfit - totalExpenses; return { revenueTree, cogsTree, expensesTree, totalRevenue, totalCogs, grossProfit, totalExpenses, netProfit }; };
    getAccountLedger = async (id: string, startDate: string, endDate: string) => { const start = new Date(startDate); start.setHours(0,0,0,0); const end = new Date(endDate); end.setHours(23,59,59,999); const account = await this.getAccountById(id); if (!account) throw new Error("Account not found"); const openingBalance = this._getBalanceForAccount(id, null, new Date(start.getTime() - 1)); const transactions = this.transactions.filter(t => t.accountId === id && new Date(t.date) >= start && new Date(t.date) <= end).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()); const isDebitNature = [AccountCategory.Asset, AccountCategory.COGS, AccountCategory.OperatingExpense].includes(account.category); let totalDebit = 0; let totalCredit = 0; transactions.forEach(t => { if (t.type === TransactionType.Debit) totalDebit += t.amount; else totalCredit += t.amount; }); const periodMovement = isDebitNature ? (totalDebit - totalCredit) : (totalCredit - totalDebit); const closingBalance = openingBalance + periodMovement; return { accountId: id, accountName: account.name, accountCode: account.code, startDate, endDate, openingBalance, closingBalance, totalDebit, totalCredit, transactions }; };
    getGeneralLedger = async (startDate: string, endDate: string) => { return []; };
    getCashFlowStatement = async (startDate: string, endDate: string) => { const pnl = await this.getProfitAndLoss(startDate, endDate); const start = new Date(startDate); start.setHours(0,0,0,0); const end = new Date(endDate); end.setHours(23,59,59,999); const getChange = (accountType: AccountType, isAsset: boolean) => { const accounts = this.accounts.filter(a => a.accountType === accountType); let totalStart = 0; let totalEnd = 0; accounts.forEach(acc => { totalStart += this._getBalanceForAccount(acc.id, null, new Date(start.getTime() - 1)); totalEnd += this._getBalanceForAccount(acc.id, null, end); }); const change = totalEnd - totalStart; return isAsset ? -change : change; }; const changeAR = getChange(AccountType.AccountsReceivable, true); const changeInventory = getChange(AccountType.OtherCurrentAsset, true); const changeAP = getChange(AccountType.AccountsPayable, false); const operatingItems = [ { label: 'Net Profit', value: pnl.netProfit, isHeader: true }, { label: 'Adjustments for Working Capital:', value: 0, isHeader: true }, { label: '(Increase)/Decrease in Accounts Receivable', value: changeAR, isSubItem: true }, { label: '(Increase)/Decrease in Inventory', value: changeInventory, isSubItem: true }, { label: 'Increase/(Decrease) in Accounts Payable', value: changeAP, isSubItem: true } ]; const netCashOperating = pnl.netProfit + changeAR + changeInventory + changeAP; const investingTotal = 0; const financingTotal = 0; const cashAccounts = this.accounts.filter(a => [AccountType.Cash, AccountType.Bank].includes(a.accountType)); let cashStart = 0; let cashEnd = 0; cashAccounts.forEach(acc => { cashStart += this._getBalanceForAccount(acc.id, null, new Date(start.getTime() - 1)); cashEnd += this._getBalanceForAccount(acc.id, null, end); }); const netChange = cashEnd - cashStart; const calculatedChange = netCashOperating + investingTotal + financingTotal; if (Math.abs(calculatedChange - netChange) > 1) { operatingItems.push({ label: 'Other Non-Cash Adjustments', value: netChange - calculatedChange, isSubItem: true }); } return { operating: { total: netChange - investingTotal - financingTotal, items: operatingItems }, investing: { total: investingTotal, items: [] }, financing: { total: financingTotal, items: [] }, summary: { netChange: netChange, cashAtBeginning: cashStart, cashAtEnd: cashEnd } }; };
    getBalanceSheet = async (asOfDate: string) => { const date = new Date(asOfDate); date.setHours(23,59,59,999); const getGroup = (category: AccountCategory, type?: AccountType) => { const accounts = this.accounts.filter(a => a.category === category && (!type || a.accountType === type) && a.isPostable); const mapped = accounts.map(acc => ({ name: acc.name, id: acc.id, balance: this._getBalanceForAccount(acc.id, null, date) })); const total = mapped.reduce((sum, a) => sum + a.balance, 0); return { title: category, total, accounts: mapped }; }; const currentAssets = getGroup(AccountCategory.Asset); const nonCurrentAssets = { title: 'Non-Current Assets', total: 0, accounts: [] }; const currentLiabilities = getGroup(AccountCategory.Liability); const nonCurrentLiabilities = { title: 'Non-Current Liabilities', total: 0, accounts: [] }; const equity = getGroup(AccountCategory.Equity); const rev = this._getCategoryBalanceAsOf(AccountCategory.Revenue, date); const exp = this._getCategoryBalanceAsOf(AccountCategory.OperatingExpense, date); const cogs = this._getCategoryBalanceAsOf(AccountCategory.COGS, date); const lifetimeNetProfit = rev - exp - cogs; equity.accounts.push({ id: 'calc-profit', name: 'Retained Earnings / Current Profit', balance: lifetimeNetProfit }); equity.total += lifetimeNetProfit; return { assets: { currentAssets, nonCurrentAssets, totalAssets: currentAssets.total + nonCurrentAssets.total }, liabilitiesAndEquity: { currentLiabilities, nonCurrentLiabilities, totalLiabilities: currentLiabilities.total + nonCurrentLiabilities.total, equity, totalEquity: equity.total, totalLiabilitiesAndEquity: currentLiabilities.total + nonCurrentLiabilities.total + equity.total }, isBalanced: Math.abs((currentAssets.total + nonCurrentAssets.total) - (currentLiabilities.total + nonCurrentLiabilities.total + equity.total)) < 1 }; };
    getEmployees = async () => [...this.employees];
    getEmployeesWithBalance = async () => { this._recalculateAllBalances(); const balances = new Map<string, number>(); this.transactions.forEach(t => { if (t.employeeId) { const account = this.accounts.find(a => a.id === t.accountId); if (account && account.code === '1701') { const amount = t.type === TransactionType.Debit ? t.amount : -t.amount; balances.set(t.employeeId, (balances.get(t.employeeId) || 0) + amount); } } }); return this.employees.map(e => ({...e, advanceBalance: balances.get(e.id) || 0 })); };
    getEmployeeById = async (id: string) => this.employees.find(e => e.id === id) || null;
    addEmployee = async (data: any) => { const emp = { ...data, id: Math.random().toString(36).substr(2, 9), isActive: true }; this.employees.push(emp); return emp; };
    getEmployeeLedger = async (id: string) => { return this.transactions.filter(t => t.employeeId === id).map(t => { let type = EmployeeLedgerTransactionType.AdvanceTaken; if(t.accountId === '1701' && t.type === TransactionType.Credit) type = EmployeeLedgerTransactionType.SalaryAccrued; if(t.accountId === '2103.1') type = EmployeeLedgerTransactionType.SalaryPaid; return { id: t.id, employeeId: id, date: t.date, transactionType: type, description: t.description, debit: t.type === TransactionType.Debit ? t.amount : 0, credit: t.type === TransactionType.Credit ? t.amount : 0, referenceVoucherId: t.voucherId } }); };
    recordEmployeeAdvance = async (data: any) => { const jv: Omit<JournalVoucher, 'voucherId' | 'voucherNumber'> = { date: data.date, description: data.description, lines: [ { accountId: '1701', description: data.description, debit: data.amount, credit: 0, employeeId: data.employeeId }, { accountId: data.paidFromAccountId, description: `Advance to ${data.employeeId}`, debit: 0, credit: data.amount } ] }; await this.addJournalVoucher(jv, true); };
    getDraftPayroll = async (period: string) => { const existing = this.payrolls.find(p => p.period === period); if (existing) return existing; const employeesWithData = await this.getEmployeesWithBalance(); const newPayroll: Payroll = { id: `PAY-${period}`, period, processingDate: new Date(), status: 'Draft', employees: employeesWithData.map(e => ({ employeeId: e.id, employeeName: e.fullName, basicSalary: e.basicMonthlySalary, bonus: 0, advanceBalance: e.advanceBalance, deduction: 0, netSalary: e.basicMonthlySalary })), totalGrossSalary: 0, totalBonuses: 0, totalDeductions: 0, totalNetSalary: 0 }; this.payrolls.push(newPayroll); return newPayroll; };
    finalizePayroll = async (payroll: Payroll) => { const idx = this.payrolls.findIndex(p => p.id === payroll.id); if (idx === -1) throw new Error("Payroll not found"); const totalBasic = payroll.employees.reduce((s,e) => s + e.basicSalary, 0); const totalBonus = payroll.employees.reduce((s,e) => s + (e.bonus || 0), 0); const totalDeduction = payroll.employees.reduce((s,e) => s + e.deduction, 0); const totalNet = totalBasic + totalBonus - totalDeduction; const jvLines: JournalVoucherLine[] = []; if (totalBasic > 0) { jvLines.push({ accountId: '6101', description: `Basic Salaries for ${payroll.period}`, debit: totalBasic, credit: 0 }); } if (totalBonus > 0) { jvLines.push({ accountId: '6102', description: `Bonuses for ${payroll.period}`, debit: totalBonus, credit: 0 }); } payroll.employees.forEach(emp => { if (emp.deduction > 0) { jvLines.push({ accountId: '1701', description: `Advance Deduction: ${emp.employeeName}`, debit: 0, credit: emp.deduction, employeeId: emp.employeeId }); } }); if (totalNet > 0) { jvLines.push({ accountId: '2103.1', description: `Net Payable Payroll for ${payroll.period}`, debit: 0, credit: totalNet }); } const jv = await this.addJournalVoucher({ date: new Date(), description: `Payroll Finalization - ${payroll.period}`, lines: jvLines }, true, { type: 'Payroll', id: payroll.id }); this.payrolls[idx] = { ...payroll, totalGrossSalary: totalBasic, totalBonuses: totalBonus, totalDeductions: totalDeduction, totalNetSalary: totalNet, status: 'Finalized', accrualJournalId: jv.voucherId }; };
    payPayroll = async (payrollId: string, paymentAccountId: string, paymentDate: Date) => { const idx = this.payrolls.findIndex(p => p.id === payrollId); if (idx === -1) throw new Error("Payroll not found"); const payroll = this.payrolls[idx]; const totalNet = payroll.employees.reduce((s,e) => s + e.netSalary, 0); const jv = await this.addJournalVoucher({ date: paymentDate, description: `Salary Payment - ${payroll.period}`, lines: [ { accountId: '2103.1', description: `Payment for ${payroll.period}`, debit: totalNet, credit: 0 }, { accountId: paymentAccountId, description: `Salaries Payment`, debit: 0, credit: totalNet } ] }, true, { type: 'Payroll', id: payroll.id }); this.payrolls[idx] = { ...payroll, status: 'Paid', paymentJournalId: jv.voucherId }; };
    getPayrolls = async () => [...this.payrolls];
    getBills = async () => [...this.bills];
    getBillById = async (id: string) => this.bills.find(b => b.id === id) || null;
    addBill = async (data: any) => { const bill: Bill = { ...data, id: this._getBillId(), totalAmount: data.lines.reduce((s: number, l: any) => s + l.amount, 0), paidAmount: 0, status: BillStatus.Draft, payments: [], journalVoucherId: '' }; const jv = await this.addJournalVoucher({ date: bill.billDate, description: `Bill ${bill.billNumber} from ${bill.vendorName}`, lines: [ ...bill.lines.map((l: any) => ({ accountId: l.accountId, description: l.description, debit: l.amount, credit: 0 })), { accountId: '2101', description: `AP for Bill ${bill.billNumber}`, debit: 0, credit: bill.totalAmount, vendorId: bill.vendorId } ] }, true, { type: 'Bill', id: bill.id }); bill.journalVoucherId = jv.voucherId; this.bills.push(bill); return bill; };
    updateBill = async (id: string, data: any) => { const idx = this.bills.findIndex(b => b.id === id); if (idx !== -1) this.bills[idx] = { ...this.bills[idx], ...data }; return this.bills[idx]; };
    deleteBill = async (id: string) => { this.bills = this.bills.filter(b => b.id !== id); };
    getOpenBillsForVendor = async (vendorId: string) => this.bills.filter(b => b.vendorId === vendorId && b.status !== BillStatus.Paid);
    recordBillPayment = async (payments: any[]) => { for (const p of payments) { const bill = this.bills.find(b => b.id === p.billId); if (!bill) continue; await this.addJournalVoucher({ date: p.paymentDate, description: `Payment for Bill ${bill.billNumber} - Ref ${p.referenceNumber}`, lines: [ { accountId: '2101', description: `Payment for Bill ${bill.billNumber}`, debit: p.amount, credit: 0, vendorId: bill.vendorId }, { accountId: p.paymentAccountId, description: `Payment to ${bill.vendorName}`, debit: 0, credit: p.amount } ] }, true, { type: 'BillPayment', id: p.billId }); bill.paidAmount += p.amount; bill.status = bill.paidAmount >= bill.totalAmount ? BillStatus.Paid : BillStatus.PartiallyPaid; bill.payments.push({ id: Math.random().toString(36).substr(2, 9), ...p, status: 'Active', voucherId: '' }); } };
    getApAgingReport = async () => ({ buckets: { current: 0, _1_30_days: 0, _31_60_days: 0, _61_90_days: 0, over_90_days: 0, total: 0 }, bills: [], byVendor: [] });
    getBillPayments = async () => [];
    voidBillPayment = async () => {};
    processBatchDelivery = async (orderIds: string[], courierVendorId: string) => { const orders = this.orders.filter(o => orderIds.includes(o.id)); if (orders.length === 0) return; const courier = this.vendors.find(v => v.id === courierVendorId); const courierName = courier ? courier.name : 'Unknown Courier'; for (const order of orders) { order.status = OrderStatus.Delivered; order.courierVendorId = courierVendorId; order.courierVendorName = courierName; } const jvLines: JournalVoucherLine[] = []; const totalAmount = orders.reduce((sum, o) => sum + (o.totalPrice - o.paidAmount), 0); if (totalAmount > 0) { jvLines.push({ accountId: '1502', description: `Bulk cash collection by ${courierName}. Orders: ${orders.map(o => o.id).join(', ')}`, debit: totalAmount, credit: 0, vendorId: courierVendorId }); orders.forEach(order => { const due = order.totalPrice - order.paidAmount; if (due > 0) { jvLines.push({ accountId: '1501', description: `Order ${order.id} delivered by ${courierName}`, debit: 0, credit: due, customerId: order.customerId, referenceId: order.id }); } }); await this.addJournalVoucher({ date: new Date(), description: `Batch Delivery Handover to ${courierName}`, lines: jvLines }, true, { type: 'Order', id: 'BATCH-' + Date.now() }); } };
    revertDelivery = async (orderId: string) => { const order = this.orders.find(o => o.id === orderId); if (!order || order.status !== OrderStatus.Delivered) { throw new Error("Order is not in Delivered status or not found."); } const courierVendorId = order.courierVendorId; const due = order.totalPrice - order.paidAmount; if (due > 0) { const jvLines: JournalVoucherLine[] = [ { accountId: '1501', description: `Revert Delivery for Order ${order.id}`, debit: due, credit: 0, customerId: order.customerId, referenceId: order.id }, { accountId: '1502', description: `Revert Delivery for Order ${order.id}`, debit: 0, credit: due, vendorId: courierVendorId } ]; await this.addJournalVoucher({ date: new Date(), description: `Reversal of Delivery for Order ${order.id}`, lines: jvLines }, true, { type: 'Revert', id: order.id }); } order.status = OrderStatus.Pending; order.courierVendorId = undefined; order.courierVendorName = undefined; };
    getRewardClaims = async () => [...this.rewardClaims];
    getRewardMonthConfigs = async () => [...this.rewardConfigs];
    upsertRewardMonthConfig = async (config: RewardMonthConfig) => { const idx = this.rewardConfigs.findIndex(c => c.period === config.period); if (idx !== -1) this.rewardConfigs[idx] = config; else this.rewardConfigs.push(config); };
    recognizeRewardPoints = async (period: string, items: number, amount: number, desc: string, rate: number, val: number) => { const jv = await this.addJournalVoucher({ date: new Date(), description: desc, lines: [ { accountId: '1180', description: desc, debit: amount, credit: 0 }, { accountId: '4202', description: desc, debit: 0, credit: amount } ] }, true, { type: 'RewardClaim', id: period }); this.rewardClaims.push({ id: Math.random().toString(36).substr(2, 9), period, claimDate: new Date(), amount, totalItems: items, appliedPointsPerItem: rate, appliedValuePerPoint: val, journalVoucherId: jv.voucherId }); };
    processOrderCancellation = async (orderId: string, scenario: 'before_purchase' | 'stocked' | 'returned'): Promise<string> => { const order = this.orders.find(o => o.id === orderId); if (!order) throw new Error("Order not found."); const jvLines: JournalVoucherLine[] = []; const descriptionSuffix = scenario.replace('_', ' ').toUpperCase(); jvLines.push({ accountId: '4101', description: `Reverse Sale: Order ${orderId} (${descriptionSuffix})`, debit: order.totalPrice, credit: 0, customerId: order.customerId }); jvLines.push({ accountId: '1501', description: `Cancel Debt: Order ${orderId}`, debit: 0, credit: order.totalPrice, customerId: order.customerId, referenceId: order.id }); let newStatus = OrderStatus.Cancelled; if (scenario === 'stocked') { newStatus = OrderStatus.Stocked; jvLines.push({ accountId: '1620', description: `Stock Item from Order ${orderId}`, debit: order.totalPrice, credit: 0 }); jvLines.push({ accountId: '1601', description: `Remove from Transit: Order ${orderId}`, debit: 0, credit: order.totalPrice }); } else if (scenario === 'returned') { newStatus = OrderStatus.Returned; jvLines.push({ accountId: '1620', description: `Restock Returned Item: Order ${orderId}`, debit: order.totalPrice, credit: 0 }); jvLines.push({ accountId: '5001', description: `Reverse COGS: Order ${orderId}`, debit: 0, credit: order.totalPrice }); } const jv = await this.addJournalVoucher({ date: new Date(), description: `Order Cancellation/Return: ${orderId} - ${descriptionSuffix}`, lines: jvLines }, true, { type: 'Order', id: orderId }); order.status = newStatus; return jv.voucherNumber; };
    getNetProfitForPeriod = async (startDateStr: string, endDateStr: string): Promise<number> => { const pnl = await this.getProfitAndLoss(startDateStr, endDateStr); return pnl.netProfit; };
    getPartnerMetrics = async (): Promise<PartnerMetric[]> => { const metrics: PartnerMetric[] = []; for (const s of this.shareholders) { const capitalAccounts = this.accounts.filter(a => a.shareholderId === s.id && a.code.startsWith('31')); const drawingAccounts = this.accounts.filter(a => a.shareholderId === s.id && a.code.startsWith('32')); let totalCapital = 0; capitalAccounts.forEach(acc => totalCapital += this._getBalanceForAccount(acc.id, null, new Date())); let totalDrawings = 0; drawingAccounts.forEach(acc => totalDrawings += this._getBalanceForAccount(acc.id, null, new Date())); metrics.push({ id: s.id, name: s.name, totalCapital, totalProfitShare: 0, totalDrawings, netBalance: totalCapital - totalDrawings }); } return metrics; };
    distributePeriodProfit = async (date: Date, distributions: { shareholderId: string; amount: number }[]) => { const lines: JournalVoucherLine[] = []; let totalDist = 0; distributions.forEach(dist => { const shareholder = this.shareholders.find(s => s.id === dist.shareholderId); const capitalAccount = this.accounts.find(a => a.shareholderId === dist.shareholderId && a.code.startsWith('31')); if (capitalAccount) { lines.push({ accountId: capitalAccount.id, description: `Profit Distribution - ${shareholder?.name}`, debit: 0, credit: dist.amount, }); totalDist += dist.amount; } }); if (totalDist > 0) { lines.push({ accountId: '3300', description: `Monthly Profit Distribution`, debit: totalDist, credit: 0, }); await this.addJournalVoucher({ date: date, description: `Profit Distribution for ${date.toLocaleDateString('en-US', {month: 'long', year: 'numeric'})}`, lines: lines }, true, { type: 'ProfitDistribution', id: `DIST-${date.getTime()}` }); } };

    // ... (initialization helpers) ...
    private _initializeRoles() {
        // Define all available scopes from constants.tsx to ensure Super Admin has them all
        const allScopes = [
            'dashboard',
            'sales.analytics', 'sales.orders', 'sales.bundles', 'sales.rewards', 'sales.receivables',
            'purchasing.bills', 'purchasing.pay_bills', 'purchasing.payments_list',
            'contacts.customers', 'contacts.vendors', 'contacts.agents', 'contacts.partners',
            'finance.receipts', 'finance.expenses', 'finance.journal', 'finance.profit_distribution', 'finance.general_ledger', 'finance.trial_balance',
            'reports.financial_summary', 'reports.profit_loss', 'reports.cash_flow', 'reports.party_statements', 'reports.balance_sheet', 'reports.ap_aging',
            'operations.transport', 'operations.warehouse',
            'hr.employees', 'hr.payroll',
            'settings.coa', 'settings.system', 'settings.roles', 'settings.users', 'settings.audit'
        ];

        const createFullPerms = () => {
            const perms: Permission = {};
            // Add module level
            Object.values(MODULE_NAMES).forEach(m => perms[m] = ['view', 'create', 'edit', 'delete', 'approve']);
            // Add granular level
            allScopes.forEach(s => perms[s] = ['view', 'create', 'edit', 'delete', 'approve']);
            return perms;
        };

        // Default Roles
        this.roles = [
            {
                id: 'role-super-admin',
                name: 'Super Admin',
                description: 'Full system access with ability to manage roles.',
                isSystem: true,
                permissions: createFullPerms()
            },
            {
                id: 'role-viewer',
                name: 'Viewer',
                description: 'Read-only access to reports and dashboards.',
                isSystem: false,
                permissions: {
                    [MODULE_NAMES.DASHBOARD]: ['view'],
                    [MODULE_NAMES.REPORTS]: ['view'],
                    'dashboard': ['view'],
                    'reports.financial_summary': ['view'],
                    'reports.profit_loss': ['view'],
                    'reports.cash_flow': ['view'],
                    'reports.party_statements': ['view'],
                    'reports.balance_sheet': ['view']
                }
            },
            {
                id: 'role-sales',
                name: 'Sales Agent',
                description: 'Manage orders and customers.',
                isSystem: false,
                permissions: {
                    [MODULE_NAMES.DASHBOARD]: ['view'],
                    [MODULE_NAMES.SALES]: ['view', 'create', 'edit'],
                    [MODULE_NAMES.CONTACTS]: ['view', 'create', 'edit'],
                    'dashboard': ['view'],
                    'sales.orders': ['view', 'create', 'edit'],
                    'sales.bundles': ['view'],
                    'sales.receivables': ['view'],
                    'contacts.customers': ['view', 'create', 'edit']
                }
            }
        ];
    }

    private _initializeUsers() {
        // Create a default admin user
        this.users = [
            {
                id: 'usr-admin',
                name: 'System Admin',
                email: 'admin@system.com',
                password: 'password',
                roleId: 'role-super-admin',
                status: 'Active',
                createdAt: new Date('2024-01-01')
            },
            {
                id: 'usr-sales',
                name: 'John Sales',
                email: 'sales@system.com',
                password: 'password',
                roleId: 'role-sales',
                status: 'Active',
                createdAt: new Date('2024-02-01')
            }
        ];
    }
    
    // ... rest of init methods ...
    private _initializeShareholders() { this.shareholders = [ { id: 'sh-1', name: 'Partner A', profitSharePercentage: 50, capitalContributions: 50000 }, { id: 'sh-2', name: 'Partner B', profitSharePercentage: 50, capitalContributions: 50000 }, ]; }
    private _initializeEmployees() { this.employees = [ { id: 'EMP-001', fullName: 'Ali Hassan', position: 'Delivery Driver', startDate: new Date('2023-01-15'), basicMonthlySalary: 600, paymentMethod: 'Cash', isActive: true }, { id: 'EMP-002', fullName: 'Sara Ahmed', position: 'Accountant', startDate: new Date('2023-03-01'), basicMonthlySalary: 900, paymentMethod: 'Bank Transfer', isActive: true }, { id: 'EMP-003', fullName: 'Karwan Mohammed', position: 'Sales Manager', startDate: new Date('2022-11-10'), basicMonthlySalary: 1200, paymentMethod: 'Bank Transfer', isActive: true }, { id: 'EMP-004', fullName: 'Rebin Othman', position: 'Warehouse Keeper', startDate: new Date('2023-05-20'), basicMonthlySalary: 500, paymentMethod: 'Cash', isActive: true }, { id: 'EMP-005', fullName: 'Lanya Azad', position: 'Customer Support', startDate: new Date('2023-06-01'), basicMonthlySalary: 600, paymentMethod: 'Cash', isActive: true }, { id: 'EMP-006', fullName: 'Zana Bakr', position: 'Logistics Coordinator', startDate: new Date('2023-02-15'), basicMonthlySalary: 800, paymentMethod: 'Cash', isActive: true }, { id: 'EMP-007', fullName: 'Hewa Salih', position: 'Driver Assistant', startDate: new Date('2023-08-01'), basicMonthlySalary: 400, paymentMethod: 'Cash', isActive: true }, { id: 'EMP-008', fullName: 'Nina Yassin', position: 'Social Media Manager', startDate: new Date('2023-04-10'), basicMonthlySalary: 700, paymentMethod: 'Bank Transfer', isActive: true }, { id: 'EMP-009', fullName: 'Barzan Fatah', position: 'Purchase Officer', startDate: new Date('2023-01-20'), basicMonthlySalary: 850, paymentMethod: 'Cash', isActive: true }, { id: 'EMP-010', fullName: 'Darya Jalal', position: 'HR Specialist', startDate: new Date('2023-09-01'), basicMonthlySalary: 750, paymentMethod: 'Bank Transfer', isActive: true }, ]; }
    private _initializeHistoricalPayrolls() { const lastMonth = new Date(); lastMonth.setMonth(lastMonth.getMonth() - 1); const twoMonthsAgo = new Date(); twoMonthsAgo.setMonth(twoMonthsAgo.getMonth() - 2); const periods = [ `${twoMonthsAgo.getFullYear()}-${String(twoMonthsAgo.getMonth() + 1).padStart(2, '0')}`, `${lastMonth.getFullYear()}-${String(lastMonth.getMonth() + 1).padStart(2, '0')}` ]; periods.forEach(period => { this.payrolls.push({ id: `PAY-${period}`, period, processingDate: new Date(), status: 'Paid', employees: this.employees.map(e => ({ employeeId: e.id, employeeName: e.fullName, basicSalary: e.basicMonthlySalary, bonus: 0, advanceBalance: 0, deduction: 0, netSalary: e.basicMonthlySalary })), totalGrossSalary: this.employees.reduce((s,e)=>s+e.basicMonthlySalary,0), totalBonuses: 0, totalDeductions: 0, totalNetSalary: this.employees.reduce((s,e)=>s+e.basicMonthlySalary,0), accrualJournalId: 'JV-HIST-ACC', paymentJournalId: 'JV-HIST-PAY' }); }); }
    private _initializeVendors() { this.vendors = [ { id: 'vnd-1', name: 'TechZone Suppliers', contactPerson: 'John Doe', phone: '07501234567', address: 'Erbil, 60 Meter' }, { id: 'vnd-2', name: 'Fashion Ist', contactPerson: 'Sarah Smith', phone: '07701234567', address: 'Sulaymaniyah, Malik Mahmud' }, { id: 'vnd-3', name: 'Speedy Logistics', contactPerson: 'Driver A', phone: '07509876543', address: 'Baghdad' } ]; }
    private _initializeAgents() { this.agents = [ { id: 'AGT-001', name: 'Karwan Delivery', phone: '07501112233', createdAt: new Date() }, { id: 'AGT-002', name: 'Barzan Representative', phone: '07703334455', createdAt: new Date() } ]; }
    private async _initializeCustomersAndOrders() { const customersData = [ { name: 'Ahmed Kamal', phone1: '07504445566', address: 'Erbil, Dream City' }, { name: 'Lanya Azad', phone1: '07708889900', address: 'Suli, Raparin' }, { name: 'Rebin Hasan', phone1: '07507778899', address: 'Duhok, KRO' }, { name: 'Saman Ali', phone1: '07701112222', address: 'Kirkuk' } ]; for (const c of customersData) { await this.addCustomer(c); } const dbCustomers = this.customers; const dbAgents = this.agents; if (dbCustomers.length === 0) return; const products = [ { desc: 'iPhone 15 Pro', price: 1100 }, { desc: 'Samsung S24 Ultra', price: 1200 }, { desc: 'MacBook Air M2', price: 1050 }, { desc: 'Sony Headphones', price: 250 }, { desc: 'Smart Watch Series 9', price: 400 }, { desc: 'Gaming Laptop', price: 1500 } ]; const now = new Date(); for (let i = 0; i < 15; i++) { const customer = dbCustomers[i % dbCustomers.length]; const product = products[i % products.length]; const agent = dbAgents.length > 0 ? dbAgents[i % dbAgents.length] : undefined; const daysAgo = Math.floor(Math.random() * 30); const orderDate = new Date(now); orderDate.setDate(now.getDate() - daysAgo); let status: OrderStatus = OrderStatus.Pending; if (i >= 5 && i <= 10) status = OrderStatus.Delivered; else if (i > 10) status = OrderStatus.Paid; const orderData = { customerId: customer.id, customerName: customer.name || 'Unknown', customerPhone: customer.phone1, agentId: agent?.id, agentName: agent?.name, productLink: `https://example.com/products/${i}`, orderDescription: `${product.desc} - Color: Black`, totalPrice: product.price, paidAmount: 0, receiptNumber: `REC-${1000+i}`, orderDate: orderDate, estimatedDueDate: new Date(orderDate.getTime() + 7 * 24 * 60 * 60 * 1000), itemCount: Math.floor(Math.random() * 5) + 1, }; const newOrder = await this.addOrder(orderData); if (status === OrderStatus.Delivered || status === OrderStatus.Paid) { await this.updateOrderStatus(newOrder.id, OrderStatus.Delivered); } if (status === OrderStatus.Paid) { await this.addReceipt({ date: new Date(), accountId: '1111', referenceNumber: `PAY-${newOrder.id}`, lines: [{ payerEntity: { type: 'customer', id: customer.id, name: customer.name || '' }, accountId: '1501', amount: product.price, description: `Full payment for Order ${newOrder.id}`, referenceId: newOrder.id }] }); } } }
    private _initializeMiscTransactions() {}
    private async _initializeBills() { this.bills = []; }
    // ... (Account initialization remains same)
    private _initializeAccounts() {
         this.accounts = [
            { id: '1000', code: '1000', name: 'ASSETS', nameKurdish: 'داراییەکان', parentId: null, category: AccountCategory.Asset, accountType: AccountType.OtherCurrentAsset, balance: 0, isDeletable: false, isPostable: false },
            { id: '1100', code: '1100', name: 'Current Assets', nameKurdish: 'داراییە کورتخایەنەکان', parentId: '1000', category: AccountCategory.Asset, accountType: AccountType.OtherCurrentAsset, balance: 0, isDeletable: false, isPostable: false },
            { id: '1110', code: '1110', name: 'Cash & Cash Equivalents', nameKurdish: 'نەختینە و هاوتاکانی', parentId: '1100', category: AccountCategory.Asset, accountType: AccountType.Cash, balance: 0, isDeletable: false, isPostable: false },
            { id: '1111', code: '1111', name: 'Main Cash Fund', nameKurdish: 'سندوقی سەرەکی', parentId: '1110', category: AccountCategory.Asset, accountType: AccountType.Cash, balance: 0, isDeletable: false, isPostable: true },
            { id: '1112', code: '1112', name: 'Office Petty Cash', nameKurdish: 'سندوقی خەرجیی پەرتەوازە', parentId: '1110', category: AccountCategory.Asset, accountType: AccountType.Cash, balance: 0, isDeletable: true, isPostable: true },
            { id: '1113', code: '1113', name: 'Cash with Delivery Agents', nameKurdish: 'ئەماناتی لای شۆفێرانی گەیاندن', parentId: '1110', category: AccountCategory.Asset, accountType: AccountType.Cash, balance: 0, isDeletable: true, isPostable: true },
            { id: '1180', code: '1180', name: 'Reward Points Asset', nameKurdish: 'پارەی پۆینتەکان', parentId: '1100', category: AccountCategory.Asset, accountType: AccountType.OtherCurrentAsset, balance: 0, isDeletable: false, isPostable: true },
            { id: '1200', code: '1200', name: 'Bank Accounts', nameKurdish: 'حیسابە بانکییەکان', parentId: '1100', category: AccountCategory.Asset, accountType: AccountType.Bank, balance: 0, isDeletable: false, isPostable: false },
            { id: '1201', code: '1201', name: 'FIB Bank Account', nameKurdish: 'حیسابی بانکی FIB', parentId: '1200', category: AccountCategory.Asset, accountType: AccountType.Bank, balance: 0, isDeletable: true, isPostable: true },
            { id: '1202', code: '1202', name: 'Cihan Bank Account', nameKurdish: 'حیسابی بانکی جیهان', parentId: '1200', category: AccountCategory.Asset, accountType: AccountType.Bank, balance: 0, isDeletable: true, isPostable: true },
            { id: '1300', code: '1300', name: 'E-Wallets', nameKurdish: 'جزدانە ئەلیکترۆنییەکان', parentId: '1100', category: AccountCategory.Asset, accountType: AccountType.EWallet, balance: 0, isDeletable: false, isPostable: false },
            { id: '1301', code: '1301', name: 'ZainCash Wallet', nameKurdish: 'جزدانی ZainCash', parentId: '1300', category: AccountCategory.Asset, accountType: AccountType.EWallet, balance: 0, isDeletable: true, isPostable: true },
            { id: '1302', code: '1302', name: 'FastPay Wallet', nameKurdish: 'جزدانی FastPay', parentId: '1300', category: AccountCategory.Asset, accountType: AccountType.EWallet, balance: 0, isDeletable: true, isPostable: true },
            { id: '1400', code: '1400', name: 'Mobile Credit Balances', nameKurdish: 'باڵانسی مۆبایل', parentId: '1100', category: AccountCategory.Asset, accountType: AccountType.MobileCredit, balance: 0, isDeletable: false, isPostable: false },
            { id: '1401', code: '1401', name: 'Korek Balance', nameKurdish: 'باڵانسی Korek', parentId: '1400', category: AccountCategory.Asset, accountType: AccountType.MobileCredit, balance: 0, isDeletable: true, isPostable: true },
            { id: '1402', code: '1402', name: 'Zain Balance', nameKurdish: 'باڵانسی Zain', parentId: '1400', category: AccountCategory.Asset, accountType: AccountType.MobileCredit, balance: 0, isDeletable: true, isPostable: true },
            { id: '1403', code: '1403', name: 'Asiacell Balance', nameKurdish: 'باڵانسی Asiacell', parentId: '1400', category: AccountCategory.Asset, accountType: AccountType.MobileCredit, balance: 0, isDeletable: true, isPostable: true },
            { id: '1500', code: '1500', name: 'Accounts Receivable', nameKurdish: 'داواکراوەکان لە کڕیاران', parentId: '1100', category: AccountCategory.Asset, accountType: AccountType.AccountsReceivable, balance: 0, isDeletable: false, isPostable: false },
            { id: '1501', code: '1501', name: 'Customer Receivables', nameKurdish: 'داواکراوی لای کڕیاران', parentId: '1500', category: AccountCategory.Asset, accountType: AccountType.AccountsReceivable, balance: 0, isDeletable: false, isPostable: true },
            { id: '1502', code: '1502', name: 'Due from Delivery Companies', nameKurdish: 'قەرزی لای کۆمپانیاکانی گەیاندن', parentId: '1500', category: AccountCategory.Asset, accountType: AccountType.AccountsReceivable, balance: 0, isDeletable: false, isPostable: true },
            { id: '1509', code: '1509', name: 'Allowance for Doubtful Accounts', nameKurdish: 'پشکی قەرزە گومانلێکراوەکان', parentId: '1500', category: AccountCategory.Asset, accountType: AccountType.AccountsReceivable, balance: 0, isDeletable: false, isPostable: true },
            { id: '1600', code: '1600', name: 'Inventory', nameKurdish: 'کاڵای کۆگاکراو', parentId: '1100', category: AccountCategory.Asset, accountType: AccountType.OtherCurrentAsset, balance: 0, isDeletable: false, isPostable: false },
            { id: '1601', code: '1601', name: 'Goods in Transit', nameKurdish: 'کاڵای کڕدراو لە ڕێگا', parentId: '1600', category: AccountCategory.Asset, accountType: AccountType.OtherCurrentAsset, balance: 0, isDeletable: false, isPostable: true },
            { id: '1620', code: '1620', name: 'Warehouse Inventory', nameKurdish: 'مەخزەنی کاڵا', parentId: '1600', category: AccountCategory.Asset, accountType: AccountType.OtherCurrentAsset, balance: 0, isDeletable: false, isPostable: true },
            { id: '1700', code: '1700', name: 'Employee Advances', nameKurdish: 'پێشینەی کارمەندان', parentId: '1100', category: AccountCategory.Asset, accountType: AccountType.OtherCurrentAsset, balance: 0, isDeletable: false, isPostable: false },
            { id: '1701', code: '1701', name: 'Employee Loans & Advances', nameKurdish: 'قەرز و پێشینەی کارمەندان', parentId: '1700', category: AccountCategory.Asset, accountType: AccountType.OtherCurrentAsset, balance: 0, isDeletable: false, isPostable: true },
            { id: '1800', code: '1800', name: 'Fixed Assets', nameKurdish: 'داراییە جێگیرەکان', parentId: '1000', category: AccountCategory.Asset, accountType: AccountType.FixedAsset, balance: 0, isDeletable: false, isPostable: false },
            { id: '1801', code: '1801', name: 'Office Furniture & Equipment', nameKurdish: 'کەلوپەلی ئۆفیس و ئەساسە', parentId: '1800', category: AccountCategory.Asset, accountType: AccountType.FixedAsset, balance: 0, isDeletable: true, isPostable: true },
            { id: '1802', code: '1802', name: 'Computers & IT Equipment', nameKurdish: 'ئامێری ئەلیکترۆنی و ئایتی', parentId: '1800', category: AccountCategory.Asset, accountType: AccountType.FixedAsset, balance: 0, isDeletable: true, isPostable: true },
            { id: '2000', code: '2000', name: 'LIABILITIES', nameKurdish: 'قەرز و پابەندییەکان', parentId: null, category: AccountCategory.Liability, accountType: AccountType.OtherCurrentLiability, balance: 0, isDeletable: false, isPostable: false },
            { id: '2100', code: '2100', name: 'Current Liabilities', nameKurdish: 'پابەندییە کورتخایەنەکان', parentId: '2000', category: AccountCategory.Liability, accountType: AccountType.OtherCurrentLiability, balance: 0, isDeletable: false, isPostable: false },
            { id: '2101', code: '2101', name: 'Accounts Payable', nameKurdish: 'قەرزی دابینکەران', parentId: '2100', category: AccountCategory.Liability, accountType: AccountType.AccountsPayable, balance: 0, isDeletable: false, isPostable: true },
            { id: '2102', code: '2102', name: 'Credit Cards Payable', nameKurdish: 'قەرزی کاردە بانکییەکان', parentId: '2100', category: AccountCategory.Liability, accountType: AccountType.Bank, balance: 0, isDeletable: false, isPostable: false },
            { id: '2102.1', code: '2102.1', name: 'MasterCard #1', nameKurdish: 'MasterCard #1', parentId: '2102', category: AccountCategory.Liability, accountType: AccountType.Bank, balance: 0, isDeletable: true, isPostable: true },
            { id: '2102.2', code: '2102.2', name: 'MasterCard #2', nameKurdish: 'MasterCard #2', parentId: '2102', category: AccountCategory.Liability, accountType: AccountType.Bank, balance: 0, isDeletable: true, isPostable: true },
            { id: '2103', code: '2103', name: 'Accrued Expenses', nameKurdish: 'خەرجییە شایستەکان', parentId: '2100', category: AccountCategory.Liability, accountType: AccountType.OtherCurrentLiability, balance: 0, isDeletable: false, isPostable: false },
            { id: '2103.1', code: '2103.1', name: 'Accrued Salaries', nameKurdish: 'مووچەی شایستەی کارمەندان', parentId: '2103', category: AccountCategory.Liability, accountType: AccountType.OtherCurrentLiability, balance: 0, isDeletable: false, isPostable: true },
            { id: '2104', code: '2104', name: 'Accrued Delivery Fees', nameKurdish: 'کرێی گەیاندنی شایستە', parentId: '2100', category: AccountCategory.Liability, accountType: AccountType.OtherCurrentLiability, balance: 0, isDeletable: false, isPostable: true },
            { id: '2200', code: '2200', name: 'Loans from Partners', nameKurdish: 'قەرزی وەرگیراو لە شەریکەکان', parentId: '2000', category: AccountCategory.Liability, accountType: AccountType.OtherCurrentLiability, balance: 0, isDeletable: false, isPostable: false },
            { id: '2201', code: '2201', name: 'Loan from Partner A', nameKurdish: 'قەرزی وەرگیراو لە شەریکی A', parentId: '2200', category: AccountCategory.Liability, accountType: AccountType.OtherCurrentLiability, balance: 0, isDeletable: true, isPostable: true },
            { id: '3000', code: '3000', name: 'EQUITY', nameKurdish: 'مافی خاوەندارێتی', parentId: null, category: AccountCategory.Equity, accountType: AccountType.Equity, balance: 0, isDeletable: false, isPostable: false },
            { id: '3100', code: '3100', name: "Partner's Capital", nameKurdish: 'سەرمایەی شەریکەکان', parentId: '3000', category: AccountCategory.Equity, accountType: AccountType.Equity, balance: 0, isDeletable: false, isPostable: false },
            { id: '3101', code: '3101', name: 'Capital - Partner A', nameKurdish: 'سەرمایەی شەریکی A', parentId: '3100', category: AccountCategory.Equity, accountType: AccountType.Equity, balance: 0, isDeletable: false, shareholderId: 'sh-1', isPostable: true },
            { id: '3200', code: '3200', name: "Partner's Drawings", nameKurdish: 'کێشانەوەی شەخسیی شەریکەکان', parentId: '3000', category: AccountCategory.Equity, accountType: AccountType.Equity, balance: 0, isDeletable: false, isPostable: false },
            { id: '3201', code: '3201', name: 'Drawings - Partner A', nameKurdish: 'کێشانەوەی شەریکی A', parentId: '3200', category: AccountCategory.Equity, accountType: AccountType.Equity, balance: 0, isDeletable: false, shareholderId: 'sh-1', isPostable: true },
            { id: '3300', code: '3300', name: 'Retained Earnings', nameKurdish: 'قازانجی هەڵگیراو/پاشەکەوتکراو', parentId: '3000', category: AccountCategory.Equity, accountType: AccountType.Equity, balance: 0, isDeletable: false, isPostable: true },
            { id: '4000', code: '4000', name: 'REVENUE', nameKurdish: 'داهاتەکان', parentId: null, category: AccountCategory.Revenue, accountType: AccountType.Revenue, balance: 0, isDeletable: false, isPostable: false },
            { id: '4100', code: '4100', name: 'Operating Revenue', nameKurdish: 'داهاتی کارپێکەری', parentId: '4000', category: AccountCategory.Revenue, accountType: AccountType.Revenue, balance: 0, isDeletable: false, isPostable: false },
            { id: '4101', code: '4101', name: 'Sales Revenue', nameKurdish: 'داهاتی فرۆشتن', parentId: '4100', category: AccountCategory.Revenue, accountType: AccountType.Revenue, balance: 0, isDeletable: false, isPostable: true },
            { id: '4102', code: '4102', name: 'Service Fee & Commission', nameKurdish: 'داهاتی کۆمیسیۆن و خزمەتگوزاری', parentId: '4100', category: AccountCategory.Revenue, accountType: AccountType.Revenue, balance: 0, isDeletable: true, isPostable: true },
            { id: '4200', code: '4200', name: 'Other Income', nameKurdish: 'داهاتەکانی تر', parentId: '4000', category: AccountCategory.Revenue, accountType: AccountType.Revenue, balance: 0, isDeletable: false, isPostable: false },
            { id: '4201', code: '4201', name: 'Foreign Exchange Gain', nameKurdish: 'قازانجی گۆڕینەوەی دراو', parentId: '4200', category: AccountCategory.Revenue, accountType: AccountType.Revenue, balance: 0, isDeletable: true, isPostable: true },
            { id: '4202', code: '4202', name: 'Rewards Income', nameKurdish: 'داهاتی پاداشت', parentId: '4200', category: AccountCategory.Revenue, accountType: AccountType.Revenue, balance: 0, isDeletable: false, isPostable: true },
            { id: '5000', code: '5000', name: 'COST OF GOODS SOLD (COGS)', nameKurdish: 'تێچووی کاڵای فرۆشراو', parentId: null, category: AccountCategory.COGS, accountType: AccountType.COGS, balance: 0, isDeletable: false, isPostable: false },
            { id: '5001', code: '5001', name: 'Purchase Cost of Goods', nameKurdish: 'تێچووی کڕینی کاڵا', parentId: '5000', category: AccountCategory.COGS, accountType: AccountType.COGS, balance: 0, isDeletable: false, isPostable: true },
            { id: '5002', code: '5002', name: 'International Shipping Cost', nameKurdish: 'تێچووی گواستنەوەی نێودەوڵەتی', parentId: '5000', category: AccountCategory.COGS, accountType: AccountType.COGS, balance: 0, isDeletable: true, isPostable: true },
            { id: '5003', code: '5003', name: 'Customs Duties & Fees', nameKurdish: 'باج و ڕسوماتە گومرگییەکان', parentId: '5000', category: AccountCategory.COGS, accountType: AccountType.COGS, balance: 0, isDeletable: true, isPostable: true },
            { id: '6000', code: '6000', name: 'OPERATING EXPENSES', nameKurdish: 'خەرجییە کارپێکەرییەکان', parentId: null, category: AccountCategory.OperatingExpense, accountType: AccountType.OperatingExpense, balance: 0, isDeletable: false, isPostable: false },
            { id: '6100', code: '6100', name: 'Employee Costs', nameKurdish: 'تێچووی کارمەندان', parentId: '6000', category: AccountCategory.OperatingExpense, accountType: AccountType.OperatingExpense, balance: 0, isDeletable: false, isPostable: false },
            { id: '6101', code: '6101', name: 'Salaries & Wages', nameKurdish: 'مووچەی بنەڕەتی', parentId: '6100', category: AccountCategory.OperatingExpense, accountType: AccountType.OperatingExpense, balance: 0, isDeletable: false, isPostable: true },
            { id: '6102', code: '6102', name: 'Employee Bonuses', nameKurdish: 'موکافەئەی کارمەندان', parentId: '6100', category: AccountCategory.OperatingExpense, accountType: AccountType.OperatingExpense, balance: 0, isDeletable: false, isPostable: true },
            { id: '6200', code: '6200', name: 'Office & Admin Expenses', nameKurdish: 'خەرجییەکانی ئۆفیس و بەڕێوەبردن', parentId: '6000', category: AccountCategory.OperatingExpense, accountType: AccountType.OperatingExpense, balance: 0, isDeletable: false, isPostable: false },
            { id: '6201', code: '6201', name: 'Office Rent', nameKurdish: 'کرێی ئۆفیس', parentId: '6200', category: AccountCategory.OperatingExpense, accountType: AccountType.OperatingExpense, balance: 0, isDeletable: true, isPostable: true },
            { id: '6202', code: '6202', name: 'Utilities', nameKurdish: 'کارەبا، ئاو و خزمەتگوزارییەکان', parentId: '6200', category: AccountCategory.OperatingExpense, accountType: AccountType.OperatingExpense, balance: 0, isDeletable: true, isPostable: true },
            { id: '6300', code: '6300', name: 'Marketing Expenses', nameKurdish: 'خەرجییەکانی بازاڕگەری', parentId: '6000', category: AccountCategory.OperatingExpense, accountType: AccountType.OperatingExpense, balance: 0, isDeletable: false, isPostable: false },
            { id: '6301', code: '6301', name: 'Online & Social Media Ads', nameKurdish: 'ڕیکلامی ئۆنلاین', parentId: '6300', category: AccountCategory.OperatingExpense, accountType: AccountType.OperatingExpense, balance: 0, isDeletable: true, isPostable: true },
            { id: '6400', code: '6400', name: 'Financial Expenses', nameKurdish: 'خەرجییە داراییەکان', parentId: '6000', category: AccountCategory.OperatingExpense, accountType: AccountType.OperatingExpense, balance: 0, isDeletable: false, isPostable: false },
            { id: '6401', code: '6401', name: 'Bank & Payment Gateway Fees', nameKurdish: 'ڕسومات و تێچووی بانق و دەروازەی پارەدان', parentId: '6400', category: AccountCategory.OperatingExpense, accountType: AccountType.OperatingExpense, balance: 0, isDeletable: true, isPostable: true },
            { id: '6402', code: '6402', name: 'Foreign Exchange Loss', nameKurdish: 'زیانی گۆڕینەوەی دراو', parentId: '6400', category: AccountCategory.OperatingExpense, accountType: AccountType.OperatingExpense, balance: 0, isDeletable: true, isPostable: true },
            { id: '6501', code: '6501', name: 'Local Delivery Expenses', nameKurdish: 'تێچووی گەیاندنی ناوخۆیی', parentId: '6000', category: AccountCategory.OperatingExpense, accountType: AccountType.OperatingExpense, balance: 0, isDeletable: false, isPostable: true },
            { id: '6600', code: '6600', name: 'General & Miscellaneous Expenses', nameKurdish: 'خەرجیی گشتی و جۆراوجۆر', parentId: '6000', category: AccountCategory.OperatingExpense, accountType: AccountType.OperatingExpense, balance: 0, isDeletable: false, isPostable: false },
            { id: '6601', code: '6601', name: 'Bad Debt Expense', nameKurdish: 'خەرجیی قەرزی لەناوچوو/سوتاو', parentId: '6600', category: AccountCategory.OperatingExpense, accountType: AccountType.OperatingExpense, balance: 0, isDeletable: true, isPostable: true },
            { id: '6602', code: '6602', name: 'Miscellaneous Expenses', nameKurdish: 'خەرجیی پەرتەوازە', parentId: '6600', category: AccountCategory.OperatingExpense, accountType: AccountType.OperatingExpense, balance: 0, isDeletable: true, isPostable: true },
        ].map(a => ({ ...a, pathCodes: [], isActive: true, isLocked: !a.isDeletable }));

        const accountMap = new Map(this.accounts.map(a => [a.id, a]));
        this.accounts.forEach(account => {
            const path: string[] = [];
            let current: Account | undefined = account;
            while (current && current.parentId) {
                const parent = accountMap.get(current.parentId);
                if (parent) {
                    path.unshift(parent.code);
                    current = parent;
                } else {
                    current = undefined;
                }
            }
            account.pathCodes = path;
        });
        
        this._recalculateAllBalances();
    }
}

let apiInstance: IDataApi | null = null;
export const getApi = async (): Promise<IDataApi> => {
    if (!apiInstance) {
        const api = new InMemoryApi();
        await api.init();
        apiInstance = api;
    }
    return apiInstance;
};
