
import React from 'react';
import { Routes, Route, useLocation, Navigate } from 'react-router-dom';
import Sidebar from './components/layout/Sidebar';
import Header from './components/layout/Header';
import Dashboard from './pages/Dashboard';
import Orders from './pages/Orders';
import Bundles from './pages/Bundles';
import Receipts from './pages/Receipts';
import Disbursements from './pages/Disbursements';
import TrialBalance from './pages/TrialBalance';
import AccountsReceivable from './pages/AccountsReceivable';
import PartyStatements from './pages/CustomerStatements';
import Customers from './pages/Customers';
import Vendors from './pages/Vendors';
import Agents from './pages/Agents';
import AgentProfile from './pages/AgentProfile';
import Shareholders from './pages/Shareholders';
import Reports from './pages/Reports';
import JournalVoucherPage from './pages/journal/JournalVoucher';
import ChartOfAccounts from './pages/ChartOfAccounts';
import AccountLedger from './pages/AccountLedger';
import GeneralLedger from './pages/GeneralLedger';
import FinancialSummary from './pages/FinancialSummary';
import ProfitAndLoss from './pages/ProfitAndLoss';
import Employees from './pages/Employees';
import EmployeeProfile from './pages/EmployeeProfile';
import Payroll from './pages/Payroll';
import CashFlowStatement from './pages/CashFlowStatement';
import BalanceSheet from './pages/BalanceSheet';
import { SIDEBAR_CONFIG } from './constants';
import Bills from './pages/Bills';
import ApAgingReport from './pages/ApAgingReport';
import PayBills from './pages/PayBills';
import BillPaymentsList from './pages/BillPaymentsList';
import RewardsTracker from './pages/RewardsTracker';
import OrderAnalytics from './pages/OrderAnalytics';
import ProfitDistribution from './pages/ProfitDistribution';
import { Login } from './components/auth/Login';
import { useData } from './context/DataContext';
import { RolesPermissions } from './pages/settings/RolesPermissions';
import { UserManagement } from './pages/settings/UserManagement';
import { AuditLog } from './pages/settings/AuditLog';

const getPageTitle = (pathname: string): string => {
    for (const item of SIDEBAR_CONFIG) {
        if (item.path === pathname) {
            return item.title;
        }
        if (item.subItems) {
            for (const subItem of item.subItems) {
                if ('path' in subItem && subItem.path === pathname) {
                    return subItem.title;
                }
            }
        }
    }
    // Handle dynamic routes
    if (pathname.startsWith('/employees/')) return 'Employee Profile';
    if (pathname.startsWith('/agents/')) return 'Agent Profile';
    if (pathname.startsWith('/accounts/')) return 'Account Ledger';

    return 'Dashboard'; // Default title
};

const AppLayout: React.FC = () => {
    const location = useLocation();
    const pageTitle = getPageTitle(location.pathname);

    const PlaceholderPage: React.FC<{title: string}> = ({title}) => (
        <div className="text-center p-10">
            <h1 className="text-2xl font-bold text-gray-800 dark:text-white">{title}</h1>
            <p className="text-gray-500 dark:text-gray-400">This page is under construction.</p>
        </div>
    );

    return (
        <div className="flex h-screen text-slate-800 dark:text-slate-200">
            <Sidebar />
            <div className="flex-1 flex flex-col overflow-hidden">
                <Header title={pageTitle} />
                <main className="flex-1 overflow-auto">
                   <div className="p-4 md:p-6 lg:p-8 h-full">
                    <Routes>
                        <Route path="/" element={<Dashboard />} />
                        
                        {/* Sales */}
                        <Route path="/sales/analytics" element={<OrderAnalytics />} />
                        <Route path="/orders" element={<Orders />} />
                        <Route path="/party-statements" element={<PartyStatements />} />
                        <Route path="/bundles" element={<Bundles />} />
                        <Route path="/receivables" element={<AccountsReceivable />} />
                        <Route path="/rewards-tracker" element={<RewardsTracker />} />
                        
                        {/* Purchasing */}
                        <Route path="/supplier-bills" element={<Bills />} />
                        <Route path="/pay-bills" element={<PayBills />} />
                        <Route path="/bill-payments" element={<BillPaymentsList />} />
                        
                        {/* Contacts */}
                        <Route path="/customers" element={<Customers />} />
                        <Route path="/vendors" element={<Vendors />} />
                        <Route path="/agents" element={<Agents />} />
                        <Route path="/agents/:agentId" element={<AgentProfile />} />
                        <Route path="/partners" element={<Shareholders />} />

                        {/* Financials */}
                        <Route path="/receipts" element={<Receipts />} />
                        <Route path="/expenses" element={<Disbursements />} />
                        <Route path="/journal-vouchers" element={<JournalVoucherPage />} />
                        <Route path="/profit-distribution" element={<ProfitDistribution />} />
                        <Route type="header" title="Accounting" />
                        <Route path="/general-ledger" element={<GeneralLedger />} />
                        <Route path="/trial-balance" element={<TrialBalance />} />
                        <Route path="/financial-summary" element={<FinancialSummary />} />
                        <Route path="/profit-and-loss" element={<ProfitAndLoss />} />
                        <Route path="/cash-flow-statement" element={<CashFlowStatement />} />
                        <Route path="/balance-sheet" element={<BalanceSheet />} />
                        <Route path="/reports/ap-aging" element={<ApAgingReport />} />

                         {/* Operations */}
                        <Route path="/internal-transport" element={<PlaceholderPage title="Internal Transport" />} />
                        <Route path="/warehouse-management" element={<PlaceholderPage title="Warehouse Management" />} />

                        {/* Human Resources */}
                        <Route path="/employees" element={<Employees />} />
                        <Route path="/employees/:employeeId" element={<EmployeeProfile />} />
                        <Route path="/payroll" element={<Payroll />} />

                        {/* Settings & Security */}
                        <Route path="/chart-of-accounts" element={<ChartOfAccounts />} />
                        <Route path="/system-settings" element={<PlaceholderPage title="System Settings" />} />
                        <Route path="/settings/roles" element={<RolesPermissions />} />
                        <Route path="/settings/users" element={<UserManagement />} />
                        <Route path="/settings/audit-log" element={<AuditLog />} />
                        
                        {/* Deprecated / To be removed */}
                        <Route path="/finance" element={<TrialBalance />} />
                        <Route path="/accounts/:accountId/ledger" element={<AccountLedger />} />
                        <Route path="/reports" element={<Reports />} />
                        <Route path="/shareholders" element={<Shareholders />} />
                        
                        {/* Catch-all for 404 */}
                        <Route path="*" element={<div className="p-10 text-center text-slate-500">Page not found.</div>} />
                    </Routes>
                   </div>
                </main>
            </div>
        </div>
    );
};

const App: React.FC = () => {
    const { currentUser, isLoadingAuth } = useData();

    if (isLoadingAuth) {
        return (
            <div className="flex h-screen items-center justify-center bg-slate-100 dark:bg-slate-900 text-slate-500">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-sky-500"></div>
            </div>
        );
    }

    return (
        <Routes>
            <Route path="/login" element={!currentUser ? <Login /> : <Navigate to="/" replace />} />
            {/* Protect all other routes */}
            <Route path="/*" element={currentUser ? <AppLayout /> : <Navigate to="/login" replace />} />
        </Routes>
    );
};

export default App;
