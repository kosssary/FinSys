
import React, { useState, useEffect, useMemo } from 'react';
import { useData } from '../context/DataContext';
import { CustomerOrder } from '../types';
import { useNavigate } from 'react-router-dom';
import { 
    BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, 
    PieChart, Pie, Legend 
} from 'recharts';
import { 
    TrendingUp, AlertTriangle, Users, DollarSign, Search, 
    ArrowUpDown, Filter, Download, Send, Calendar, FileSpreadsheet, FileText
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// --- Types ---
interface ArCustomer {
    id: string;
    name: string;
    phone: string;
    totalBalance: number;
    lastPaymentDate: Date | null;
    buckets: {
        current: number; // 0-7 days
        weekly: number;  // 8-14 days
        monthly: number; // 15-30 days
        critical: number; // 30+ days
    };
}

// --- Constants ---
const COLORS = {
    current: '#10b981', // emerald-500
    weekly: '#f59e0b',  // amber-500
    monthly: '#f97316', // orange-500
    critical: '#ef4444', // rose-500
};

// --- Components ---

const GlassCard: React.FC<{ children: React.ReactNode; className?: string; title?: string }> = ({ children, className = '', title }) => (
    <div className={`bg-white/60 backdrop-blur-xl border border-white/50 rounded-2xl shadow-[0_8px_32px_rgba(0,0,0,0.05)] overflow-hidden ${className}`}>
        {title && (
            <div className="px-6 py-4 border-b border-white/40 flex justify-between items-center">
                <h3 className="font-bold text-slate-700 text-lg">{title}</h3>
            </div>
        )}
        <div className="p-6">{children}</div>
    </div>
);

const SummaryWidget: React.FC<{ title: string; value: string; subtitle?: string; icon: React.ReactNode; color: string }> = ({ title, value, subtitle, icon, color }) => (
    <div className="relative group bg-white/60 backdrop-blur-md border border-white/50 rounded-2xl p-5 shadow-sm hover:shadow-lg transition-all duration-300">
        <div className={`absolute top-4 right-4 p-2 rounded-xl bg-${color}-100/50 text-${color}-600`}>
            {icon}
        </div>
        <p className="text-sm font-semibold text-slate-500 uppercase tracking-wider">{title}</p>
        <p className="text-3xl font-bold text-slate-800 mt-2">{value}</p>
        {subtitle && <p className="text-xs font-medium text-slate-400 mt-1">{subtitle}</p>}
        <div className={`absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-${color}-400 to-${color}-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-b-2xl`} />
    </div>
);

const AccountsReceivable: React.FC = () => {
    const { getOrders, getCustomers, _version } = useData();
    const navigate = useNavigate();

    const [arData, setArData] = useState<ArCustomer[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState('');
    const [sortConfig, setSortConfig] = useState<{ key: string; direction: 'asc' | 'desc' }>({ key: 'totalBalance', direction: 'desc' });

    // --- Data Processing ---
    useEffect(() => {
        const fetchData = async () => {
            setIsLoading(true);
            const [orders, customers] = await Promise.all([getOrders(), getCustomers()]);

            const customerMap = new Map<string, ArCustomer>();
            const today = new Date();
            today.setHours(0, 0, 0, 0);

            // Initialize map with customers
            customers.forEach(c => {
                customerMap.set(c.id, {
                    id: c.id,
                    name: c.name || 'Unknown',
                    phone: c.phone1,
                    totalBalance: 0,
                    lastPaymentDate: null, // Mocking this or deriving from orders
                    buckets: { current: 0, weekly: 0, monthly: 0, critical: 0 }
                });
            });

            // Process Orders to Calculate Buckets
            orders.forEach(order => {
                // FIX: Exclude 'Delivered' orders because debt transfers to the Courier/Agent (Account 1502)
                // The Customer (Account 1501) is no longer liable once Delivered in this workflow.
                if (order.status === 'Cancelled' || order.status === 'Paid' || order.status === 'Delivered') return;
                
                const balance = order.totalPrice - order.paidAmount;
                if (balance <= 0) return;

                const customer = customerMap.get(order.customerId);
                if (!customer) return;

                customer.totalBalance += balance;

                // Aging Logic
                const dueDate = order.estimatedDueDate ? new Date(order.estimatedDueDate) : new Date(order.createdAt);
                dueDate.setHours(0,0,0,0);
                
                // Calculate days PAST due (positive = overdue)
                const diffTime = today.getTime() - dueDate.getTime();
                const daysDiff = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

                if (daysDiff <= 7) {
                    customer.buckets.current += balance; // 0-7 Days
                } else if (daysDiff <= 14) {
                    customer.buckets.weekly += balance; // 8-14 Days
                } else if (daysDiff <= 30) {
                    customer.buckets.monthly += balance; // 15-30 Days
                } else {
                    customer.buckets.critical += balance; // 30+ Days
                }
                
                if (!customer.lastPaymentDate || new Date(order.createdAt) > customer.lastPaymentDate) {
                    customer.lastPaymentDate = new Date(order.createdAt); 
                }
            });

            const activeDebtors = Array.from(customerMap.values()).filter(c => c.totalBalance > 1); 
            setArData(activeDebtors);
            setIsLoading(false);
        };

        fetchData();
    }, [_version, getOrders, getCustomers]);

    // --- Derived Statistics ---
    const stats = useMemo(() => {
        const totalOutstanding = arData.reduce((sum, c) => sum + c.totalBalance, 0);
        const totalCurrent = arData.reduce((sum, c) => sum + c.buckets.current, 0);
        const totalOverdue = totalOutstanding - totalCurrent;
        const countDebtors = arData.length;
        const efficiency = totalOutstanding > 0 ? (totalCurrent / totalOutstanding) * 100 : 100;

        // Forecast
        const cashInflow7Days = totalCurrent * 0.95; 
        const cashInflow14Days = cashInflow7Days + (arData.reduce((sum, c) => sum + c.buckets.weekly, 0) * 0.70); 

        return { totalOutstanding, totalOverdue, countDebtors, efficiency, cashInflow7Days, cashInflow14Days };
    }, [arData]);

    // --- Chart Data ---
    const bucketChartData = useMemo(() => {
        const sums = arData.reduce((acc, curr) => ({
            current: acc.current + curr.buckets.current,
            weekly: acc.weekly + curr.buckets.weekly,
            monthly: acc.monthly + curr.buckets.monthly,
            critical: acc.critical + curr.buckets.critical,
        }), { current: 0, weekly: 0, monthly: 0, critical: 0 });

        return [
            { name: '0-7 Days', value: sums.current, color: COLORS.current },
            { name: '8-14 Days', value: sums.weekly, color: COLORS.weekly },
            { name: '15-30 Days', value: sums.monthly, color: COLORS.monthly },
            { name: '30+ Days', value: sums.critical, color: COLORS.critical },
        ];
    }, [arData]);

    const topDebtorsChartData = useMemo(() => {
        return [...arData]
            .sort((a, b) => b.totalBalance - a.totalBalance)
            .slice(0, 5)
            .map(c => ({ name: c.name, value: c.totalBalance }));
    }, [arData]);

    // --- Sorting & Filtering ---
    const processedTableData = useMemo(() => {
        let data = [...arData];
        
        if (searchQuery) {
            const q = searchQuery.toLowerCase();
            data = data.filter(c => c.name.toLowerCase().includes(q) || c.phone.includes(q));
        }

        data.sort((a, b) => {
            let valA: any = a[sortConfig.key as keyof ArCustomer];
            let valB: any = b[sortConfig.key as keyof ArCustomer];

            // Handle nested bucket sorting
            if (sortConfig.key.startsWith('bucket_')) {
                const bucketKey = sortConfig.key.split('_')[1] as keyof typeof a.buckets;
                valA = a.buckets[bucketKey];
                valB = b.buckets[bucketKey];
            }

            if (valA < valB) return sortConfig.direction === 'asc' ? -1 : 1;
            if (valA > valB) return sortConfig.direction === 'asc' ? 1 : -1;
            return 0;
        });

        return data;
    }, [arData, searchQuery, sortConfig]);

    const handleSort = (key: string) => {
        setSortConfig(prev => ({
            key,
            direction: prev.key === key && prev.direction === 'desc' ? 'asc' : 'desc'
        }));
    };

    const formatCurrency = (val: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(val);

    // --- Export Functions ---
    const handleExportExcel = () => {
        const XLSX = (window as any).XLSX;
        if (!XLSX) return alert("Excel library not loaded");

        const exportData = processedTableData.map(c => ({
            "Customer Name": c.name,
            "Phone": c.phone,
            "Total Balance": c.totalBalance,
            "0-7 Days": c.buckets.current,
            "8-14 Days": c.buckets.weekly,
            "15-30 Days": c.buckets.monthly,
            "30+ Days": c.buckets.critical,
            "Last Payment": c.lastPaymentDate ? c.lastPaymentDate.toLocaleDateString() : '-'
        }));

        const ws = XLSX.utils.json_to_sheet(exportData);
        // Set column widths
        ws['!cols'] = [
            { wch: 25 }, { wch: 15 }, { wch: 15 }, { wch: 12 }, { wch: 12 }, { wch: 12 }, { wch: 12 }, { wch: 15 }
        ];

        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Receivables");
        XLSX.writeFile(wb, `AR_Report_${new Date().toISOString().split('T')[0]}.xlsx`);
    };

    const handleExportPdf = () => {
        const { jsPDF } = (window as any).jspdf;
        if (!jsPDF) return alert("PDF library not loaded");

        const doc = new jsPDF({ orientation: 'landscape' }); // Landscape for better table fit
        const pageWidth = doc.internal.pageSize.getWidth();
        const pageHeight = doc.internal.pageSize.getHeight();
        const margin = 14;
        let cursorY = 0;

        // Colors
        const colors = {
            primary: '#0f172a', // Slate 900
            accent: '#0ea5e9', // Sky 500
            success: '#10b981', // Emerald 500
            danger: '#ef4444', // Rose 500
            warning: '#f59e0b', // Amber 500
            light: '#f8fafc', // Slate 50
            text: '#334155' // Slate 700
        };

        // 1. Professional Header (Full Width)
        doc.setFillColor(colors.primary);
        doc.rect(0, 0, pageWidth, 35, 'F');

        doc.setFontSize(22);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor('#ffffff');
        doc.text('Accounts Receivable Intelligence Report', margin, 18);
        
        doc.setFontSize(10);
        doc.setFont('helvetica', 'normal');
        doc.setTextColor('#94a3b8'); // Slate 400
        doc.text(`Generated on: ${new Date().toLocaleString()}`, margin, 26);
        
        doc.setTextColor('#ffffff');
        doc.text('Financial Management System', pageWidth - margin, 18, { align: 'right' });
        doc.setTextColor('#94a3b8');
        doc.text('Confidential Internal Document', pageWidth - margin, 26, { align: 'right' });

        cursorY = 50;

        // 2. Visual KPI Summary Cards
        const cardWidth = (pageWidth - (margin * 2) - 15) / 4;
        const cardHeight = 24;
        
        const drawCard = (x: number, title: string, value: string, color: string, iconChar: string) => {
            // Card shadow/bg
            doc.setFillColor(255, 255, 255);
            doc.setDrawColor(226, 232, 240); // Slate 200
            doc.roundedRect(x, cursorY, cardWidth, cardHeight, 2, 2, 'FD');
            
            // Color indicator bar
            doc.setFillColor(color);
            doc.rect(x, cursorY, 1.5, cardHeight, 'F');

            // Title
            doc.setFontSize(8);
            doc.setTextColor(100, 116, 139); // Slate 500
            doc.setFont('helvetica', 'bold');
            doc.text(title.toUpperCase(), x + 5, cursorY + 8);

            // Value
            doc.setFontSize(12);
            doc.setTextColor(15, 23, 42); // Slate 900
            doc.text(value, x + 5, cursorY + 18);
        };

        drawCard(margin, 'Total Outstanding', formatCurrency(stats.totalOutstanding), colors.accent, '$');
        drawCard(margin + cardWidth + 5, 'Overdue Amount', formatCurrency(stats.totalOverdue), colors.danger, '!');
        drawCard(margin + (cardWidth * 2) + 10, 'Collection Efficiency', `${stats.efficiency.toFixed(1)}%`, colors.success, '%');
        drawCard(margin + (cardWidth * 3) + 15, 'Active Debtors', stats.countDebtors.toString(), '#6366f1', '#');

        cursorY += cardHeight + 15;

        // 3. The Data Table
        const tableColumn = ["Customer", "Phone", "Total Balance", "0-7 Days", "8-14 Days", "15-30 Days", "30+ Days"];
        const tableRows = processedTableData.map(row => [
            row.name,
            row.phone,
            formatCurrency(row.totalBalance),
            row.buckets.current > 0 ? formatCurrency(row.buckets.current) : '-',
            row.buckets.weekly > 0 ? formatCurrency(row.buckets.weekly) : '-',
            row.buckets.monthly > 0 ? formatCurrency(row.buckets.monthly) : '-',
            row.buckets.critical > 0 ? formatCurrency(row.buckets.critical) : '-'
        ]);

        (doc as any).autoTable({
            startY: cursorY,
            head: [tableColumn],
            body: tableRows,
            theme: 'grid',
            headStyles: { 
                fillColor: [248, 250, 252], // Slate 50
                textColor: [71, 85, 105], // Slate 600
                fontStyle: 'bold',
                lineWidth: 0.1,
                lineColor: [226, 232, 240], // Slate 200
                halign: 'center'
            },
            styles: {
                fontSize: 9,
                cellPadding: 3,
                textColor: [51, 65, 85], // Slate 700
                lineColor: [241, 245, 249], // Slate 100
                lineWidth: 0.1,
            },
            columnStyles: {
                0: { fontStyle: 'bold', halign: 'left' },
                1: { halign: 'left', fontSize: 8, textColor: [100, 116, 139] },
                2: { halign: 'right', fontStyle: 'bold', textColor: [15, 23, 42] }, // Total Balance
                3: { halign: 'right', textColor: [16, 185, 129] }, // 0-7 (Emerald)
                4: { halign: 'right', textColor: [245, 158, 11] }, // 8-14 (Amber)
                5: { halign: 'right', textColor: [249, 115, 22] }, // 15-30 (Orange)
                6: { halign: 'right', fontStyle: 'bold', textColor: [239, 68, 68] }, // 30+ (Red)
            },
            didParseCell: (data: any) => {
                // Highlight Critical Bucket (Column index 6: 30+ Days)
                if (data.section === 'body' && data.column.index === 6) {
                    const val = parseFloat(data.cell.raw.toString().replace(/[^0-9.-]+/g,""));
                    if (val > 0) {
                        data.cell.styles.fillColor = [254, 242, 242]; // Red 50 bg for urgency
                        data.cell.styles.textColor = [220, 38, 38]; // Red 600 text
                    }
                }
            },
            margin: { left: margin, right: margin }
        });

        // 4. Footer
        const pageCount = doc.internal.getNumberOfPages();
        for (let i = 1; i <= pageCount; i++) {
            doc.setPage(i);
            
            // Footer line
            doc.setDrawColor(226, 232, 240);
            doc.line(margin, pageHeight - 12, pageWidth - margin, pageHeight - 12);

            doc.setFontSize(8);
            doc.setTextColor(148, 163, 184);
            doc.text(`Page ${i} of ${pageCount}`, pageWidth - margin, pageHeight - 8, { align: 'right' });
            doc.text('Generated by Integrated Financial Management System', margin, pageHeight - 8);
        }

        doc.save(`AR_Intelligence_Report_${new Date().toISOString().split('T')[0]}.pdf`);
    };


    if (isLoading) return <div className="flex justify-center items-center h-96 text-slate-500">Analyzing Receivables...</div>;

    return (
        <div className="space-y-8 pb-8">
            {/* 1. Hero Stats */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <SummaryWidget 
                    title="Total Outstanding" 
                    value={formatCurrency(stats.totalOutstanding)} 
                    icon={<DollarSign />} 
                    color="sky" 
                />
                <SummaryWidget 
                    title="Overdue Amount" 
                    value={formatCurrency(stats.totalOverdue)} 
                    subtitle="Older than 7 days" 
                    icon={<AlertTriangle />} 
                    color="rose" 
                />
                <SummaryWidget 
                    title="Collection Efficiency" 
                    value={`${stats.efficiency.toFixed(1)}%`} 
                    subtitle="Debt within 0-7 days" 
                    icon={<TrendingUp />} 
                    color="emerald" 
                />
                <SummaryWidget 
                    title="Active Debtors" 
                    value={stats.countDebtors.toString()} 
                    icon={<Users />} 
                    color="indigo" 
                />
            </div>

            {/* 2. Charts & Forecast */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <GlassCard title="Aging Breakdown" className="lg:col-span-2">
                    <div className="h-64">
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={bucketChartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                                <XAxis dataKey="name" stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                                <Tooltip 
                                    cursor={{fill: 'transparent'}}
                                    contentStyle={{ backgroundColor: 'rgba(255,255,255,0.8)', borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px rgba(0,0,0,0.1)' }}
                                />
                                <Bar dataKey="value" radius={[6, 6, 0, 0]} barSize={60}>
                                    {bucketChartData.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={entry.color} />
                                    ))}
                                </Bar>
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                </GlassCard>

                <div className="space-y-6">
                    {/* Cash Forecast Card */}
                    <div className="bg-gradient-to-br from-sky-500 to-cyan-600 rounded-2xl p-6 text-white shadow-lg">
                        <h3 className="font-bold text-white/90 text-lg flex items-center gap-2">
                            <Calendar size={18}/> Cash Forecast
                        </h3>
                        <div className="mt-4 space-y-4">
                            <div>
                                <p className="text-sky-100 text-xs uppercase font-semibold">Est. Inflow (7 Days)</p>
                                <p className="text-2xl font-bold">{formatCurrency(stats.cashInflow7Days)}</p>
                            </div>
                            <div className="pt-4 border-t border-white/20">
                                <p className="text-sky-100 text-xs uppercase font-semibold">Est. Inflow (14 Days)</p>
                                <p className="text-2xl font-bold">{formatCurrency(stats.cashInflow14Days)}</p>
                            </div>
                        </div>
                    </div>

                    {/* Concentration Risk */}
                    <GlassCard title="Top 5 Debtors">
                        <div className="h-40">
                            <ResponsiveContainer width="100%" height="100%">
                                <PieChart>
                                    <Pie data={topDebtorsChartData} innerRadius={40} outerRadius={60} paddingAngle={5} dataKey="value">
                                        {topDebtorsChartData.map((entry, index) => (
                                            <Cell key={`cell-${index}`} fill={['#0ea5e9', '#3b82f6', '#6366f1', '#8b5cf6', '#a855f7'][index % 5]} />
                                        ))}
                                    </Pie>
                                    <Tooltip />
                                </PieChart>
                            </ResponsiveContainer>
                        </div>
                        <div className="text-center text-xs text-slate-500 mt-2">Concentration Risk</div>
                    </GlassCard>
                </div>
            </div>

            {/* 3. Smart Aging Table */}
            <GlassCard className="overflow-visible">
                <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
                    <h3 className="text-xl font-bold text-slate-800">Detailed Aging Report</h3>
                    <div className="relative w-full md:w-72">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                        <input 
                            type="text" 
                            placeholder="Search customer..." 
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="w-full pl-10 pr-4 py-2 bg-white/50 border border-white/40 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-sky-500/50"
                        />
                    </div>
                </div>

                <div className="overflow-x-auto -mx-6">
                    <table className="w-full min-w-[1000px]">
                        <thead className="bg-slate-50/50 border-b border-white/40 text-left">
                            <tr>
                                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase cursor-pointer hover:text-sky-600" onClick={() => handleSort('name')}>
                                    <div className="flex items-center gap-1">Customer <ArrowUpDown size={12}/></div>
                                </th>
                                <th className="px-6 py-4 text-right text-xs font-bold text-slate-500 uppercase cursor-pointer hover:text-sky-600" onClick={() => handleSort('totalBalance')}>
                                    <div className="flex items-center justify-end gap-1">Total Balance <ArrowUpDown size={12}/></div>
                                </th>
                                <th className="px-6 py-4 text-right text-xs font-bold text-emerald-600 uppercase cursor-pointer" onClick={() => handleSort('bucket_current')}>0-7 Days</th>
                                <th className="px-6 py-4 text-right text-xs font-bold text-amber-600 uppercase cursor-pointer" onClick={() => handleSort('bucket_weekly')}>8-14 Days</th>
                                <th className="px-6 py-4 text-right text-xs font-bold text-orange-600 uppercase cursor-pointer" onClick={() => handleSort('bucket_monthly')}>15-30 Days</th>
                                <th className="px-6 py-4 text-right text-xs font-bold text-rose-600 uppercase cursor-pointer" onClick={() => handleSort('bucket_critical')}>30+ Days</th>
                                <th className="px-6 py-4 text-center text-xs font-bold text-slate-500 uppercase">Last Activity</th>
                                <th className="px-6 py-4 text-center text-xs font-bold text-slate-500 uppercase">Action</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-white/40">
                            <AnimatePresence>
                                {processedTableData.map((customer) => (
                                    <motion.tr 
                                        key={customer.id}
                                        initial={{ opacity: 0 }}
                                        animate={{ opacity: 1 }}
                                        exit={{ opacity: 0 }}
                                        className="hover:bg-sky-50/30 transition-colors group"
                                    >
                                        <td className="px-6 py-4">
                                            <p className="font-bold text-slate-800">{customer.name}</p>
                                            <p className="text-xs text-slate-500">{customer.phone}</p>
                                        </td>
                                        <td className="px-6 py-4 text-right font-mono font-bold text-slate-800">
                                            {formatCurrency(customer.totalBalance)}
                                        </td>
                                        <td className="px-6 py-4 text-right font-mono text-emerald-600 font-medium">
                                            {customer.buckets.current > 0 ? formatCurrency(customer.buckets.current) : '-'}
                                        </td>
                                        <td className="px-6 py-4 text-right font-mono text-amber-600 font-medium">
                                            {customer.buckets.weekly > 0 ? formatCurrency(customer.buckets.weekly) : '-'}
                                        </td>
                                        <td className="px-6 py-4 text-right font-mono text-orange-600 font-medium">
                                            {customer.buckets.monthly > 0 ? formatCurrency(customer.buckets.monthly) : '-'}
                                        </td>
                                        <td className={`px-6 py-4 text-right font-mono font-bold ${customer.buckets.critical > 0 ? 'text-rose-600 bg-rose-50/50 rounded-lg' : 'text-slate-400'}`}>
                                            {customer.buckets.critical > 0 ? formatCurrency(customer.buckets.critical) : '-'}
                                        </td>
                                        <td className="px-6 py-4 text-center text-sm text-slate-500">
                                            {customer.lastPaymentDate ? customer.lastPaymentDate.toLocaleDateString() : 'N/A'}
                                        </td>
                                        <td className="px-6 py-4 text-center">
                                            <button 
                                                onClick={() => navigate('/party-statements', { state: { customerId: customer.id } })}
                                                className="p-2 rounded-full bg-white border border-slate-200 text-slate-500 hover:text-sky-600 hover:border-sky-300 hover:shadow-md transition-all"
                                                title="View Statement"
                                            >
                                                <Send size={16} />
                                            </button>
                                        </td>
                                    </motion.tr>
                                ))}
                            </AnimatePresence>
                        </tbody>
                    </table>
                </div>
            </GlassCard>

            <motion.div
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.5, type: 'spring', stiffness: 100 }}
                className="fixed bottom-6 right-6 z-40"
            >
                <div className="bg-white/70 backdrop-blur-md border border-white/50 rounded-full shadow-lg flex items-center gap-1 p-2">
                    <button onClick={handleExportExcel} className="flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold text-emerald-800 hover:bg-emerald-100/50 transition-colors" title="Export to Excel">
                        <FileSpreadsheet size={16} />
                        <span>Excel</span>
                    </button>
                    <button onClick={handleExportPdf} className="flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold text-sky-800 hover:bg-sky-100/50 transition-colors" title="Export to PDF">
                        <FileText size={16} />
                        <span>PDF</span>
                    </button>
                </div>
            </motion.div>
        </div>
    );
};

export default AccountsReceivable;
