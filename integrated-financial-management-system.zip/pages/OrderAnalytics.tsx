
import React, { useState, useEffect, useMemo } from 'react';
import { useData } from '../context/DataContext';
import { CustomerOrder, OrderStatus, Agent } from '../types';
import { motion, AnimatePresence } from 'framer-motion';
import {
    AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer,
    PieChart, Pie, Cell, Label, LineChart, Line
} from 'recharts';
import {
    Calendar, ChevronLeft, ChevronRight, TrendingUp, TrendingDown,
    Package, CheckCircle, Truck, AlertCircle, Trophy, User, Medal
} from 'lucide-react';

// --- TYPES ---
interface DailyData {
    day: number;
    orders: number;
    delivered: number;
}

interface AgentRank {
    id: string;
    name: string;
    count: number;
    share: number;
}

// --- COMPONENTS ---

const GlassContainer: React.FC<{ children: React.ReactNode; className?: string; title?: string }> = ({ children, className = '', title }) => (
    <div className={`bg-white/60 dark:bg-slate-900/60 backdrop-blur-2xl border border-white/40 dark:border-slate-700/40 rounded-3xl shadow-[0_8px_30px_rgba(0,0,0,0.04)] overflow-hidden ${className}`}>
        {title && (
            <div className="px-6 py-4 border-b border-white/30 dark:border-slate-700/30 flex justify-between items-center">
                <h3 className="text-base font-bold text-slate-800 dark:text-slate-100 uppercase tracking-wider">{title}</h3>
            </div>
        )}
        <div className="p-6 relative h-full">{children}</div>
    </div>
);

const TrendIndicator: React.FC<{ value: number }> = ({ value }) => {
    if (value === 0) return <span className="text-slate-400 text-xs font-medium">– 0%</span>;
    const isPositive = value > 0;
    return (
        <div className={`flex items-center text-xs font-bold ${isPositive ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'}`}>
            {isPositive ? <TrendingUp size={14} className="mr-1" /> : <TrendingDown size={14} className="mr-1" />}
            {Math.abs(value).toFixed(1)}%
        </div>
    );
};

const KPICard: React.FC<{
    title: string;
    value: number | string;
    trend: number;
    icon: React.ReactNode;
    color: 'blue' | 'amber' | 'emerald' | 'rose';
    chartData?: any[];
}> = ({ title, value, trend, icon, color, chartData }) => {
    const colorClasses = {
        blue: 'bg-blue-100 text-blue-600',
        amber: 'bg-amber-100 text-amber-600',
        emerald: 'bg-emerald-100 text-emerald-600',
        rose: 'bg-rose-100 text-rose-600'
    };

    const chartColors = {
        blue: '#3b82f6',
        amber: '#f59e0b',
        emerald: '#10b981',
        rose: '#f43f5e'
    };

    return (
        <GlassContainer className="relative !overflow-hidden min-h-[160px] flex flex-col justify-between transition-transform hover:scale-[1.02] duration-300">
             {/* Subtle background chart */}
             {chartData && (
                <div className="absolute bottom-0 left-0 right-0 h-20 opacity-20 pointer-events-none">
                    <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={chartData}>
                            <defs>
                                <linearGradient id={`grad-${color}`} x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor={chartColors[color]} stopOpacity={0.8}/>
                                    <stop offset="95%" stopColor={chartColors[color]} stopOpacity={0}/>
                                </linearGradient>
                            </defs>
                            <Area type="monotone" dataKey="val" stroke={chartColors[color]} fill={`url(#grad-${color})`} strokeWidth={2} />
                        </AreaChart>
                    </ResponsiveContainer>
                </div>
            )}
            
            <div className="relative z-10 flex justify-between items-start">
                <div>
                    <p className="text-sm font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide">{title}</p>
                    <div className="mt-2 flex items-baseline gap-3">
                        <h2 className="text-4xl font-bold text-slate-800 dark:text-white tracking-tight">{value}</h2>
                    </div>
                </div>
                <div className={`p-3 rounded-2xl ${colorClasses[color]} bg-opacity-50 backdrop-blur-sm shadow-inner`}>
                    {icon}
                </div>
            </div>
            
            <div className="relative z-10 mt-4 flex items-center gap-2">
                <TrendIndicator value={trend} />
                <span className="text-xs text-slate-400 font-medium">vs last month</span>
            </div>
        </GlassContainer>
    );
};

const AgentRow: React.FC<{ agent: AgentRank; index: number; maxCount: number }> = ({ agent, index, maxCount }) => {
    const medals = [
        <Medal size={20} className="text-yellow-500 drop-shadow-sm" />,
        <Medal size={20} className="text-slate-400 drop-shadow-sm" />,
        <Medal size={20} className="text-amber-700 drop-shadow-sm" />
    ];

    return (
        <div className="flex items-center gap-4 py-3 border-b border-white/30 dark:border-slate-700/30 last:border-0">
            <div className="w-8 flex justify-center font-bold text-slate-400">
                {index < 3 ? medals[index] : <span className="text-sm">#{index + 1}</span>}
            </div>
            <div className="flex-1">
                <div className="flex justify-between items-center mb-1">
                    <span className="font-semibold text-slate-700 dark:text-slate-200 text-sm">{agent.name || 'Unknown Agent'}</span>
                    <span className="font-mono font-bold text-slate-800 dark:text-white text-sm">{agent.count}</span>
                </div>
                <div className="w-full bg-slate-100 dark:bg-slate-700 rounded-full h-1.5 overflow-hidden">
                    <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${(agent.count / maxCount) * 100}%` }}
                        transition={{ duration: 1, ease: "easeOut" }}
                        className="bg-gradient-to-r from-sky-400 to-blue-600 h-full rounded-full"
                    />
                </div>
            </div>
        </div>
    );
};

// --- MAIN PAGE ---

const OrderAnalytics: React.FC = () => {
    const { getOrders, getAgents, _version } = useData();
    
    // State
    const [orders, setOrders] = useState<CustomerOrder[]>([]);
    const [agents, setAgents] = useState<Agent[]>([]);
    const [selectedDate, setSelectedDate] = useState(new Date());
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        setIsLoading(true);
        Promise.all([getOrders(), getAgents()]).then(([fetchedOrders, fetchedAgents]) => {
            setOrders(fetchedOrders);
            setAgents(fetchedAgents);
            setIsLoading(false);
        });
    }, [_version]);

    // --- Derived Data ---

    const stats = useMemo(() => {
        const currentMonth = selectedDate.getMonth();
        const currentYear = selectedDate.getFullYear();
        const prevDate = new Date(selectedDate);
        prevDate.setMonth(currentMonth - 1);
        const prevMonth = prevDate.getMonth();
        const prevYear = prevDate.getFullYear();

        const currentOrders = orders.filter(o => {
            const d = new Date(o.createdAt);
            return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
        });

        const prevOrders = orders.filter(o => {
            const d = new Date(o.createdAt);
            return d.getMonth() === prevMonth && d.getFullYear() === prevYear;
        });

        // Helper for percentages
        const calcTrend = (curr: number, prev: number) => prev === 0 ? 0 : ((curr - prev) / prev) * 100;

        // Metrics
        const total = currentOrders.length;
        const totalPrev = prevOrders.length;
        
        const pending = currentOrders.filter(o => o.status !== OrderStatus.Delivered && o.status !== OrderStatus.Paid && o.status !== OrderStatus.Cancelled).length;
        const pendingPrev = prevOrders.filter(o => o.status !== OrderStatus.Delivered && o.status !== OrderStatus.Paid && o.status !== OrderStatus.Cancelled).length;

        const delivered = currentOrders.filter(o => o.status === OrderStatus.Delivered || o.status === OrderStatus.Paid).length;
        const deliveredPrev = prevOrders.filter(o => o.status === OrderStatus.Delivered || o.status === OrderStatus.Paid).length;

        const returned = currentOrders.filter(o => o.status === OrderStatus.Cancelled).length;
        const returnedPrev = prevOrders.filter(o => o.status === OrderStatus.Cancelled).length;

        // Daily Volume Data
        const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
        const volumeData = Array.from({ length: daysInMonth }, (_, i) => {
            const day = i + 1;
            const dayOrders = currentOrders.filter(o => new Date(o.createdAt).getDate() === day);
            return {
                day,
                orders: dayOrders.length,
                delivered: dayOrders.filter(o => o.status === OrderStatus.Delivered || o.status === OrderStatus.Paid).length,
                val: dayOrders.length // for sparklines
            };
        });

        // Fulfillment Donut Data
        const donutData = [
            { name: 'Delivered', value: delivered, color: '#10b981' },
            { name: 'Pending', value: pending, color: '#f59e0b' },
            { name: 'Returned', value: returned, color: '#f43f5e' }
        ].filter(d => d.value > 0);

        // Agent Ranking
        const agentMap = new Map<string, number>();
        currentOrders.forEach(o => {
            if (o.agentId) {
                agentMap.set(o.agentId, (agentMap.get(o.agentId) || 0) + 1);
            }
        });

        const agentRanking: AgentRank[] = Array.from(agentMap.entries())
            .map(([id, count]) => {
                const agent = agents.find(a => a.id === id);
                return { id, name: agent?.name || 'Unknown', count, share: (count / total) * 100 };
            })
            .sort((a, b) => b.count - a.count)
            .slice(0, 5);

        return {
            total,
            totalTrend: calcTrend(total, totalPrev),
            pending,
            pendingTrend: calcTrend(pending, pendingPrev),
            delivered,
            deliveredTrend: calcTrend(delivered, deliveredPrev),
            returned,
            returnedTrend: calcTrend(returned, returnedPrev),
            volumeData,
            donutData,
            agentRanking,
            successRate: total > 0 ? Math.round((delivered / total) * 100) : 0
        };

    }, [orders, agents, selectedDate]);

    // Handlers
    const changeMonth = (delta: number) => {
        const newDate = new Date(selectedDate);
        newDate.setMonth(newDate.getMonth() + delta);
        setSelectedDate(newDate);
    };

    if (isLoading) return <div className="flex items-center justify-center h-full text-slate-500">Loading Analytics...</div>;

    return (
        <div className="space-y-8 pb-10">
            
            {/* 1. Control Deck */}
            <div className="sticky top-0 z-40 flex justify-center">
                <div className="bg-white/70 dark:bg-slate-800/70 backdrop-blur-xl border border-white/50 dark:border-slate-700/50 rounded-full shadow-xl px-6 py-2 flex items-center gap-6">
                    <button onClick={() => changeMonth(-1)} className="p-2 rounded-full hover:bg-white/50 dark:hover:bg-slate-700/50 text-slate-600 dark:text-slate-300 transition-colors">
                        <ChevronLeft size={20} />
                    </button>
                    <div className="flex flex-col items-center min-w-[140px]">
                        <span className="text-lg font-bold text-slate-800 dark:text-white">{selectedDate.toLocaleDateString('en-US', { month: 'long' })}</span>
                        <span className="text-xs font-medium text-slate-500 dark:text-slate-400">{selectedDate.getFullYear()}</span>
                    </div>
                    <button onClick={() => changeMonth(1)} className="p-2 rounded-full hover:bg-white/50 dark:hover:bg-slate-700/50 text-slate-600 dark:text-slate-300 transition-colors">
                        <ChevronRight size={20} />
                    </button>
                </div>
            </div>

            {/* 2. Pulse Cards (KPIs) */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <KPICard 
                    title="Total Orders" 
                    value={stats.total} 
                    trend={stats.totalTrend} 
                    icon={<Package size={24} />} 
                    color="blue" 
                    chartData={stats.volumeData.map(d => ({ val: d.orders }))}
                />
                <KPICard 
                    title="Pending Actions" 
                    value={stats.pending} 
                    trend={stats.pendingTrend} 
                    icon={<Truck size={24} />} 
                    color="amber"
                />
                <KPICard 
                    title="Delivered" 
                    value={stats.delivered} 
                    trend={stats.deliveredTrend} 
                    icon={<CheckCircle size={24} />} 
                    color="emerald" 
                    chartData={stats.volumeData.map(d => ({ val: d.delivered }))}
                />
                <KPICard 
                    title="Returned" 
                    value={stats.returned} 
                    trend={stats.returnedTrend} 
                    icon={<AlertCircle size={24} />} 
                    color="rose" 
                />
            </div>

            {/* 3. Visual Story */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[400px]">
                {/* Volume Wave */}
                <GlassContainer className="lg:col-span-2 flex flex-col" title="Daily Order Volume">
                    <div className="flex-1 min-h-0 mt-4">
                        <ResponsiveContainer width="100%" height="100%">
                            <AreaChart data={stats.volumeData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                                <defs>
                                    <linearGradient id="colorOrders" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="5%" stopColor="#38bdf8" stopOpacity={0.5}/>
                                        <stop offset="95%" stopColor="#38bdf8" stopOpacity={0}/>
                                    </linearGradient>
                                </defs>
                                <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 12 }} />
                                <YAxis axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 12 }} />
                                <Tooltip 
                                    contentStyle={{ backgroundColor: 'rgba(255,255,255,0.8)', backdropFilter: 'blur(10px)', border: 'none', borderRadius: '12px', boxShadow: '0 4px 6px rgba(0,0,0,0.1)' }}
                                    itemStyle={{ color: '#0f172a', fontWeight: 'bold' }}
                                    labelStyle={{ color: '#64748b', marginBottom: '0.25rem' }}
                                    formatter={(value: number) => [`${value} Orders`, 'Volume']}
                                />
                                <Area type="monotone" dataKey="orders" stroke="#0ea5e9" strokeWidth={3} fillOpacity={1} fill="url(#colorOrders)" />
                            </AreaChart>
                        </ResponsiveContainer>
                    </div>
                </GlassContainer>

                {/* Fulfillment Status Donut */}
                <GlassContainer title="Fulfillment Status">
                    <div className="relative h-full w-full flex items-center justify-center">
                        {stats.total === 0 ? (
                            <div className="text-slate-400 text-sm">No data available</div>
                        ) : (
                            <ResponsiveContainer width="100%" height={300}>
                                <PieChart>
                                    <Pie
                                        data={stats.donutData}
                                        cx="50%"
                                        cy="50%"
                                        innerRadius={60}
                                        outerRadius={85}
                                        paddingAngle={5}
                                        dataKey="value"
                                        cornerRadius={6}
                                    >
                                        {stats.donutData.map((entry, index) => (
                                            <Cell key={`cell-${index}`} fill={entry.color} stroke="none" />
                                        ))}
                                        <Label
                                            value={`${stats.successRate}%`}
                                            position="center"
                                            className="fill-slate-800 dark:fill-white text-3xl font-bold"
                                        />
                                         <Label
                                            value="Success"
                                            position="center"
                                            dy={20}
                                            className="fill-slate-500 dark:fill-slate-400 text-xs font-medium uppercase tracking-wider"
                                        />
                                    </Pie>
                                    <Tooltip />
                                </PieChart>
                            </ResponsiveContainer>
                        )}
                        <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-4">
                            {stats.donutData.map((entry, i) => (
                                <div key={i} className="flex items-center gap-1.5">
                                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: entry.color }} />
                                    <span className="text-xs text-slate-600 dark:text-slate-300 font-medium">{entry.name}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                </GlassContainer>
            </div>

            {/* 4. Agent Leaderboard */}
            <GlassContainer title="Top Performing Agents" className="min-h-[300px]">
                <div className="mt-4">
                    {stats.agentRanking.length === 0 ? (
                        <div className="text-center py-10 text-slate-400">No agent data for this period.</div>
                    ) : (
                        <div className="flex flex-col gap-1">
                            <div className="grid grid-cols-[auto_1fr] gap-4 px-2 pb-2 text-xs font-bold text-slate-400 uppercase tracking-wider">
                                <span className="w-8 text-center">Rank</span>
                                <span>Agent Performance</span>
                            </div>
                            {stats.agentRanking.map((agent, index) => (
                                <AgentRow 
                                    key={agent.id} 
                                    agent={agent} 
                                    index={index} 
                                    maxCount={stats.agentRanking[0].count} 
                                />
                            ))}
                        </div>
                    )}
                </div>
            </GlassContainer>
        </div>
    );
};

export default OrderAnalytics;
