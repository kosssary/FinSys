
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useData } from '../../context/DataContext';
import { Account, JournalVoucher, JournalVoucherLine } from '../../types';
import { motion } from 'framer-motion';
import { 
    Plus, Edit, ChevronsLeft, ChevronLeft, ChevronRight, ChevronsRight, 
    Save, Paperclip, UploadCloud, FileText, FileSpreadsheet, XCircle, Trash2, Eye
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

import { JournalLinesTable } from '../../components/journal/JournalLinesTable';
import { JournalSummaryCard } from '../../components/journal/JournalSummaryCard';
import AccountSelectionModal from '../../components/modals/AccountSelectionModal';
import DescriptionEditModal from '../../components/modals/DescriptionEditModal';

// --- TYPE DEFINITIONS & UTILITIES ---
type ViewMode = 'viewing' | 'editing' | 'creating';
const formatCurrency = (value: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value);


// --- UI PRIMITIVES ---
const AuroraCard: React.FC<{ children: React.ReactNode; className?: string, title?: string }> = ({ children, className = '', title }) => ( <div className={`bg-white/50 backdrop-blur-2xl border border-white/40 rounded-3xl shadow-[0_8px_50px_rgba(0,0,0,0.06)] overflow-hidden ${className}`}> {title && <h3 className="text-sm font-bold text-slate-500 uppercase tracking-wider px-6 pt-5 pb-2">{title}</h3>} <div className={title ? 'p-6 pt-3' : 'p-6'}>{children}</div> </div> );
const AuroraButton: React.FC<React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'secondary' | 'ghost', children: React.ReactNode; }> = ({ variant = 'secondary', children, className = '', ...props }) => { const base = "flex items-center justify-center rounded-2xl px-5 py-3 text-sm font-bold transition-all duration-200 active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none"; const variants = { primary: "bg-gradient-to-r from-sky-500 via-cyan-400 to-emerald-400 text-white shadow-lg hover:scale-[1.02] focus:ring-2 focus:ring-sky-300/60", secondary: "bg-white/70 border border-white/60 text-slate-700 shadow-sm hover:bg-white/80 focus:ring-2 focus:ring-slate-300/60", ghost: "bg-transparent text-slate-600 hover:bg-black/5 !shadow-none !px-3 !py-2 !rounded-lg" }; return <button className={`${base} ${variants[variant]} ${className}`} {...props}>{children}</button>; };
const AuroraToolbar: React.FC<any> = ({ isManual, isSystem, onManualDelete, onViewSource, voucherNumber, viewMode, onNew, onSave, onEdit, onCancel, navigateVoucher, onVoucherSearch }) => {
    const [isEditingNumber, setIsEditingNumber] = useState(false);
    const [searchValue, setSearchValue] = useState('');

    useEffect(() => {
        if (!isEditingNumber) {
            setSearchValue('');
        }
    }, [isEditingNumber]);

    const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'Enter') {
            onVoucherSearch(searchValue);
            setIsEditingNumber(false);
        } else if (e.key === 'Escape') {
            setIsEditingNumber(false);
        }
    };
    
    return (
     <div className="sticky top-2 z-50"> <div className="flex flex-col md:flex-row items-center justify-between gap-4 bg-white/60 backdrop-blur-2xl border border-white/40 rounded-3xl shadow-[0_8px_50px_rgba(0,0,0,0.06)] p-3"> <div className="flex items-center gap-4"> <div><h1 className="text-lg font-bold text-slate-800">Journal Voucher</h1><p className="text-xs font-medium text-slate-500 -mt-1" lang="ar">سەندەی ڕۆژنامە</p></div> <div className="hidden md:flex items-center gap-1 bg-white/50 rounded-2xl border border-white/50 p-1"> <AuroraButton variant="ghost" onClick={() => navigateVoucher('first')}><ChevronsLeft size={18}/></AuroraButton> <AuroraButton variant="ghost" onClick={() => navigateVoucher('prev')}><ChevronLeft size={18}/></AuroraButton> <AuroraButton variant="ghost" onClick={() => navigateVoucher('next')}><ChevronRight size={18}/></AuroraButton> <AuroraButton variant="ghost" onClick={() => navigateVoucher('last')}><ChevronsRight size={18}/></AuroraButton> </div> 
      {isEditingNumber ? (
        <input 
            type="text" 
            value={searchValue}
            onChange={(e) => setSearchValue(e.target.value)}
            onKeyDown={handleKeyDown}
            onBlur={() => setIsEditingNumber(false)}
            autoFocus
            className="font-mono text-lg font-semibold text-sky-600 bg-sky-100/50 border border-sky-200/50 rounded-xl px-4 py-2 w-28 text-center focus:outline-none focus:ring-2 focus:ring-sky-400"
            placeholder={voucherNumber.split('-')[1]}
        />
     ) : (
        <div onClick={() => viewMode === 'viewing' && setIsEditingNumber(true)} className="font-mono text-lg font-semibold text-sky-600 bg-sky-100/50 border border-sky-200/50 rounded-xl px-4 py-2 cursor-pointer min-w-[112px] text-center">{viewMode === 'creating' ? 'NEW' : voucherNumber}</div>
     )}
     </div> <div className="flex items-center gap-2"> 
        {viewMode === 'viewing' ? (
            <>
                {isManual && <AuroraButton onClick={onManualDelete} variant="secondary" className="!bg-rose-500/10 !border-rose-500/20 !text-rose-600 hover:!bg-rose-500/20"><Trash2 size={16} className="mr-2"/>Delete</AuroraButton>}
                {isSystem && <AuroraButton onClick={onViewSource} variant="secondary" className="!bg-indigo-500/10 !border-indigo-500/20 !text-indigo-600 hover:!bg-indigo-500/20"><Eye size={16} className="mr-2"/>View Source</AuroraButton>}
                <AuroraButton onClick={onNew}><Plus size={16} className="mr-2"/>New</AuroraButton>
                {isManual && <AuroraButton variant="primary" onClick={onEdit}><Edit size={16} className="mr-2"/>Edit</AuroraButton>}
            </>
        ) : (
            <>
                <AuroraButton onClick={onCancel}>Cancel</AuroraButton>
                <AuroraButton variant="primary" onClick={onSave}><Save size={16} className="mr-2"/>Save</AuroraButton>
            </>
        )} 
        </div> </div> </div> );
}

// --- MAIN PAGE COMPONENT ---
const JournalVoucherPage: React.FC = () => {
    const { getJournalVouchers, addJournalVoucher, updateJournalVoucher, deleteVoucher, getAccountsList, _version } = useData();
    const navigate = useNavigate();
    
    // Data Stores
    const [allVouchers, setAllVouchers] = useState<JournalVoucher[]>([]);
    const [accounts, setAccounts] = useState<Account[]>([]);

    // UI & Form State
    const [viewMode, setViewMode] = useState<ViewMode>('viewing');
    const [currentVoucherIndex, setCurrentVoucherIndex] = useState(0);
    const [date, setDate] = useState('');
    const [description, setDescription] = useState('');
    const [lines, setLines] = useState<(JournalVoucherLine & { clientId: string })[]>([]);
    const [notes, setNotes] = useState('');
    const [attachments, setAttachments] = useState<File[]>([]);
    
    // Modal State
    const [isAccountModalOpen, setIsAccountModalOpen] = useState(false);
    const [editingLineIndex, setEditingLineIndex] = useState<number | null>(null);
    const [isDescriptionModalOpen, setIsDescriptionModalOpen] = useState(false);
    const [editingDescriptionData, setEditingDescriptionData] = useState<{ index: number; value: string } | null>(null);

    const currentVoucher = allVouchers[currentVoucherIndex];
    const isFormDisabled = viewMode === 'viewing' || (viewMode === 'editing' && !!currentVoucher?.sourceReference);
    const isManual = currentVoucher && !currentVoucher.sourceReference;
    const isSystem = currentVoucher && !!currentVoucher.sourceReference;

    
    const postableAccounts = useMemo(() => accounts.filter(a => a.isPostable), [accounts]);

    const { totalDebit, totalCredit, isBalanced } = useMemo(() => {
        const debit = lines.reduce((sum, line) => sum + (Number(line.debit) || 0), 0);
        const credit = lines.reduce((sum, line) => sum + (Number(line.credit) || 0), 0);
        return { totalDebit: debit, totalCredit: credit, isBalanced: debit > 0 && Math.abs(debit - credit) < 0.001 };
    }, [lines]);

    // Data Fetching
    useEffect(() => {
        Promise.all([ getJournalVouchers(), getAccountsList() ]).then(([vouchers, accs]) => {
            setAllVouchers(vouchers);
            setAccounts(accs);
            if (vouchers.length > 0) { setCurrentVoucherIndex(0); } else { handleNew(); }
        });
    }, [_version]);

    const populateForm = useCallback((voucher: JournalVoucher | null) => {
        if (!voucher) return;
        setDate(new Date(voucher.date).toISOString().split('T')[0]);
        setDescription(voucher.description || '');
        setLines(voucher.lines.map((l, i) => ({ ...l, clientId: `line-${i}-${Date.now()}` })));
        setNotes(''); 
        setAttachments([]);
    }, []);

    useEffect(() => { if (currentVoucher && viewMode === 'viewing') { populateForm(currentVoucher); } }, [currentVoucher, viewMode, populateForm]);

    // Event Handlers
    const handleNew = useCallback(() => {
        setViewMode('creating');
        setDate(new Date().toISOString().split('T')[0]);
        setDescription('');
        setLines([
            { clientId: `line-0-${Date.now()}`, accountId: '', description: '', debit: 0, credit: 0 },
            { clientId: `line-1-${Date.now()}`, accountId: '', description: '', debit: 0, credit: 0 }
        ]);
        setNotes(''); setAttachments([]);
    }, []);

    const handleSave = async () => {
        if (!isBalanced) { alert("Debits and Credits must be balanced and not zero."); return; }
        const validLines = lines.filter(l => l.accountId && (Number(l.debit) > 0 || Number(l.credit) > 0));
        if (validLines.length < 2) { alert("A journal entry must have at least two valid lines."); return; }

        const payload = {
            date: new Date(date),
            // Only use fallback if user didn't type anything, but allow empty string technically if backend handles it
            description: description || 'Journal Voucher',
            lines: validLines.map(({ clientId, ...rest }) => ({...rest, debit: Number(rest.debit), credit: Number(rest.credit)}))
        };
        
        try {
            if (viewMode === 'creating') { await addJournalVoucher(payload); } 
            else if (viewMode === 'editing' && currentVoucher) { await updateJournalVoucher({ voucherId: currentVoucher.voucherId, ...payload }); }
            alert('Voucher saved successfully!');
            setViewMode('viewing');
        } catch (error) { console.error("Save failed:", error); alert("Failed to save voucher."); }
    };
    
    const handleCancel = () => { setViewMode('viewing'); populateForm(currentVoucher); };
    
     const handleDelete = async () => {
        if (!currentVoucher || !isManual) return;
        if (window.confirm(`Are you sure you want to delete manual voucher ${currentVoucher.voucherNumber}?`)) {
            try {
                await deleteVoucher(currentVoucher.voucherId);
                alert('Voucher deleted successfully!');
                // Refetch will handle showing the next/new voucher
            } catch (error) {
                console.error("Delete failed:", error);
                alert(`Failed to delete voucher: ${(error as Error).message}`);
            }
        }
    };

    const handleViewSource = () => {
        if (!currentVoucher || !currentVoucher.sourceReference) return;
        const { type, id } = currentVoucher.sourceReference;
        let path = '/';
        switch (type) {
            case 'Receipt': path = '/receipts'; break;
            case 'Disbursement': path = '/disbursements'; break;
            case 'Order': path = '/orders'; break;
            case 'Bundle': path = '/bundles'; break; // Assuming bundle page exists
            case 'Payroll': path = '/payroll'; break;
        }

        const state: any = {};
        if (type === 'Receipt' || type === 'Disbursement') {
            state.voucherId = id;
        } else {
            state.search = id; // General search for orders/bundles etc.
        }
        navigate(path, { state });
    };
    
    const navigateVoucher = (dir: 'first'|'prev'|'next'|'last') => { 
        if (viewMode !== 'viewing' || allVouchers.length === 0) return; 
        let i = currentVoucherIndex; 
        if (dir === 'first') i = 0; 
        else if (dir === 'last') i = allVouchers.length - 1;
        else if (dir === 'next') i = Math.min(allVouchers.length - 1, i + 1); 
        else if (dir === 'prev') i = Math.max(0, i - 1); 
        setCurrentVoucherIndex(i); 
    };

    const handleVoucherSearch = (searchValue: string) => {
        const num = parseInt(searchValue, 10);
        if (isNaN(num)) return;
        
        const prefixes = ['JV', 'SJV'];
        let found = false;
        for (const prefix of prefixes) {
            const targetVoucherNumber = `${prefix}-${String(num).padStart(3, '0')}`;
            const index = allVouchers.findIndex(v => v.voucherNumber === targetVoucherNumber);
            if (index !== -1) {
                setCurrentVoucherIndex(index);
                found = true;
                break;
            }
        }
        if (!found) {
            alert('Voucher not found.');
        }
    };

    // Attachment Handlers
    const handleFileChange = (files: FileList | null) => {
        if (files) {
            setAttachments(prev => [...prev, ...Array.from(files).slice(0, 5 - prev.length)]);
        }
    };
    const removeAttachment = (index: number) => {
        setAttachments(prev => prev.filter((_, i) => i !== index));
    };
    const [isDragging, setIsDragging] = useState(false);
    const handleDragOver = (e: React.DragEvent<HTMLLabelElement>) => { e.preventDefault(); setIsDragging(true); };
    const handleDragLeave = (e: React.DragEvent<HTMLLabelElement>) => { e.preventDefault(); setIsDragging(false); };
    const handleDrop = (e: React.DragEvent<HTMLLabelElement>) => { e.preventDefault(); setIsDragging(false); if (e.dataTransfer.files) { handleFileChange(e.dataTransfer.files); } };

    // Modal Handlers
    const handleOpenAccountModal = (index: number) => {
        setEditingLineIndex(index);
        setIsAccountModalOpen(true);
    };

    const handleAccountSelect = (account: Account) => {
        if (editingLineIndex !== null) {
            setLines(ls => ls.map((l, i) => {
                if (i !== editingLineIndex) return l;
                return { ...l, accountId: account.id };
            }));
        }
        setIsAccountModalOpen(false);
        setEditingLineIndex(null);
    };

    const handleDescriptionDoubleClick = (index: number, value: string) => {
        setEditingDescriptionData({ index, value });
        setIsDescriptionModalOpen(true);
    };

    const handleSaveDescription = (newValue: string) => {
        if (editingDescriptionData) {
            setLines(ls => ls.map((l, i) => i === editingDescriptionData.index ? { ...l, description: newValue } : l));
        }
    };

    // Export Handlers
    const handleExportExcel = () => {
        if (!currentVoucher) return;
        const XLSX = (window as any).XLSX;
        if (!XLSX) {
            alert("Excel export library is not available.");
            return;
        }
        
        const accountMap = new Map<string, Account>(accounts.map(a => [a.id, a]));

        const headerData = [
            ["Voucher #:", currentVoucher.voucherNumber],
            ["Date:", new Date(currentVoucher.date).toLocaleDateString()],
            ["Description:", currentVoucher.description],
            [], // Spacer
            ["Account Code", "Account Name", "Line Description", "Debit", "Credit"]
        ];
        
        const linesData = currentVoucher.lines.map(line => {
            const account = accountMap.get(line.accountId);
            return [
                account?.code || '',
                account?.name || '',
                line.description,
                line.debit > 0 ? line.debit : null,
                line.credit > 0 ? line.credit : null,
            ];
        });

        const footerData = [
            ["", "", "Total", totalDebit, totalCredit]
        ];

        const worksheet = XLSX.utils.aoa_to_sheet([...headerData, ...linesData, ...footerData]);
        
        worksheet['!cols'] = [
            { wch: 15 }, // Account Code
            { wch: 30 }, // Account Name
            { wch: 40 }, // Line Description
            { wch: 15 }, // Debit
            { wch: 15 }, // Credit
        ];

        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, "Journal Voucher");
        XLSX.writeFile(workbook, `JV_${currentVoucher.voucherNumber}.xlsx`);
    };

    const handleExportPdf = () => {
        if (!currentVoucher) return;
        const { jsPDF } = (window as any).jspdf;
        if (!jsPDF) { alert("PDF export library is not available."); return; }

        const doc = new jsPDF();
        const accountMap = new Map<string, Account>(accounts.map(a => [a.id, a]));
        const formatPdfCurrency = (value: number) => new Intl.NumberFormat('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(value);

        // Header
        doc.setFontSize(18);
        doc.setFont('helvetica', 'bold');
        doc.text('Journal Voucher', 15, 20);

        doc.setFontSize(10);
        doc.setFont('helvetica', 'normal');
        doc.text(`Voucher #: ${currentVoucher.voucherNumber}`, 15, 30);
        doc.text(`Date: ${new Date(currentVoucher.date).toLocaleDateString()}`, 15, 35);
        doc.text(`Description: ${currentVoucher.description}`, 15, 40);

        // Table
        const tableColumn = ["Account", "Description", "Debit", "Credit"];
        const tableRows = currentVoucher.lines.map(line => {
            const account = accountMap.get(line.accountId);
            return [
                `${account?.code} - ${account?.name}`,
                line.description,
                line.debit > 0 ? formatPdfCurrency(line.debit) : '',
                line.credit > 0 ? formatPdfCurrency(line.credit) : ''
            ];
        });

        (doc as any).autoTable({
            head: [tableColumn],
            body: tableRows,
            startY: 50,
            theme: 'grid',
            headStyles: { fillColor: [22, 160, 133] },
            foot: [ ['', 'Total', formatPdfCurrency(totalDebit), formatPdfCurrency(totalCredit)] ],
            footStyles: { fontStyle: 'bold', fillColor: [240, 240, 240], textColor: [0,0,0] },
            didParseCell: (data: any) => {
                if (data.column.index > 1) { data.cell.styles.halign = 'right'; }
            }
        });

        // Footer
        const pageCount = doc.internal.getNumberOfPages();
        for (let i = 1; i <= pageCount; i++) {
            doc.setPage(i);
            doc.setFontSize(8);
            doc.text(`Page ${i} of ${pageCount}`, doc.internal.pageSize.width - 20, doc.internal.pageSize.height - 10);
        }
        
        doc.save(`JV_${currentVoucher.voucherNumber}.pdf`);
    };

    return (
        <div className="max-w-7xl mx-auto space-y-6">
            <AuroraToolbar 
                voucherNumber={currentVoucher?.voucherNumber} 
                viewMode={viewMode} 
                onNew={handleNew} 
                onSave={handleSave} 
                onEdit={() => setViewMode('editing')} 
                onCancel={handleCancel} 
                navigateVoucher={navigateVoucher} 
                onVoucherSearch={handleVoucherSearch}
                isManual={isManual}
                isSystem={isSystem}
                onManualDelete={handleDelete}
                onViewSource={handleViewSource}
            />
            
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
                <AuroraCard>
                    <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                        <input type="date" value={date} onChange={e => setDate(e.target.value)} disabled={isFormDisabled} className="input-glass md:col-span-1" />
                        <input type="text" value={description} onChange={e => setDescription(e.target.value)} placeholder="Voucher Description (e.g., Adjusting entry)" disabled={isFormDisabled} className="input-glass md:col-span-4" />
                    </div>
                </AuroraCard>
            </motion.div>
            
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.1 }}>
                 <JournalLinesTable lines={lines} setLines={setLines} accounts={postableAccounts} disabled={isFormDisabled} onOpenAccountModal={handleOpenAccountModal} onDescriptionDoubleClick={handleDescriptionDoubleClick}/>
            </motion.div>

            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.2 }}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <JournalSummaryCard totalDebit={totalDebit} totalCredit={totalCredit} />
                     <AuroraCard title="Notes & Attachments">
                        <div className="space-y-4">
                            <textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Add internal notes..." disabled={isFormDisabled} rows={2} className="input-glass w-full !h-auto"></textarea>
                            <div>
                                <label htmlFor="file-upload" onDragOver={handleDragOver} onDragLeave={handleDragLeave} onDrop={handleDrop} className={`relative cursor-pointer bg-white/60 rounded-xl border-2 border-dashed  transition-colors w-full flex justify-center items-center text-center p-4 ${isDragging ? 'border-sky-400/80 bg-sky-50/50' : 'border-slate-300/80 hover:border-sky-400/80'}`}>
                                    <UploadCloud size={20} className="text-slate-400 mr-2" />
                                    <span className="text-sm font-semibold text-slate-600">Click to upload or drag & drop</span>
                                    <input id="file-upload" type="file" className="sr-only" multiple disabled={isFormDisabled} onChange={(e) => handleFileChange(e.target.files)} />
                                </label>
                            </div>
                            {attachments.length > 0 && (
                                <div className="space-y-2 pt-2">
                                    {attachments.map((file, index) => (
                                        <div key={index} className="flex items-center justify-between bg-white/50 p-2 rounded-lg text-sm">
                                            <div className="flex items-center gap-2 truncate">
                                                <Paperclip size={16} className="text-slate-500 flex-shrink-0" />
                                                <span className="truncate" title={file.name}>{file.name} - {Math.round(file.size / 1024)} KB</span>
                                            </div>
                                            {!isFormDisabled && <button onClick={() => removeAttachment(index)} className="p-1 text-slate-400 hover:text-red-500 transition"><XCircle size={16} /></button>}
                                        </div>
                                    ))}
                                </div>
                            )}
                        </div>
                     </AuroraCard>
                </div>
            </motion.div>

             <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.3 }} className="flex justify-end items-center gap-2">
                <AuroraButton variant="secondary" onClick={handleExportExcel} disabled={viewMode === 'creating'}><FileSpreadsheet size={16} className="mr-2"/> Export Excel</AuroraButton>
                <AuroraButton variant="secondary" onClick={handleExportPdf} disabled={viewMode === 'creating'}><FileText size={16} className="mr-2"/> Print/PDF</AuroraButton>
                {viewMode !== 'viewing' && <AuroraButton variant="primary" onClick={handleSave} disabled={!isBalanced}><Save size={16} className="mr-2"/> Post Journal</AuroraButton>}
            </motion.div>

            <motion.div>
                <AccountSelectionModal 
                    isOpen={isAccountModalOpen}
                    onClose={() => setIsAccountModalOpen(false)}
                    onSelect={handleAccountSelect}
                    accounts={postableAccounts}
                />
            </motion.div>
            
            <DescriptionEditModal 
                isOpen={isDescriptionModalOpen}
                onClose={() => setIsDescriptionModalOpen(false)}
                initialValue={editingDescriptionData?.value || ''}
                onSave={handleSaveDescription}
            />

            <style>{`
                .input-glass {
                    width: 100%;
                    height: 56px;
                    background-color: rgba(255, 255, 255, 0.4);
                    border: 1px solid rgba(255, 255, 255, 0.5);
                    backdrop-filter: blur(20px);
                    border-radius: 1.25rem;
                    box-shadow: inset 0 1px 2px 0 rgb(0 0 0 / 0.05);
                    padding: 1rem;
                    color: #1e293b;
                    font-size: 0.875rem;
                    transition: all 0.2s;
                }
                .input-glass:focus { outline: none; box-shadow: inset 0 1px 2px 0 rgb(0 0 0 / 0.05), 0 0 0 2px #7dd3fc; }
                .input-glass:disabled { background-color: rgba(241, 245, 249, 0.7); cursor: not-allowed; }
            `}</style>
        </div>
    );
};

export default JournalVoucherPage;
