import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { useData } from '../context/DataContext';
import { BillPayment, Account } from '../types';
import { motion } from 'framer-motion';
import { Calendar, Search, XCircle, CheckCircle, RefreshCw } from 'lucide-react';

type EnhancedBillPayment = BillPayment & {
    vendorName: string;
    billId: string;
    billNumber: string;
};

const formatCurrency = (value: number) => new Intl.NumberFormat('en-US').format(value);

const BillPaymentsList: React.FC = () => {
    const { getBills, getAccountsList, voidBillPayment, _version } = useData();
    const [payments, setPayments] = useState<EnhancedBillPayment[]>([]);
    const [accountsMap, setAccountsMap] = useState<Map<string, Account>>(new Map());
    const [isLoading, setIsLoading] = useState(true);

    const [startDate, setStartDate] = useState(new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0]);
    const [endDate, setEndDate] = useState(new Date().toISOString().split('T')[0]);
    const [searchQuery, setSearchQuery] = useState('');

    const fetchData = useCallback(async () => {
        setIsLoading(true);
        try {
            const [bills, accounts] = await Promise.all([getBills(), getAccountsList()]);
            const aMap = new Map(accounts.map(a => [a.id, a]));
            setAccountsMap(aMap);

            const allPayments: EnhancedBillPayment[] = [];
            bills.forEach(bill => {
                bill.payments.forEach(p => {
                    allPayments.push({
                        ...p,
                        vendorName: bill.vendorName,
                        billId: bill.id,
                        billNumber: bill.billNumber,
                    });
                });
            });
            setPayments(allPayments.sort((a,b) => new Date(b.paymentDate).getTime() - new Date(a.paymentDate).getTime()));
        } catch (error) {
            console.error("Failed to fetch bill payments:", error);
        } finally {
            setIsLoading(false);
        }
    }, [getBills, getAccountsList]);

    useEffect(() => {
        fetchData();
    }, [_version, fetchData]);

    const handleVoidPayment = async (paymentId: string) => {
        if (window.confirm("Are you sure you want to void this payment? This action will reverse the transaction and cannot be undone.")) {
            try {
                await voidBillPayment(paymentId);
            } catch (error) {
                console.error("Failed to void payment:", error);
                alert(`Error: ${(error as Error).message}`);
            }
        }
    };

    const filteredPayments = useMemo(() => {
        const start = new Date(startDate);
        const end = new Date(endDate);
        end.setHours(23, 59, 59, 999);

        return payments.filter(p => {
            const paymentDate = new Date(p.paymentDate);
            const isInDateRange = paymentDate >= start && paymentDate <= end;
            if (!isInDateRange) return false;
            
            if (searchQuery) {
                const lowerQuery = searchQuery.toLowerCase();
                return p.vendorName.toLowerCase().includes(lowerQuery) ||
                       p.billNumber.toLowerCase().includes(lowerQuery) ||
                       p.referenceNumber.toLowerCase().includes(lowerQuery);
            }
            return true;
        });
    }, [payments, startDate, endDate, searchQuery]);

    return (
        <div className="space-y-6">
             <style>{`
                .glowing-card {
                    position: relative;
                    background-color: var(--glass-bg);
                    backdrop-filter: blur(30px);
                    border: 1px solid var(--glass-border);
                    border-radius: 22px;
                    box-shadow: 0 8px 32px 0 var(--glass-shadow);
                    overflow: hidden;
                }
                .dark .glowing-card::before {
                    content: "";
                    position: absolute;
                    inset: -1px;
                    border-radius: 22px;
                    background: conic-gradient(from 180deg at 50% 50%, rgba(56, 189, 248, 0.15) 0%, rgba(168, 85, 247, 0.15) 33%, rgba(236, 72, 153, 0.15) 66%, rgba(56, 189, 248, 0.15) 100%);
                    filter: blur(12px);
                    z-index: -1;
                    opacity: 0.8;
                }
                .input-filter { height: 40px; background-color: rgba(255,255,255,0.7); border: 1px solid rgba(255,255,255,0.5); border-radius: 0.5rem; padding: 0 0.75rem; font-size: 0.875rem; color: #1e293b; }
                .dark .input-filter { color: #d1d5db; background-color: rgba(55,65,81,0.4); border-color: rgba(75,85,99,0.6); }
                .th-cell { padding: 0.75rem 1rem; text-align: center; font-size: 0.75rem; color: #64748b; text-transform: uppercase; font-weight: 600; } .dark .th-cell { color: #94a3b8; }
            `}</style>
            
            {/* Filter Panel */}
            <div className="bg-white/60 backdrop-blur-xl border border-white/50 rounded-2xl shadow-sm p-4 flex flex-col lg:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-2">
                    <Calendar className="text-slate-500" size={18} />
                    <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="input-filter" />
                    <span className="text-slate-500">-</span>
                    <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className="input-filter" />
                </div>
                <div className="relative w-full md:max-w-xs">
                    <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input type="text" value={searchQuery} onChange={e => setSearchQuery(e.target.value)} placeholder="Search vendor, bill#, ref#" className="w-full h-10 bg-white/70 border border-white/50 rounded-lg shadow-inner pl-10 pr-4 text-sm text-slate-800 focus:ring-1 focus:ring-sky-300/60 focus:outline-none" />
                </div>
                <button onClick={fetchData} disabled={isLoading} className="h-10 px-4 flex items-center gap-2 text-sm font-semibold text-slate-700 bg-white/50 rounded-lg border border-white/40 hover:bg-white/70 transition-colors disabled:opacity-50">
                    <RefreshCw size={14} className={isLoading ? 'animate-spin' : ''} />
                </button>
            </div>

            {/* Table */}
            <div className="glowing-card p-0">
                <div className="overflow-x-auto">
                    <table className="w-full min-w-[900px]">
                        <thead>
                            <tr className="border-b border-white/10">
                                <th className="th-cell">Vendor</th>
                                <th className="th-cell">Bill #</th>
                                <th className="th-cell">Paid From</th>
                                <th className="th-cell">Reference #</th>
                                <th className="th-cell">Amount</th>
                                <th className="th-cell">Status</th>
                                <th className="th-cell">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredPayments.map(p => {
                                const account = accountsMap.get(p.paymentAccountId);
                                return (
                                <tr key={p.id} className="border-b border-white/5 last:border-b-0 hover:bg-sky-900/10 transition-colors">
                                    <td className="px-4 py-3 text-sm font-semibold text-slate-700 dark:text-slate-200 text-center">{p.vendorName}</td>
                                    <td className="px-4 py-3 text-sm text-slate-500 dark:text-slate-400 text-center">{p.billNumber}</td>
                                    <td className="px-4 py-3 text-sm text-slate-500 dark:text-slate-400 text-center">{account ? `${account.code} - ${account.name}` : p.paymentAccountId}</td>
                                    <td className="px-4 py-3 text-sm font-mono text-slate-500 dark:text-slate-400 text-center">{p.referenceNumber}</td>
                                    <td className="px-4 py-3 text-center font-mono font-semibold text-slate-800 dark:text-slate-100">${formatCurrency(p.amount)}</td>
                                    <td className="px-4 py-3 text-center">
                                        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold leading-tight rounded-full ${
                                            p.status === 'Active'
                                            ? 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300' 
                                            : 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300'
                                        }`}>
                                            {p.status === 'Active' ? <CheckCircle size={12} /> : <XCircle size={12} />}
                                            {p.status}
                                        </span>
                                    </td>
                                    <td className="px-4 py-3 text-center">
                                        {p.status === 'Active' && (
                                            <button onClick={() => handleVoidPayment(p.id)} className="text-red-500 hover:text-red-700 text-xs font-bold">Void</button>
                                        )}
                                    </td>
                                </tr>
                                );
                            })}
                        </tbody>
                    </table>
                     {isLoading && <div className="text-center p-10 text-slate-500">Loading payments...</div>}
                     {!isLoading && filteredPayments.length === 0 && <div className="text-center p-10 text-slate-500">No payments found for the selected criteria.</div>}
                </div>
            </div>
        </div>
    );
};

export default BillPaymentsList;