
import React, { useState, useEffect, useMemo } from 'react';
import { useData } from '../context/DataContext';
import { Shareholder, PartnerMetric } from '../types';
import { GlassCard } from '../components/ui/GlassCard';
import { GlassButton } from '../components/ui/GlassButton';
import { Calendar, PieChart, DollarSign, TrendingUp, Download, Users, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const formatCurrency = (value: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value);

// --- COMPONENTS ---

const StatCard: React.FC<{ title: string; value: string; icon: React.ReactNode; color: string }> = ({ title, value, icon, color }) => (
    <div className="bg-white/60 backdrop-blur-xl border border-white/50 rounded-2xl p-5 shadow-sm flex flex-col justify-between h-full">
        <div className="flex justify-between items-start">
            <div>
                <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">{title}</p>
                <p className={`text-2xl font-bold mt-2 text-slate-800`}>{value}</p>
            </div>
            <div className={`p-2.5 rounded-xl bg-${color}-100 text-${color}-600`}>{icon}</div>
        </div>
    </div>
);

const DistributionRow: React.FC<{ 
    shareholder: Shareholder; 
    percentage: number; 
    onChange: (id: string, val: number) => void; 
    totalProfit: number; 
}> = ({ shareholder, percentage, onChange, totalProfit }) => {
    const amount = (totalProfit * percentage) / 100;
    
    return (
        <tr className="border-b border-slate-100 last:border-0 hover:bg-slate-50/50 transition-colors">
            <td className="px-6 py-4 font-medium text-slate-800">{shareholder.name}</td>
            <td className="px-6 py-4">
                <div className="flex items-center gap-2">
                    <input 
                        type="number" 
                        value={percentage} 
                        onChange={(e) => onChange(shareholder.id, parseFloat(e.target.value) || 0)}
                        className="w-20 h-9 text-center bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-sky-200 outline-none font-bold text-slate-700"
                        min="0" max="100"
                    />
                    <span className="text-slate-400">%</span>
                </div>
            </td>
            <td className="px-6 py-4 text-right font-mono font-bold text-emerald-600 text-lg">
                {formatCurrency(amount)}
            </td>
        </tr>
    );
};

const MetricsRow: React.FC<{ metric: PartnerMetric }> = ({ metric }) => (
    <tr className="border-b border-slate-100 last:border-0 hover:bg-slate-50/50 transition-colors">
        <td className="px-6 py-4 font-bold text-slate-800">{metric.name}</td>
        <td className="px-6 py-4 text-right font-mono text-slate-600">{formatCurrency(metric.totalCapital)}</td>
        <td className="px-6 py-4 text-right font-mono text-emerald-600">{formatCurrency(metric.totalProfitShare)}</td>
        <td className="px-6 py-4 text-right font-mono text-rose-500">{formatCurrency(metric.totalDrawings)}</td>
        <td className="px-6 py-4 text-right font-mono font-extrabold text-sky-700 bg-sky-50/30 rounded-r-lg">
            {formatCurrency(metric.netBalance)}
        </td>
    </tr>
);

// --- MAIN PAGE ---

const ProfitDistribution: React.FC = () => {
    const { getShareholders, getNetProfitForPeriod, distributePeriodProfit, getPartnerMetrics, _version } = useData();
    
    // State
    const [shareholders, setShareholders] = useState<Shareholder[]>([]);
    const [metrics, setMetrics] = useState<PartnerMetric[]>([]);
    const [selectedMonth, setSelectedMonth] = useState(new Date().toISOString().slice(0, 7)); // YYYY-MM
    const [netProfit, setNetProfit] = useState<number>(0);
    const [percentages, setPercentages] = useState<Record<string, number>>({});
    const [isLoading, setIsLoading] = useState(true);
    const [isDistributing, setIsDistributing] = useState(false);

    // Fetch Initial Data
    useEffect(() => {
        const init = async () => {
            const s = await getShareholders();
            setShareholders(s);
            
            // Initialize percentages from shareholder defaults
            const initialPercs: Record<string, number> = {};
            s.forEach(sh => initialPercs[sh.id] = Number(sh.profitSharePercentage));
            setPercentages(initialPercs);
            
            setIsLoading(false);
        };
        init();
    }, []);

    // Fetch Period Data when month changes
    useEffect(() => {
        const fetchPeriodData = async () => {
            if (!selectedMonth) return;
            
            // Calculate start and end of selected month
            const parts = selectedMonth.split('-');
            const year = Number(parts[0]);
            const month = Number(parts[1]);
            const start = new Date(year, month - 1, 1);
            const end = new Date(year, month, 0);
            
            const profit = await getNetProfitForPeriod(start.toISOString(), end.toISOString());
            setNetProfit(Number(profit as any));

            const partnerMetrics = await getPartnerMetrics();
            setMetrics(partnerMetrics);
        };
        fetchPeriodData();
    }, [selectedMonth, _version]);

    // Handlers
    const handlePercentageChange = (id: string, val: number) => {
        setPercentages(prev => ({ ...prev, [id]: val }));
    };

    const totalPercentage: number = Object.values(percentages).reduce((sum: number, val: number) => sum + val, 0);
    const totalDistributedAmount = (netProfit * totalPercentage) / 100;

    const handleDistribute = async () => {
        if (Math.abs(totalPercentage - 100) > 0.01) {
            alert("Total percentage must equal 100%.");
            return;
        }
        if (netProfit <= 0) {
            alert("Cannot distribute profit when there is a loss or zero profit.");
            return;
        }

        if (!window.confirm(`Are you sure you want to distribute ${formatCurrency(netProfit)} for ${selectedMonth}? This will create accounting entries.`)) return;

        setIsDistributing(true);
        try {
            const distributions = shareholders.map(s => ({
                shareholderId: s.id,
                amount: (netProfit * (percentages[s.id] || 0)) / 100
            }));
            
            // Parse selected month for the transaction date (end of month)
            const [year, month] = selectedMonth.split('-').map(Number);
            const distDate = new Date(year, month, 0);

            await distributePeriodProfit(distDate, distributions);
            alert("Profit distributed successfully!");
        } catch (error) {
            console.error(error);
            alert("Failed to distribute profit.");
        } finally {
            setIsDistributing(false);
        }
    };

    return (
        <div className="space-y-8 max-w-6xl mx-auto pb-20">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-slate-800">Profit Distribution Manager</h1>
                    <p className="text-sm text-slate-500">Monthly Net Profit Allocation</p>
                </div>
                <div className="flex items-center gap-2 bg-white p-1 rounded-xl shadow-sm border border-slate-200">
                    <Calendar className="text-slate-400 ml-2" size={18}/>
                    <input 
                        type="month" 
                        value={selectedMonth} 
                        onChange={e => setSelectedMonth(e.target.value)}
                        className="bg-transparent border-none text-sm font-bold text-slate-700 focus:ring-0"
                    />
                </div>
            </div>

            {/* Distribution Workflow Card */}
            <GlassCard className="relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500" />
                
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 p-2">
                    {/* Left: Summary */}
                    <div className="lg:col-span-1 space-y-6">
                        <div className="p-6 bg-gradient-to-br from-slate-900 to-slate-800 rounded-2xl text-white shadow-xl">
                            <p className="text-slate-400 text-xs font-bold uppercase tracking-wider mb-1">Distributable Net Profit</p>
                            <p className={`text-3xl font-mono font-bold ${netProfit < 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                                {formatCurrency(netProfit)}
                            </p>
                            <div className="mt-4 pt-4 border-t border-white/10 flex justify-between items-center">
                                <span className="text-xs text-slate-400">For {selectedMonth}</span>
                                <span className={`px-2 py-1 rounded-md text-xs font-bold ${netProfit > 0 ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300'}`}>
                                    {netProfit > 0 ? 'PROFITABLE' : 'LOSS'}
                                </span>
                            </div>
                        </div>

                        <div className="p-4 bg-indigo-50 rounded-xl border border-indigo-100">
                            <div className="flex justify-between items-center mb-2">
                                <span className="text-sm font-semibold text-indigo-900">Allocation Status</span>
                                <span className={`font-bold ${totalPercentage === 100 ? 'text-emerald-600' : 'text-indigo-600'}`}>{totalPercentage}%</span>
                            </div>
                            <div className="w-full bg-white rounded-full h-2 overflow-hidden">
                                <div 
                                    className={`h-full transition-all duration-500 ${totalPercentage > 100 ? 'bg-rose-500' : 'bg-indigo-500'}`} 
                                    style={{ width: `${Math.min(totalPercentage, 100)}%` }} 
                                />
                            </div>
                            <p className="text-xs text-indigo-400 mt-2 text-center">Target: 100%</p>
                        </div>
                        
                        <GlassButton 
                            variant="primary" 
                            onClick={handleDistribute}
                            disabled={isDistributing || netProfit <= 0}
                            className="w-full py-4 text-base shadow-lg shadow-indigo-200"
                        >
                            {isDistributing ? 'Processing...' : 'Distribute Profit'}
                        </GlassButton>
                    </div>

                    {/* Right: Table */}
                    <div className="lg:col-span-2">
                        <h3 className="text-lg font-bold text-slate-700 mb-4 flex items-center gap-2">
                            <PieChart size={20} className="text-indigo-500"/> Shareholder Allocation
                        </h3>
                        <div className="bg-white/50 rounded-2xl border border-slate-200 overflow-hidden">
                            <table className="w-full text-sm text-left">
                                <thead className="bg-slate-50/80 text-xs text-slate-500 uppercase font-bold">
                                    <tr>
                                        <th className="px-6 py-3">Partner</th>
                                        <th className="px-6 py-3 w-32">Share %</th>
                                        <th className="px-6 py-3 text-right">Calculated Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {shareholders.map(s => (
                                        <DistributionRow 
                                            key={s.id}
                                            shareholder={s}
                                            percentage={percentages[s.id] || 0}
                                            onChange={handlePercentageChange}
                                            totalProfit={netProfit}
                                        />
                                    ))}
                                </tbody>
                                <tfoot className="bg-slate-50 border-t border-slate-200 font-bold text-slate-700">
                                    <tr>
                                        <td className="px-6 py-4">Total</td>
                                        <td className="px-6 py-4">{totalPercentage}%</td>
                                        <td className="px-6 py-4 text-right">{formatCurrency(totalDistributedAmount)}</td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </GlassCard>

            {/* Partners Dashboard */}
            <div className="space-y-4">
                <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                    <Users size={24} className="text-slate-400"/> Partners Dashboard
                </h2>
                
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                    <StatCard title="Total Invested Capital" value={formatCurrency(metrics.reduce((s, m) => s + m.totalCapital, 0))} icon={<DollarSign />} color="blue" />
                    <StatCard title="Lifetime Profit Share" value={formatCurrency(metrics.reduce((s, m) => s + m.totalProfitShare, 0))} icon={<TrendingUp />} color="emerald" />
                    <StatCard title="Total Withdrawn" value={formatCurrency(metrics.reduce((s, m) => s + m.totalDrawings, 0))} icon={<Download />} color="rose" />
                    <StatCard title="Net Equity Balance" value={formatCurrency(metrics.reduce((s, m) => s + m.netBalance, 0))} icon={<PieChart />} color="indigo" />
                </div>

                <GlassCard className="overflow-hidden" bodyClassName="p-0">
                    <table className="w-full text-sm text-left">
                        <thead className="bg-slate-100/50 text-xs text-slate-500 uppercase font-bold border-b border-slate-200">
                            <tr>
                                <th className="px-6 py-4">Partner Name</th>
                                <th className="px-6 py-4 text-right">Total Capital</th>
                                <th className="px-6 py-4 text-right">Lifetime Profit</th>
                                <th className="px-6 py-4 text-right">Total Drawings</th>
                                <th className="px-6 py-4 text-right">Net Balance</th>
                            </tr>
                        </thead>
                        <tbody>
                            {metrics.map(metric => (
                                <MetricsRow key={metric.id} metric={metric} />
                            ))}
                            {metrics.length === 0 && (
                                <tr><td colSpan={5} className="text-center py-8 text-slate-400">No partner data available.</td></tr>
                            )}
                        </tbody>
                    </table>
                </GlassCard>
            </div>
        </div>
    );
};

export default ProfitDistribution;
