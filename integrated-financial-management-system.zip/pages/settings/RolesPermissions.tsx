
import React, { useState, useEffect, useMemo } from 'react';
import { useData } from '../../context/DataContext';
import { Role, PermissionAction } from '../../types';
import { SIDEBAR_CONFIG } from '../../constants';
import { GlassCard } from '../../components/ui/GlassCard';
import { GlassButton } from '../../components/ui/GlassButton';
import { GlassModal } from '../../components/ui/GlassModal';
import { GlassField } from '../../components/ui/GlassField';
import { 
    Plus, Shield, Trash2, Save, CheckSquare, Square, Lock, 
    ChevronRight, ChevronDown, ShieldCheck, Check, LayoutGrid,
    CheckCircle2, Circle
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export const RolesPermissions: React.FC = () => {
    const { getRoles, saveRole, deleteRole, _version } = useData();
    const [roles, setRoles] = useState<Role[]>([]);
    const [selectedRole, setSelectedRole] = useState<Role | null>(null);
    const [isEditing, setIsEditing] = useState(false);
    
    // New Role Modal State
    const [isNewRoleModalOpen, setIsNewRoleModalOpen] = useState(false);
    const [newRoleName, setNewRoleName] = useState('');
    const [newRoleDesc, setNewRoleDesc] = useState('');

    useEffect(() => {
        getRoles().then(data => {
            setRoles(data);
            if (!selectedRole && data.length > 0) {
                setSelectedRole(data[0]);
            } else if (selectedRole) {
                const updated = data.find(r => r.id === selectedRole.id);
                if (updated) setSelectedRole(updated);
            }
        });
    }, [_version]);

    const handleCreateRole = async () => {
        if (!newRoleName.trim()) return;
        
        const newRole: Role = {
            id: '', 
            name: newRoleName,
            description: newRoleDesc,
            permissions: {},
            isSystem: false
        };
        
        try {
            const saved = await saveRole(newRole);
            setSelectedRole(saved);
            setIsNewRoleModalOpen(false);
            setNewRoleName('');
            setNewRoleDesc('');
        } catch (e) {
            alert("Failed to create role.");
        }
    };

    // Helper to toggle permission
    const togglePermission = (currentPerms: PermissionAction[], action: PermissionAction) => {
        if (currentPerms.includes(action)) {
            return currentPerms.filter(a => a !== action);
        } else {
            return [...currentPerms, action];
        }
    };

    const handleToggle = (scope: string, action: PermissionAction) => {
        if (!selectedRole || selectedRole.isSystem) return;

        const currentScopePerms = selectedRole.permissions[scope] || [];
        let newScopePerms = togglePermission(currentScopePerms, action);

        // Logic: If I give access to a sub-item (e.g. reports.profit_loss), 
        // I MUST also give access to the parent module (e.g. reports) so the sidebar group appears.
        let newAllPermissions = { ...selectedRole.permissions, [scope]: newScopePerms };

        // Find parent module if this is a sub-item
        const parentItem = SIDEBAR_CONFIG.find(item => 
            item.subItems?.some((sub: any) => sub.permissionScope === scope)
        );

        if (parentItem && parentItem.module && newScopePerms.includes('view')) {
            // Ensure parent has 'view' access
            const parentScope = parentItem.module; // or parentItem.permissionScope if defined
            const currentParentPerms = newAllPermissions[parentScope] || [];
            if (!currentParentPerms.includes('view')) {
                newAllPermissions[parentScope] = [...currentParentPerms, 'view'];
            }
        }

        const updatedRole = {
            ...selectedRole,
            permissions: newAllPermissions
        };
        
        setSelectedRole(updatedRole);
        setIsEditing(true);
    };

    const handleToggleModuleAll = (moduleItem: any, enable: boolean) => {
        if (!selectedRole || selectedRole.isSystem) return;

        let newPermissions = { ...selectedRole.permissions };
        
        // 1. Toggle the module itself
        const moduleScope = moduleItem.permissionScope || moduleItem.module;
        if (moduleScope) {
            newPermissions[moduleScope] = enable ? ['view'] : [];
        }

        // 2. Toggle all sub-items
        if (moduleItem.subItems) {
            moduleItem.subItems.forEach((sub: any) => {
                if (sub.permissionScope) {
                    newPermissions[sub.permissionScope] = enable ? ['view'] : [];
                }
            });
        }

        setSelectedRole({ ...selectedRole, permissions: newPermissions });
        setIsEditing(true);
    };

    const handleSavePermissions = async () => {
        if (!selectedRole) return;
        try {
            await saveRole(selectedRole);
            setIsEditing(false);
            alert("Permissions updated successfully.");
        } catch (e) {
            alert("Failed to save permissions.");
        }
    };

    const handleDeleteRole = async (id: string) => {
        if (window.confirm("Are you sure you want to delete this role?")) {
            try {
                await deleteRole(id);
                const remaining = roles.filter(r => r.id !== id);
                if (remaining.length > 0) setSelectedRole(remaining[0]);
                else setSelectedRole(null);
            } catch (e) {
                alert((e as Error).message);
            }
        }
    };

    return (
        <div className="h-[calc(100vh-8rem)] flex flex-col lg:flex-row gap-6">
            {/* Left Sidebar: Roles List */}
            <div className="lg:w-1/4 min-w-[280px] flex flex-col gap-4">
                <GlassCard className="flex-1 flex flex-col overflow-hidden" bodyClassName="p-0 flex flex-col h-full">
                    <div className="p-5 border-b border-white/50 flex justify-between items-center bg-white/40">
                        <div>
                            <h3 className="font-bold text-slate-700 text-lg">Roles</h3>
                            <p className="text-xs text-slate-500">Manage access levels</p>
                        </div>
                        <button onClick={() => setIsNewRoleModalOpen(true)} className="p-2 rounded-xl bg-sky-100 hover:bg-sky-200 text-sky-600 transition-colors shadow-sm">
                            <Plus size={20} />
                        </button>
                    </div>
                    <div className="flex-1 overflow-y-auto p-3 space-y-2">
                        {roles.map(role => (
                            <div
                                key={role.id}
                                onClick={() => { setSelectedRole(role); setIsEditing(false); }}
                                className={`relative w-full text-left p-4 rounded-xl transition-all cursor-pointer border ${
                                    selectedRole?.id === role.id 
                                    ? 'bg-gradient-to-r from-sky-500 to-cyan-500 text-white border-transparent shadow-md' 
                                    : 'bg-white/40 border-white/60 hover:bg-white/60 text-slate-600'
                                }`}
                            >
                                <div className="flex items-center gap-3">
                                    <div className={`p-2 rounded-lg ${selectedRole?.id === role.id ? 'bg-white/20' : 'bg-slate-100'}`}>
                                        {role.isSystem ? <Lock size={18} /> : <Shield size={18} />}
                                    </div>
                                    <div>
                                        <div className="font-bold text-sm">{role.name}</div>
                                        <div className={`text-xs ${selectedRole?.id === role.id ? 'text-sky-100' : 'text-slate-400'}`}>
                                            {role.isSystem ? 'System Role (Locked)' : role.description || 'Custom Role'}
                                        </div>
                                    </div>
                                </div>
                                {!role.isSystem && selectedRole?.id === role.id && (
                                    <button 
                                        onClick={(e) => { e.stopPropagation(); handleDeleteRole(role.id); }} 
                                        className="absolute top-4 right-4 p-1.5 text-white/70 hover:text-white hover:bg-white/20 rounded-lg transition-colors"
                                    >
                                        <Trash2 size={16} />
                                    </button>
                                )}
                            </div>
                        ))}
                    </div>
                </GlassCard>
            </div>

            {/* Right Panel: Permission Tree */}
            <div className="flex-1 flex flex-col min-h-0">
                {selectedRole ? (
                    <GlassCard className="h-full flex flex-col overflow-hidden" bodyClassName="p-0 flex flex-col h-full" 
                        title={
                            <div className="flex items-center gap-2">
                                <ShieldCheck className="text-sky-500" />
                                <span>{selectedRole.name} Permissions</span>
                            </div>
                        }
                        actions={
                            isEditing && (
                                <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
                                    <GlassButton variant="primary" onClick={handleSavePermissions} className="!py-2 !px-4 !text-xs shadow-lg shadow-sky-500/30">
                                        <Save size={16} className="mr-2"/> Save Changes
                                    </GlassButton>
                                </motion.div>
                            )
                        }
                    >
                        {selectedRole.isSystem && (
                            <div className="bg-amber-50 text-amber-700 px-6 py-3 text-sm font-medium border-b border-amber-100 flex items-center gap-2">
                                <Lock size={16} />
                                <span>System roles have full access and cannot be modified to ensure system stability.</span>
                            </div>
                        )}
                        
                        <div className="flex-1 overflow-y-auto p-6 bg-slate-50/30">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-6xl mx-auto">
                                {SIDEBAR_CONFIG.map((module) => (
                                    <PermissionModuleCard
                                        key={module.key}
                                        configItem={module}
                                        role={selectedRole}
                                        onToggle={handleToggle}
                                        onToggleAll={handleToggleModuleAll}
                                    />
                                ))}
                            </div>
                        </div>
                    </GlassCard>
                ) : (
                    <div className="flex-1 flex flex-col items-center justify-center text-slate-400 bg-white/30 rounded-2xl border border-white/40">
                        <Shield size={48} className="mb-4 opacity-20" />
                        <p>Select a role to configure permissions</p>
                    </div>
                )}
            </div>

            <GlassModal
                isOpen={isNewRoleModalOpen}
                onClose={() => setIsNewRoleModalOpen(false)}
                title="Create New Role"
                subtitle="Define a new role to assign permissions."
                footer={
                    <div className="flex justify-end gap-3 w-full">
                        <GlassButton variant="secondary" onClick={() => setIsNewRoleModalOpen(false)}>Cancel</GlassButton>
                        <GlassButton variant="primary" onClick={handleCreateRole}>Create Role</GlassButton>
                    </div>
                }
            >
                <div className="py-6 space-y-4 max-w-md mx-auto">
                    <GlassField id="roleName" label="Role Name" value={newRoleName} onChange={e => setNewRoleName(e.target.value)} autoFocus />
                    <GlassField id="roleDesc" label="Description" value={newRoleDesc} onChange={e => setNewRoleDesc(e.target.value)} />
                </div>
            </GlassModal>
        </div>
    );
};

// --- SUB-COMPONENTS FOR TREE VIEW ---

const PermissionModuleCard: React.FC<{ 
    configItem: any; 
    role: Role; 
    onToggle: (scope: string, action: PermissionAction) => void; 
    onToggleAll: (item: any, enable: boolean) => void;
}> = ({ configItem, role, onToggle, onToggleAll }) => {
    const scope = configItem.permissionScope || configItem.module;
    const isModuleEnabled = scope ? role.permissions[scope]?.includes('view') : false;
    
    // Filter out header items
    const subItems = configItem.subItems?.filter((item: any) => item.type !== 'header') || [];
    
    // Check if all sub-items are checked
    const allSubChecked = subItems.length > 0 && subItems.every((sub: any) => 
        sub.permissionScope && role.permissions[sub.permissionScope]?.includes('view')
    );

    return (
        <div className={`rounded-xl border transition-all duration-200 ${isModuleEnabled ? 'bg-white border-sky-200 shadow-sm' : 'bg-slate-50/50 border-slate-200 opacity-80'}`}>
            {/* Header */}
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg ${isModuleEnabled ? 'bg-sky-100 text-sky-600' : 'bg-slate-200 text-slate-500'}`}>
                        {configItem.icon || <LayoutGrid size={18} />}
                    </div>
                    <div>
                        <h4 className={`font-bold text-sm ${isModuleEnabled ? 'text-slate-800' : 'text-slate-500'}`}>{configItem.title}</h4>
                        <p className="text-[10px] text-slate-400 uppercase tracking-wide font-semibold">Module</p>
                    </div>
                </div>
                
                <div className="flex items-center gap-2">
                    <button 
                        onClick={() => onToggleAll(configItem, !allSubChecked)}
                        disabled={role.isSystem}
                        className="text-xs font-medium text-sky-600 hover:text-sky-700 px-2 py-1 rounded hover:bg-sky-50 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        {allSubChecked ? 'Uncheck All' : 'Check All'}
                    </button>
                    {/* Master Toggle for the Module itself */}
                    {scope && (
                        <PermissionToggle 
                            isChecked={!!isModuleEnabled} 
                            onChange={() => onToggle(scope, 'view')} 
                            disabled={role.isSystem}
                        />
                    )}
                </div>
            </div>

            {/* Sub Items Grid */}
            {subItems.length > 0 && (
                <div className={`p-4 grid gap-3 ${isModuleEnabled ? 'opacity-100' : 'opacity-50 grayscale pointer-events-none'}`}>
                    {subItems.map((sub: any) => (
                        <PermissionSubItemRow 
                            key={sub.path || sub.title} 
                            item={sub} 
                            role={role} 
                            onToggle={onToggle} 
                        />
                    ))}
                </div>
            )}
        </div>
    );
};

const PermissionSubItemRow: React.FC<{ 
    item: any; 
    role: Role; 
    onToggle: (scope: string, action: PermissionAction) => void; 
}> = ({ item, role, onToggle }) => {
    const scope = item.permissionScope;
    if (!scope) return null;

    const isChecked = role.permissions[scope]?.includes('view');

    return (
        <div 
            onClick={() => !role.isSystem && onToggle(scope, 'view')}
            className={`flex items-center justify-between p-2 rounded-lg border cursor-pointer transition-all ${
                isChecked 
                ? 'bg-sky-50 border-sky-200' 
                : 'bg-white border-slate-100 hover:border-slate-300'
            }`}
        >
            <div className="flex items-center gap-3">
                <div className={`text-slate-400 ${isChecked ? 'text-sky-500' : ''}`}>
                    {isChecked ? <CheckCircle2 size={18} /> : <Circle size={18} />}
                </div>
                <span className={`text-sm font-medium ${isChecked ? 'text-sky-900' : 'text-slate-600'}`}>
                    {item.title}
                </span>
            </div>
            
            {isChecked && (
                <div className="flex gap-1" onClick={e => e.stopPropagation()}>
                    {/* Here you could add Edit/Delete checkboxes if you want extremely granular action control */}
                    <span className="text-[10px] font-bold text-sky-600 bg-sky-100 px-2 py-0.5 rounded">Visible</span>
                </div>
            )}
        </div>
    );
};

const PermissionToggle: React.FC<{ isChecked: boolean; onChange: () => void; disabled: boolean }> = ({ isChecked, onChange, disabled }) => (
    <button 
        onClick={onChange}
        disabled={disabled}
        className={`relative w-10 h-6 rounded-full transition-colors duration-200 focus:outline-none ${
            isChecked ? 'bg-emerald-500' : 'bg-slate-300'
        } ${disabled ? 'cursor-not-allowed opacity-60' : 'cursor-pointer'}`}
    >
        <span 
            className={`absolute top-1 left-1 bg-white w-4 h-4 rounded-full shadow-sm transition-transform duration-200 ${
                isChecked ? 'translate-x-4' : 'translate-x-0'
            }`} 
        />
    </button>
);
