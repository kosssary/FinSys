
import React, { useState, useEffect, useMemo } from 'react';
import { useData } from '../../context/DataContext';
import { User, Role } from '../../types';
import { GlassCard } from '../../components/ui/GlassCard';
import { GlassButton } from '../../components/ui/GlassButton';
import { GlassModal } from '../../components/ui/GlassModal';
import { GlassField } from '../../components/ui/GlassField';
import { UserPlus, Mail, Shield, Trash2, CheckCircle, XCircle, Eye, EyeOff, Lock, History } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { AuditLog } from './AuditLog';

export const UserManagement: React.FC = () => {
    const { getUsers, inviteUser, getRoles, deleteUser, updateUserRole, updateUser, _version } = useData();
    const [users, setUsers] = useState<User[]>([]);
    const [roles, setRoles] = useState<Role[]>([]);
    
    const [activeTab, setActiveTab] = useState<'active' | 'pending'>('active');
    
    // Invite Modal
    const [isInviteModalOpen, setIsInviteModalOpen] = useState(false);
    const [inviteEmail, setInviteEmail] = useState('');
    const [inviteName, setInviteName] = useState('');
    const [inviteRoleId, setInviteRoleId] = useState('');

    // Approve Modal
    const [isApproveModalOpen, setIsApproveModalOpen] = useState(false);
    const [userToApprove, setUserToApprove] = useState<User | null>(null);
    const [approvalRoleId, setApprovalRoleId] = useState('');

    // History Modal
    const [isHistoryModalOpen, setIsHistoryModalOpen] = useState(false);
    const [selectedHistoryUser, setSelectedHistoryUser] = useState<User | null>(null);

    // Password Visibility State (Key: userId)
    const [visiblePasswords, setVisiblePasswords] = useState<Record<string, boolean>>({});

    useEffect(() => {
        Promise.all([getUsers(), getRoles()]).then(([usersData, rolesData]) => {
            setUsers(usersData);
            setRoles(rolesData);
            if (rolesData.length > 0) {
                setInviteRoleId(rolesData[0].id);
                setApprovalRoleId(rolesData[0].id);
            }
        });
    }, [_version]);

    const handleInvite = async () => {
        if (!inviteEmail || !inviteName || !inviteRoleId) return;
        try {
            await inviteUser(inviteEmail, inviteRoleId, inviteName);
            setIsInviteModalOpen(false);
            setInviteEmail('');
            setInviteName('');
            alert(`Invitation sent to ${inviteEmail}`);
        } catch (e) {
            alert("Failed to invite user.");
        }
    };

    const handleDelete = async (userId: string) => {
        if (window.confirm("Are you sure you want to remove this user?")) {
            try {
                await deleteUser(userId);
            } catch (e) {
                alert("Failed to delete user.");
            }
        }
    };

    const handleRoleChange = async (userId: string, newRoleId: string) => {
        try {
            await updateUserRole(userId, newRoleId);
        } catch (e) {
            alert("Failed to update role.");
        }
    };

    const togglePasswordVisibility = (userId: string) => {
        setVisiblePasswords(prev => ({ ...prev, [userId]: !prev[userId] }));
    };

    const openApproveModal = (user: User) => {
        setUserToApprove(user);
        setIsApproveModalOpen(true);
    };

    const handleApprove = async () => {
        if (!userToApprove || !approvalRoleId) return;
        try {
            await updateUser(userToApprove.id, { 
                status: 'Active', 
                roleId: approvalRoleId 
            });
            setIsApproveModalOpen(false);
            setUserToApprove(null);
        } catch (e) {
            alert("Failed to approve user.");
        }
    };

    const handleReject = async (userId: string) => {
        if (window.confirm("Reject this registration request? This will delete the request.")) {
            await deleteUser(userId);
        }
    };

    const openHistoryModal = (user: User) => {
        setSelectedHistoryUser(user);
        setIsHistoryModalOpen(true);
    };

    const filteredUsers = useMemo(() => {
        if (activeTab === 'pending') {
            return users.filter(u => u.status === 'Pending');
        }
        return users.filter(u => u.status !== 'Pending');
    }, [users, activeTab]);

    return (
        <div className="space-y-6">
            {/* Tabs */}
            <div className="flex gap-6 border-b border-slate-200 dark:border-slate-700 pb-px">
                <button 
                    onClick={() => setActiveTab('active')}
                    className={`pb-2 text-sm font-medium transition-colors relative ${activeTab === 'active' ? 'text-sky-600 dark:text-sky-400' : 'text-slate-500 hover:text-slate-700'}`}
                >
                    Active Users
                    {activeTab === 'active' && <motion.div layoutId="user-tab" className="absolute left-0 right-0 bottom-0 h-0.5 bg-sky-500" />}
                </button>
                <button 
                    onClick={() => setActiveTab('pending')}
                    className={`pb-2 text-sm font-medium transition-colors relative flex items-center gap-2 ${activeTab === 'pending' ? 'text-sky-600 dark:text-sky-400' : 'text-slate-500 hover:text-slate-700'}`}
                >
                    Pending Requests
                    {users.filter(u => u.status === 'Pending').length > 0 && (
                        <span className="px-1.5 py-0.5 bg-rose-100 text-rose-600 rounded-full text-xs font-bold">
                            {users.filter(u => u.status === 'Pending').length}
                        </span>
                    )}
                    {activeTab === 'pending' && <motion.div layoutId="user-tab" className="absolute left-0 right-0 bottom-0 h-0.5 bg-sky-500" />}
                </button>
            </div>

            <GlassCard 
                title={activeTab === 'active' ? "System Users" : "Registration Requests"} 
                actions={
                    activeTab === 'active' && (
                        <GlassButton variant="primary" onClick={() => setIsInviteModalOpen(true)}>
                            <UserPlus size={18} className="mr-2" /> Invite User
                        </GlassButton>
                    )
                }
                bodyClassName="p-0"
            >
                <div className="overflow-x-auto">
                    <table className="w-full text-left text-sm">
                        <thead className="bg-slate-50/80 text-slate-500 font-semibold border-b border-slate-200">
                            <tr>
                                <th className="px-6 py-4">User</th>
                                <th className="px-6 py-4">Status</th>
                                {activeTab === 'active' && (
                                    <>
                                        <th className="px-6 py-4">Role</th>
                                        <th className="px-6 py-4">Password</th>
                                        <th className="px-6 py-4">Last Active</th>
                                    </>
                                )}
                                {activeTab === 'pending' && <th className="px-6 py-4">Requested At</th>}
                                <th className="px-6 py-4 text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                            {filteredUsers.map(user => (
                                <tr key={user.id} className="hover:bg-white/40 transition-colors">
                                    <td className="px-6 py-4">
                                        <div className="flex items-center gap-3">
                                            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-sky-400 to-blue-500 flex items-center justify-center text-white font-bold text-sm shadow-sm">
                                                {user.name.charAt(0).toUpperCase()}
                                            </div>
                                            <div>
                                                <div className="font-bold text-slate-700">{user.name}</div>
                                                <div className="text-xs text-slate-400">{user.email}</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4">
                                        <span className={`px-2 py-1 rounded-full text-xs font-bold ${
                                            user.status === 'Active' ? 'bg-emerald-100 text-emerald-700' : 
                                            user.status === 'Pending' ? 'bg-amber-100 text-amber-700' :
                                            user.status === 'Invited' ? 'bg-blue-100 text-blue-700' : 
                                            'bg-slate-200 text-slate-600'
                                        }`}>
                                            {user.status}
                                        </span>
                                    </td>
                                    
                                    {activeTab === 'active' && (
                                        <>
                                            <td className="px-6 py-4">
                                                <div className="relative group/role">
                                                    <select 
                                                        value={user.roleId}
                                                        onChange={(e) => handleRoleChange(user.id, e.target.value)}
                                                        className="bg-white/50 border border-slate-200 rounded-lg px-3 py-1.5 text-sm text-slate-700 font-medium focus:ring-2 focus:ring-sky-200 outline-none cursor-pointer hover:bg-white"
                                                    >
                                                        {roles.map(role => (
                                                            <option key={role.id} value={role.id}>{role.name}</option>
                                                        ))}
                                                    </select>
                                                </div>
                                            </td>
                                            <td className="px-6 py-4">
                                                <div className="flex items-center gap-2 bg-slate-100/50 px-3 py-1 rounded-lg border border-slate-200 w-fit">
                                                    <span className="font-mono text-slate-600">
                                                        {visiblePasswords[user.id] ? user.password : '••••••••'}
                                                    </span>
                                                    <button onClick={() => togglePasswordVisibility(user.id)} className="text-slate-400 hover:text-sky-600 transition-colors">
                                                        {visiblePasswords[user.id] ? <EyeOff size={14} /> : <Eye size={14} />}
                                                    </button>
                                                </div>
                                            </td>
                                            <td className="px-6 py-4 text-slate-500 text-xs">
                                                {user.lastLogin ? new Date(user.lastLogin).toLocaleString() : 'Never'}
                                            </td>
                                        </>
                                    )}

                                    {activeTab === 'pending' && (
                                        <td className="px-6 py-4 text-slate-500 text-xs">
                                            {user.createdAt ? new Date(user.createdAt).toLocaleString() : '-'}
                                        </td>
                                    )}

                                    <td className="px-6 py-4 text-right">
                                        {activeTab === 'active' ? (
                                            <div className="flex items-center justify-end gap-2">
                                                <button onClick={() => openHistoryModal(user)} className="p-2 text-slate-400 hover:text-sky-500 hover:bg-sky-50 rounded-lg transition-colors" title="View Activity History">
                                                    <History size={18} />
                                                </button>
                                                <button onClick={() => handleDelete(user.id)} className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors" title="Delete User">
                                                    <Trash2 size={18} />
                                                </button>
                                            </div>
                                        ) : (
                                            <div className="flex items-center justify-end gap-2">
                                                <button 
                                                    onClick={() => openApproveModal(user)}
                                                    className="flex items-center gap-1 px-3 py-1.5 bg-emerald-500 text-white rounded-lg hover:bg-emerald-600 transition-colors text-xs font-bold"
                                                >
                                                    <CheckCircle size={14} /> Approve
                                                </button>
                                                <button 
                                                    onClick={() => handleReject(user.id)}
                                                    className="flex items-center gap-1 px-3 py-1.5 bg-rose-100 text-rose-600 rounded-lg hover:bg-rose-200 transition-colors text-xs font-bold"
                                                >
                                                    <XCircle size={14} /> Reject
                                                </button>
                                            </div>
                                        )}
                                    </td>
                                </tr>
                            ))}
                            {filteredUsers.length === 0 && (
                                <tr>
                                    <td colSpan={activeTab === 'active' ? 6 : 4} className="text-center py-8 text-slate-400">
                                        No {activeTab} users found.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </GlassCard>

            {/* Invite Modal */}
            <GlassModal
                isOpen={isInviteModalOpen}
                onClose={() => setIsInviteModalOpen(false)}
                title="Invite Team Member"
                subtitle="Send an invitation to join the workspace."
                footer={
                    <div className="flex justify-end gap-3 w-full">
                        <GlassButton variant="secondary" onClick={() => setIsInviteModalOpen(false)}>Cancel</GlassButton>
                        <GlassButton variant="primary" onClick={handleInvite}>Send Invitation</GlassButton>
                    </div>
                }
            >
                <div className="py-6 space-y-4 max-w-md mx-auto">
                    <GlassField id="userName" label="Full Name" value={inviteName} onChange={e => setInviteName(e.target.value)} autoFocus />
                    <GlassField id="userEmail" label="Email Address" value={inviteEmail} onChange={e => setInviteEmail(e.target.value)} icon={<Mail size={16}/>} />
                    
                    <div className="relative group">
                        <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none z-10">
                            <Shield size={16} />
                        </div>
                        <select
                            value={inviteRoleId}
                            onChange={(e) => setInviteRoleId(e.target.value)}
                            className="w-full h-14 bg-white/70 border border-white/60 rounded-xl shadow-inner pl-10 pr-4 pt-4 text-slate-800 text-sm font-medium focus:ring-2 focus:ring-sky-300/60 focus:outline-none transition appearance-none"
                        >
                            {roles.map(role => (
                                <option key={role.id} value={role.id}>{role.name}</option>
                            ))}
                        </select>
                        <label className="absolute left-10 top-3 text-xs text-slate-500 pointer-events-none">Assign Role</label>
                    </div>
                </div>
            </GlassModal>

            {/* Approve Modal */}
            <GlassModal
                isOpen={isApproveModalOpen}
                onClose={() => setIsApproveModalOpen(false)}
                title="Approve Registration"
                subtitle={`Assign a role for ${userToApprove?.name}`}
                footer={
                    <div className="flex justify-end gap-3 w-full">
                        <GlassButton variant="secondary" onClick={() => setIsApproveModalOpen(false)}>Cancel</GlassButton>
                        <GlassButton variant="primary" onClick={handleApprove}>Confirm Approval</GlassButton>
                    </div>
                }
            >
                <div className="py-6 space-y-4 max-w-md mx-auto">
                    <div className="p-4 bg-blue-50 rounded-xl border border-blue-100 mb-4">
                        <p className="text-sm text-blue-800">
                            User <strong>{userToApprove?.name}</strong> ({userToApprove?.email}) will be activated. Please select their access level.
                        </p>
                    </div>
                    <div className="relative group">
                        <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none z-10">
                            <Shield size={16} />
                        </div>
                        <select
                            value={approvalRoleId}
                            onChange={(e) => setApprovalRoleId(e.target.value)}
                            className="w-full h-14 bg-white/70 border border-white/60 rounded-xl shadow-inner pl-10 pr-4 pt-4 text-slate-800 text-sm font-medium focus:ring-2 focus:ring-sky-300/60 focus:outline-none transition appearance-none"
                        >
                            {roles.map(role => (
                                <option key={role.id} value={role.id}>{role.name}</option>
                            ))}
                        </select>
                        <label className="absolute left-10 top-3 text-xs text-slate-500 pointer-events-none">Assign Role</label>
                    </div>
                </div>
            </GlassModal>

            {/* User History Modal */}
            <GlassModal
                isOpen={isHistoryModalOpen}
                onClose={() => setIsHistoryModalOpen(false)}
                title="Activity History"
                subtitle={`Activity log for ${selectedHistoryUser?.name}`}
                footer={
                    <div className="flex justify-end w-full">
                        <GlassButton variant="primary" onClick={() => setIsHistoryModalOpen(false)}>Close</GlassButton>
                    </div>
                }
            >
                <div className="h-[60vh] overflow-y-auto">
                    {selectedHistoryUser && <AuditLog userIdFilter={selectedHistoryUser.id} />}
                </div>
            </GlassModal>
        </div>
    );
};
