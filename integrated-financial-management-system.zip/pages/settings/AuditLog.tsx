
import React, { useState, useEffect, useMemo } from 'react';
import { useData } from '../../context/DataContext';
import { ActivityLog, ActionType } from '../../types';
import { GlassCard } from '../../components/ui/GlassCard';
import { 
    Search, Filter, Calendar, Activity, User, Tag, 
    PlusCircle, Edit3, Trash2, LogIn, LogOut, ShieldCheck, 
    CheckCircle, XCircle, AlertCircle, Box, DollarSign,
    FileText, Users, RefreshCw
} from 'lucide-react';
import { motion } from 'framer-motion';

const getActionIcon = (action: ActionType) => {
    switch (action) {
        case 'Create': return <PlusCircle size={14} />;
        case 'Edit': return <Edit3 size={14} />;
        case 'Delete': return <Trash2 size={14} />;
        case 'Login': return <LogIn size={14} />;
        case 'Logout': return <LogOut size={14} />;
        case 'Approve': return <CheckCircle size={14} />;
        case 'Reject': return <XCircle size={14} />;
        case 'Status Change': return <RefreshCw size={14} />;
        default: return <Activity size={14} />;
    }
};

const getActionColor = (action: ActionType) => {
    switch (action) {
        case 'Create': return 'bg-emerald-100 text-emerald-700 border-emerald-200';
        case 'Edit': return 'bg-sky-100 text-sky-700 border-sky-200';
        case 'Delete': return 'bg-rose-100 text-rose-700 border-rose-200';
        case 'Login': return 'bg-indigo-100 text-indigo-700 border-indigo-200';
        case 'Logout': return 'bg-slate-100 text-slate-700 border-slate-200';
        case 'Approve': return 'bg-green-100 text-green-700 border-green-200';
        case 'Reject': return 'bg-red-100 text-red-700 border-red-200';
        case 'Status Change': return 'bg-amber-100 text-amber-700 border-amber-200';
        default: return 'bg-gray-100 text-gray-700';
    }
};

const getModuleIcon = (module: string) => {
    switch (module) {
        case 'Orders': return <Box size={14} />;
        case 'Financials': 
        case 'Finance': return <DollarSign size={14} />;
        case 'Payroll': return <FileText size={14} />;
        case 'Auth': return <ShieldCheck size={14} />;
        case 'Users': return <Users size={14} />;
        default: return <Tag size={14} />;
    }
};

export const AuditLog: React.FC<{ userIdFilter?: string }> = ({ userIdFilter }) => {
    const { getActivityLogs, _version } = useData();
    const [logs, setLogs] = useState<ActivityLog[]>([]);
    const [searchQuery, setSearchQuery] = useState('');
    const [moduleFilter, setModuleFilter] = useState<string>('');
    const [actionFilter, setActionFilter] = useState<string>('');
    const [isLoading, setIsLoading] = useState(true);

    // Date Range
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');

    useEffect(() => {
        setIsLoading(true);
        getActivityLogs().then(data => {
            setLogs(data);
            setIsLoading(false);
        });
    }, [_version]);

    const modules = useMemo(() => Array.from(new Set(logs.map(l => l.module))), [logs]);
    const actions = useMemo(() => Array.from(new Set(logs.map(l => l.action))), [logs]);

    const filteredLogs = useMemo(() => {
        return logs.filter(log => {
            if (userIdFilter && log.userId !== userIdFilter) return false;
            
            if (searchQuery) {
                const q = searchQuery.toLowerCase();
                if (!log.description.toLowerCase().includes(q) && 
                    !log.userName.toLowerCase().includes(q) && 
                    !log.targetId?.toLowerCase().includes(q)) return false;
            }

            if (moduleFilter && log.module !== moduleFilter) return false;
            if (actionFilter && log.action !== actionFilter) return false;

            if (startDate) {
                const logDate = new Date(log.timestamp);
                const start = new Date(startDate);
                if (logDate < start) return false;
            }
            if (endDate) {
                const logDate = new Date(log.timestamp);
                const end = new Date(endDate);
                end.setHours(23, 59, 59, 999);
                if (logDate > end) return false;
            }

            return true;
        });
    }, [logs, userIdFilter, searchQuery, moduleFilter, actionFilter, startDate, endDate]);

    return (
        <div className="space-y-6">
            {!userIdFilter && (
                <div className="flex flex-col md:flex-row justify-between items-center gap-4">
                    <div>
                        <h1 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
                            <Activity className="text-sky-500" /> System Audit Log
                        </h1>
                        <p className="text-sm text-slate-500">Track all system activities and changes.</p>
                    </div>
                </div>
            )}

            <GlassCard className="p-5 bg-white/80">
                <div className="flex flex-col xl:flex-row gap-4 justify-between items-start xl:items-center">
                    {/* Search - Takes full width on mobile, fixed width on desktop */}
                    <div className="relative w-full xl:w-96">
                        <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                        <input 
                            type="text" 
                            value={searchQuery}
                            onChange={e => setSearchQuery(e.target.value)}
                            placeholder="Search by user, action, or details..." 
                            className="w-full h-11 pl-10 pr-4 rounded-xl bg-slate-100/50 border border-slate-200 text-sm focus:ring-2 focus:ring-sky-300 focus:outline-none transition-all"
                        />
                    </div>
                    
                    {/* Filters Group */}
                    <div className="flex flex-col md:flex-row gap-3 w-full xl:w-auto">
                        {/* Dropdowns */}
                        <div className="flex gap-2 w-full md:w-auto">
                            <div className="relative flex-1 md:w-40">
                                <Filter size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                                <select 
                                    value={moduleFilter} 
                                    onChange={e => setModuleFilter(e.target.value)} 
                                    className="w-full h-11 pl-9 bg-slate-100/50 border border-slate-200 rounded-xl text-sm text-slate-700 focus:ring-2 focus:ring-sky-300 focus:outline-none appearance-none cursor-pointer"
                                >
                                    <option value="">All Modules</option>
                                    {modules.map(m => <option key={m} value={m}>{m}</option>)}
                                </select>
                            </div>
                            
                            <div className="relative flex-1 md:w-40">
                                <Tag size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                                <select 
                                    value={actionFilter} 
                                    onChange={e => setActionFilter(e.target.value)} 
                                    className="w-full h-11 pl-9 bg-slate-100/50 border border-slate-200 rounded-xl text-sm text-slate-700 focus:ring-2 focus:ring-sky-300 focus:outline-none appearance-none cursor-pointer"
                                >
                                    <option value="">All Actions</option>
                                    {actions.map(a => <option key={a} value={a}>{a}</option>)}
                                </select>
                            </div>
                        </div>

                        {/* Date Range Pill */}
                        <div className="flex items-center gap-2 bg-slate-100/50 border border-slate-200 p-1 rounded-xl w-full md:w-auto">
                            <div className="relative flex-1 md:flex-none">
                                <input 
                                    type="date" 
                                    value={startDate} 
                                    onChange={e => setStartDate(e.target.value)} 
                                    className="w-full md:w-32 h-9 bg-white rounded-lg border-none text-xs px-2 focus:ring-2 focus:ring-sky-300 text-slate-600" 
                                />
                            </div>
                            <span className="text-slate-400 text-xs font-bold px-1">TO</span>
                            <div className="relative flex-1 md:flex-none">
                                <input 
                                    type="date" 
                                    value={endDate} 
                                    onChange={e => setEndDate(e.target.value)} 
                                    className="w-full md:w-32 h-9 bg-white rounded-lg border-none text-xs px-2 focus:ring-2 focus:ring-sky-300 text-slate-600" 
                                />
                            </div>
                        </div>
                    </div>
                </div>
            </GlassCard>

            <div className="bg-white/60 backdrop-blur-xl border border-white/50 rounded-2xl shadow-sm overflow-hidden min-h-[500px]">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left">
                        <thead className="bg-slate-50/80 border-b border-slate-200 font-semibold text-slate-500">
                            <tr>
                                <th className="px-6 py-4">Time</th>
                                <th className="px-6 py-4">User</th>
                                <th className="px-6 py-4">Action</th>
                                <th className="px-6 py-4">Module</th>
                                <th className="px-6 py-4">Description</th>
                                <th className="px-6 py-4">Ref ID</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                            {filteredLogs.map(log => (
                                <motion.tr 
                                    key={log.id} 
                                    initial={{ opacity: 0 }} 
                                    animate={{ opacity: 1 }}
                                    className="hover:bg-white/60 transition-colors"
                                >
                                    <td className="px-6 py-3 text-slate-500 text-xs whitespace-nowrap">
                                        {new Date(log.timestamp).toLocaleString()}
                                    </td>
                                    <td className="px-6 py-3">
                                        <div className="flex items-center gap-2">
                                            <div className="w-6 h-6 rounded-full bg-slate-200 flex items-center justify-center text-xs font-bold text-slate-600">
                                                {log.userName.charAt(0)}
                                            </div>
                                            <div>
                                                <p className="font-bold text-slate-700 text-xs">{log.userName}</p>
                                                <p className="text-[10px] text-slate-400">{log.userRole}</p>
                                            </div>
                                        </div>
                                    </td>
                                    <td className="px-6 py-3">
                                        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider border ${getActionColor(log.action)}`}>
                                            {getActionIcon(log.action)}
                                            {log.action}
                                        </span>
                                    </td>
                                    <td className="px-6 py-3 text-slate-600 font-medium">
                                        <div className="flex items-center gap-2">
                                            <div className="p-1 bg-slate-100 rounded-md text-slate-500">
                                                {getModuleIcon(log.module)}
                                            </div>
                                            {log.module}
                                        </div>
                                    </td>
                                    <td className="px-6 py-3 text-slate-700 max-w-md truncate" title={log.description}>
                                        {log.description}
                                    </td>
                                    <td className="px-6 py-3 font-mono text-xs text-slate-500">
                                        {log.targetId ? (
                                            <span className="bg-slate-100 px-2 py-0.5 rounded text-slate-600 border border-slate-200">
                                                {log.targetId}
                                            </span>
                                        ) : '-'}
                                    </td>
                                </motion.tr>
                            ))}
                            {filteredLogs.length === 0 && (
                                <tr>
                                    <td colSpan={6} className="text-center py-12 text-slate-400">
                                        <div className="flex flex-col items-center justify-center gap-2">
                                            <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center text-slate-300">
                                                <Activity size={24} />
                                            </div>
                                            <p>No activity logs found matching your criteria.</p>
                                        </div>
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};
