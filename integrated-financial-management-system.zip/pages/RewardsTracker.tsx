


import React, { useState, useEffect, useMemo } from 'react';
import { useData } from '../context/DataContext';
import { GlassCard } from '../components/ui/GlassCard';
import { GlassButton } from '../components/ui/GlassButton';
import { Gift, TrendingUp, Package, CheckCircle, RefreshCw, AlertCircle } from 'lucide-react';
import { RewardClaim, RewardMonthConfig, CustomerOrder } from '../types';

const formatCurrency = (value: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value);

// --- Helper Types ---
interface MonthlyRewardData {
    period: string; // YYYY-MM
    monthLabel: string;
    totalOrders: number;
    totalItems: number;
    // Config State
    pointsPerItem: number;
    valuePerPoint: number;
    // Calculations
    totalPoints: number;
    cashValue: number;
    // Status
    isClaimed: boolean;
    claimData?: RewardClaim;
    hasSavedConfig: boolean;
}

// --- Components ---
const StatCard: React.FC<{ title: string; value: string; icon: React.ReactNode; color: string }> = ({ title, value, icon, color }) => (
    <div className="relative overflow-hidden bg-white/60 backdrop-blur-xl border border-white/50 rounded-2xl p-5 shadow-sm">
        <div className={`absolute top-0 right-0 p-3 opacity-10 text-${color}-600`}>
            {React.cloneElement(icon as React.ReactElement<any>, { size: 60 })}
        </div>
        <div className="relative z-10">
            <div className={`p-2 w-fit rounded-lg bg-${color}-100 text-${color}-700 mb-3`}>{icon}</div>
            <p className="text-sm font-semibold text-slate-500 uppercase tracking-wider">{title}</p>
            <p className="text-2xl font-bold text-slate-800 mt-1">{value}</p>
        </div>
    </div>
);

const RewardsTracker: React.FC = () => {
    const { getOrders, getAccountById, getRewardClaims, getRewardMonthConfigs, upsertRewardMonthConfig, recognizeRewardPoints, _version } = useData();
    
    // State
    const [assetBalance, setAssetBalance] = useState(0);
    const [monthlyData, setMonthlyData] = useState<MonthlyRewardData[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    // Global Defaults (used for months without specific config)
    const [defaultPointsPerItem, setDefaultPointsPerItem] = useState(8);
    const [defaultValuePer100Points, setDefaultValuePer100Points] = useState(1.00);

    // Fetch Data
    useEffect(() => {
        const loadData = async () => {
            setIsLoading(true);
            try {
                const [orders, account, claims, configs] = await Promise.all([
                    getOrders(),
                    getAccountById('1180'),
                    getRewardClaims(),
                    getRewardMonthConfigs()
                ]);

                setAssetBalance(account?.balance || 0);

                // Group Orders by Month
                const grouped = new Map<string, { count: number; items: number }>();
                
                orders.forEach(o => {
                    if (o.status === 'Cancelled') return;
                    // Use orderDate for grouping. If missing, fallback to createdAt, but ensure it's a valid date object.
                    const date = o.orderDate ? new Date(o.orderDate) : new Date(o.createdAt);
                    const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
                    
                    // Ensure itemCount is at least 1 if missing (fallback for legacy/mock data)
                    const count = (o.itemCount !== undefined && o.itemCount > 0) ? o.itemCount : 1;

                    const current = grouped.get(key) || { count: 0, items: 0 };
                    grouped.set(key, {
                        count: current.count + 1,
                        items: current.items + count
                    });
                });

                // Build Monthly Data
                const result: MonthlyRewardData[] = [];
                const periods = Array.from(grouped.keys()).sort().reverse();

                for (const period of periods) {
                    const stats = grouped.get(period)!;
                    const claim = claims.find(c => c.period === period);
                    const config = configs.find(c => c.period === period);

                    // Determine Rates:
                    // 1. If claimed, use claim snapshot (historical accuracy)
                    // 2. If config saved, use saved config (user override)
                    // 3. Else, use current global defaults
                    
                    let pointsRate = defaultPointsPerItem;
                    let valueRate = defaultValuePer100Points; // Value per 100 points
                    
                    if (claim) {
                        pointsRate = claim.appliedPointsPerItem;
                        valueRate = claim.appliedValuePerPoint;
                    } else if (config) {
                        pointsRate = config.pointsPerItem;
                        valueRate = config.valuePerPoint;
                    }

                    const totalPoints = stats.items * pointsRate;
                    const cashValue = (totalPoints / 100) * valueRate;

                    const [year, month] = period.split('-');
                    const dateObj = new Date(parseInt(year), parseInt(month) - 1);
                    const monthLabel = dateObj.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

                    result.push({
                        period,
                        monthLabel,
                        totalOrders: stats.count,
                        totalItems: stats.items,
                        pointsPerItem: pointsRate,
                        valuePerPoint: valueRate,
                        totalPoints,
                        cashValue,
                        isClaimed: !!claim,
                        claimData: claim,
                        hasSavedConfig: !!config
                    });
                }
                setMonthlyData(result);

            } catch (error) {
                console.error(error);
            } finally {
                setIsLoading(false);
            }
        };
        loadData();
    }, [_version, defaultPointsPerItem, defaultValuePer100Points]); // Re-calc if defaults change (for unsaved rows)


    // Handlers
    const handleRateChange = async (period: string, field: 'points' | 'value', newValue: string) => {
        const numValue = parseFloat(newValue);
        if (isNaN(numValue) || numValue < 0) return;

        const row = monthlyData.find(r => r.period === period);
        if (!row) return;

        const newConfig: RewardMonthConfig = {
            period,
            pointsPerItem: field === 'points' ? numValue : row.pointsPerItem,
            valuePerPoint: field === 'value' ? numValue : row.valuePerPoint,
        };

        // Optimistic UI Update
        setMonthlyData(prev => prev.map(r => {
            if (r.period === period) {
                const newPoints = field === 'points' ? numValue : r.pointsPerItem;
                const newValueRate = field === 'value' ? numValue : r.valuePerPoint;
                return {
                    ...r,
                    pointsPerItem: newPoints,
                    valuePerPoint: newValueRate,
                    totalPoints: r.totalItems * newPoints,
                    cashValue: (r.totalItems * newPoints / 100) * newValueRate,
                    hasSavedConfig: true
                };
            }
            return r;
        }));

        // Persist Snapshot
        await upsertRewardMonthConfig(newConfig);
    };

    const handleClaim = async (row: MonthlyRewardData) => {
        if (row.cashValue <= 0) {
             alert("Cannot claim 0 value. Ensure there are items and points configured for this month.");
             return;
        }
        if (!window.confirm(`Confirm claiming ${formatCurrency(row.cashValue)} for ${row.monthLabel}? This will create a financial journal entry.`)) return;

        try {
            await recognizeRewardPoints(
                row.period,
                row.totalItems,
                row.cashValue,
                `Reward Points Income - ${row.monthLabel}`,
                row.pointsPerItem,
                row.valuePerPoint
            );
            
            // Optimistically update local state to show claimed status immediately
            setMonthlyData(prev => prev.map(r => r.period === row.period ? { ...r, isClaimed: true } : r));
            
            alert("Points successfully claimed as income! Check General Ledger (Account 1180).");
        } catch (error) {
            alert(`Error: ${(error as Error).message}`);
        }
    };

    const pendingPointsValue = monthlyData.filter(r => !r.isClaimed).reduce((sum, r) => sum + r.cashValue, 0);
    const totalItemsMonth = monthlyData.length > 0 ? monthlyData[0].totalItems : 0;

    return (
        <div className="space-y-8">
            {/* Top Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <StatCard 
                    title="Total Points Value (Asset)" 
                    value={formatCurrency(assetBalance)} 
                    icon={<Gift />} 
                    color="emerald" 
                />
                <StatCard 
                    title="Pending Potential Value" 
                    value={formatCurrency(pendingPointsValue)} 
                    icon={<TrendingUp />} 
                    color="amber" 
                />
                <StatCard 
                    title="Items Ordered (Latest Month)" 
                    value={totalItemsMonth.toString()} 
                    icon={<Package />} 
                    color="sky" 
                />
            </div>

            {/* Config Bar */}
            <GlassCard className="flex flex-col md:flex-row justify-between items-center gap-4 p-4">
                <div className="flex items-center gap-2 text-slate-600">
                    <AlertCircle size={18} />
                    <span className="text-sm font-semibold">Global Defaults for New Months:</span>
                </div>
                <div className="flex gap-6">
                    <div className="flex items-center gap-2">
                        <label className="text-sm text-slate-500">Points / Item:</label>
                        <input 
                            type="number" 
                            value={defaultPointsPerItem} 
                            onChange={e => setDefaultPointsPerItem(parseFloat(e.target.value) || 0)} 
                            className="w-20 h-9 text-center bg-white/50 border border-slate-300 rounded-lg text-sm"
                        />
                    </div>
                    <div className="flex items-center gap-2">
                        <label className="text-sm text-slate-500">Value / 100 Pts ($):</label>
                        <input 
                            type="number" 
                            value={defaultValuePer100Points} 
                            onChange={e => setDefaultValuePer100Points(parseFloat(e.target.value) || 0)} 
                            className="w-20 h-9 text-center bg-white/50 border border-slate-300 rounded-lg text-sm"
                            step="0.1"
                        />
                    </div>
                </div>
            </GlassCard>

            {/* Main Table */}
            <GlassCard title="Monthly Rewards Breakdown" bodyClassName="p-0">
                <div className="overflow-x-auto">
                    <table className="w-full min-w-[900px]">
                        <thead className="bg-slate-50/50 border-b border-slate-200">
                            <tr>
                                <th className="px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase">Month</th>
                                <th className="px-6 py-4 text-center text-xs font-bold text-slate-500 uppercase">Total Items</th>
                                <th className="px-6 py-4 text-center text-xs font-bold text-slate-500 uppercase">Points / Item</th>
                                <th className="px-6 py-4 text-center text-xs font-bold text-slate-500 uppercase">Total Points</th>
                                <th className="px-6 py-4 text-center text-xs font-bold text-slate-500 uppercase">Value / 100 Pts</th>
                                <th className="px-6 py-4 text-right text-xs font-bold text-slate-500 uppercase">Cash Value ($)</th>
                                <th className="px-6 py-4 text-center text-xs font-bold text-slate-500 uppercase">Status</th>
                                <th className="px-6 py-4 text-center text-xs font-bold text-slate-500 uppercase">Action</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                            {isLoading ? (
                                <tr><td colSpan={8} className="text-center py-8 text-slate-500">Loading data...</td></tr>
                            ) : monthlyData.map((row) => (
                                <tr key={row.period} className={`hover:bg-slate-50/50 transition-colors ${row.isClaimed ? 'bg-slate-50/30' : ''}`}>
                                    <td className="px-6 py-4">
                                        <p className="font-bold text-slate-700">{row.monthLabel}</p>
                                        <p className="text-xs text-slate-400">{row.totalOrders} Orders</p>
                                    </td>
                                    <td className="px-6 py-4 text-center font-semibold text-slate-600">{row.totalItems}</td>
                                    <td className="px-6 py-4 text-center">
                                        {row.isClaimed ? (
                                            <span className="text-slate-500 font-mono">{row.pointsPerItem}</span>
                                        ) : (
                                            <input 
                                                type="number" 
                                                value={row.pointsPerItem} 
                                                onChange={e => handleRateChange(row.period, 'points', e.target.value)}
                                                className="w-16 h-8 text-center border border-slate-200 rounded bg-white focus:ring-2 focus:ring-sky-200 outline-none transition-all"
                                            />
                                        )}
                                    </td>
                                    <td className="px-6 py-4 text-center font-mono text-slate-600">{row.totalPoints.toLocaleString()}</td>
                                    <td className="px-6 py-4 text-center">
                                         {row.isClaimed ? (
                                            <span className="text-slate-500 font-mono">${row.valuePerPoint}</span>
                                        ) : (
                                            <input 
                                                type="number" 
                                                value={row.valuePerPoint} 
                                                onChange={e => handleRateChange(row.period, 'value', e.target.value)}
                                                className="w-16 h-8 text-center border border-slate-200 rounded bg-white focus:ring-2 focus:ring-sky-200 outline-none transition-all"
                                                step="0.1"
                                            />
                                        )}
                                    </td>
                                    <td className="px-6 py-4 text-right">
                                        <span className="font-bold font-mono text-emerald-600 text-lg">{formatCurrency(row.cashValue)}</span>
                                    </td>
                                    <td className="px-6 py-4 text-center">
                                        {row.isClaimed ? (
                                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                                <CheckCircle size={12} className="mr-1" /> Claimed
                                            </span>
                                        ) : (
                                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-800">
                                                Pending
                                            </span>
                                        )}
                                    </td>
                                    <td className="px-6 py-4 text-center">
                                        <GlassButton 
                                            variant={row.isClaimed ? 'secondary' : 'primary'} 
                                            disabled={row.isClaimed || row.cashValue <= 0}
                                            onClick={() => handleClaim(row)}
                                            className={`h-9 text-xs ${row.isClaimed ? 'opacity-50 cursor-not-allowed' : ''}`}
                                        >
                                            {row.isClaimed ? 'Claimed' : 'Claim Income'}
                                        </GlassButton>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </GlassCard>
        </div>
    );
};

export default RewardsTracker;