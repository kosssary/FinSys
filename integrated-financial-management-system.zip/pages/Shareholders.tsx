

import React, { useState, useEffect } from 'react';
import { useData } from '../context/DataContext';
import { Shareholder } from '../types';
import Table from '../components/ui/Table';
import AddShareholderModal from '../components/modals/AddShareholderModal';

const Shareholders: React.FC = () => {
    const { getShareholders, _version } = useData();
    const [shareholders, setShareholders] = useState<Shareholder[]>([]);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingShareholder, setEditingShareholder] = useState<Shareholder | null>(null);

    useEffect(() => {
        getShareholders().then(setShareholders);
    }, [_version]);

    const handleOpenModal = (shareholder: Shareholder | null = null) => {
        setEditingShareholder(shareholder);
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setEditingShareholder(null);
    };

    const formatCurrency = (value: number) => {
        return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value);
    };

    return (
        <div>
            <div className="flex justify-end items-center mb-6">
                 <button 
                    onClick={() => handleOpenModal()}
                    className="px-5 py-2.5 font-semibold tracking-wide text-white capitalize transition-all duration-200 transform bg-gradient-to-r from-sky-500 to-cyan-500 rounded-lg hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-sky-300 active:scale-95">
                    Add Shareholder
                </button>
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md">
                <Table<Shareholder>
                    headers={['Name', 'Profit Share', 'Capital Contribution', 'Actions']}
                    data={shareholders}
                    renderRow={(shareholder) => (
                        <tr key={shareholder.id} className="text-gray-700 dark:text-gray-400">
                            <td className="px-4 py-3 text-sm font-semibold">{shareholder.name}</td>
                            <td className="px-4 py-3 text-sm">{shareholder.profitSharePercentage}%</td>
                            <td className="px-4 py-3 text-sm font-semibold">{formatCurrency(shareholder.capitalContributions)}</td>
                            <td className="px-4 py-3 text-sm">
                                <button onClick={() => handleOpenModal(shareholder)} className="text-blue-500 hover:underline">Edit</button>
                            </td>
                        </tr>
                    )}
                />
            </div>

            <AddShareholderModal 
                isOpen={isModalOpen} 
                onClose={handleCloseModal}
                shareholder={editingShareholder}
            />
        </div>
    );
};

export default Shareholders;