
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useData } from '../context/DataContext';
import { Employee, EmployeeLedgerEntry, Payroll } from '../types';
import RecordAdvanceModal from '../components/modals/RecordAdvanceModal';
import { 
    User, Briefcase, Calendar, DollarSign, Wallet, ChevronLeft, 
    Plus, ArrowUpRight, ArrowDownLeft, History, FileText, CreditCard,
    AlertCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// --- HELPER COMPONENTS ---

const GlassContainer: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className = '' }) => (
    <div className={`bg-white/60 dark:bg-slate-900/60 backdrop-blur-2xl border border-white/50 dark:border-slate-700/50 rounded-3xl shadow-[0_8px_30px_rgba(0,0,0,0.04)] ${className}`}>
        {children}
    </div>
);

const StatPill: React.FC<{ label: string; value: string; icon: React.ReactNode; colorClass?: string }> = ({ label, value, icon, colorClass = "bg-white/50 text-slate-700" }) => (
    <div className={`flex items-center gap-3 px-5 py-3 rounded-2xl border border-white/40 shadow-sm ${colorClass}`}>
        <div className="p-2 bg-white/60 dark:bg-black/20 rounded-xl backdrop-blur-md">
            {icon}
        </div>
        <div>
            <p className="text-[10px] uppercase tracking-wider font-bold opacity-70">{label}</p>
            <p className="text-lg font-bold font-mono leading-tight">{value}</p>
        </div>
    </div>
);

const EmptyState: React.FC<{ title: string; message: string; icon: React.ReactNode }> = ({ title, message, icon }) => (
    <div className="flex flex-col items-center justify-center py-16 text-center">
        <div className="w-20 h-20 bg-slate-50/50 dark:bg-slate-800/50 rounded-full flex items-center justify-center mb-4 text-slate-300 dark:text-slate-600">
            {React.cloneElement(icon as React.ReactElement, { size: 40 })}
        </div>
        <h3 className="text-lg font-bold text-slate-600 dark:text-slate-300">{title}</h3>
        <p className="text-sm text-slate-400 max-w-xs mt-1">{message}</p>
    </div>
);

// --- MAIN PAGE ---

const EmployeeProfile: React.FC = () => {
    const { employeeId } = useParams<{ employeeId: string }>();
    const { getEmployeeById, getEmployeeLedger, getPayrolls, _version } = useData();

    const [employee, setEmployee] = useState<Employee | null>(null);
    const [ledger, setLedger] = useState<EmployeeLedgerEntry[]>([]);
    const [payrolls, setPayrolls] = useState<Payroll[]>([]);
    const [activeTab, setActiveTab] = useState<'ledger' | 'payroll' | 'details'>('ledger');
    const [isAdvanceModalOpen, setIsAdvanceModalOpen] = useState(false);
    const [isLoading, setIsLoading] = useState(true);
    
    const fetchData = useCallback(async () => {
        if (!employeeId) return;
        setIsLoading(true);
        try {
            const [emp, ledg, allPayrolls] = await Promise.all([
                getEmployeeById(employeeId),
                getEmployeeLedger(employeeId),
                getPayrolls()
            ]);
            setEmployee(emp);
            setLedger(ledg);
            setPayrolls(allPayrolls.filter(p => p.employees.some(e => e.employeeId === employeeId)));
        } finally {
            setIsLoading(false);
        }
    }, [employeeId, getEmployeeById, getEmployeeLedger, getPayrolls]);

    useEffect(() => {
        fetchData();
    }, [employeeId, _version, fetchData]);

    const formatCurrency = (value: number) => new Intl.NumberFormat('en-US').format(value);
    
    const currentBalance = useMemo(() => ledger.reduce((bal, entry) => bal + entry.debit - entry.credit, 0), [ledger]);

    if (isLoading) {
        return <div className="flex items-center justify-center h-screen text-slate-400">Loading Profile...</div>;
    }

    if (!employee) {
        return <div className="text-center p-10 text-rose-500">Employee not found.</div>;
    }

    const getInitials = (name: string) => name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);

    return (
        <div className="space-y-8 pb-20 max-w-7xl mx-auto">
            {/* Back Navigation */}
            <Link to="/employees" className="inline-flex items-center text-sm font-medium text-slate-500 hover:text-sky-600 transition-colors">
                <ChevronLeft size={16} className="mr-1" /> Back to Employees Directory
            </Link>

            {/* 1. HERO HEADER CARD */}
            <GlassContainer className="relative overflow-hidden p-8">
                {/* Decorative Background Blob */}
                <div className="absolute -top-24 -right-24 w-64 h-64 bg-gradient-to-br from-sky-400/20 to-indigo-400/20 rounded-full blur-3xl pointer-events-none" />

                <div className="relative z-10 flex flex-col lg:flex-row justify-between items-start lg:items-center gap-8">
                    
                    {/* Identity Section */}
                    <div className="flex items-center gap-6">
                        <div className="relative">
                            <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-sky-500 to-indigo-600 flex items-center justify-center text-white text-3xl font-bold shadow-lg shadow-indigo-500/30 ring-4 ring-white/30">
                                {getInitials(employee.fullName)}
                            </div>
                            <div className={`absolute -bottom-2 -right-2 w-6 h-6 rounded-full border-4 border-white dark:border-slate-800 ${employee.isActive ? 'bg-emerald-500' : 'bg-slate-400'}`} />
                        </div>
                        <div>
                            <h1 className="text-3xl font-bold text-slate-800 dark:text-white tracking-tight">{employee.fullName}</h1>
                            <div className="flex items-center gap-2 mt-1">
                                <span className="px-3 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-600 dark:text-slate-300 uppercase tracking-wide">
                                    {employee.position}
                                </span>
                                <span className="text-sm text-slate-400 flex items-center gap-1">
                                    <Calendar size={14} /> Joined {new Date(employee.startDate).toLocaleDateString()}
                                </span>
                            </div>
                        </div>
                    </div>

                    {/* Actions & Stats */}
                    <div className="flex flex-col items-end gap-6 w-full lg:w-auto">
                        <button 
                            onClick={() => setIsAdvanceModalOpen(true)}
                            className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-sky-500 to-indigo-500 text-white rounded-xl font-bold shadow-lg hover:shadow-sky-500/25 hover:scale-[1.02] active:scale-[0.98] transition-all"
                        >
                            <Wallet size={18} />
                            Record Advance / Loan
                        </button>
                        
                        <div className="flex flex-wrap justify-end gap-3">
                            <StatPill 
                                label="Monthly Salary" 
                                value={`$${formatCurrency(employee.basicMonthlySalary)}`} 
                                icon={<DollarSign size={18} className="text-emerald-600" />} 
                                colorClass="bg-emerald-50/50 border-emerald-100 text-emerald-900"
                            />
                            <StatPill 
                                label="Current Balance" 
                                value={`$${formatCurrency(currentBalance)}`} 
                                icon={<AlertCircle size={18} className={currentBalance > 0 ? "text-rose-600" : "text-slate-400"} />} 
                                colorClass={currentBalance > 0 ? "bg-rose-50/50 border-rose-100 text-rose-900" : "bg-slate-50/50 border-slate-200 text-slate-700"}
                            />
                        </div>
                    </div>
                </div>
            </GlassContainer>

            {/* 2. TABS NAVIGATION */}
            <div className="flex justify-center">
                <div className="flex p-1.5 bg-slate-200/60 dark:bg-slate-800/60 backdrop-blur-md rounded-2xl">
                    {[
                        { id: 'ledger', label: 'Financial Ledger', icon: History },
                        { id: 'payroll', label: 'Payroll History', icon: FileText },
                        { id: 'details', label: 'Personal Details', icon: User },
                    ].map((tab) => (
                        <button
                            key={tab.id}
                            onClick={() => setActiveTab(tab.id as any)}
                            className={`relative flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-bold transition-all duration-200 ${
                                activeTab === tab.id 
                                ? 'text-slate-800 dark:text-white shadow-sm' 
                                : 'text-slate-500 hover:text-slate-700 dark:text-slate-400'
                            }`}
                        >
                            {activeTab === tab.id && (
                                <motion.div 
                                    layoutId="activeTab"
                                    className="absolute inset-0 bg-white dark:bg-slate-700 rounded-xl"
                                    initial={false}
                                    transition={{ type: "spring", stiffness: 500, damping: 30 }}
                                />
                            )}
                            <span className="relative z-10 flex items-center gap-2">
                                <tab.icon size={16} /> {tab.label}
                            </span>
                        </button>
                    ))}
                </div>
            </div>

            {/* 3. CONTENT AREA */}
            <AnimatePresence mode="wait">
                <motion.div
                    key={activeTab}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.2 }}
                >
                    {/* LEDGER TAB */}
                    {activeTab === 'ledger' && (
                        <GlassContainer className="overflow-hidden">
                            {ledger.length > 0 ? (
                                <div className="overflow-x-auto">
                                    <table className="w-full">
                                        <thead>
                                            <tr className="border-b border-slate-200/50 text-left text-xs font-bold text-slate-500 uppercase tracking-wider">
                                                <th className="px-6 py-4">Date</th>
                                                <th className="px-6 py-4">Type</th>
                                                <th className="px-6 py-4">Description</th>
                                                <th className="px-6 py-4 text-right text-rose-600">Debit (Owed)</th>
                                                <th className="px-6 py-4 text-right text-emerald-600">Credit (Paid)</th>
                                                <th className="px-6 py-4 text-right">Balance</th>
                                            </tr>
                                        </thead>
                                        <tbody className="divide-y divide-slate-100/50">
                                            {(() => {
                                                let runningBalance = 0;
                                                return ledger.map((entry) => {
                                                    runningBalance += entry.debit - entry.credit;
                                                    return (
                                                        <tr key={entry.id} className="hover:bg-sky-50/30 transition-colors group">
                                                            <td className="px-6 py-4 text-sm text-slate-600 font-medium">
                                                                {new Date(entry.date).toLocaleDateString()}
                                                            </td>
                                                            <td className="px-6 py-4">
                                                                <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold ${
                                                                    entry.debit > 0 ? 'bg-rose-100 text-rose-700' : 'bg-emerald-100 text-emerald-700'
                                                                }`}>
                                                                    {entry.debit > 0 ? <ArrowUpRight size={12}/> : <ArrowDownLeft size={12}/>}
                                                                    {entry.transactionType}
                                                                </span>
                                                            </td>
                                                            <td className="px-6 py-4 text-sm text-slate-600 max-w-xs truncate" title={entry.description}>
                                                                {entry.description}
                                                            </td>
                                                            <td className="px-6 py-4 text-right font-mono text-sm text-rose-600 font-medium">
                                                                {entry.debit > 0 ? formatCurrency(entry.debit) : '-'}
                                                            </td>
                                                            <td className="px-6 py-4 text-right font-mono text-sm text-emerald-600 font-medium">
                                                                {entry.credit > 0 ? formatCurrency(entry.credit) : '-'}
                                                            </td>
                                                            <td className="px-6 py-4 text-right font-mono text-sm font-bold text-slate-700">
                                                                {formatCurrency(runningBalance)}
                                                            </td>
                                                        </tr>
                                                    );
                                                });
                                            })()}
                                        </tbody>
                                    </table>
                                </div>
                            ) : (
                                <EmptyState 
                                    title="No Financial History" 
                                    message="This employee has no recorded advances, loans, or salary payments yet." 
                                    icon={<History />}
                                />
                            )}
                        </GlassContainer>
                    )}

                    {/* PAYROLL TAB */}
                    {activeTab === 'payroll' && (
                        <GlassContainer className="overflow-hidden">
                            {payrolls.length > 0 ? (
                                <div className="overflow-x-auto">
                                    <table className="w-full">
                                        <thead>
                                            <tr className="border-b border-slate-200/50 text-left text-xs font-bold text-slate-500 uppercase tracking-wider">
                                                <th className="px-6 py-4">Period</th>
                                                <th className="px-6 py-4">Status</th>
                                                <th className="px-6 py-4 text-right">Gross Salary</th>
                                                <th className="px-6 py-4 text-right text-rose-500">Deductions</th>
                                                <th className="px-6 py-4 text-right text-emerald-600">Net Paid</th>
                                            </tr>
                                        </thead>
                                        <tbody className="divide-y divide-slate-100/50">
                                            {payrolls.map(payroll => {
                                                const empData = payroll.employees.find(e => e.employeeId === employeeId);
                                                if (!empData) return null;
                                                return (
                                                    <tr key={payroll.id} className="hover:bg-sky-50/30 transition-colors">
                                                        <td className="px-6 py-4 text-sm font-bold text-slate-700">
                                                            {payroll.period}
                                                        </td>
                                                        <td className="px-6 py-4">
                                                            <span className={`px-2.5 py-1 rounded-full text-xs font-bold border ${
                                                                payroll.status === 'Paid' ? 'bg-green-100 text-green-700 border-green-200' : 'bg-amber-100 text-amber-700 border-amber-200'
                                                            }`}>
                                                                {payroll.status}
                                                            </span>
                                                        </td>
                                                        <td className="px-6 py-4 text-right font-mono text-sm text-slate-600">
                                                            {formatCurrency(empData.basicSalary)}
                                                        </td>
                                                        <td className="px-6 py-4 text-right font-mono text-sm text-rose-600">
                                                            {formatCurrency(empData.deduction)}
                                                        </td>
                                                        <td className="px-6 py-4 text-right font-mono text-sm font-bold text-emerald-600">
                                                            {formatCurrency(empData.netSalary)}
                                                        </td>
                                                    </tr>
                                                );
                                            })}
                                        </tbody>
                                    </table>
                                </div>
                            ) : (
                                <EmptyState 
                                    title="No Payroll Records" 
                                    message="This employee has not been included in any finalized payrolls yet." 
                                    icon={<FileText />}
                                />
                            )}
                        </GlassContainer>
                    )}

                    {/* DETAILS TAB */}
                    {activeTab === 'details' && (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <GlassContainer className="p-6">
                                <h3 className="text-sm font-bold text-slate-500 uppercase tracking-wider mb-4 border-b border-slate-200/50 pb-2">Employment Details</h3>
                                <div className="space-y-4">
                                    <div className="flex justify-between">
                                        <span className="text-slate-500 text-sm">Full Name</span>
                                        <span className="text-slate-800 font-semibold">{employee.fullName}</span>
                                    </div>
                                    <div className="flex justify-between">
                                        <span className="text-slate-500 text-sm">Position</span>
                                        <span className="text-slate-800 font-semibold">{employee.position}</span>
                                    </div>
                                    <div className="flex justify-between">
                                        <span className="text-slate-500 text-sm">Start Date</span>
                                        <span className="text-slate-800 font-semibold">{new Date(employee.startDate).toLocaleDateString()}</span>
                                    </div>
                                    <div className="flex justify-between">
                                        <span className="text-slate-500 text-sm">Status</span>
                                        <span className="text-emerald-600 font-bold flex items-center gap-1">
                                            <div className="w-2 h-2 rounded-full bg-emerald-500" /> Active
                                        </span>
                                    </div>
                                </div>
                            </GlassContainer>

                            <GlassContainer className="p-6">
                                <h3 className="text-sm font-bold text-slate-500 uppercase tracking-wider mb-4 border-b border-slate-200/50 pb-2">Compensation</h3>
                                <div className="space-y-4">
                                    <div className="flex justify-between">
                                        <span className="text-slate-500 text-sm">Basic Monthly Salary</span>
                                        <span className="text-slate-800 font-mono font-bold">{formatCurrency(employee.basicMonthlySalary)} $</span>
                                    </div>
                                    <div className="flex justify-between">
                                        <span className="text-slate-500 text-sm">Payment Method</span>
                                        <span className="text-slate-800 font-semibold flex items-center gap-2">
                                            <CreditCard size={14} /> {employee.paymentMethod}
                                        </span>
                                    </div>
                                </div>
                            </GlassContainer>
                        </div>
                    )}
                </motion.div>
            </AnimatePresence>

            <RecordAdvanceModal 
                isOpen={isAdvanceModalOpen} 
                onClose={() => setIsAdvanceModalOpen(false)}
                employeeId={employee.id}
                employeeName={employee.fullName}
            />
        </div>
    );
};

export default EmployeeProfile;
