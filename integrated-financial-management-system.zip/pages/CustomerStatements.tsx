
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { useData } from '../context/DataContext';
import { PartyStatement, Customer, Vendor, TransactionType } from '../types';
import { useLocation } from 'react-router-dom'; // Added useLocation

import { StatementHeader } from '../components/statements/StatementHeader';
import { KpiCard } from '../components/statements/KpiCard';
import { ChartPanel } from '../components/statements/ChartPanel';
import { DataGrid } from '../components/statements/DataGrid';
import { ExportBar } from '../components/statements/ExportBar';
import { StatementContext, StatementTransaction, Party } from '../components/statements/types';
import { exportAnalyticsPdf } from '../components/statements/pdf/exportAnalyticsPdf';
import { exportAnalyticsExcel } from '../components/statements/excel/exportAnalyticsExcel';

type PartyWithBalance = (Customer | Vendor) & { balance: number; type: 'customer' | 'vendor' };

const PartyStatements: React.FC = () => {
    const { getCustomersWithBalance, getVendorsWithBalance, getStatementForCustomer, getStatementForVendor, _version } = useData();
    const location = useLocation(); // Hook to access state

    // Data State
    const [parties, setParties] = useState<PartyWithBalance[]>([]);
    const [statementContext, setStatementContext] = useState<StatementContext | null>(null);

    // UI State
    const [selectedParty, setSelectedParty] = useState<PartyWithBalance | null>(null);
    const [startDate, setStartDate] = useState(new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0]);
    const [endDate, setEndDate] = useState(new Date().toISOString().split('T')[0]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isExpandedViewOpen, setIsExpandedViewOpen] = useState(false);
    
    // Refs for PDF chart export
    const chartPanelRef = useRef<HTMLDivElement>(null);


    useEffect(() => {
        Promise.all([
            getCustomersWithBalance(),
            getVendorsWithBalance()
        ]).then(([customers, vendors]) => {
            const customerParties = customers.map(c => ({...c, type: 'customer' as 'customer' }));
            const vendorParties = vendors.map(v => ({...v, type: 'vendor' as 'vendor' }));
            const allParties = [...customerParties, ...vendorParties].sort((a,b) => (a.name || '').localeCompare(b.name || ''));
            setParties(allParties);

            // Auto-select logic
            if (location.state && location.state.customerId) {
                const targetId = location.state.customerId;
                const preSelected = allParties.find(p => p.id === targetId);
                if (preSelected) {
                    setSelectedParty(preSelected);
                    // Optionally adjust date range if passed in state, otherwise keep default
                }
            }
        });
    }, [_version, getCustomersWithBalance, getVendorsWithBalance, location.state]); // Added location.state to deps

    const handleGenerateReport = async () => {
        if (!selectedParty) {
            setError('Please select a customer or vendor.');
            return;
        }
        setIsLoading(true);
        setError(null);
        setStatementContext(null);

        try {
            let rawStatement: PartyStatement;
            if(selectedParty.type === 'customer') {
                rawStatement = await getStatementForCustomer(selectedParty.id, startDate, endDate);
            } else {
                rawStatement = await getStatementForVendor(selectedParty.id, startDate, endDate);
            }
            
            const transactions: StatementTransaction[] = rawStatement.statementRows.map(row => {
                 let type: StatementTransaction['type'] = 'Adjustment';
                 let sourceType: StatementTransaction['sourceType'] = 'Receipt'; // Default to a voucher
                 let sourceId = row.voucherId;

                 const desc = row.description.toLowerCase();
                 if (desc.includes('sale for order')) {
                     type = 'Order';
                     sourceType = 'Order';
                     const orderIdMatch = desc.match(/ord-\d{4}/i);
                     if (orderIdMatch) sourceId = orderIdMatch[0].toUpperCase();
                 } else if (desc.includes('payment for order') || desc.includes('receipt from')) {
                     type = 'Payment';
                 } else if (desc.includes('bill')) {
                     type = 'Bill';
                     sourceType = 'Bill';
                     const billIdMatch = desc.match(/bill-\d{4}/i);
                     if(billIdMatch) sourceId = billIdMatch[0].toUpperCase();
                 } else if (desc.includes('payment for bill')) {
                    type = 'Bill Payment';
                    sourceType = 'Disbursement';
                 } else if (row.amount > 0 && row.type === TransactionType.Debit) {
                     type = 'Refund';
                 }

                 return {
                    id: row.id,
                    date: row.date.toString(),
                    description: row.description,
                    type: type,
                    debit: row.type === 'Debit' ? row.amount : 0,
                    credit: row.type === 'Credit' ? row.amount : 0,
                    balance: row.balance,
                    sourceId: sourceId,
                    sourceType: sourceType,
                 };
            });
            
            setStatementContext({
                party: selectedParty,
                fromDate: startDate,
                toDate: endDate,
                openingBalance: rawStatement.openingBalance,
                closingBalance: rawStatement.closingBalance,
                totalDebit: rawStatement.totalDebit,
                totalCredit: rawStatement.totalCredit,
                transactions: transactions
            });

        } catch (err) {
            console.error(err);
            setError('Failed to generate the report.');
        } finally {
            setIsLoading(false);
        }
    };

    const handleExportExcel = () => {
        if (!statementContext) return;
        try {
            exportAnalyticsExcel(statementContext);
        } catch (error) {
            console.error("Excel export failed:", error);
            alert("Could not export to Excel.");
        }
    };
    
    const handleExportPdf = async () => {
        if (!statementContext || !chartPanelRef.current) return;
        try {
            // Assume html2canvas is available on window object from CDN
            const html2canvas = (window as any).html2canvas;
            if (!html2canvas) {
                alert("PDF export library (html2canvas) is not available.");
                return;
            }
            await exportAnalyticsPdf(statementContext, chartPanelRef.current, html2canvas);
        } catch (error) {
            console.error("PDF export failed:", error);
            alert("Could not export to PDF.");
        }
    };

    const handleShare = () => {
        if (!statementContext) return;
        const url = new URL(window.location.href);
        url.searchParams.set('partyId', statementContext.party.id);
        url.searchParams.set('partyType', statementContext.party.type);
        url.searchParams.set('from', statementContext.fromDate);
        url.searchParams.set('to', statementContext.toDate);
        navigator.clipboard.writeText(url.toString());
        alert('Report link copied to clipboard!');
    };

    return (
        <div className="space-y-6">
            <StatementHeader
                parties={parties}
                selectedParty={selectedParty}
                onPartyChange={setSelectedParty}
                startDate={startDate}
                onStartDateChange={setStartDate}
                endDate={endDate}
                onEndDateChange={setEndDate}
                onGenerate={handleGenerateReport}
                isLoading={isLoading}
            />

            <AnimatePresence>
                {isLoading && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="text-center p-10 text-slate-500">
                        Generating Workspace...
                    </motion.div>
                )}
                {error && <p className="text-center text-rose-600">{error}</p>}
                
                {statementContext && (
                    <motion.div 
                        initial={{ opacity: 0, y: 10 }} 
                        animate={{ opacity: 1, y: 0 }} 
                        transition={{ duration: 0.5 }}
                        className="space-y-6"
                    >
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                            <KpiCard title="Opening Balance" value={statementContext.openingBalance} />
                            <KpiCard title="Total Debit" value={statementContext.totalDebit} color="rose" />
                            <KpiCard title="Total Credit" value={statementContext.totalCredit} color="emerald" />
                            <KpiCard title="Closing Balance" value={statementContext.closingBalance} color="sky" />
                        </div>

                        <div ref={chartPanelRef}>
                            <ChartPanel context={statementContext} />
                        </div>
                        
                        <DataGrid context={statementContext} onExpandClick={() => setIsExpandedViewOpen(true)} />
                    </motion.div>
                )}
            </AnimatePresence>
            
            {statementContext && (
                <ExportBar
                    onExportExcel={handleExportExcel}
                    onExportPdf={handleExportPdf}
                    onShare={handleShare}
                />
            )}

            <AnimatePresence>
                {isExpandedViewOpen && statementContext && (
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 md:p-8"
                        onClick={() => setIsExpandedViewOpen(false)}
                    >
                        <motion.div
                            initial={{ scale: 0.95, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            exit={{ scale: 0.95, opacity: 0 }}
                            transition={{ duration: 0.2 }}
                            className="bg-slate-50 dark:bg-slate-900 rounded-2xl shadow-2xl w-full h-full flex flex-col overflow-hidden"
                            onClick={e => e.stopPropagation()}
                        >
                            <DataGrid context={statementContext} isExpandedView={true} onCloseExpandedView={() => setIsExpandedViewOpen(false)} />
                        </motion.div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
};

export default PartyStatements;
