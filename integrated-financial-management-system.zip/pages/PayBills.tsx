
import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { useData } from '../context/DataContext';
import { Bill, Vendor, BillStatus, Account, AccountType } from '../types';
import { motion, AnimatePresence } from 'framer-motion';
import {
    Banknote, WalletCards, Hash, MessageSquare, UserRound, ChevronsRight, Eraser, RefreshCw, Search,
    ArrowUp, ArrowDown, Phone, Mail, ChevronDown, Lightbulb
} from 'lucide-react';
import { GlassField } from '../components/ui/GlassField';
import { GlassTextarea } from '../components/ui/GlassTextarea';
import { GlassSearchableSelect } from '../components/ui/GlassSearchableSelect';
import { CurrencyInput } from '../components/ui/CurrencyInput';


const formatCurrency = (value: number | string) => {
    const num = Number(value) || 0;
    const options: Intl.NumberFormatOptions = {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    };
    return new Intl.NumberFormat('en-US', options).format(num);
};

const getDaysOverdue = (dueDateStr: Date | string): number => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const dueDate = new Date(dueDateStr);
    dueDate.setHours(0, 0, 0, 0);
    return Math.floor((today.getTime() - dueDate.getTime()) / (1000 * 3600 * 24));
};

type SortKey = 'dueDate' | 'vendorName' | 'balanceDue';

// Locally defined AuroraButton for primary actions, consistent with other pages.
const AuroraButton: React.FC<React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'secondary' | 'ghost', children: React.ReactNode; }> = ({ variant = 'secondary', children, className = '', ...props }) => { const base = "flex items-center justify-center rounded-full px-5 py-3 text-sm font-bold transition-all duration-200 active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none"; const variants = { primary: "bg-gradient-to-r from-sky-500 via-cyan-400 to-emerald-400 text-white shadow-lg hover:scale-[1.02] focus:ring-2 focus:ring-sky-300/60", secondary: "bg-white/70 border border-white/60 text-slate-700 shadow-sm hover:bg-white/80 focus:ring-2 focus:ring-slate-300/60", ghost: "bg-transparent text-slate-600 hover:bg-black/5 !shadow-none !px-3 !py-2 !rounded-lg" }; return <button className={`${base} ${variants[variant]} ${className}`} {...props}>{children}</button>; };

// --- MAIN PAGE COMPONENT ---
const PayBills: React.FC = () => {
    const { getBills, getAccountsList, getVendorsWithBalance, recordBillPayment, _version } = useData();

    const [allBills, setAllBills] = useState<Bill[]>([]);
    const [accounts, setAccounts] = useState<Account[]>([]);
    const [vendors, setVendors] = useState<(Vendor & { balance: number })[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState('');

    const [selectedVendorId, setSelectedVendorId] = useState<string | null>(null);
    const [selectedBills, setSelectedBills] = useState<Map<string, number>>(new Map());
    
    // Form State
    const [paymentDate, setPaymentDate] = useState(new Date().toISOString().split('T')[0]);
    const [paidFromAccountId, setPaidFromAccountId] = useState<string>('');
    const [referenceNo, setReferenceNo] = useState('');
    const [notes, setNotes] = useState('');
    const [noteSuggestions, setNoteSuggestions] = useState<{ en: string[], ku: string[], ar: string[] }>({ en: [], ku: [], ar: [] });
    const [suggestionLang, setSuggestionLang] = useState<'en' | 'ku' | 'ar'>('en');
    const [formErrors, setFormErrors] = useState<{ referenceNo?: string }>({});


    // Filter & Sort State
    const [statusFilter, setStatusFilter] = useState<'all' | 'overdue' | 'due_soon'>('all');
    const [sortConfig, setSortConfig] = useState<{ key: SortKey; direction: 'asc' | 'desc' }>({ key: 'dueDate', direction: 'asc' });

    const fetchData = useCallback(async () => {
        setIsLoading(true);
        try {
            const [billsData, accountsData, vendorsData] = await Promise.all([
                getBills(),
                getAccountsList(),
                getVendorsWithBalance(),
            ]);
            setAllBills(billsData.filter(b => b.status !== BillStatus.Paid));
            const paymentAccs = accountsData.filter(a => a.isPostable && [AccountType.Cash, AccountType.Bank, AccountType.EWallet].includes(a.accountType));
            setAccounts(paymentAccs);
            if (paymentAccs.length > 0 && !paidFromAccountId) {
                setPaidFromAccountId(paymentAccs[0].id);
            }
            setVendors(vendorsData);
        } catch (err) {
            console.error("Failed to fetch data:", err);
        } finally {
            setIsLoading(false);
        }
    }, [_version]);

    useEffect(() => { fetchData(); }, [fetchData]);

    useEffect(() => {
        if (selectedBills.size > 0 && referenceNo.trim() !== '') {
            const ref = referenceNo.trim();
            const firstBillId = selectedBills.keys().next().value;
            const firstBill = allBills.find(b => b.id === firstBillId);
            if (!firstBill) return;

            const vendorName = firstBill.vendorName;
            const billNumbers = Array.from(selectedBills.keys())
                .map(billId => allBills.find(b => b.id === billId)?.billNumber)
                .filter(Boolean)
                .join(', ');

            const suggestions = {
                en: [
                    `Payment for Bill(s) ${billNumbers} from ${vendorName} (Ref: ${ref}).`,
                    `Settlement of invoice(s) ${billNumbers} against our account with ${vendorName}, Ref: ${ref}.`,
                    `To record payment made to ${vendorName} for bill(s): ${billNumbers}, reference no. ${ref}.`
                ],
                ku: [
                    `پارەدان بۆ پسوڵەی ژمارە ${billNumbers} لە ${vendorName} (ژ.سەرچاوە: ${ref}).`,
                    `تسویەی پسوڵەی ژمارە ${billNumbers} بەرامبەر حیسابی ئێمە لەگەڵ ${vendorName}، ژ.سەرچاوە: ${ref}.`,
                    `تۆمارکردنی پارەدان بۆ ${vendorName} بەرامبەر پسوڵەی(پسوڵەکانی): ${billNumbers}، ژمارەی سەرچاوە ${ref}.`
                ],
                ar: [
                    `دفع للفاتورة (للفواتير) رقم ${billNumbers} من ${vendorName} (مرجع: ${ref}).`,
                    `تسوية الفاتورة (الفواتير) رقم ${billNumbers} مقابل حسابنا مع ${vendorName}، مرجع: ${ref}.`,
                    `لتسجيل دفعة إلى ${vendorName} للفاتورة (الفواتير): ${billNumbers}، رقم المرجع ${ref}.`
                ]
            };
            setNoteSuggestions(suggestions);
        } else {
            setNoteSuggestions({ en: [], ku: [], ar: [] });
        }
    }, [selectedBills, referenceNo, allBills]);


    const selectedVendor = useMemo(() => {
        if (!selectedVendorId) return null;
        return vendors.find(v => v.id === selectedVendorId) || null;
    }, [selectedVendorId, vendors]);
    
    const filteredAndSortedBills = useMemo(() => {
        let processed = [...allBills];
        if (searchQuery) {
            const lowerQuery = searchQuery.toLowerCase();
            processed = processed.filter(b => b.vendorName.toLowerCase().includes(lowerQuery) || b.billNumber.toLowerCase().includes(lowerQuery));
        }
        if (statusFilter !== 'all') {
            const today = new Date();
            if (statusFilter === 'overdue') {
                processed = processed.filter(b => getDaysOverdue(b.dueDate) > 0);
            } else if (statusFilter === 'due_soon') {
                const sevenDaysFromNow = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000);
                processed = processed.filter(b => {
                    const dueDate = new Date(b.dueDate);
                    return dueDate >= today && dueDate <= sevenDaysFromNow;
                });
            }
        }
        
        processed.sort((a, b) => {
            let aVal, bVal;
            const key = sortConfig.key;
            if (key === 'balanceDue') {
                aVal = a.totalAmount - a.paidAmount;
                bVal = b.totalAmount - b.paidAmount;
            } else if (key === 'dueDate') {
                aVal = new Date(a.dueDate).getTime();
                bVal = new Date(b.dueDate).getTime();
            } else {
                aVal = a.vendorName || '';
                bVal = b.vendorName || '';
            }

            if (aVal < bVal) return sortConfig.direction === 'asc' ? -1 : 1;
            if (aVal > bVal) return sortConfig.direction === 'asc' ? 1 : -1;
            return 0;
        });
        return processed;
    }, [allBills, searchQuery, statusFilter, sortConfig]);

    const handleSort = (key: SortKey) => setSortConfig(p => ({ key, direction: p.key === key && p.direction === 'asc' ? 'desc' : 'asc' }));
    
    const handleSelectBill = (bill: Bill) => {
        setSelectedBills(prev => {
            const newMap = new Map(prev);
            if (newMap.has(bill.id)) {
                newMap.delete(bill.id);
            } else {
                const balanceDue = bill.totalAmount - bill.paidAmount;
                newMap.set(bill.id, balanceDue);
            }
            return newMap;
        });
        setSelectedVendorId(bill.vendorId);
    };

    const handlePaymentAmountChange = (bill: Bill, amountStr: string) => {
        const balanceDue = bill.totalAmount - bill.paidAmount;
        let amount = parseFloat(amountStr) || 0;
        if (amount > balanceDue) amount = balanceDue;
        setSelectedBills(prev => new Map(prev).set(bill.id, amount));
    };
    
    const handlePay = async () => {
        const errors: { referenceNo?: string } = {};
        if (!referenceNo.trim()) {
            errors.referenceNo = 'Reference number is required.';
        }

        if (Object.keys(errors).length > 0) {
            setFormErrors(errors);
            return;
        }

        if (selectedBills.size === 0 || !paidFromAccountId) {
            alert('Please select at least one bill and a payment account.');
            return;
        }

        const payments = Array.from(selectedBills.entries())
            .filter(([, amount]) => amount > 0)
            .map(([billId, amount]) => ({
                billId,
                amount,
                paymentDate: new Date(paymentDate),
                paymentAccountId: paidFromAccountId,
                referenceNumber: referenceNo.trim(),
                notes: notes.trim() || undefined
            }));

        try {
            await recordBillPayment(payments);
            alert('Payments recorded successfully!');
            setSelectedBills(new Map());
            setReferenceNo('');
            setNotes('');
        } catch (error) {
            alert(`Payment failed: ${(error as Error).message}`);
        }
    };

    const { totalSelected, totalToPay, totalOutstanding } = useMemo(() => {
        const vendorBills = selectedVendorId ? allBills.filter(b => b.vendorId === selectedVendorId) : [];
        const outstanding = vendorBills.reduce((sum, b) => sum + (b.totalAmount - b.paidAmount), 0);
        const toPay = Array.from(selectedBills.values()).reduce((sum: number, amount: number) => sum + amount, 0);
        return { totalSelected: selectedBills.size, totalToPay: toPay, totalOutstanding: outstanding };
    }, [selectedBills, selectedVendorId, allBills]);
    
    const accountOptions = useMemo(() => accounts.map(acc => ({
        value: acc.id,
        label: `${acc.code} - ${acc.name}`,
        details: `Balance: ${formatCurrency(acc.balance)}`
    })), [accounts]);

    const selectedAccount = useMemo(() => accountOptions.find(opt => opt.value === paidFromAccountId) || null, [paidFromAccountId, accountOptions]);

    return (
        <div className="flex flex-col h-full overflow-hidden space-y-4 p-1">
            {/* 1. Header */}
            <motion.div initial={{ y: -20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} className="flex-shrink-0 flex items-center justify-between">
                 {/* Empty div or simple label if needed, but title removed as requested */}
                 <div className="relative w-full md:max-w-sm">
                    <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input 
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Search by vendor or bill #"
                        className="w-full h-11 bg-white/80 dark:bg-slate-800/80 border border-white/60 dark:border-slate-700/60 rounded-xl shadow-inner pl-10 pr-4 text-slate-800 dark:text-slate-200 text-sm focus:ring-2 focus:ring-sky-300/60 focus:outline-none transition"
                    />
                </div>
                <div className="flex items-center gap-3 w-full md:w-auto">
                     <div className="flex items-center p-1 bg-slate-200/50 dark:bg-slate-900/50 rounded-xl neo-glass-panel">
                        {(['all', 'overdue', 'due_soon'] as const).map(status => (
                            <button
                                key={status}
                                onClick={() => setStatusFilter(status)}
                                className={`px-3 py-1.5 text-sm font-semibold rounded-lg transition-all ${
                                    statusFilter === status
                                        ? 'bg-white dark:bg-slate-800 shadow-md text-sky-600 dark:text-sky-300'
                                        : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                                }`}
                            >
                                {status.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                            </button>
                        ))}
                    </div>
                    <button onClick={fetchData} className="w-11 h-11 flex items-center justify-center bg-white/80 dark:bg-slate-800/80 border border-white/60 dark:border-slate-700/60 rounded-xl shadow-sm hover:bg-white/90 dark:hover:bg-slate-700/90 transition-colors">
                        <RefreshCw size={18} className={isLoading ? 'animate-spin' : ''}/>
                    </button>
                </div>
            </motion.div>

            {/* 2. Overview Strip */}
            <motion.div initial={{ y: -10, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{delay: 0.1}} className="flex-shrink-0 grid grid-cols-3 gap-4">
                <div className="neo-glass-panel rounded-2xl p-4 text-center transition-all hover:scale-[1.03]"><p className="text-xs font-semibold text-slate-500">Vendor Outstanding</p><p className="text-2xl font-bold font-mono">{selectedVendor ? formatCurrency(totalOutstanding) : '-'}</p></div>
                <div className="neo-glass-panel rounded-2xl p-4 text-center transition-all hover:scale-[1.03]"><p className="text-xs font-semibold text-slate-500">Bills Selected</p><p className="text-2xl font-bold font-mono">{totalSelected}</p></div>
                <div className="neo-glass-panel rounded-2xl p-4 text-center transition-all hover:scale-[1.03] micro-glow-cyan"><p className="text-xs font-semibold text-slate-500">Total to Pay</p><p className="text-2xl font-bold font-mono text-sky-600 dark:text-sky-400">{formatCurrency(totalToPay)}</p></div>
            </motion.div>

            {/* 3. Main Content */}
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{delay: 0.2}} className="flex-1 flex gap-4 overflow-hidden">
                {/* Left Panel */}
                <div className="w-[32%] flex-shrink-0 flex flex-col gap-4">
                    {selectedVendor && (
                        <motion.div initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} className="neo-glass-panel rounded-2xl p-4 flex items-center gap-4">
                            <div className="w-12 h-12 flex items-center justify-center neo-glass-panel rounded-full border-2 border-sky-400/50"><UserRound size={24} className="text-sky-500"/></div>
                            <div>
                                <p className="font-bold text-lg">{selectedVendor.name}</p>
                                <p className="text-xs text-slate-500 flex items-center gap-2"><Phone size={12}/> {selectedVendor.phone || 'N/A'} <Mail size={12}/> {selectedVendor.contactPerson || 'N/A'}</p>
                            </div>
                        </motion.div>
                    )}
                    <div className="neo-glass-panel rounded-2xl p-4 flex-1 flex flex-col gap-4">
                       <GlassSearchableSelect
                            id="paidFromAccount"
                            label="Paid From Account *"
                            icon={<WalletCards size={16} />}
                            options={accountOptions}
                            selected={selectedAccount}
                            onSelect={(opt) => setPaidFromAccountId(opt?.value || '')}
                        />
                        <GlassField id="referenceNo" label="Reference No. *" value={referenceNo} 
                            onChange={e => {
                                setReferenceNo(e.target.value);
                                if (formErrors.referenceNo) {
                                    setFormErrors(prev => ({...prev, referenceNo: undefined}));
                                }
                            }}
                            icon={<Hash size={16} />}
                            error={formErrors.referenceNo}
                        />
                        <div className="flex-1 min-h-[80px]"><GlassTextarea id="notes" label="Notes (for Journal Voucher)" value={notes} onChange={e => setNotes(e.target.value)} icon={<MessageSquare size={16} />} dir={suggestionLang === 'ar' || suggestionLang === 'ku' ? 'rtl' : 'ltr'} /></div>
                         {noteSuggestions[suggestionLang].length > 0 && !notes && (
                            <div className="mt-2 space-y-2">
                                <div className="flex justify-between items-center">
                                    <p className="text-xs font-semibold text-slate-500 flex items-center gap-1.5">
                                        <Lightbulb size={14} />
                                        Suggestions
                                    </p>
                                    <div className="flex items-center gap-1 bg-slate-200/50 dark:bg-slate-900/50 p-0.5 rounded-md">
                                        <button onClick={() => setSuggestionLang('en')} className={`px-2 py-0.5 text-xs font-bold rounded ${suggestionLang === 'en' ? 'bg-white dark:bg-slate-700 text-sky-600' : 'text-slate-500'}`}>EN</button>
                                        <button onClick={() => setSuggestionLang('ku')} className={`px-2 py-0.5 text-xs font-bold rounded ${suggestionLang === 'ku' ? 'bg-white dark:bg-slate-700 text-sky-600' : 'text-slate-500'}`}>KU</button>
                                        <button onClick={() => setSuggestionLang('ar')} className={`px-2 py-0.5 text-xs font-bold rounded ${suggestionLang === 'ar' ? 'bg-white dark:bg-slate-700 text-sky-600' : 'text-slate-500'}`}>AR</button>
                                    </div>
                                </div>
                                <div className="flex flex-wrap gap-2" dir={suggestionLang === 'ar' || suggestionLang === 'ku' ? 'rtl' : 'ltr'}>
                                    {noteSuggestions[suggestionLang].map((suggestion, index) => (
                                        <button
                                            key={index}
                                            onClick={() => setNotes(suggestion)}
                                            className="px-2.5 py-1 text-xs bg-sky-100/70 text-sky-700 rounded-full hover:bg-sky-200/70 transition-colors"
                                        >
                                            {suggestion}
                                        </button>
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>
                </div>

                {/* Right Panel */}
                <div className="w-[68%] flex-shrink-0 neo-glass-panel rounded-2xl flex flex-col overflow-hidden">
                     <div className="flex-shrink-0 grid grid-cols-12 gap-2 px-4 py-3 bg-white/5 dark:bg-black/10 text-xs font-semibold uppercase text-slate-500">
                        <div className="col-span-1 text-center"></div>
                        <div className="col-span-3 text-left"><button onClick={() => handleSort('vendorName')} className="flex items-center justify-start gap-1 w-full">Vendor {sortConfig.key === 'vendorName' && (sortConfig.direction === 'asc' ? <ArrowUp size={12}/> : <ArrowDown size={12}/>)}</button></div>
                        <div className="col-span-2 text-center">Bill No.</div>
                        <div className="col-span-2 text-center"><button onClick={() => handleSort('dueDate')} className="flex items-center justify-center gap-1 w-full">Due Date {sortConfig.key === 'dueDate' && (sortConfig.direction === 'asc' ? <ArrowUp size={12}/> : <ArrowDown size={12}/>)}</button></div>
                        <div className="col-span-2 text-center"><button onClick={() => handleSort('balanceDue')} className="flex items-center justify-center gap-1 w-full">Amount Due {sortConfig.key === 'balanceDue' && (sortConfig.direction === 'asc' ? <ArrowUp size={12}/> : <ArrowDown size={12}/>)}</button></div>
                        <div className="col-span-2 text-center">Payment</div>
                    </div>
                    <div className="flex-1 overflow-y-auto p-1.5">
                        {filteredAndSortedBills.map(bill => {
                            const balanceDue = bill.totalAmount - bill.paidAmount;
                            const isSelected = selectedBills.has(bill.id);
                            const daysOverdue = getDaysOverdue(bill.dueDate);
                            return (
                                <motion.div key={bill.id} layout initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                                    onClick={() => handleSelectBill(bill)}
                                    className={`grid grid-cols-12 gap-2 items-center px-4 py-2 rounded-lg mb-1.5 transition-colors duration-200 cursor-pointer bg-white/5 dark:bg-black/5 hover:bg-sky-500/10 ${isSelected ? 'bg-sky-500/20' : ''}`}
                                >
                                    <div className="col-span-1 flex justify-center"><input type="checkbox" checked={isSelected} readOnly className="w-4 h-4 rounded border-slate-400 text-sky-500 focus:ring-sky-500 bg-transparent"/></div>
                                    <div className="col-span-3 text-left text-sm font-semibold truncate" title={bill.vendorName}>{bill.vendorName}</div>
                                    <div className="col-span-2 text-center text-xs text-slate-500 font-mono truncate" title={bill.billNumber}>{bill.billNumber}</div>
                                    <div className="col-span-2 text-center text-xs font-semibold">
                                        <span className={`px-2 py-1 rounded-full ${daysOverdue > 7 ? 'bg-red-500/10 text-red-500' : daysOverdue > 0 ? 'bg-orange-500/10 text-orange-500' : 'bg-green-500/10 text-green-500'}`}>
                                            {daysOverdue > 0 ? `${daysOverdue}d overdue` : new Date(bill.dueDate).toLocaleDateString()}
                                        </span>
                                    </div>
                                    <div className="col-span-2 text-center font-mono text-sm font-semibold">{formatCurrency(balanceDue)}</div>
                                    <div className="col-span-2 h-8">
                                        <CurrencyInput 
                                            value={selectedBills.get(bill.id) ?? ''} 
                                            onChange={val => handlePaymentAmountChange(bill, val)} 
                                            disabled={!isSelected}
                                            compact
                                            wrapperClassName="w-full h-full"
                                        />
                                    </div>
                                </motion.div>
                            );
                        })}
                    </div>
                </div>
            </motion.div>

            {/* 4. Bottom Action Bar */}
            <AnimatePresence>
                {totalSelected > 0 && (
                    <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 20, opacity: 0 }} className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20">
                        <div className="neo-glass-panel rounded-full p-1.5 flex items-center gap-4 micro-glow-cyan">
                            <AuroraButton onClick={() => setSelectedBills(new Map())} variant="secondary" className="!rounded-full !py-2"><Eraser size={14} className="mr-2"/> Clear</AuroraButton>
                            <AuroraButton onClick={handlePay} variant="primary" className="!rounded-full !py-2"><ChevronsRight size={16} className="mr-2"/>Pay {totalSelected} Bills</AuroraButton>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
};

export default PayBills;
