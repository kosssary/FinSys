import React, { useState, useEffect, Fragment, useCallback } from 'react';
import { useData } from '../context/DataContext';
import { AdvancedTrialBalanceData, AdvancedTrialBalanceRow, AccountCategory } from '../types';
import { motion, AnimatePresence } from 'framer-motion';
import { Calendar, RefreshCw, Filter, CheckCircle, XCircle } from 'lucide-react';
import Switch from '../components/ui/Switch';

// --- Helper Functions ---
const formatCurrency = (value: number) => {
    const isNegative = value < 0;
    const formatted = new Intl.NumberFormat('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(Math.abs(value));
    return isNegative ? `(${formatted})` : formatted;
};

// --- Child Components ---
const SummaryCard: React.FC<{ title: string; value: number; glowColor: string }> = ({ title, value, glowColor }) => (
    <div className="relative p-4 bg-white/5 backdrop-blur-[40px] border border-white/10 rounded-2xl">
         <div className="absolute inset-0 border-2 border-transparent rounded-2xl" style={{
            background: `radial-gradient(circle at 50% 100%, ${glowColor}, transparent 80%)`,
            opacity: 0.7,
            zIndex: -1,
        }} />
        <p className="text-sm text-slate-500 dark:text-slate-400 font-semibold">{title}</p>
        <p className="text-2xl font-bold font-mono text-slate-800 dark:text-white mt-1">{formatCurrency(value)}</p>
    </div>
);

// --- Main Component ---
const TrialBalance: React.FC = () => {
    const { getAdvancedTrialBalance, _version } = useData();
    const [data, setData] = useState<AdvancedTrialBalanceData | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');
    const [accountTypeFilter, setAccountTypeFilter] = useState<Set<AccountCategory>>(new Set());
    const [showZeroBalance, setShowZeroBalance] = useState(false);

    const setDatePreset = useCallback((preset: 'month' | 'quarter' | 'year') => {
        const now = new Date();
        let start = new Date(), end = new Date();
        switch (preset) {
            case 'quarter': const quarter = Math.floor(now.getMonth() / 3); start = new Date(now.getFullYear(), quarter * 3, 1); end = new Date(now.getFullYear(), quarter * 3 + 3, 0); break;
            case 'year': start = new Date(now.getFullYear(), 0, 1); end = new Date(); break;
            case 'month': default: start = new Date(now.getFullYear(), now.getMonth(), 1); end = new Date(now.getFullYear(), now.getMonth() + 1, 0); break;
        }
        setStartDate(start.toISOString().split('T')[0]);
        setEndDate(end.toISOString().split('T')[0]);
    }, []);

    useEffect(() => { setDatePreset('month'); }, [setDatePreset]);

    const fetchData = useCallback(async () => {
        if (!startDate || !endDate) return;
        setIsLoading(true);
        try {
            const result = await getAdvancedTrialBalance(startDate, endDate, accountTypeFilter, showZeroBalance);
            setData(result);
        } catch (error) {
            console.error("Failed to fetch trial balance:", error);
            setData(null);
        } finally {
            setIsLoading(false);
        }
    }, [startDate, endDate, accountTypeFilter, showZeroBalance, getAdvancedTrialBalance]);

    useEffect(() => { fetchData(); }, [fetchData, _version]);
    
    const handleFilterToggle = (category: AccountCategory) => {
        setAccountTypeFilter(prev => {
            const newSet = new Set(prev);
            if (newSet.has(category)) newSet.delete(category);
            else newSet.add(category);
            return newSet;
        });
    };
    
    const categoryOrder: AccountCategory[] = [AccountCategory.Asset, AccountCategory.Liability, AccountCategory.Equity, AccountCategory.Revenue, AccountCategory.COGS, AccountCategory.OperatingExpense];

    return (
        <div className="space-y-6">
             <style>{`
                .glowing-card {
                    position: relative;
                    background-color: var(--glass-bg);
                    backdrop-filter: blur(30px);
                    border: 1px solid var(--glass-border);
                    border-radius: 22px;
                    box-shadow: 0 8px 32px 0 var(--glass-shadow);
                }
                .dark .glowing-card::before {
                    content: "";
                    position: absolute;
                    inset: -1px;
                    border-radius: 22px;
                    background: conic-gradient(from 180deg at 50% 50%, rgba(56, 189, 248, 0.2) 0%, rgba(168, 85, 247, 0.2) 33%, rgba(236, 72, 153, 0.2) 66%, rgba(56, 189, 248, 0.2) 100%);
                    filter: blur(16px);
                    z-index: -1;
                }
                .group-divider {
                    position: relative;
                    padding-top: 1rem;
                    padding-bottom: 0.5rem;
                }
                 .group-divider::before {
                    content: "";
                    position: absolute;
                    top: 0;
                    left: 0;
                    right: 0;
                    height: 1px;
                    background-image: linear-gradient(to right, transparent, var(--glass-border), transparent);
                }
            `}</style>
            {/* Header */}
            <div className="flex flex-col md:flex-row justify-end items-start md:items-center gap-4">
                {/* Filter Panel */}
                <div className="relative z-10 glowing-card p-2 flex flex-wrap items-center gap-2">
                    <div className="flex items-center gap-2 border-r border-white/10 pr-2">
                         <Calendar className="text-slate-500 ml-2" size={16} />
                         <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="h-9 bg-transparent border-none rounded-lg px-2 text-sm text-slate-800 dark:text-slate-200 focus:ring-0 focus:outline-none w-32" />
                         <span className="text-slate-400">-</span>
                         <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className="h-9 bg-transparent border-none rounded-lg px-2 text-sm text-slate-800 dark:text-slate-200 focus:ring-0 focus:outline-none w-32" />
                    </div>
                    <div className="flex items-center gap-2 border-r border-white/10 px-2">
                         <Filter size={16} className="text-slate-500" />
                        {categoryOrder.slice(0, 3).map(cat => (
                            <button key={cat} onClick={() => handleFilterToggle(cat)} className={`px-2 py-1 text-xs font-semibold rounded-md transition-colors ${accountTypeFilter.has(cat) ? 'bg-sky-500/20 text-sky-700 dark:text-sky-300' : 'bg-black/5 dark:bg-white/5 text-slate-600 dark:text-slate-300 hover:bg-black/10 dark:hover:bg-white/10'}`}>{cat.substring(0,3)}</button>
                        ))}
                    </div>
                     <div className="flex items-center gap-2 pr-2">
                        <label className="flex items-center gap-2 text-xs font-semibold text-slate-600 dark:text-slate-300 cursor-pointer">
                            <span>Show Zeros</span>
                            <Switch isChecked={showZeroBalance} onChange={() => setShowZeroBalance(p => !p)} />
                        </label>
                    </div>
                    <button onClick={fetchData} disabled={isLoading} className="h-9 w-9 flex items-center justify-center text-slate-700 dark:text-slate-200 bg-white/50 dark:bg-white/10 rounded-lg border border-white/40 dark:border-white/20 hover:bg-white/70 dark:hover:bg-white/20 transition-colors disabled:opacity-50">
                        <RefreshCw size={14} className={isLoading ? 'animate-spin' : ''} />
                    </button>
                </div>
            </div>

             <AnimatePresence mode="wait">
                {isLoading ? (
                    <motion.div key="loader" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="text-center p-20 text-slate-500">
                        <p>Generating Trial Balance...</p>
                    </motion.div>
                ) : !data ? (
                     <motion.div key="error" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="text-center p-20 text-rose-500">
                        <p>Could not load data for the selected criteria.</p>
                    </motion.div>
                ) : (
                    <motion.div key="data" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
                        <div className="glowing-card p-0">
                            <div className="overflow-x-auto">
                                <table className="w-full min-w-[1200px]">
                                    <thead className="border-b border-white/10">
                                        <tr>
                                            <th className="px-4 py-3 text-left text-xs font-semibold tracking-wider text-slate-500 uppercase" style={{width: '10%'}}>Code</th>
                                            <th className="px-4 py-3 text-left text-xs font-semibold tracking-wider text-slate-500 uppercase" style={{width: '25%'}}>Account</th>
                                            <th className="px-4 py-3 text-right text-xs font-semibold tracking-wider text-slate-500 uppercase" style={{width: '12.5%'}}>Opening (Dr)</th>
                                            <th className="px-4 py-3 text-right text-xs font-semibold tracking-wider text-slate-500 uppercase" style={{width: '12.5%'}}>Opening (Cr)</th>
                                            <th className="px-4 py-3 text-right text-xs font-semibold tracking-wider text-slate-500 uppercase" style={{width: '12.5%'}}>Period (Dr)</th>
                                            <th className="px-4 py-3 text-right text-xs font-semibold tracking-wider text-slate-500 uppercase" style={{width: '12.5%'}}>Period (Cr)</th>
                                            <th className="px-4 py-3 text-right text-xs font-semibold tracking-wider text-slate-500 uppercase" style={{width: '12.5%'}}>Closing (Dr)</th>
                                            <th className="px-4 py-3 text-right text-xs font-semibold tracking-wider text-slate-500 uppercase" style={{width: '12.5%'}}>Closing (Cr)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {categoryOrder.map(category => (
                                            data.groups[category] && data.groups[category]!.length > 0 && (
                                                <Fragment key={category}>
                                                    <tr><td colSpan={8} className="px-4 group-divider"><div className="font-bold text-sm text-slate-700 dark:text-slate-200">{category}</div></td></tr>
                                                    {data.groups[category]!.map((row: AdvancedTrialBalanceRow) => (
                                                        <tr key={row.account.id} className="border-b border-white/5 last:border-b-0">
                                                            <td className="px-4 py-2 text-sm font-mono text-slate-600 dark:text-slate-400">{row.account.code}</td>
                                                            <td className="px-4 py-2 text-sm font-medium text-slate-800 dark:text-slate-200">{row.account.name}</td>
                                                            <td className="px-4 py-2 text-sm font-mono text-right text-slate-600 dark:text-slate-400">{row.openingDr > 0 ? formatCurrency(row.openingDr) : '-'}</td>
                                                            <td className="px-4 py-2 text-sm font-mono text-right text-slate-600 dark:text-slate-400">{row.openingCr > 0 ? formatCurrency(row.openingCr) : '-'}</td>
                                                            <td className="px-4 py-2 text-sm font-mono text-right text-slate-700 dark:text-slate-300">{row.periodDebit > 0 ? formatCurrency(row.periodDebit) : '-'}</td>
                                                            <td className="px-4 py-2 text-sm font-mono text-right text-slate-700 dark:text-slate-300">{row.periodCredit > 0 ? formatCurrency(row.periodCredit) : '-'}</td>
                                                            <td className="px-4 py-2 text-sm font-mono text-right font-semibold text-slate-800 dark:text-slate-100">{row.closingDr > 0 ? formatCurrency(row.closingDr) : '-'}</td>
                                                            <td className="px-4 py-2 text-sm font-mono text-right font-semibold text-slate-800 dark:text-slate-100">{row.closingCr > 0 ? formatCurrency(row.closingCr) : '-'}</td>
                                                        </tr>
                                                    ))}
                                                </Fragment>
                                            )
                                        ))}
                                    </tbody>
                                    <tfoot className="border-t-2 border-white/20">
                                        <tr className="font-bold text-lg text-slate-800 dark:text-white">
                                            <td className="px-4 py-3" colSpan={2}>Totals</td>
                                            <td className="px-4 py-3 text-right font-mono" style={{textShadow:'0 0 8px rgba(56, 189, 248, 0.5)'}}>{formatCurrency(data.totals.openingDr)}</td>
                                            <td className="px-4 py-3 text-right font-mono" style={{textShadow:'0 0 8px rgba(56, 189, 248, 0.5)'}}>{formatCurrency(data.totals.openingCr)}</td>
                                            <td className="px-4 py-3 text-right font-mono" style={{textShadow:'0 0 8px rgba(56, 189, 248, 0.5)'}}>{formatCurrency(data.totals.periodDebit)}</td>
                                            <td className="px-4 py-3 text-right font-mono" style={{textShadow:'0 0 8px rgba(56, 189, 248, 0.5)'}}>{formatCurrency(data.totals.periodCredit)}</td>
                                            <td className="px-4 py-3 text-right font-mono" style={{textShadow:'0 0 8px rgba(56, 189, 248, 0.5)'}}>{formatCurrency(data.totals.closingDr)}</td>
                                            <td className="px-4 py-3 text-right font-mono" style={{textShadow:'0 0 8px rgba(56, 189, 248, 0.5)'}}>{formatCurrency(data.totals.closingCr)}</td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                            <SummaryCard title="Total Debits" value={data.totals.closingDr} glowColor="rgba(56, 189, 248, 0.4)" />
                            <SummaryCard title="Total Credits" value={data.totals.closingCr} glowColor="rgba(168, 85, 247, 0.4)" />
                            <div className="relative p-4 bg-white/5 backdrop-blur-[40px] border border-white/10 rounded-2xl flex flex-col justify-center items-center">
                                {Math.abs(data.totals.closingDr - data.totals.closingCr) < 0.01 ? (
                                    <>
                                        <div className="absolute inset-0 border-2 border-transparent rounded-2xl" style={{ background: `radial-gradient(circle at 50% 50%, rgba(16, 185, 129, 0.4), transparent 80%)`, opacity: 0.8, zIndex: -1 }} />
                                        <CheckCircle size={24} className="text-emerald-500 mb-1" />
                                        <p className="text-sm font-bold text-emerald-600 dark:text-emerald-400">Balanced</p>
                                        <p className="text-lg font-mono font-bold text-slate-600 dark:text-slate-300">0.00</p>
                                    </>
                                ) : (
                                    <>
                                        <div className="absolute inset-0 border-2 border-transparent rounded-2xl" style={{ background: `radial-gradient(circle at 50% 50%, rgba(220, 38, 38, 0.4), transparent 80%)`, opacity: 0.8, zIndex: -1 }} />
                                        <XCircle size={24} className="text-rose-500 mb-1" />
                                        <p className="text-sm font-bold text-rose-600 dark:text-rose-400">Difference</p>
                                        <p className="text-lg font-mono font-bold text-rose-500">{formatCurrency(data.totals.closingDr - data.totals.closingCr)}</p>
                                    </>
                                )}
                            </div>
                        </div>

                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
};

export default TrialBalance;