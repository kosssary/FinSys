
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useData } from '../context/DataContext';
import { Account, Voucher, Customer, TransactionType, DisbursementVoucherPayload, PartyEntity, Employee, Shareholder, Vendor, SmartVoucherLineEntity } from '../types';
import { motion, AnimatePresence } from 'framer-motion';
import { 
    Plus, Edit, ChevronsLeft, ChevronLeft, ChevronRight, ChevronsRight, 
    Save, Paperclip, XCircle, Calendar, Wallet, Search,
    UserSearch, BookCopy, MessageSquare, CircleDollarSign, Hash, UploadCloud,
    Trash2, Info
} from 'lucide-react';
import { useLocation, useNavigate, Link } from 'react-router-dom';
import { SearchableAccountInput } from '../components/ui/SearchableAccountInput';
import PartySelectionModal from '../components/modals/PartySelectionModal';
import AccountSelectionModal from '../components/modals/AccountSelectionModal';
import DescriptionEditModal from '../components/modals/DescriptionEditModal';
import { CurrencyInput } from '../components/ui/CurrencyInput';

// --- TYPE DEFINITIONS & UTILITIES ---
type PartyWithBalance = { id: string; name: string; type: string; balance?: number; };
type ViewMode = 'viewing' | 'editing' | 'creating';
const formatCurrency = (value: number | string) => new Intl.NumberFormat('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(Number(value) || 0);
const safeEval = (expr: string): number | null => { try { if (!/^[0-9+\-*/.() ]+$/.test(expr)) return null; const result = new Function(`return ${expr}`)(); return typeof result === 'number' ? result : null; } catch (error) { return null; } };

interface VoucherGridLine {
    id: string; // for React keys
    party: SmartVoucherLineEntity | null;
    accountId: string | null;
    description: string;
    amount: string;
}

// --- UI PRIMITIVES ---
const AuroraCard: React.FC<{ children: React.ReactNode; className?: string, title?: string }> = ({ children, className = '', title }) => ( <div className={`bg-white/50 backdrop-blur-2xl border border-white/40 rounded-3xl shadow-[0_8px_50px_rgba(0,0,0,0.06)] overflow-visible ${className}`}> {title && <h3 className="text-sm font-bold text-slate-500 uppercase tracking-wider px-6 pt-5 pb-2">{title}</h3>} <div className={title ? 'p-6 pt-3' : 'p-6'}>{children}</div> </div> );
const AuroraButton: React.FC<React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'secondary' | 'ghost', children: React.ReactNode; }> = ({ variant = 'secondary', children, className = '', ...props }) => { const base = "flex items-center justify-center rounded-2xl px-5 py-3 text-sm font-bold transition-all duration-200 active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none"; const variants = { primary: "bg-gradient-to-r from-sky-500 via-rose-400 to-orange-400 text-white shadow-lg hover:scale-[1.02] focus:ring-2 focus:ring-sky-300/60", secondary: "bg-white/70 border border-white/60 text-slate-700 shadow-sm hover:bg-white/80 focus:ring-2 focus:ring-slate-300/60", ghost: "bg-transparent text-slate-600 hover:bg-black/5 !shadow-none !px-3 !py-2 !rounded-lg" }; return <button className={`${base} ${variants[variant]} ${className}`} {...props}>{children}</button>; };
const AuroraToolbar: React.FC<any> = ({ voucherNumber, viewMode, onNew, onSave, onEdit, onDelete, onCancel, navigateVoucher, onVoucherSearch }) => {
    const [isEditingNumber, setIsEditingNumber] = useState(false);
    const [searchValue, setSearchValue] = useState('');

    useEffect(() => {
        if (!isEditingNumber) {
            setSearchValue('');
        }
    }, [isEditingNumber]);

    const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'Enter') {
            onVoucherSearch(searchValue);
            setIsEditingNumber(false);
        } else if (e.key === 'Escape') {
            setIsEditingNumber(false);
        }
    };
    
    return (
     <div className="sticky top-2 z-50"> <div className="flex flex-col md:flex-row items-center justify-between gap-4 bg-white/60 backdrop-blur-2xl border border-white/40 rounded-3xl shadow-[0_8px_50px_rgba(0,0,0,0.06)] p-3"> <div className="flex items-center gap-4"> <div></div> <div className="hidden md:flex items-center gap-1 bg-white/50 rounded-2xl border border-white/50 p-1"> <AuroraButton variant="ghost" onClick={() => navigateVoucher('first')}><ChevronsLeft size={18}/></AuroraButton> <AuroraButton variant="ghost" onClick={() => navigateVoucher('prev')}><ChevronLeft size={18}/></AuroraButton> <AuroraButton variant="ghost" onClick={() => navigateVoucher('next')}><ChevronRight size={18}/></AuroraButton> <AuroraButton variant="ghost" onClick={() => navigateVoucher('last')}><ChevronsRight size={18}/></AuroraButton> </div> 
      {isEditingNumber ? (
        <input 
            type="text" 
            value={searchValue}
            onChange={(e) => setSearchValue(e.target.value)}
            onKeyDown={handleKeyDown}
            onBlur={() => setIsEditingNumber(false)}
            autoFocus
            className="font-mono text-lg font-semibold text-sky-600 bg-sky-100/50 border border-sky-200/50 rounded-xl px-4 py-2 w-28 text-center focus:outline-none focus:ring-2 focus:ring-sky-400"
            placeholder={voucherNumber.split('-')[1]}
        />
     ) : (
        <div onClick={() => viewMode === 'viewing' && setIsEditingNumber(true)} className="font-mono text-lg font-semibold text-sky-600 bg-sky-100/50 border border-sky-200/50 rounded-xl px-4 py-2 cursor-pointer min-w-[112px] text-center">{viewMode === 'creating' ? 'NEW' : voucherNumber}</div>
     )}
     </div> <div className="flex items-center gap-2"> {viewMode === 'viewing' ? (<><AuroraButton onClick={onDelete} variant="secondary" className="!bg-rose-500/10 !border-rose-500/20 !text-rose-600 hover:!bg-rose-500/20"><Trash2 size={16} className="mr-2"/>Delete</AuroraButton><AuroraButton onClick={onNew}><Plus size={16} className="mr-2"/>New</AuroraButton><AuroraButton variant="primary" onClick={onEdit}><Edit size={16} className="mr-2"/>Edit</AuroraButton></>) : (<><AuroraButton onClick={onCancel}>Cancel</AuroraButton><AuroraButton variant="primary" onClick={onSave}><Save size={16} className="mr-2"/>Save</AuroraButton></>)} </div> </div> </div> );
}

// --- MAIN PAGE ---
const Disbursements: React.FC = () => {
    const { getVouchers, addDisbursement, updateDisbursement, deleteVoucher, getAccountsList, getCustomersWithBalance, getEmployeesWithBalance, getShareholders, getVendorsWithBalance, getOpenBillsForVendor, _version } = useData();
    const location = useLocation();
    const navigate = useNavigate();
    
    // Data stores
    const [allVouchers, setAllVouchers] = useState<Voucher[]>([]);
    const [customers, setCustomers] = useState<(Customer & { balance: number })[]>([]);
    const [vendors, setVendors] = useState<(Vendor & { balance: number })[]>([]);
    const [employees, setEmployees] = useState<(Employee & { advanceBalance: number; name?: string })[]>([]);
    const [shareholders, setShareholders] = useState<Shareholder[]>([]);
    const [accounts, setAccounts] = useState<Account[]>([]);

    // Form State
    const [viewMode, setViewMode] = useState<ViewMode>('viewing');
    const [currentVoucherIndex, setCurrentVoucherIndex] = useState(0);
    const [date, setDate] = useState('');
    const [paidFromAccountId, setPaidFromAccountId] = useState<string | null>(null);
    const [referenceNumber, setReferenceNumber] = useState('');
    const [lines, setLines] = useState<VoucherGridLine[]>([]);
    const [notes, setNotes] = useState('');
    const [attachments, setAttachments] = useState<File[]>([]);
    const [payeeWithOpenBills, setPayeeWithOpenBills] = useState<{ name: string; id: string } | null>(null);
    
    // Modal State
    const [isPartyModalOpen, setIsPartyModalOpen] = useState(false);
    const [isAccountModalOpen, setIsAccountModalOpen] = useState(false);
    const [isHeaderAccountModalOpen, setIsHeaderAccountModalOpen] = useState(false);
    const [editingLineIndex, setEditingLineIndex] = useState<number | null>(null);
    const [isDescriptionModalOpen, setIsDescriptionModalOpen] = useState(false);
    const [editingDescriptionData, setEditingDescriptionData] = useState<{ index: number; value: string } | null>(null);

    const isFormDisabled = viewMode === 'viewing';
    const currentVoucher = allVouchers[currentVoucherIndex];

    const { paidFromAccounts, contraAccounts, allParties } = useMemo(() => {
        const paymentAccs = accounts.filter(a => a.isPostable && ['1110','1200','1300','1400'].some(code => a.pathCodes.includes(code) || a.code.startsWith(code)));
        
        const contraAccParentCodes = ['1501', '1701', '2101', '2102', '2200', '3200', '5000', '6000'];
        const contraAccs = accounts.filter(a =>
            a.isPostable &&
            contraAccParentCodes.some(code => a.pathCodes.includes(code) || a.code.startsWith(code))
        );

        const allPartiesList: PartyWithBalance[] = [
            ...vendors.map(s => ({id: s.id, name: s.name, type: 'vendor', balance: s.balance})),
            ...customers.map(c => ({id: c.id, name: c.name || '', type: 'customer', balance: c.balance})),
            ...employees.map(e => ({id: e.id, name: e.fullName, type: 'employee', balance: e.advanceBalance})),
            ...shareholders.map(s => ({id: s.id, name: s.name, type: 'shareholder', balance: 0}))
        ];
        return { paidFromAccounts: paymentAccs, contraAccounts: contraAccs, allParties: allPartiesList };
    }, [accounts, customers, employees, shareholders, vendors]);
    
    // Initial Data Fetch
    useEffect(() => {
        Promise.all([ getVouchers(TransactionType.Debit), getAccountsList(), getCustomersWithBalance(), getEmployeesWithBalance(), getShareholders(), getVendorsWithBalance() ]).then(([vouchers, accs, custs, emps, shares, vends]) => {
            setAllVouchers(vouchers);
            setAccounts(accs);
            setCustomers(custs);
            setEmployees(emps);
            setShareholders(shares);
            setVendors(vends);
            if (vouchers.length > 0) { 
                const targetVoucherId = location.state?.voucherId;
                const indexToSet = targetVoucherId 
                    ? vouchers.findIndex(v => v.voucherId === targetVoucherId)
                    : 0;
                
                setCurrentVoucherIndex(indexToSet !== -1 ? indexToSet : 0);

                if (targetVoucherId) {
                    navigate(location.pathname, { replace: true }); // Clear state
                }
            } else { 
                handleNew(); 
            }
        });
    }, [_version, location.state]);

    const populateForm = useCallback((voucher: Voucher | null) => {
        if (!voucher) return;
        setDate(new Date(voucher.date).toISOString().split('T')[0]);
        setPaidFromAccountId(voucher.accountId);
        setReferenceNumber(voucher.referenceNumber || '');
        setLines(voucher.lines.map((l, i) => {
             const party = allParties.find(p => p.id === l.partyId);
             const partyEntity: SmartVoucherLineEntity | null = party ? { id: party.id, name: party.name, type: l.partyType } : null;
            
            return {
                id: `line-${i}-${Date.now()}`,
                party: partyEntity,
                accountId: l.accountId,
                description: l.description,
                amount: String(l.amount),
            };
        }));
        setNotes(''); setAttachments([]);
    }, [allParties]);

    useEffect(() => { if (currentVoucher && viewMode === 'viewing') { populateForm(currentVoucher); } }, [currentVoucher, viewMode, populateForm]);
    
    // Intelligent Guide Logic
    useEffect(() => {
        const checkLinesForSuppliers = async () => {
            setPayeeWithOpenBills(null); // Reset on each check
            for (const line of lines) {
                if (line.party?.type === 'vendor') {
                    const openBills = await getOpenBillsForVendor(line.party.id);
                    if (openBills.length > 0) {
                        setPayeeWithOpenBills({ name: line.party.name, id: line.party.id });
                        break; 
                    }
                }
            }
        };
        if (viewMode !== 'viewing') {
            checkLinesForSuppliers();
        }
    }, [lines, getOpenBillsForVendor, viewMode]);

    // Event Handlers
    const handleNew = useCallback(() => {
        setViewMode('creating');
        setDate(new Date().toISOString().split('T')[0]);
        setPaidFromAccountId(null);
        setReferenceNumber('');
        setLines([{ id: `line-0-${Date.now()}`, party: null, accountId: null, description: '', amount: '' }]);
        setNotes(''); setAttachments([]);
    }, []);

    const handleSave = async () => {
        if (!paidFromAccountId || !date) { alert("Please select a 'Paid From' account and a date."); return; }
        const validLines = lines.filter(l => l.party && l.accountId && Number(l.amount) > 0);
        if (validLines.length === 0) { alert("Please add at least one valid line item."); return; }
        
        const payload: DisbursementVoucherPayload = {
            date: new Date(date),
            accountId: paidFromAccountId,
            referenceNumber: referenceNumber,
            lines: validLines.map(l => ({
                payeeEntity: l.party as PartyEntity,
                accountId: l.accountId!,
                amount: Number(l.amount),
                description: l.description,
                referenceId: referenceNumber,
            }))
        };
        
        try {
            if (viewMode === 'creating') { await addDisbursement(payload); } 
            else if (viewMode === 'editing' && currentVoucher) {
                // await updateDisbursement({ voucherId: currentVoucher.voucherId, ...payload } as any);
            }
            alert('Voucher saved successfully!');
            setViewMode('viewing');
        } catch (error) { console.error("Save failed:", error); alert("Failed to save voucher."); }
    };
    
    const handleCancel = () => { setViewMode('viewing'); populateForm(currentVoucher); };
    
    const handleDelete = async () => {
        if (!currentVoucher) return;
        if (window.confirm(`Are you sure you want to delete voucher ${currentVoucher.voucherNumber}? This action cannot be undone.`)) {
            try {
                await deleteVoucher(currentVoucher.voucherId);
                alert('Voucher deleted successfully!');
                // After deletion, the _version change will trigger a re-fetch and reset the index
            } catch (error) {
                console.error("Delete failed:", error);
                alert(`Failed to delete voucher: ${(error as Error).message}`);
            }
        }
    };

    const navigateVoucher = (dir: 'first'|'prev'|'next'|'last') => { 
        if (viewMode !== 'viewing' || allVouchers.length === 0) return; 
        let i = currentVoucherIndex; 
        if (dir === 'first') i = 0;
        else if (dir === 'last') i = allVouchers.length - 1;
        else if (dir === 'next') i = Math.min(allVouchers.length - 1, i + 1); 
        else if (dir === 'prev') i = Math.max(0, i - 1); 
        setCurrentVoucherIndex(i); 
    };

    const handleVoucherSearch = (searchValue: string) => {
        const num = parseInt(searchValue, 10);
        if (isNaN(num)) return;
        const targetVoucherNumber = `DV-${String(num).padStart(3, '0')}`;
        const index = allVouchers.findIndex(v => v.voucherNumber === targetVoucherNumber);
        if (index !== -1) {
            setCurrentVoucherIndex(index);
        } else {
            alert('Voucher not found.');
        }
    };


    // Line Management
    const handleLineChange = (index: number, field: keyof VoucherGridLine, value: any) => { setLines(ls => ls.map((l, i) => i === index ? { ...l, [field]: value } : l)); };
    
    const handleCurrencyConversion = (index: number, iqdAmount: number, rate: number) => {
        setLines(ls => ls.map((l, i) => {
            if (i === index) {
                const note = `(Paid: ${iqdAmount.toLocaleString()} IQD @ ${rate})`;
                let currentDesc = l.description || '';
                // Replace existing auto-note
                currentDesc = currentDesc.replace(/\(Paid: .*? IQD @ .*?\)/g, '').trim();
                return { ...l, description: (currentDesc + ' ' + note).trim() };
            }
            return l;
        }));
    };

    const addLine = () => setLines(ls => [...ls, { id: `line-${ls.length}-${Date.now()}`, party: null, accountId: null, description: '', amount: '' }]);
    const removeLine = (index: number) => setLines(ls => ls.length > 1 ? ls.filter((_, i) => i !== index) : ls);
    
    const totalAmount = useMemo(() => lines.reduce((sum, l) => sum + (Number(l.amount) || 0), 0), [lines]);
    
    const handleOpenPartyModal = (index: number) => { setEditingLineIndex(index); setIsPartyModalOpen(true); };
    const handlePartySelect = (party: PartyEntity) => { if (editingLineIndex !== null) { handleLineChange(editingLineIndex, 'party', party); } setIsPartyModalOpen(false); };

    const handleOpenAccountModal = (index: number) => { setEditingLineIndex(index); setIsAccountModalOpen(true); };
    const handleAccountSelect = (account: Account) => { if (editingLineIndex !== null) { handleLineChange(editingLineIndex, 'accountId', account.id); } setIsAccountModalOpen(false); };
    
    const handleHeaderAccountSelect = (account: Account) => { setPaidFromAccountId(account.id); setIsHeaderAccountModalOpen(false); };
    
    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        if (event.target.files) {
            setAttachments(prev => [...prev, ...Array.from(event.target.files!)]);
        }
    };
    const removeAttachment = (index: number) => {
        setAttachments(prev => prev.filter((_, i) => i !== index));
    };

    const handleDescriptionDoubleClick = (index: number, value: string) => {
        setEditingDescriptionData({ index, value });
        setIsDescriptionModalOpen(true);
    };

    const handleSaveDescription = (newValue: string) => {
        if (editingDescriptionData) {
            handleLineChange(editingDescriptionData.index, 'description', newValue);
        }
    };

    return (
        <div className="max-w-7xl mx-auto space-y-8">
            <AuroraToolbar voucherNumber={currentVoucher?.voucherNumber} viewMode={viewMode} onNew={handleNew} onSave={handleSave} onEdit={() => setViewMode('editing')} onCancel={handleCancel} onDelete={handleDelete} navigateVoucher={navigateVoucher} onVoucherSearch={handleVoucherSearch}/>
            
            <AuroraCard>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="relative group">
                        <Calendar size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none z-10" />
                        <input type="date" value={date} onChange={e => setDate(e.target.value)} disabled={isFormDisabled} className="header-input-field pl-12" />
                    </div>
                    <div className="relative group">
                        <Wallet size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none z-10" />
                        <SearchableAccountInput 
                            value={paidFromAccountId || ''} 
                            accounts={paidFromAccounts} 
                            onSelect={acc => setPaidFromAccountId(acc.id)} 
                            disabled={isFormDisabled} 
                            placeholder="Paid From Account" 
                            className="header-input-field !pl-12"
                            onDoubleClick={() => !isFormDisabled && setIsHeaderAccountModalOpen(true)}
                        />
                    </div>
                    <div className="relative group">
                        <Hash size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none z-10" />
                        <input type="text" value={referenceNumber} onChange={e => setReferenceNumber(e.target.value)} disabled={isFormDisabled} className="header-input-field pl-12" placeholder="Reference #" />
                    </div>
                </div>
            </AuroraCard>

            <AuroraCard className="overflow-visible relative z-30">
                <div className="min-w-[900px] -m-6">
                    <div className="grid grid-cols-12 gap-4 px-6 py-3 text-xs font-bold text-slate-500 uppercase tracking-wider border-b border-white/60">
                        <div className="col-span-3">Paid To (Payee)</div>
                        <div className="col-span-3">Account</div>
                        <div className="col-span-3">Description</div>
                        <div className="col-span-2 text-right">Amount</div>
                        <div className="col-span-1"></div>
                    </div>
                    <div className="divide-y divide-white/40">
                    {lines.map((line, index) => (
                        <div key={line.id} className="grid grid-cols-12 gap-4 px-6 py-2 items-center group">
                            <div className="col-span-3 relative">
                                <UserSearch size={16} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none z-10" />
                                <SearchableAccountInput 
                                    value={line.party?.id || ''} 
                                    accounts={allParties.map(p => ({...p, id: p.id, name: p.name, code: p.type, nameKurdish: '', balance: p.balance}))} 
                                    onSelect={p => handleLineChange(index, 'party', {id: p.id, name: p.name, type: p.code as PartyEntity['type']})} 
                                    disabled={isFormDisabled} 
                                    placeholder="Select Payee"
                                    className="input-grid"
                                    onDoubleClick={() => !isFormDisabled && handleOpenPartyModal(index)}
                                />
                            </div>
                            <div className="col-span-3 relative">
                                <BookCopy size={16} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none z-10" />
                                <SearchableAccountInput 
                                    value={line.accountId || ''} 
                                    accounts={contraAccounts} 
                                    onSelect={acc => handleLineChange(index, 'accountId', acc.id)} 
                                    disabled={isFormDisabled} 
                                    placeholder="Select Account" 
                                    className="input-grid"
                                    onDoubleClick={() => !isFormDisabled && handleOpenAccountModal(index)}
                                />
                            </div>
                            <div className="col-span-3 relative">
                                <MessageSquare size={16} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none z-10" />
                                <input type="text" value={line.description} onChange={e => handleLineChange(index, 'description', e.target.value)} onDoubleClick={() => !isFormDisabled && handleDescriptionDoubleClick(index, line.description)} disabled={isFormDisabled} className="input-grid" placeholder="Line description..." />
                            </div>
                            <div className="col-span-2 relative h-10">
                                <CurrencyInput 
                                    value={line.amount} 
                                    onChange={(val) => handleLineChange(index, 'amount', val)}
                                    onConversion={(iqd, rate) => handleCurrencyConversion(index, iqd, rate)}
                                    disabled={isFormDisabled}
                                    compact
                                    wrapperClassName="relative w-full h-full bg-white/70 border border-white/60 rounded-xl shadow-inner flex items-center overflow-hidden"
                                />
                            </div>
                            <div className="col-span-1 text-center">{!isFormDisabled && <button onClick={() => removeLine(index)} className="text-slate-400 hover:text-red-500 opacity-50 group-hover:opacity-100 transition"><XCircle size={18}/></button>}</div>
                        </div>
                    ))}
                    </div>
                     <div className="flex justify-between items-center px-6 py-3 mt-2 border-t border-white/60 bg-sky-50/20">
                        {!isFormDisabled && <button onClick={addLine} className="text-sm font-semibold text-sky-600 hover:text-sky-800 flex items-center gap-1"><Plus size={16}/> Add Line</button>}
                        <div className="flex items-center gap-4 ml-auto"><span className="text-sm font-bold text-slate-500">GRAND TOTAL</span><span className="text-xl font-mono font-bold text-sky-700 w-40 text-right pr-2">{formatCurrency(totalAmount)}</span></div>
                    </div>
                </div>
            </AuroraCard>

             <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                 <AuroraCard className="md:col-span-2" title="Notes & Attachments">
                    <div className="space-y-4">
                        <textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Add internal notes for this voucher..." disabled={isFormDisabled} rows={3} className="w-full bg-white/40 border border-white/50 rounded-xl shadow-inner p-3 text-sm focus:ring-1 focus:ring-sky-300/60 focus:outline-none transition"></textarea>
                        
                        {/* Intelligent Guide for Open Bills */}
                        <AnimatePresence>
                            {payeeWithOpenBills && viewMode !== 'viewing' && (
                                <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="bg-amber-50 border border-amber-200 rounded-lg p-3 flex items-start gap-3">
                                    <Info className="text-amber-500 flex-shrink-0 mt-0.5" size={18} />
                                    <div>
                                        <p className="text-sm font-semibold text-amber-800">Open Bills Detected</p>
                                        <p className="text-xs text-amber-700 mt-1">
                                            We found unpaid bills for <strong>{payeeWithOpenBills.name}</strong>. 
                                            It is recommended to use the <Link to="/pay-bills" className="underline font-bold hover:text-amber-900">Pay Bills</Link> feature to link this payment directly to the bills.
                                        </p>
                                    </div>
                                </motion.div>
                            )}
                        </AnimatePresence>

                        <div>
                            <label className="text-sm font-semibold text-slate-600 mb-2 block">Attachments</label>
                            <div className="mt-2">
                                <label htmlFor="file-upload" className="relative cursor-pointer bg-white/60 rounded-xl border-2 border-dashed border-slate-300/80 hover:border-sky-400/80 transition-colors w-full flex flex-col justify-center items-center text-center p-6">
                                    <UploadCloud size={24} className="text-slate-400" />
                                    <span className="mt-2 block text-sm font-semibold text-slate-600">Click to upload or drag & drop</span>
                                    <span className="block text-xs text-slate-500">PDF, PNG, JPG, etc.</span>
                                    <input id="file-upload" name="file-upload" type="file" className="sr-only" multiple onChange={handleFileChange} disabled={isFormDisabled} />
                                </label>
                            </div>
                        </div>
                        {attachments.length > 0 && (
                            <div className="space-y-2 pt-2">
                                {attachments.map((file, index) => (
                                    <div key={index} className="flex items-center justify-between bg-white/50 p-2 rounded-lg text-sm">
                                        <div className="flex items-center gap-2 truncate">
                                            <Paperclip size={16} className="text-slate-500 flex-shrink-0" />
                                            <span className="truncate" title={file.name}>{file.name}</span>
                                        </div>
                                        {!isFormDisabled && <button onClick={() => removeAttachment(index)} className="p-1 text-slate-400 hover:text-red-500 transition"><XCircle size={16} /></button>}
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                 </AuroraCard>
                 <AuroraCard className="flex flex-col justify-center items-center text-center space-y-4 !bg-gradient-to-br from-sky-50/50 to-cyan-50/50">
                    <p className="text-sm font-bold text-slate-500 uppercase tracking-widest">Voucher Total</p>
                    <p className="text-5xl font-mono font-bold text-transparent bg-clip-text bg-gradient-to-r from-sky-600 to-cyan-500">{formatCurrency(totalAmount)}</p>
                    {viewMode !== 'viewing' && <AuroraButton variant="primary" className="w-full !py-4 !text-base" onClick={handleSave}><Save size={18} className="mr-2"/>Save Voucher</AuroraButton>}
                 </AuroraCard>
            </div>
            
            <PartySelectionModal
                isOpen={isPartyModalOpen}
                onClose={() => setIsPartyModalOpen(false)}
                onSelect={handlePartySelect}
                partyTypes={['vendor', 'customer', 'employee', 'shareholder']}
                data={{ customers, employees, shareholders, vendors }}
            />
            
            <AccountSelectionModal 
                isOpen={isAccountModalOpen}
                onClose={() => setIsAccountModalOpen(false)}
                onSelect={handleAccountSelect}
                accounts={contraAccounts}
            />
             <AccountSelectionModal 
                isOpen={isHeaderAccountModalOpen}
                onClose={() => setIsHeaderAccountModalOpen(false)}
                onSelect={handleHeaderAccountSelect}
                accounts={paidFromAccounts}
            />

            <DescriptionEditModal 
                isOpen={isDescriptionModalOpen}
                onClose={() => setIsDescriptionModalOpen(false)}
                initialValue={editingDescriptionData?.value || ''}
                onSave={handleSaveDescription}
            />

            <style>{`
                .header-input-field {
                    width: 100%;
                    height: 56px;
                    background-color: rgba(255, 255, 255, 0.7);
                    border: 1px solid rgba(255, 255, 255, 0.6);
                    border-radius: 1.25rem;
                    box-shadow: inset 0 1px 2px 0 rgb(0 0 0 / 0.05);
                    padding-top: 1rem;
                    padding-bottom: 1rem;
                    padding-right: 1rem;
                    color: #1e293b;
                    font-size: 0.875rem;
                    transition: all 0.2s;
                }
                .header-input-field:focus { outline: none; box-shadow: inset 0 1px 2px 0 rgb(0 0 0 / 0.05), 0 0 0 2px #7dd3fc; }
                .header-input-field:disabled { background-color: rgba(241, 245, 249, 0.7); cursor: not-allowed; }
                input[type="date"].header-input-field::-webkit-calendar-picker-indicator { cursor: pointer; opacity: 0.6; }

                .input-grid { width: 100%; height: 40px; background: rgba(255,255,255,0.7); border: 1px solid rgba(255,255,255,0.6); border-radius: 0.75rem; box-shadow: inset 0 1px 2px 0 rgb(0 0 0 / 0.05); padding-left: 2.25rem; padding-right: 1rem; color: #1e293b; font-size: 0.875rem; transition: all 0.2s; }
                .input-grid:focus { outline: none; box-shadow: inset 0 1px 2px 0 rgb(0 0 0 / 0.05), 0 0 0 2px #7dd3fc; }
                .input-grid:disabled { background-color: transparent; box-shadow: none; border-color: rgba(203, 213, 225, 0.5); }
                .input-grid::placeholder { color: #94a3b8; }
            `}</style>
        </div>
    );
};

export default Disbursements;
