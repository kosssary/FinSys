
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useData } from '../context/DataContext';
import { Payroll, PayrollEmployee } from '../types';
import PaySalariesModal from '../components/modals/PaySalariesModal';
import { Calendar, CheckCircle, DollarSign, Wallet, Lock, AlertTriangle, ArrowRight, Activity, Save, Users, RefreshCw, FileSpreadsheet, FileText, Download } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const formatCurrency = (value: number) => new Intl.NumberFormat('en-US').format(value);

const PayrollPage: React.FC = () => {
    const { getDraftPayroll, finalizePayroll, _version } = useData();
    const [period, setPeriod] = useState<string>(`${new Date().getFullYear()}-${String(new Date().getMonth() + 1).padStart(2, '0')}`);
    const [payroll, setPayroll] = useState<Payroll | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [isProcessing, setIsProcessing] = useState(false);
    const [isPayModalOpen, setIsPayModalOpen] = useState(false);
    const [successMessage, setSuccessMessage] = useState<string | null>(null);

    const fetchPayroll = useCallback(async () => {
        setIsLoading(true);
        try {
            const data = await getDraftPayroll(period);
            setPayroll(data);
        } catch (error) {
            console.error(error);
        } finally {
            setIsLoading(false);
        }
    }, [period, getDraftPayroll]);

    useEffect(() => {
        fetchPayroll();
    }, [period, _version, fetchPayroll]);

    // Clear success message after 3 seconds
    useEffect(() => {
        if (successMessage) {
            const timer = setTimeout(() => setSuccessMessage(null), 3000);
            return () => clearTimeout(timer);
        }
    }, [successMessage]);

    const handleValueChange = (employeeId: string, field: 'deduction' | 'bonus', newValue: number) => {
        if (!payroll || payroll.status !== 'Draft') return;

        setPayroll(prev => {
            if (!prev) return null;
            const newEmployees = prev.employees.map(emp => {
                if (emp.employeeId === employeeId) {
                    const updates: Partial<PayrollEmployee> = {};
                    
                    if (field === 'deduction') {
                        updates.deduction = Math.max(0, newValue);
                    } else if (field === 'bonus') {
                        updates.bonus = Math.max(0, newValue);
                    }
                    
                    const currentBonus = field === 'bonus' ? (updates.bonus || 0) : (emp.bonus || 0);
                    const currentDeduction = field === 'deduction' ? (updates.deduction || 0) : emp.deduction;
                    
                    updates.netSalary = emp.basicSalary + currentBonus - currentDeduction;
                    return { ...emp, ...updates };
                }
                return emp;
            });
            return { ...prev, employees: newEmployees };
        });
    };

    const handleFinalize = async () => {
        if (!payroll || payroll.status !== 'Draft') return;
        
        if (window.confirm(`Are you sure you want to finalize payroll for ${period}? This will post accounting entries and cannot be undone.`)) {
            setIsProcessing(true);
            try {
                await finalizePayroll(payroll);
                setSuccessMessage("Payroll Finalized & Posted Successfully!");
                fetchPayroll();
            } catch (error) {
                alert(`Error: ${(error as Error).message}`);
            } finally {
                setIsProcessing(false);
            }
        }
    };

    // --- EXPORT FUNCTIONS ---
    const handleExportExcel = () => {
        if (!payroll) return;
        const XLSX = (window as any).XLSX;
        if (!XLSX) return alert("Excel library not available.");

        const rows = payroll.employees.map(emp => ({
            "Employee ID": emp.employeeId,
            "Name": emp.employeeName,
            "Basic Salary": emp.basicSalary,
            "Current Loan Balance": emp.advanceBalance,
            "Bonuses": emp.bonus || 0,
            "Deductions": emp.deduction || 0,
            "Net Pay": emp.netSalary
        }));

        const ws = XLSX.utils.json_to_sheet(rows);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, `Payroll_${period}`);
        XLSX.writeFile(wb, `Payroll_${period}.xlsx`);
    };

    const handleExportPdf = () => {
        if (!payroll) return;
        const { jsPDF } = (window as any).jspdf;
        if (!jsPDF) return alert("PDF library not available.");

        const doc = new jsPDF({ orientation: 'landscape' });
        const margin = 14;

        doc.setFontSize(18);
        doc.text(`Payroll Sheet - ${period}`, margin, 20);
        doc.setFontSize(10);
        doc.text(`Status: ${payroll.status}`, margin, 26);

        const tableColumn = ["ID", "Employee", "Basic Salary", "Loan Bal.", "Bonus", "Deduction", "Net Pay"];
        const tableRows = payroll.employees.map(emp => [
            emp.employeeId,
            emp.employeeName,
            formatCurrency(emp.basicSalary),
            formatCurrency(emp.advanceBalance),
            formatCurrency(emp.bonus || 0),
            formatCurrency(emp.deduction || 0),
            formatCurrency(emp.netSalary)
        ]);

        (doc as any).autoTable({
            head: [tableColumn],
            body: tableRows,
            startY: 35,
            styles: { fontSize: 9 },
            headStyles: { fillColor: [15, 23, 42] },
            columnStyles: {
                2: { halign: 'right' },
                3: { halign: 'right', textColor: [234, 88, 12] },
                4: { halign: 'right', textColor: [16, 185, 129] },
                5: { halign: 'right', textColor: [220, 38, 38] },
                6: { halign: 'right', fontStyle: 'bold' },
            }
        });

        doc.save(`Payroll_${period}.pdf`);
    };

    const totals = useMemo(() => {
        if (!payroll) return { totalGross: 0, totalBonuses: 0, totalDeductions: 0, totalNet: 0 };
        return {
            totalGross: payroll.employees.reduce((s, e) => s + e.basicSalary, 0),
            totalBonuses: payroll.employees.reduce((s, e) => s + (e.bonus || 0), 0),
            totalDeductions: payroll.employees.reduce((s, e) => s + e.deduction, 0),
            totalNet: payroll.employees.reduce((s, e) => s + e.netSalary, 0)
        };
    }, [payroll]);

    const statusColors = {
        'Draft': 'bg-amber-100 text-amber-700 border-amber-200',
        'Finalized': 'bg-sky-100 text-sky-700 border-sky-200',
        'Paid': 'bg-emerald-100 text-emerald-700 border-emerald-200'
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 via-sky-50/30 to-slate-50 p-4 md:p-8 font-sans text-slate-600">
            
            {/* Success Message Overlay */}
            <AnimatePresence>
                {successMessage && (
                    <motion.div 
                        initial={{ opacity: 0, y: -20 }} 
                        animate={{ opacity: 1, y: 0 }} 
                        exit={{ opacity: 0, y: -20 }}
                        className="fixed top-10 left-1/2 transform -translate-x-1/2 z-50 bg-emerald-500 text-white px-6 py-3 rounded-full shadow-xl flex items-center gap-3 font-bold text-sm backdrop-blur-md bg-opacity-90"
                    >
                        <CheckCircle size={18} className="text-white" />
                        {successMessage}
                    </motion.div>
                )}
            </AnimatePresence>

            {/* Main Glass Container */}
            <div className="max-w-7xl mx-auto bg-white/65 backdrop-blur-[20px] border border-white/80 shadow-[0_8px_32px_0_rgba(31,38,135,0.07)] rounded-3xl flex flex-col h-[calc(100vh-6rem)] overflow-hidden">
                
                {/* Header Section */}
                <div className="px-8 py-6 flex flex-col md:flex-row justify-between items-center gap-4 border-b border-slate-100">
                    <div className="flex items-center gap-3">
                        <div className="p-2.5 bg-indigo-50 rounded-xl text-indigo-600">
                            <Activity size={20} />
                        </div>
                        <div>
                            <h1 className="text-lg font-bold text-slate-800 tracking-tight">Payroll Dashboard</h1>
                            <p className="text-xs font-medium text-slate-400">Manage salaries & compensation</p>
                        </div>
                    </div>

                    <div className="flex items-center gap-3 bg-white/50 p-1.5 rounded-xl border border-white shadow-sm">
                        <input 
                            type="month" 
                            value={period} 
                            onChange={e => setPeriod(e.target.value)} 
                            className="bg-transparent border-none text-sm font-bold text-slate-700 focus:ring-0 cursor-pointer pl-2"
                        />
                        {payroll && (
                            <span className={`px-3 py-1 rounded-lg text-xs font-bold uppercase tracking-wider ${
                                payroll.status === 'Draft' ? 'bg-amber-100 text-amber-700' :
                                payroll.status === 'Finalized' ? 'bg-sky-100 text-sky-700' :
                                'bg-emerald-100 text-emerald-700'
                            }`}>
                                {payroll.status}
                            </span>
                        )}
                    </div>
                </div>

                {/* Table Content */}
                <div className="flex-1 overflow-auto">
                    {isLoading ? (
                        <div className="flex flex-col items-center justify-center h-full text-slate-400">
                            <RefreshCw size={32} className="animate-spin mb-2 opacity-50" />
                            <p className="text-sm font-medium">Loading Data...</p>
                        </div>
                    ) : payroll ? (
                        <table className="w-full text-sm text-left">
                            <thead className="text-xs text-slate-400 uppercase font-bold bg-white/40 sticky top-0 z-10 backdrop-blur-md">
                                <tr>
                                    <th className="px-8 py-4 pl-10 font-semibold">Employee</th>
                                    <th className="px-6 py-4 text-right font-semibold">Base Salary</th>
                                    <th className="px-6 py-4 text-center w-32 font-semibold">Bonus</th>
                                    <th className="px-6 py-4 text-right font-semibold">Loan Balance</th>
                                    <th className="px-6 py-4 text-center w-32 font-semibold">Deduction</th>
                                    <th className="px-8 py-4 text-right pr-10 font-semibold">Net Pay</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-50">
                                {payroll.employees.map((emp) => (
                                    <tr key={emp.employeeId} className="hover:bg-white/40 transition-colors group">
                                        <td className="px-8 py-3 pl-10">
                                            <div className="flex items-center gap-3">
                                                <div className="w-8 h-8 rounded-full bg-white shadow-sm border border-slate-100 flex items-center justify-center text-slate-500 font-bold text-[10px]">
                                                    {emp.employeeName.charAt(0)}
                                                </div>
                                                <div>
                                                    <p className="font-bold text-slate-700 text-sm">{emp.employeeName}</p>
                                                    <p className="text-[10px] text-slate-400 font-mono">{emp.employeeId}</p>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-6 py-3 text-right font-mono text-slate-600">
                                            {formatCurrency(emp.basicSalary)}
                                        </td>
                                        <td className="px-6 py-3 text-center">
                                            <div className="relative group/input">
                                                <input
                                                    type="number"
                                                    value={emp.bonus || ''}
                                                    onChange={e => handleValueChange(emp.employeeId, 'bonus', parseFloat(e.target.value) || 0)}
                                                    placeholder="0"
                                                    disabled={payroll.status !== 'Draft'}
                                                    className="w-full bg-transparent text-center font-medium text-emerald-600 placeholder-slate-300 rounded-lg py-1 transition-all group-hover/input:bg-white/50 focus:bg-white focus:ring-2 focus:ring-emerald-100 outline-none"
                                                />
                                            </div>
                                        </td>
                                        <td className="px-6 py-3 text-right">
                                            <div className={`font-mono font-bold text-sm ${emp.advanceBalance > 0 ? 'text-orange-500' : 'text-slate-300'}`}>
                                                {formatCurrency(emp.advanceBalance)}
                                            </div>
                                        </td>
                                        <td className="px-6 py-3 text-center">
                                            <div className="relative group/input">
                                                <input
                                                    type="number"
                                                    value={emp.deduction || ''}
                                                    onChange={e => handleValueChange(emp.employeeId, 'deduction', parseFloat(e.target.value) || 0)}
                                                    placeholder="0"
                                                    disabled={payroll.status !== 'Draft'}
                                                    className="w-full bg-transparent text-center font-medium text-rose-500 placeholder-slate-300 rounded-lg py-1 transition-all group-hover/input:bg-white/50 focus:bg-white focus:ring-2 focus:ring-rose-100 outline-none"
                                                />
                                            </div>
                                        </td>
                                        <td className="px-8 py-3 pr-10 text-right">
                                            <span className="font-bold text-indigo-600 bg-indigo-50/50 px-2 py-0.5 rounded text-sm">
                                                {formatCurrency(emp.netSalary)}
                                            </span>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    ) : (
                        <div className="flex flex-col items-center justify-center h-full text-slate-400">
                            <p>No data found for this period.</p>
                        </div>
                    )}
                </div>

                {/* Floating Bottom Bar */}
                {payroll && (
                    <div className="absolute bottom-6 left-0 right-0 flex justify-center items-center px-6 z-20 pointer-events-none">
                        <div className="bg-white/75 backdrop-blur-xl border border-white/60 shadow-2xl shadow-slate-200/50 rounded-full px-2 py-2 flex items-center gap-8 pointer-events-auto">
                            <div className="flex gap-8 px-6">
                                <div className="text-center">
                                    <p className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Gross</p>
                                    <p className="text-xs font-bold text-slate-700">{formatCurrency(totals.totalGross)}</p>
                                </div>
                                <div className="w-px bg-slate-200 h-6 self-center"></div>
                                <div className="text-center">
                                    <p className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Net Pay</p>
                                    <p className="text-base font-black text-indigo-600">{formatCurrency(totals.totalNet)}</p>
                                </div>
                            </div>

                            <div className="flex gap-2">
                                {payroll.status === 'Draft' && (
                                    <button 
                                        onClick={handleFinalize}
                                        disabled={isProcessing}
                                        className="bg-slate-800 hover:bg-slate-700 text-white px-5 py-2 rounded-full font-bold text-xs shadow-lg shadow-slate-900/10 transition-all hover:scale-105 active:scale-95 flex items-center gap-2"
                                    >
                                        {isProcessing ? <RefreshCw size={14} className="animate-spin"/> : <Lock size={14} />}
                                        <span>Finalize</span>
                                    </button>
                                )}
                                {payroll.status === 'Finalized' && (
                                    <button 
                                        onClick={() => setIsPayModalOpen(true)}
                                        className="bg-emerald-500 hover:bg-emerald-600 text-white px-5 py-2 rounded-full font-bold text-xs shadow-lg shadow-emerald-500/20 transition-all hover:scale-105 active:scale-95 flex items-center gap-2"
                                    >
                                        <Wallet size={14} /> Pay Now
                                    </button>
                                )}
                                {payroll.status === 'Paid' && (
                                    <div className="bg-emerald-50 text-emerald-600 border border-emerald-100 px-4 py-2 rounded-full font-bold text-xs flex items-center gap-2">
                                        <CheckCircle size={14} /> Paid
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                )}

                {/* Export Buttons (Bottom Right) */}
                <div className="absolute bottom-6 right-6 z-30 flex flex-col gap-2">
                    <button onClick={handleExportExcel} className="w-9 h-9 bg-white/80 hover:bg-white border border-white/50 shadow-lg rounded-full flex items-center justify-center text-emerald-600 hover:scale-110 transition-all" title="Export Excel">
                        <FileSpreadsheet size={16} />
                    </button>
                    <button onClick={handleExportPdf} className="w-9 h-9 bg-white/80 hover:bg-white border border-white/50 shadow-lg rounded-full flex items-center justify-center text-rose-600 hover:scale-110 transition-all" title="Export PDF">
                        <FileText size={16} />
                    </button>
                </div>

            </div>

            {payroll && (payroll.status === 'Finalized' || payroll.status === 'Paid') && (
                <PaySalariesModal
                    isOpen={isPayModalOpen}
                    onClose={() => setIsPayModalOpen(false)}
                    payroll={payroll}
                />
            )}
        </div>
    );
};

export default PayrollPage;
