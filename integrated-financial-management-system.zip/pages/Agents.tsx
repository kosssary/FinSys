import React, { useState, useMemo, useEffect } from 'react';
import { useData } from '../context/DataContext';
import { Agent } from '../types';
import AddAgentModal from '../components/modals/AddAgentModal';
import { Plus, Search, ArrowUp, ArrowDown, Pencil, Trash2, ExternalLink } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

type ColumnKeys = 'id' | 'name' | 'phone' | 'commissionRate' | 'createdAt';

const Agents: React.FC = () => {
    const { getAgents, deleteAgent, _version } = useData();
    const navigate = useNavigate();
    const [agents, setAgents] = useState<Agent[]>([]);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingAgent, setEditingAgent] = useState<Agent | null>(null);
    const [searchQuery, setSearchQuery] = useState('');
    const [sortConfig, setSortConfig] = useState<{ key: ColumnKeys; direction: 'ascending' | 'descending' } | null>({ key: 'name', direction: 'ascending' });

    useEffect(() => {
        getAgents().then(setAgents);
    }, [_version]);

    const handleOpenModal = (agent: Agent | null) => {
        setEditingAgent(agent);
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setEditingAgent(null);
        setIsModalOpen(false);
    };

    const handleDelete = async (agentId: string) => {
        if (window.confirm('Are you sure you want to delete this agent? This action cannot be undone.')) {
            try {
                await deleteAgent(agentId);
            } catch (error) {
                alert(`Error: ${(error as Error).message}`);
            }
        }
    };

    const filteredAndSortedAgents = useMemo(() => {
        let processed = [...agents];
        
        if (searchQuery) {
            const lowerQuery = searchQuery.toLowerCase();
            processed = agents.filter(agent =>
                (agent.name && agent.name.toLowerCase().includes(lowerQuery)) ||
                (agent.phone && agent.phone.includes(searchQuery)) ||
                agent.id.toLowerCase().includes(lowerQuery)
            );
        }

        if (sortConfig) {
            processed.sort((a, b) => {
                const aVal = a[sortConfig.key] || '';
                const bVal = b[sortConfig.key] || '';
                if (aVal < bVal) return sortConfig.direction === 'ascending' ? -1 : 1;
                if (aVal > bVal) return sortConfig.direction === 'ascending' ? 1 : -1;
                return 0;
            });
        }
        
        return processed;
    }, [agents, searchQuery, sortConfig]);

    const requestSort = (key: ColumnKeys) => {
        let direction: 'ascending' | 'descending' = 'ascending';
        if (sortConfig && sortConfig.key === key && sortConfig.direction === 'ascending') {
            direction = 'descending';
        }
        setSortConfig({ key, direction });
    };

    const getSortIcon = (key: ColumnKeys) => {
        if (!sortConfig || sortConfig.key !== key) return null;
        return sortConfig.direction === 'ascending' ? <ArrowUp size={14} /> : <ArrowDown size={14} />;
    };
    
    const headers: { key: ColumnKeys; label: string }[] = [
        { key: 'id', label: 'Agent ID' },
        { key: 'name', label: 'Name' },
        { key: 'phone', label: 'Phone' },
        { key: 'commissionRate', label: 'Commission %' },
        { key: 'createdAt', label: 'Date Added' },
    ];

    return (
        <div className="space-y-6">
            <div className="relative z-20 flex flex-col md:flex-row justify-between items-center gap-4 p-4 bg-white/60 backdrop-blur-md border border-white/50 rounded-2xl shadow-sm">
                 <div className="relative w-full md:max-w-md">
                    <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input 
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Search by ID, name or phone..."
                        className="w-full h-11 bg-white/80 border border-white/60 rounded-xl shadow-inner pl-10 pr-4 text-slate-800 text-sm focus:ring-2 focus:ring-sky-300/60 focus:outline-none transition"
                    />
                </div>
                <div className="flex items-center gap-3 w-full md:w-auto">
                    <button 
                        onClick={() => handleOpenModal(null)}
                        className="flex items-center justify-center gap-2 w-full md:w-auto h-11 px-5 text-sm font-bold bg-gradient-to-r from-sky-500 to-cyan-500 text-white rounded-xl shadow hover:shadow-lg active:scale-[0.98] transition-all"
                    >
                        <Plus size={18} />
                        <span>New Agent</span>
                    </button>
                </div>
            </div>

            <div className="bg-white/65 backdrop-blur-xl border border-white/50 rounded-2xl shadow-[0_10px_40px_rgba(0,0,0,0.06)]">
                <table className="w-full min-w-[900px]">
                    <thead>
                        <tr className="border-b border-white/60">
                            {headers.map(header => (
                                <th key={header.key} className="px-4 py-3 text-left text-xs font-semibold tracking-wider text-slate-500 uppercase">
                                    <button onClick={() => requestSort(header.key)} className="w-full flex items-center gap-2 group">
                                        <span>{header.label}</span>
                                        {getSortIcon(header.key)}
                                    </button>
                                </th>
                            ))}
                             <th className="px-4 py-3 text-left text-xs font-semibold tracking-wider text-slate-500 uppercase">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-white/60">
                        {filteredAndSortedAgents.map((agent) => (
                            <tr key={agent.id} className="hover:bg-sky-100/30 transition-colors duration-150">
                                <td className="px-4 py-3 text-sm font-mono text-slate-700">{agent.id}</td>
                                <td className="px-4 py-3 font-semibold text-sm text-slate-800 cursor-pointer hover:text-sky-600" onClick={() => navigate(`/agents/${agent.id}`)}>{agent.name || 'N/A'}</td>
                                <td className="px-4 py-3 text-sm text-slate-500">{agent.phone}</td>
                                <td className="px-4 py-3 text-sm text-slate-500">{agent.commissionRate ? `${agent.commissionRate}%` : '-'}</td>
                                <td className="px-4 py-3 text-sm text-slate-500">{new Date(agent.createdAt).toLocaleDateString()}</td>
                                <td className="px-4 py-3">
                                    <div className="flex items-center gap-4">
                                         <button onClick={() => navigate(`/agents/${agent.id}`)} className="text-slate-500 hover:text-sky-600 transition-colors" title="View Profile">
                                            <ExternalLink size={16} />
                                        </button>
                                        <button onClick={() => handleOpenModal(agent)} className="text-slate-500 hover:text-sky-600 transition-colors" title="Edit Agent">
                                            <Pencil size={16} />
                                        </button>
                                        <button onClick={() => handleDelete(agent.id)} className="text-slate-500 hover:text-red-600 transition-colors" title="Delete Agent">
                                            <Trash2 size={16} />
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                 {filteredAndSortedAgents.length === 0 && (
                    <div className="text-center py-16 text-slate-500">
                        <p>No agents found.</p>
                    </div>
                )}
            </div>

            <AddAgentModal 
                isOpen={isModalOpen} 
                onClose={handleCloseModal}
                editingAgent={editingAgent}
                onSave={handleCloseModal}
            />
        </div>
    );
};

export default Agents;