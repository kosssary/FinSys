
import React, { useState, useEffect, useCallback, useMemo, Fragment } from 'react';
import { useData } from '../context/DataContext';
import { DashboardData, Kpi, Transaction } from '../types';
import { useNavigate } from 'react-router-dom';
import { ResponsiveContainer, LineChart, Line, ComposedChart, Bar, BarChart, XAxis, YAxis, Tooltip, Legend, PieChart, Pie, Cell, Label } from 'recharts';
import { useTheme } from '../context/ThemeContext';
import { Theme } from '../context/ThemeContext';
import { motion, AnimatePresence } from 'framer-motion';
import {
    AreaChart,
    ArrowDown,
    ArrowUp,
    Banknote,
    BookCopy,
    CheckCircle2,
    ChevronDown,
    CircleDollarSign,
    Clock,
    Download,
    Eye,
    EyeOff,
    FileText,
    Landmark,
    LayoutGrid,
    List,
    PieChart as PieChartIcon,
    Settings2,
    ShoppingCart,
    SlidersHorizontal,
    TrendingDown,
    TrendingUp,
    Upload,
    Users,
    Wallet,
} from 'lucide-react';


// --- CONFIGURATION ---

const ALL_WIDGETS = [
    { id: 'kpis', name: 'Key Performance Indicators' },
    { id: 'shortcuts', name: 'Quick Shortcuts' },
    { id: 'financial-trend', name: 'Financial Trend Chart' },
    { id: 'expense-breakdown', name: 'Expense Breakdown Chart' },
    { id: 'cash-flow', name: 'Cash Flow Chart' },
    { id: 'unpaid-invoices', name: 'Top Unpaid Invoices' },
    { id: 'recent-activity', name: 'Recent Activity Feed' },
];

const ALL_SHORTCUTS = [
  { id: 'orders', title: 'Orders', icon: ShoppingCart, path: '/orders' },
  { id: 'receipts', title: 'Receipts', icon: Download, path: '/receipts' },
  { id: 'disbursements', title: 'Disbursements', icon: Upload, path: '/disbursements' },
  { id: 'customers', title: 'Customers', icon: Users, path: '/customers' },
  { id: 'coa', title: 'Chart of Accounts', icon: BookCopy, path: '/chart-of-accounts' },
  { id: 'pnl', title: 'Profit & Loss', icon: AreaChart, path: '/profit-and-loss' },
];

const DEFAULT_CONFIG = {
    widgets: {
        kpis: true,
        shortcuts: true,
        'financial-trend': true,
        'expense-breakdown': true,
        'cash-flow': true,
        'unpaid-invoices': true,
        'recent-activity': true,
    },
    shortcuts: {
        orders: true,
        receipts: true,
        disbursements: true,
        customers: true,
        coa: true,
        pnl: true,
    }
};

const DATE_RANGES = [
    { key: 'today', label: 'Today' },
    { key: 'week', label: 'This Week' },
    { key: 'month', label: 'This Month' },
    { key: 'year', label: 'This Year' },
];

// --- HELPER FUNCTIONS ---

const formatMonetary = (value: number) => new Intl.NumberFormat('en-US').format(value) + ' $';
const formatCount = (value: number) => new Intl.NumberFormat('en-US').format(value);

// --- MAIN DASHBOARD COMPONENT ---

const Dashboard: React.FC = () => {
    const { getDashboardData, _version } = useData();
    const { theme } = useTheme();
    const [dashboardData, setDashboardData] = useState<DashboardData | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    // --- State for Customization & Filtering ---
    const [config, setConfig] = useState(() => {
        try {
            const savedConfig = localStorage.getItem('dashboardConfig');
            return savedConfig ? JSON.parse(savedConfig) : DEFAULT_CONFIG;
        } catch {
            return DEFAULT_CONFIG;
        }
    });
    const [isPrivacyMode, setIsPrivacyMode] = useState(() => localStorage.getItem('dashboardPrivacyMode') === 'true');
    const [isCustomizeModalOpen, setIsCustomizeModalOpen] = useState(false);
    const [dateRangeKey, setDateRangeKey] = useState('month');
    const [dateRange, setDateRange] = useState({
        start: new Date(),
        end: new Date()
    });

    // --- Date Range Logic ---
    useEffect(() => {
        const today = new Date();
        let start = new Date();
        let end = new Date();

        switch (dateRangeKey) {
            case 'today':
                start = new Date(today.setHours(0, 0, 0, 0));
                end = new Date(new Date().setHours(23, 59, 59, 999));
                break;
            case 'week':
                const firstDayOfWeek = today.getDate() - today.getDay();
                start = new Date(new Date(today.setDate(firstDayOfWeek)).setHours(0, 0, 0, 0));
                end = new Date(new Date(start).setDate(start.getDate() + 6));
                break;
            case 'year':
                 start = new Date(today.getFullYear(), 0, 1);
                 end = new Date(today.getFullYear(), 11, 31);
                 break;
            case 'month':
            default:
                start = new Date(today.getFullYear(), today.getMonth(), 1);
                end = new Date(today.getFullYear(), today.getMonth() + 1, 0);
                break;
        }
        setDateRange({ start, end });
    }, [dateRangeKey]);

    // --- Data Fetching ---
    useEffect(() => {
        setIsLoading(true);
        getDashboardData(dateRange.start, dateRange.end)
            .then(setDashboardData)
            .catch(console.error)
            .finally(() => setIsLoading(false));
    }, [_version, getDashboardData, dateRange]);

    // --- Persist Settings ---
    useEffect(() => {
        localStorage.setItem('dashboardConfig', JSON.stringify(config));
    }, [config]);

    useEffect(() => {
        localStorage.setItem('dashboardPrivacyMode', String(isPrivacyMode));
    }, [isPrivacyMode]);

    const d = dashboardData; // shorthand

    const mainContent = isLoading ? (
        <div className="flex items-center justify-center h-full min-h-[50vh]">
            <p className="text-gray-500 dark:text-gray-400">Loading Dashboard Data...</p>
        </div>
    ) : d ? (
        <div className="grid grid-cols-12 auto-rows-min gap-6">
            {config.widgets.kpis && (
                <>
                    <div className="col-span-12"><TotalAvailableCashWidget data={d.keyBalances} isPrivacyMode={isPrivacyMode} /></div>
                    <div className="col-span-12 sm:col-span-6 md:col-span-4 lg:col-span-3"><KpiCard title="Net Profit" kpi={d.netProfit} icon={<TrendingUp />} isPrivacyMode={isPrivacyMode} link="/profit-and-loss" /></div>
                    <div className="col-span-12 sm:col-span-6 md:col-span-4 lg:col-span-3"><KpiCard title="Total Revenue" kpi={d.totalRevenue} icon={<CircleDollarSign />} isPrivacyMode={isPrivacyMode} link="/profit-and-loss" /></div>
                    <div className="col-span-12 sm:col-span-6 md:col-span-4 lg:col-span-3"><KpiCard title="Gross Profit Margin" kpi={d.grossProfitMargin} icon={<PieChartIcon />} isPrivacyMode={isPrivacyMode} isPercentage link="/profit-and-loss" /></div>
                    <div className="col-span-12 sm:col-span-6 md:col-span-4 lg:col-span-3"><KpiCard title="Total Expenses" kpi={d.totalExpenses} icon={<TrendingDown />} isPrivacyMode={isPrivacyMode} link="/profit-and-loss" /></div>
                </>
            )}
            {config.widgets['financial-trend'] && <div className="col-span-12 lg:col-span-8 h-80"><Widget title="Financial Trend"><FinancialTrendChart data={d.financialTrend} isPrivacyMode={isPrivacyMode} /></Widget></div>}
            {config.widgets['expense-breakdown'] && <div className="col-span-12 lg:col-span-4 h-80"><Widget title="Expense Breakdown"><ExpenseBreakdownChart data={d.expenseBreakdown} isDarkMode={theme === Theme.Dark} isPrivacyMode={isPrivacyMode} /></Widget></div>}
            {config.widgets['cash-flow'] && <div className="col-span-12 h-72"><Widget title="Cash Flow"><CashFlowChart data={d.cashFlowTrend} isPrivacyMode={isPrivacyMode} /></Widget></div>}
            {config.widgets['unpaid-invoices'] && <div className="col-span-12 lg:col-span-7"><Widget title="Top 5 Unpaid Invoices"><UnpaidInvoicesList data={d.topUnpaidInvoices} isPrivacyMode={isPrivacyMode} /></Widget></div>}
            {config.widgets['recent-activity'] && <div className="col-span-12 lg:col-span-5"><Widget title="Recent Activity"><RecentTransactionsList data={d.recentTransactions} isPrivacyMode={isPrivacyMode} /></Widget></div>}
        </div>
    ) : (
        <div className="flex items-center justify-center h-full min-h-[50vh]">
            <p className="text-red-500">Failed to load dashboard data.</p>
        </div>
    );

    return (
        <div className="space-y-6">
            <DashboardHeader 
                dateRange={dateRangeKey}
                onDateRangeChange={setDateRangeKey}
                isPrivacyMode={isPrivacyMode} 
                onTogglePrivacy={() => setIsPrivacyMode(p => !p)}
                onCustomize={() => setIsCustomizeModalOpen(true)}
            />
            {config.widgets.shortcuts && <QuickShortcuts config={config.shortcuts} />}
            {mainContent}
            <CustomizeModal 
                isOpen={isCustomizeModalOpen}
                onClose={() => setIsCustomizeModalOpen(false)}
                config={config}
                setConfig={setConfig}
            />
             <style>{`
                .recharts-default-tooltip {
                    background-color: rgba(255, 255, 255, 0.9) !important;
                    backdrop-filter: blur(4px) !important;
                    border: 1px solid rgba(0, 0, 0, 0.1) !important;
                    border-radius: 0.75rem !important;
                    box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1) !important;
                }
                .dark .recharts-default-tooltip {
                     background-color: rgba(29, 39, 56, 0.9) !important;
                     border: 1px solid rgba(255, 255, 255, 0.1) !important;
                }
            `}</style>
        </div>
    );
};

// --- NEW DASHBOARD-SPECIFIC SUB-COMPONENTS ---

const LiveClock = () => {
    const [time, setTime] = useState(new Date());
    useEffect(() => {
        const timer = setInterval(() => setTime(new Date()), 1000);
        return () => clearInterval(timer);
    }, []);

    return (
        <div className="flex items-center gap-3 text-slate-600 dark:text-slate-300">
            <Clock size={24} />
            <div className="text-right">
                <p className="font-semibold font-mono text-lg leading-tight">
                    {time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
                <p className="text-xs">
                    {time.toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })}
                </p>
            </div>
        </div>
    );
};

const DateRangeSelector: React.FC<{ value: string; onChange: (value: string) => void; }> = ({ value, onChange }) => (
    <div className="flex items-center p-1 bg-slate-200/80 dark:bg-slate-700/80 rounded-lg">
        {DATE_RANGES.map(range => (
            <button
                key={range.key}
                onClick={() => onChange(range.key)}
                className={`px-3 py-1 text-sm font-semibold rounded-md transition-colors ${
                    value === range.key
                        ? 'bg-white dark:bg-slate-900/70 text-sky-600 dark:text-sky-400 shadow-sm'
                        : 'text-slate-600 dark:text-slate-300 hover:bg-white/50 dark:hover:bg-black/10'
                }`}
            >
                {range.label}
            </button>
        ))}
    </div>
);


const DashboardHeader: React.FC<{ isPrivacyMode: boolean, onTogglePrivacy: () => void, onCustomize: () => void, dateRange: string, onDateRangeChange: (range: string) => void }> = ({ isPrivacyMode, onTogglePrivacy, onCustomize, dateRange, onDateRangeChange }) => (
    <div className="flex flex-wrap items-center justify-between gap-4">
        <LiveClock />
        <div className="flex items-center gap-2">
            <DateRangeSelector value={dateRange} onChange={onDateRangeChange} />
            <button onClick={onTogglePrivacy} className="p-2 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors" title={isPrivacyMode ? "Show Values" : "Hide Values"}>
                {isPrivacyMode ? <EyeOff size={20} className="text-slate-500 dark:text-slate-400" /> : <Eye size={20} className="text-slate-500 dark:text-slate-400" />}
            </button>
            <button onClick={onCustomize} className="p-2 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors" title="Customize Dashboard">
                <SlidersHorizontal size={20} className="text-slate-500 dark:text-slate-400" />
            </button>
        </div>
    </div>
);

const QuickShortcuts: React.FC<{ config: Record<string, boolean> }> = ({ config }) => {
    const navigate = useNavigate();
    const visibleShortcuts = ALL_SHORTCUTS.filter(s => config[s.id]);

    if (visibleShortcuts.length === 0) return null;

    return (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
            {visibleShortcuts.map(shortcut => (
                <button key={shortcut.id} onClick={() => navigate(shortcut.path)} className="flex flex-col items-center justify-center gap-2 p-4 bg-white/60 dark:bg-slate-800/60 backdrop-blur-lg border border-slate-200/50 dark:border-slate-700/50 rounded-xl shadow-sm hover:shadow-lg hover:-translate-y-1 transition-all duration-200">
                    <div className="w-10 h-10 flex items-center justify-center bg-sky-100 dark:bg-sky-900/50 rounded-full">
                        <shortcut.icon size={20} className="text-sky-600 dark:text-sky-300" />
                    </div>
                    <span className="text-sm font-semibold text-slate-700 dark:text-slate-200">{shortcut.title}</span>
                </button>
            ))}
        </div>
    );
};

const KpiCard: React.FC<{ title: string; kpi: Kpi; icon: React.ReactNode; isPrivacyMode: boolean; isPercentage?: boolean; isCount?: boolean; link: string; }> = ({ title, kpi, icon, isPrivacyMode, isPercentage, isCount, link }) => {
    const navigate = useNavigate();
    const valueText = isPercentage ? `${kpi.value.toFixed(1)}%` : (isCount ? formatCount(kpi.value) : formatMonetary(kpi.value));
    const isPositive = kpi.comparison >= 0;

    return (
        <div onClick={() => navigate(link)} className="bg-white/60 dark:bg-slate-800/60 backdrop-blur-lg border border-slate-200/50 dark:border-slate-700/50 rounded-2xl shadow-sm h-full flex flex-col p-4 cursor-pointer hover:shadow-xl hover:border-sky-500/80 transition-all duration-300">
            <div className="flex justify-between items-start text-slate-500 dark:text-slate-400">
                <h3 className="text-sm font-semibold uppercase tracking-wider">{title}</h3>
                <div className="text-slate-400">{icon}</div>
            </div>
            <div className="mt-2 mb-3">
                 <p className="text-3xl font-bold text-slate-900 dark:text-white transition-all duration-300">
                    {isPrivacyMode ? '••••••' : valueText}
                </p>
            </div>
            <div className="mt-auto flex justify-between items-end">
                 <div className={`flex items-center text-sm font-bold ${isPositive ? 'text-emerald-500' : 'text-red-500'}`}>
                    {isPositive ? <TrendingUp size={16} className="mr-1"/> : <TrendingDown size={16} className="mr-1"/>}
                     {isPrivacyMode ? '••%' : `${Math.abs(kpi.comparison).toFixed(1)}%`}
                </div>
                <div className="w-24 h-8">
                     <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={kpi.sparkline} margin={{ top: 5, right: 0, left: 0, bottom: 0 }}>
                            <Line type="monotone" dataKey="value" stroke={isPositive ? '#10B981' : '#EF4444'} strokeWidth={2.5} dot={false} />
                        </LineChart>
                    </ResponsiveContainer>
                </div>
            </div>
        </div>
    );
};

const TotalAvailableCashWidget: React.FC<{ data: DashboardData['keyBalances']; isPrivacyMode: boolean; }> = ({ data, isPrivacyMode }) => {
    const total = data.cash + data.banks + data.eWallets;
    const items = [
        { title: 'Cash Funds', value: data.cash, icon: <Banknote className="text-green-600 dark:text-green-400" />, color: "bg-green-100 dark:bg-green-900/50" },
        { title: 'Bank Accounts', value: data.banks, icon: <Landmark className="text-blue-600 dark:text-blue-400" />, color: "bg-blue-100 dark:bg-blue-900/50" },
        { title: 'E-Wallets', value: data.eWallets, icon: <Wallet className="text-purple-600 dark:text-purple-400" />, color: "bg-purple-100 dark:bg-purple-900/50" },
    ];
    return (
        <div className="bg-white/60 dark:bg-slate-800/60 backdrop-blur-lg border border-slate-200/50 dark:border-slate-700/50 rounded-2xl shadow-sm p-6">
            <p className="text-base font-medium text-slate-500 dark:text-slate-400">Total Available Cash (کۆی پارەی بەردەست)</p>
            <p className="text-3xl font-bold text-slate-900 dark:text-white mt-2 mb-4 transition-all duration-300">
                {isPrivacyMode ? '•••••• $' : formatMonetary(total)}
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 border-t dark:border-slate-700 pt-4">
                {items.map(item => (
                    <div key={item.title} className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg ${item.color}`}>{item.icon}</div>
                        <div>
                            <p className="text-sm text-slate-500 dark:text-slate-400">{item.title}</p>
                            <p className="text-lg font-semibold text-slate-800 dark:text-slate-100 transition-all duration-300">
                                {isPrivacyMode ? '•••••• $' : formatMonetary(item.value)}
                            </p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

const CustomizeModal: React.FC<{ isOpen: boolean; onClose: () => void; config: typeof DEFAULT_CONFIG; setConfig: (config: typeof DEFAULT_CONFIG) => void; }> = ({ isOpen, onClose, config, setConfig }) => {
    
    const handleToggle = (type: 'widgets' | 'shortcuts', id: string) => {
        setConfig({
            ...config,
            [type]: { ...config[type], [id]: !config[type][id] },
        });
    };

    return (
        <AnimatePresence>
            {isOpen && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm" onClick={onClose}>
                    <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                        className="bg-white dark:bg-slate-800 rounded-xl shadow-2xl w-full max-w-lg max-h-[80vh] flex flex-col" onClick={e => e.stopPropagation()}>
                        <div className="p-4 border-b dark:border-slate-700 flex justify-between items-center">
                            <h2 className="text-lg font-bold">Customize Dashboard</h2>
                            <button onClick={onClose} className="p-1 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700">&times;</button>
                        </div>
                        <div className="p-6 overflow-y-auto space-y-6">
                            <div>
                                <h3 className="font-semibold mb-2">Widgets</h3>
                                <div className="space-y-2">
                                    {ALL_WIDGETS.map(widget => (
                                        <label key={widget.id} className="flex items-center justify-between p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700/50">
                                            <span>{widget.name}</span>
                                            <Switch isChecked={config.widgets[widget.id]} onChange={() => handleToggle('widgets', widget.id)} />
                                        </label>
                                    ))}
                                </div>
                            </div>
                            <div>
                                <h3 className="font-semibold mb-2">Quick Shortcuts</h3>
                                 <div className="space-y-2">
                                    {ALL_SHORTCUTS.map(shortcut => (
                                        <label key={shortcut.id} className="flex items-center justify-between p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700/50">
                                            <span>{shortcut.title}</span>
                                            <Switch isChecked={config.shortcuts[shortcut.id]} onChange={() => handleToggle('shortcuts', shortcut.id)} />
                                        </label>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </motion.div>
                </motion.div>
            )}
        </AnimatePresence>
    );
};

const Switch: React.FC<{ isChecked: boolean; onChange: () => void; }> = ({ isChecked, onChange }) => (
    <div onClick={onChange} className={`flex items-center w-10 h-5 px-0.5 rounded-full cursor-pointer transition-colors ${isChecked ? 'bg-blue-600 justify-end' : 'bg-slate-300 dark:bg-slate-600 justify-start'}`}>
        <motion.div layout transition={{ type: 'spring', stiffness: 700, damping: 30 }} className="w-4 h-4 bg-white rounded-full shadow" />
    </div>
);


// --- RE-USED & RE-STYLED EXISTING COMPONENTS ---

const Widget: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
    <div className="bg-white/60 dark:bg-slate-800/60 backdrop-blur-lg border border-slate-200/50 dark:border-slate-700/50 rounded-2xl shadow-sm h-full flex flex-col p-4">
        <h3 className="text-base font-semibold text-slate-800 dark:text-slate-100 mb-2 px-2">{title}</h3>
        <div className="flex-1">{children}</div>
    </div>
);

const FinancialTrendChart: React.FC<{ data: DashboardData['financialTrend'], isPrivacyMode: boolean }> = ({ data, isPrivacyMode }) => (
    <ResponsiveContainer width="100%" height="100%"><ComposedChart data={data} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}><XAxis dataKey="date" tick={{ fill: '#9CA3AF', fontSize: 10 }} axisLine={false} tickLine={false} /><YAxis tick={{ fill: '#9CA3AF', fontSize: 10 }} tickFormatter={(val) => isPrivacyMode ? '****' : formatMonetary(val)} axisLine={false} tickLine={false} /><Tooltip formatter={(value: number) => isPrivacyMode ? '••••••' : formatMonetary(value)} cursor={{ fill: 'rgba(128, 128, 128, 0.1)' }} /><Legend wrapperStyle={{ fontSize: '12px' }} /><Bar dataKey="revenue" fill="#0ea5e9" name="Revenue" maxBarSize={30} radius={[4, 4, 0, 0]} /><Bar dataKey="expenses" fill="#F87171" name="Expenses" maxBarSize={30} radius={[4, 4, 0, 0]} /><Line type="monotone" dataKey="profit" stroke="#10B981" strokeWidth={3} name="Net Profit" dot={false} /></ComposedChart></ResponsiveContainer>
);

const CashFlowChart: React.FC<{ data: DashboardData['cashFlowTrend'], isPrivacyMode: boolean }> = ({ data, isPrivacyMode }) => (
    <ResponsiveContainer width="100%" height="100%"><BarChart data={data} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}><XAxis dataKey="date" tick={{ fill: '#9CA3AF', fontSize: 10 }} axisLine={false} tickLine={false} /><YAxis tick={{ fill: '#9CA3AF', fontSize: 10 }} tickFormatter={(val) => isPrivacyMode ? '****' : formatMonetary(val)} axisLine={false} tickLine={false} /><Tooltip formatter={(value: number) => isPrivacyMode ? '••••••' : formatMonetary(value)} cursor={{ fill: 'rgba(128, 128, 128, 0.1)' }} /><Legend wrapperStyle={{ fontSize: '12px' }} /><Bar dataKey="cashIn" fill="#22C55E" name="Cash In" stackId="a" maxBarSize={20} /><Bar dataKey="cashOut" fill="#EF4444" name="Cash Out" stackId="a" maxBarSize={20} radius={[4, 4, 0, 0]} /></BarChart></ResponsiveContainer>
);

const ExpenseBreakdownChart: React.FC<{ data: DashboardData['expenseBreakdown']; isDarkMode: boolean; isPrivacyMode: boolean }> = ({ data, isDarkMode, isPrivacyMode }) => {
    const totalExpenses = data.reduce((sum, entry) => sum + entry.value, 0);
    const EXPENSE_CHART_COLORS = isDarkMode ? ['#0EA5E9', '#F97316', '#FBBF24', '#22C55E', '#14B8A6', '#3B82F6'] : ['#38BDF8', '#FB923C', '#FACC15', '#4ADE80', '#2DD4BF', '#60A5FA'];
    const CustomPieLabel = ({ viewBox }: any) => {
        const { cx, cy } = viewBox;
        return (<><text x={cx} y={cy - 8} textAnchor="middle" dominantBaseline="central" className="fill-slate-500 dark:fill-slate-400 text-xs font-semibold uppercase tracking-wider">Total</text><text x={cx} y={cy + 12} textAnchor="middle" dominantBaseline="central" className="fill-slate-800 dark:fill-white text-2xl font-bold">{isPrivacyMode ? '••••••' : formatMonetary(totalExpenses)}</text></>);
    };

    return (<ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={data} dataKey="value" nameKey="name" cx="50%" cy="45%" innerRadius="60%" outerRadius="85%" paddingAngle={5} className="cursor-pointer">{data.map((entry, index) => <Cell key={`cell-${index}`} fill={EXPENSE_CHART_COLORS[index % EXPENSE_CHART_COLORS.length]} stroke="none" />)}</Pie><Tooltip formatter={(value: number) => isPrivacyMode ? '••••••' : formatMonetary(value)} /><Legend wrapperStyle={{ fontSize: '12px' }} layout="horizontal" align="center" verticalAlign="bottom" iconSize={8} /><Label content={<CustomPieLabel />} position="center" /></PieChart></ResponsiveContainer>);
};

const UnpaidInvoicesList: React.FC<{ data: DashboardData['topUnpaidInvoices']; isPrivacyMode: boolean }> = ({ data, isPrivacyMode }) => {
    const navigate = useNavigate();
    return (
        <div className="space-y-2 overflow-y-auto h-full pr-2">
            {data.length === 0 && <p className="text-center text-sm text-slate-400 dark:text-slate-500 pt-8">All invoices are paid up!</p>}
            {data.map(invoice => (
                <div key={invoice.orderId} onClick={() => navigate('/customer-statements', { state: { customerId: invoice.customerId } })} className="flex items-center justify-between p-2.5 rounded-lg hover:bg-black/5 dark:hover:bg-white/5 cursor-pointer text-sm transition-colors">
                    <div className="flex items-center gap-3"><span className={`w-2.5 h-2.5 rounded-full ${invoice.daysOverdue > 30 ? 'bg-red-500' : (invoice.daysOverdue > 7 ? 'bg-amber-500' : 'bg-yellow-500')}`} /><div><p className="font-semibold text-slate-800 dark:text-slate-200">{invoice.customerName}</p><p className="text-xs text-slate-500 dark:text-slate-400">Order: {invoice.orderId}</p></div></div>
                    <div className="text-right"><p className="font-bold text-slate-800 dark:text-slate-200">{isPrivacyMode ? '••••••' : formatMonetary(invoice.amountDue)}</p><p className="text-xs text-red-500 dark:text-red-400 font-semibold">{invoice.daysOverdue > 0 ? `${invoice.daysOverdue} days overdue` : 'Due soon'}</p></div>
                </div>
            ))}
        </div>
    );
};

const RecentTransactionsList: React.FC<{ data: DashboardData['recentTransactions']; isPrivacyMode: boolean }> = ({ data, isPrivacyMode }) => (
    <div className="space-y-1 overflow-y-auto h-full pr-2">
        {data.map(tx => (
            <div key={tx.id} className="flex items-center justify-between p-2.5 text-sm rounded-lg">
                <div className="flex items-center gap-4"><span className={`flex items-center justify-center w-8 h-8 rounded-full ${tx.type === 'Debit' ? 'bg-emerald-100 dark:bg-emerald-900/50 text-emerald-600' : 'bg-red-100 dark:bg-red-900/50 text-red-600'}`}>{tx.type === 'Debit' ? <ArrowDown size={16} /> : <ArrowUp size={16} />}</span><p className="truncate pr-2 text-slate-600 dark:text-slate-300 font-medium">{tx.description}</p></div>
                <p className={`font-mono font-semibold whitespace-nowrap ${tx.type === 'Debit' ? 'text-emerald-500' : 'text-red-500'}`}>{tx.type === 'Debit' ? '+' : '-'}{isPrivacyMode ? '••••••' : formatMonetary(tx.amount)}</p>
            </div>
        ))}
    </div>
);

export default Dashboard;