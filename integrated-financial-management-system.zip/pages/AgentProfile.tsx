import React, { useState, useEffect, useCallback } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useData } from '../context/DataContext';
import { Agent, CustomerOrder } from '../types';
import { GlassCard } from '../components/ui/GlassCard';
import { User, Phone, Percent, Calendar, ShoppingCart, ChevronLeft } from 'lucide-react';

const AgentProfile: React.FC = () => {
    const { agentId } = useParams<{ agentId: string }>();
    const { getAgentById, getOrders, _version } = useData();

    const [agent, setAgent] = useState<Agent | null>(null);
    const [agentOrders, setAgentOrders] = useState<CustomerOrder[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    const fetchData = useCallback(async () => {
        if (!agentId) return;
        setIsLoading(true);
        try {
            const [agt, allOrders] = await Promise.all([
                getAgentById(agentId),
                getOrders()
            ]);
            setAgent(agt);
            setAgentOrders(allOrders.filter(o => o.agentId === agentId).sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
        } catch (error) {
            console.error("Failed to fetch agent details:", error);
        } finally {
            setIsLoading(false);
        }
    }, [agentId, getAgentById, getOrders]);

    useEffect(() => {
        fetchData();
    }, [agentId, _version, fetchData]);

    const formatCurrency = (value: number) => new Intl.NumberFormat('en-US').format(value);

    if (isLoading) {
        return <div className="flex items-center justify-center h-64 text-slate-500">Loading agent profile...</div>;
    }

    if (!agent) {
        return <div className="flex items-center justify-center h-64 text-slate-500">Agent not found.</div>;
    }

    const totalSales = agentOrders.reduce((sum, order) => sum + order.totalPrice, 0);
    const totalCommission = agent.commissionRate ? (totalSales * agent.commissionRate / 100) : 0;

    return (
        <div className="space-y-6">
            {/* Back Button */}
            <div>
                <Link to="/agents" className="inline-flex items-center text-sm text-slate-500 hover:text-sky-600 transition-colors">
                    <ChevronLeft size={16} className="mr-1" /> Back to Agents
                </Link>
            </div>

            {/* Profile Header */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <GlassCard className="md:col-span-2 flex items-center gap-6 p-6">
                    <div className="w-20 h-20 rounded-full bg-gradient-to-br from-indigo-100 to-purple-100 flex items-center justify-center text-indigo-600 shadow-inner">
                        <User size={40} />
                    </div>
                    <div>
                        <h1 className="text-2xl font-bold text-slate-800">{agent.name}</h1>
                        <div className="flex items-center gap-4 mt-2 text-slate-500 text-sm">
                            <span className="flex items-center gap-1"><Phone size={14} /> {agent.phone}</span>
                            <span className="flex items-center gap-1"><Calendar size={14} /> Joined {new Date(agent.createdAt).toLocaleDateString()}</span>
                        </div>
                    </div>
                </GlassCard>

                <GlassCard className="flex flex-col justify-center p-6 bg-gradient-to-br from-sky-50/50 to-indigo-50/50">
                    <p className="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-1">Commission Rate</p>
                    <div className="flex items-baseline gap-1">
                        <Percent size={20} className="text-sky-600" />
                        <span className="text-3xl font-bold text-slate-800">{agent.commissionRate || 0}%</span>
                    </div>
                </GlassCard>
            </div>

            {/* Performance Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <GlassCard className="p-6">
                    <p className="text-sm font-semibold text-slate-500">Total Orders</p>
                    <div className="flex items-center gap-2 mt-2">
                        <ShoppingCart size={24} className="text-emerald-500" />
                        <span className="text-2xl font-bold text-slate-800">{agentOrders.length}</span>
                    </div>
                </GlassCard>
                <GlassCard className="p-6">
                    <p className="text-sm font-semibold text-slate-500">Total Sales Volume</p>
                    <div className="mt-2">
                        <span className="text-2xl font-bold text-slate-800">{formatCurrency(totalSales)} $</span>
                    </div>
                </GlassCard>
                <GlassCard className="p-6">
                    <p className="text-sm font-semibold text-slate-500">Total Commission Earned</p>
                    <div className="mt-2">
                        <span className="text-2xl font-bold text-indigo-600">{formatCurrency(totalCommission)} $</span>
                    </div>
                </GlassCard>
            </div>

            {/* Order History */}
            <GlassCard title="Order History">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                        <thead>
                            <tr className="border-b border-slate-200/60 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">
                                <th className="px-4 py-3">Order ID</th>
                                <th className="px-4 py-3">Date</th>
                                <th className="px-4 py-3">Customer</th>
                                <th className="px-4 py-3 text-right">Amount</th>
                                <th className="px-4 py-3 text-right">Commission</th>
                                <th className="px-4 py-3 text-center">Status</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                            {agentOrders.map(order => (
                                <tr key={order.id} className="hover:bg-slate-50/50 transition-colors">
                                    <td className="px-4 py-3 font-mono text-slate-600">{order.id}</td>
                                    <td className="px-4 py-3 text-slate-600">{new Date(order.createdAt).toLocaleDateString()}</td>
                                    <td className="px-4 py-3 font-medium text-slate-800">{order.customerName}</td>
                                    <td className="px-4 py-3 text-right font-mono text-slate-700">{formatCurrency(order.totalPrice)}</td>
                                    <td className="px-4 py-3 text-right font-mono text-indigo-600">
                                        {formatCurrency((order.totalPrice * (agent.commissionRate || 0)) / 100)}
                                    </td>
                                    <td className="px-4 py-3 text-center">
                                        <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                                            order.status === 'Paid' ? 'bg-emerald-100 text-emerald-700' :
                                            order.status === 'Cancelled' ? 'bg-rose-100 text-rose-700' :
                                            'bg-sky-100 text-sky-700'
                                        }`}>
                                            {order.status}
                                        </span>
                                    </td>
                                </tr>
                            ))}
                            {agentOrders.length === 0 && (
                                <tr>
                                    <td colSpan={6} className="px-4 py-8 text-center text-slate-500">
                                        No orders found for this agent.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </GlassCard>
        </div>
    );
};

export default AgentProfile;