import React, { useState, useMemo, useEffect } from 'react';
import { useData } from '../context/DataContext';
import { Customer } from '../types';
import AddCustomerModal from '../components/modals/AddCustomerModal';
import { Plus, Search, ArrowUp, ArrowDown, Pencil, Trash2 } from 'lucide-react';

type ColumnKeys = 'id' | 'name' | 'phone1' | 'phone2' | 'address' | 'createdAt';

const Customers: React.FC = () => {
    const { getCustomers, deleteCustomer, _version } = useData();
    const [customers, setCustomers] = useState<Customer[]>([]);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
    const [searchQuery, setSearchQuery] = useState('');
    const [sortConfig, setSortConfig] = useState<{ key: ColumnKeys; direction: 'ascending' | 'descending' } | null>({ key: 'createdAt', direction: 'descending' });

    useEffect(() => {
        getCustomers().then(setCustomers);
    }, [_version]);

    const handleOpenModal = (customer: Customer | null) => {
        setEditingCustomer(customer);
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setEditingCustomer(null);
        setIsModalOpen(false);
    };

    const handleDelete = async (customerId: string) => {
        if (window.confirm('Are you sure you want to delete this customer? This action cannot be undone.')) {
            try {
                await deleteCustomer(customerId);
            } catch (error) {
                alert(`Error: ${(error as Error).message}`);
            }
        }
    };

    const filteredAndSortedCustomers = useMemo(() => {
        let processed = [...customers];
        
        if (searchQuery) {
            processed = customers.filter(customer =>
                (customer.name && customer.name.toLowerCase().includes(searchQuery.toLowerCase())) ||
                customer.phone1.includes(searchQuery) ||
                (customer.phone2 && customer.phone2.includes(searchQuery)) ||
                customer.id.toLowerCase().includes(searchQuery.toLowerCase())
            );
        }

        if (sortConfig) {
            processed.sort((a, b) => {
                const aVal = a[sortConfig.key] || '';
                const bVal = b[sortConfig.key] || '';
                if (aVal < bVal) return sortConfig.direction === 'ascending' ? -1 : 1;
                if (aVal > bVal) return sortConfig.direction === 'ascending' ? 1 : -1;
                return 0;
            });
        }
        
        return processed;
    }, [customers, searchQuery, sortConfig]);

    const requestSort = (key: ColumnKeys) => {
        let direction: 'ascending' | 'descending' = 'ascending';
        if (sortConfig && sortConfig.key === key && sortConfig.direction === 'ascending') {
            direction = 'descending';
        }
        setSortConfig({ key, direction });
    };

    const getSortIcon = (key: ColumnKeys) => {
        if (!sortConfig || sortConfig.key !== key) return null;
        return sortConfig.direction === 'ascending' ? <ArrowUp size={14} /> : <ArrowDown size={14} />;
    };
    
    const headers: { key: ColumnKeys; label: string }[] = [
        { key: 'id', label: 'Customer ID' },
        { key: 'name', label: 'Name' },
        { key: 'phone1', label: 'Primary Phone' },
        { key: 'phone2', label: 'Secondary Phone' },
        { key: 'address', label: 'Address' },
        { key: 'createdAt', label: 'Date Added' },
    ];

    return (
        <div className="space-y-6">
            <div className="relative z-20 flex flex-col md:flex-row justify-between items-center gap-4 p-4 bg-white/60 backdrop-blur-md border border-white/50 rounded-2xl shadow-sm">
                 <div className="relative w-full md:max-w-md">
                    <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input 
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Search by ID, name or phone..."
                        className="w-full h-11 bg-white/80 border border-white/60 rounded-xl shadow-inner pl-10 pr-4 text-slate-800 text-sm focus:ring-2 focus:ring-sky-300/60 focus:outline-none transition"
                    />
                </div>
                <div className="flex items-center gap-3 w-full md:w-auto">
                    <button 
                        onClick={() => handleOpenModal(null)}
                        className="flex items-center justify-center gap-2 w-full md:w-auto h-11 px-5 text-sm font-bold bg-gradient-to-r from-sky-500 to-cyan-500 text-white rounded-xl shadow hover:shadow-lg active:scale-[0.98] transition-all"
                    >
                        <Plus size={18} />
                        <span>New Customer</span>
                    </button>
                </div>
            </div>

            <div className="bg-white/65 backdrop-blur-xl border border-white/50 rounded-2xl shadow-[0_10px_40px_rgba(0,0,0,0.06)]">
                <table className="w-full min-w-[900px]">
                    <thead>
                        <tr className="border-b border-white/60">
                            {headers.map(header => (
                                <th key={header.key} className="px-4 py-3 text-left text-xs font-semibold tracking-wider text-slate-500 uppercase">
                                    <button onClick={() => requestSort(header.key)} className="w-full flex items-center gap-2 group">
                                        <span>{header.label}</span>
                                        {getSortIcon(header.key)}
                                    </button>
                                </th>
                            ))}
                             <th className="px-4 py-3 text-left text-xs font-semibold tracking-wider text-slate-500 uppercase">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-white/60">
                        {filteredAndSortedCustomers.map((customer) => (
                            <tr key={customer.id} className="hover:bg-sky-100/30 transition-colors duration-150">
                                <td className="px-4 py-3 text-sm font-mono text-slate-700">{customer.id}</td>
                                <td className="px-4 py-3 font-semibold text-sm text-slate-800">{customer.name || 'N/A'}</td>
                                <td className="px-4 py-3 text-sm text-slate-500">{customer.phone1}</td>
                                <td className="px-4 py-3 text-sm text-slate-500">{customer.phone2 || 'N/A'}</td>
                                <td className="px-4 py-3 text-sm text-slate-500">{customer.address}</td>
                                <td className="px-4 py-3 text-sm text-slate-500">{new Date(customer.createdAt).toLocaleDateString()}</td>
                                <td className="px-4 py-3">
                                    <div className="flex items-center gap-4">
                                        <button onClick={() => handleOpenModal(customer)} className="text-slate-500 hover:text-sky-600 transition-colors" title="Edit Customer">
                                            <Pencil size={16} />
                                        </button>
                                        <button onClick={() => handleDelete(customer.id)} className="text-slate-500 hover:text-red-600 transition-colors" title="Delete Customer">
                                            <Trash2 size={16} />
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                 {filteredAndSortedCustomers.length === 0 && (
                    <div className="text-center py-16 text-slate-500">
                        <p>No customers found matching your criteria.</p>
                    </div>
                )}
            </div>

            <AddCustomerModal 
                isOpen={isModalOpen} 
                onClose={handleCloseModal}
                editingCustomer={editingCustomer}
                onSave={handleCloseModal}
            />
        </div>
    );
};

export default Customers;