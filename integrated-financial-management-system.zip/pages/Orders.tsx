




import React, { useState, useMemo, useEffect, useRef } from 'react';
import { useLocation } from 'react-router-dom';
import { useData } from '../context/DataContext';
import { CustomerOrder, OrderStatus, PaymentStatus, Agent } from '../types';
import AddOrderModal from '../components/modals/AddOrderModal';
import BatchDeliveryModal from '../components/modals/BatchDeliveryModal';
import { CancellationWizardModal } from '../components/modals/CancellationWizardModal';
import { Plus, Search, Settings2, ChevronDown, ExternalLink, Pencil, Trash2, ArrowUp, ArrowDown, Filter, X, GripVertical, Truck, CheckSquare, RotateCcw, ChevronUp, XCircle } from 'lucide-react';
import { Reorder, motion, AnimatePresence } from 'framer-motion';

const getLogisticsStatusColor = (status: OrderStatus) => {
    switch (status) {
        case OrderStatus.Paid: return 'bg-green-500/10 text-green-700 dark:bg-green-500/20 dark:text-green-400';
        case OrderStatus.Delivered: return 'bg-blue-500/10 text-blue-700 dark:bg-blue-500/20 dark:text-blue-400';
        case OrderStatus.OutForDelivery: return 'bg-cyan-500/10 text-cyan-700 dark:bg-cyan-500/20 dark:text-cyan-400';
        case OrderStatus.InTransit: return 'bg-purple-500/10 text-purple-700 dark:bg-purple-500/20 dark:text-purple-400';
        case OrderStatus.Cancelled: return 'bg-red-500/10 text-red-700 dark:bg-red-500/20 dark:text-red-400';
        case OrderStatus.Bundled: return 'bg-indigo-500/10 text-indigo-700 dark:bg-indigo-500/20 dark:text-indigo-400';
        case OrderStatus.Stocked: return 'bg-slate-500/10 text-slate-700 dark:bg-slate-500/20 dark:text-slate-400';
        case OrderStatus.Returned: return 'bg-orange-500/10 text-orange-700 dark:bg-orange-500/20 dark:text-orange-400';
        default: return 'bg-slate-500/10 text-slate-700 dark:bg-slate-500/20 dark:text-slate-400';
    }
};

const getPaymentStatus = (order: CustomerOrder): PaymentStatus => {
    if (order.paidAmount <= 0) return PaymentStatus.NotPaid;
    if (order.paidAmount >= order.totalPrice) return PaymentStatus.FullyPaid;
    return PaymentStatus.PartiallyPaid;
}

const getPaymentStatusColor = (status: PaymentStatus) => {
    switch (status) {
        case PaymentStatus.FullyPaid: return 'bg-green-500/10 text-green-700 dark:bg-green-500/20 dark:text-green-400';
        case PaymentStatus.PartiallyPaid: return 'bg-yellow-500/10 text-yellow-700 dark:bg-yellow-500/20 dark:text-yellow-400';
        case PaymentStatus.NotPaid: return 'bg-red-500/10 text-red-700 dark:bg-red-500/20 dark:text-red-400';
        default: return 'bg-slate-500/10 text-slate-700 dark:bg-slate-500/20 dark:text-slate-400';
    }
};

const COLUMN_CONFIG = {
    orderId: { header: 'Order ID', sortable: true },
    customer: { header: 'Customer', sortable: true },
    agent: { header: 'Agent / Referral', sortable: true },
    itemCount: { header: 'Qty', sortable: true },
    totalPrice: { header: 'Total Price', sortable: true },
    paidAmount: { header: 'Paid', sortable: true },
    due: { header: 'Due', sortable: true },
    paymentStatus: { header: 'Payment Status', sortable: true, filterable: true, options: Object.values(PaymentStatus) },
    logisticsStatus: { header: 'Logistics Status', sortable: true, filterable: true, options: Object.values(OrderStatus) },
    receiptNumber: { header: 'Receipt #', sortable: true },
    orderDate: { header: 'Order Date', sortable: true },
    date: { header: 'Created At', sortable: true },
    estDueDate: { header: 'Est. Due Date', sortable: false },
    productLink: { header: 'Product Link', sortable: false },
    orderNotes: { header: 'Notes', sortable: false },
    logisticsId: { header: 'Logistics ID', sortable: false },
    deliveredBy: { header: 'Delivered By', sortable: false },
};

type ColumnKeys = keyof typeof COLUMN_CONFIG;

const useClickOutside = (ref: React.RefObject<HTMLDivElement>, handler: () => void) => {
    useEffect(() => {
        const listener = (event: MouseEvent | TouchEvent) => {
            if (!ref.current || ref.current.contains(event.target as Node)) return;
            handler();
        };
        document.addEventListener('mousedown', listener);
        document.addEventListener('touchstart', listener);
        return () => {
            document.removeEventListener('mousedown', listener);
            document.removeEventListener('touchstart', listener);
        };
    }, [ref, handler]);
};

const initialColumnOrder: ColumnKeys[] = [
    'orderId', 'customer', 'itemCount', 'agent', 'totalPrice', 'paidAmount', 'due', 'paymentStatus', 'logisticsStatus', 'receiptNumber', 'orderDate',
    'date', 'estDueDate', 'productLink', 'orderNotes', 'logisticsId', 'deliveredBy'
];

const Orders: React.FC = () => {
    const { getOrders, updateOrderStatus, deleteOrder, getAgents, processBatchDelivery, revertDelivery, _version } = useData();
    const location = useLocation();
    const [orders, setOrders] = useState<CustomerOrder[]>([]);
    const [agents, setAgents] = useState<Agent[]>([]);
    
    // Modals
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isBatchModalOpen, setIsBatchModalOpen] = useState(false);
    const [isCancellationModalOpen, setIsCancellationModalOpen] = useState(false);
    
    const [editingOrder, setEditingOrder] = useState<CustomerOrder | null>(null);
    const [selectedOrderForCancel, setSelectedOrderForCancel] = useState<CustomerOrder | null>(null);

    const [searchQuery, setSearchQuery] = useState('');
    const [isToggleDropdownOpen, setIsToggleDropdownOpen] = useState(false);
    const dropdownRef = useRef<HTMLDivElement>(null);

    // Tab State
    const [activeTab, setActiveTab] = useState<'pending' | 'history'>('pending');

    // Selection State
    const [selectedOrderIds, setSelectedOrderIds] = useState<Set<string>>(new Set());

    // --- Sort & Filter State ---
    const [sortConfig, setSortConfig] = useState<{ key: ColumnKeys; direction: 'ascending' | 'descending' } | null>({ key: 'orderDate', direction: 'descending' });
    const [filters, setFilters] = useState<{ logisticsStatus: Set<OrderStatus>, paymentStatus: Set<PaymentStatus>, agentId: string | null }>({
        logisticsStatus: new Set(),
        paymentStatus: new Set(),
        agentId: null,
    });
    
    useClickOutside(dropdownRef, () => setIsToggleDropdownOpen(false));
    
    const [visibleColumns, setVisibleColumns] = useState<Record<ColumnKeys, boolean>>({
        orderId: true,
        customer: true,
        agent: true,
        itemCount: true,
        totalPrice: true,
        paidAmount: true,
        due: true,
        paymentStatus: true,
        logisticsStatus: true,
        receiptNumber: true,
        orderDate: true,
        date: false,
        estDueDate: false,
        productLink: false,
        orderNotes: false,
        logisticsId: true,
        deliveredBy: false,
    });
    
    const [columnOrder, setColumnOrder] = useState<ColumnKeys[]>(initialColumnOrder);
    
    useEffect(() => {
        if (location.state?.search) setSearchQuery(location.state.search);
    }, [location.state]);

    useEffect(() => {
        Promise.all([getOrders(), getAgents()]).then(([fetchedOrders, fetchedAgents]) => {
            setOrders(fetchedOrders);
            setAgents(fetchedAgents);
        });
    }, [_version]);
    
    const processedOrders = useMemo(() => {
        let processed = [...orders];

        // Tab Filtering
        if (activeTab === 'pending') {
            // Exclude completed/final states from pending tab
            const finalStates = [OrderStatus.Delivered, OrderStatus.Paid, OrderStatus.Cancelled, OrderStatus.Stocked, OrderStatus.Returned];
            processed = processed.filter(order => !finalStates.includes(order.status));
        } else {
            // History shows final states
            const finalStates = [OrderStatus.Delivered, OrderStatus.Paid, OrderStatus.Cancelled, OrderStatus.Stocked, OrderStatus.Returned];
            processed = processed.filter(order => finalStates.includes(order.status));
        }

        // Search Filter
        if (searchQuery) {
            const lowerCaseQuery = searchQuery.toLowerCase();
            processed = processed.filter(order =>
                order.id.toLowerCase().includes(lowerCaseQuery) ||
                order.customerId.toLowerCase().includes(lowerCaseQuery) ||
                order.customerName.toLowerCase().includes(lowerCaseQuery) ||
                order.customerPhone.includes(searchQuery) ||
                (order.customerPhone2 && order.customerPhone2.includes(searchQuery)) ||
                (order.agentName && order.agentName.toLowerCase().includes(lowerCaseQuery)) ||
                (order.courierVendorName && order.courierVendorName.toLowerCase().includes(lowerCaseQuery))
            );
        }
        
        // Status Filters
        if (filters.logisticsStatus.size > 0) {
            processed = processed.filter(order => filters.logisticsStatus.has(order.status));
        }
        if (filters.paymentStatus.size > 0) {
            processed = processed.filter(order => filters.paymentStatus.has(getPaymentStatus(order)));
        }
        if (filters.agentId) {
            processed = processed.filter(order => order.agentId === filters.agentId);
        }

        // Sorting
        if (sortConfig) {
            processed.sort((a, b) => {
                let aVal: any;
                let bVal: any;
                const key = sortConfig.key;

                if (key === 'customer') { aVal = a.customerName; bVal = b.customerName; }
                else if (key === 'agent') { aVal = a.agentName || ''; bVal = b.agentName || ''; }
                else if (key === 'due') { aVal = a.totalPrice - a.paidAmount; bVal = b.totalPrice - b.paidAmount; }
                else if (key === 'paymentStatus') { aVal = getPaymentStatus(a); bVal = getPaymentStatus(b); }
                else if (key === 'logisticsStatus') { aVal = a.status; bVal = a.status; }
                else if (key === 'receiptNumber') { aVal = a.receiptNumber || ''; bVal = b.receiptNumber || ''; }
                else if (key === 'orderDate') { aVal = new Date(a.orderDate).getTime(); bVal = new Date(b.orderDate).getTime(); }
                else if (key === 'date') { aVal = new Date(a.createdAt).getTime(); bVal = new Date(b.createdAt).getTime(); }
                else if (key === 'deliveredBy') { aVal = a.courierVendorName || ''; bVal = b.courierVendorName || ''; }
                else { aVal = a[key as keyof CustomerOrder]; bVal = b[key as keyof CustomerOrder]; }

                if (aVal < bVal) return sortConfig.direction === 'ascending' ? -1 : 1;
                if (aVal > bVal) return sortConfig.direction === 'ascending' ? 1 : -1;
                return 0;
            });
        }
        return processed;
    }, [orders, searchQuery, filters, sortConfig, activeTab]);
    
    const handleSaveOrder = (savedOrder: CustomerOrder) => {
        // Optimistic update handled by DataContext triggering re-fetch
    };
    
    const handleColumnToggle = (key: ColumnKeys) => {
        setVisibleColumns(prev => ({ ...prev, [key]: !prev[key] }));
    };

    // Move Column Logic
    const moveColumn = (key: ColumnKeys, direction: 'up' | 'down', e: React.MouseEvent) => {
        e.stopPropagation(); // Prevent dropdown from closing
        const index = columnOrder.indexOf(key);
        if (index === -1) return;
        const newOrder = [...columnOrder];
        
        if (direction === 'up' && index > 0) {
            [newOrder[index - 1], newOrder[index]] = [newOrder[index], newOrder[index - 1]];
        } else if (direction === 'down' && index < newOrder.length - 1) {
            [newOrder[index + 1], newOrder[index]] = [newOrder[index], newOrder[index + 1]];
        }
        setColumnOrder(newOrder);
    };
    
    const requestSort = (key: ColumnKeys) => {
        let direction: 'ascending' | 'descending' = 'ascending';
        if (sortConfig && sortConfig.key === key && sortConfig.direction === 'ascending') {
            direction = 'descending';
        }
        setSortConfig({ key, direction });
    };

    const getSortIcon = (key: ColumnKeys) => {
        if (!sortConfig || sortConfig.key !== key) return null;
        return sortConfig.direction === 'ascending' ? <ArrowUp size={14} /> : <ArrowDown size={14} />;
    };
    
    const formatCurrency = (value: number) => new Intl.NumberFormat('en-US').format(value);

    const handleEdit = (order: CustomerOrder) => {
        setEditingOrder(order);
        setIsModalOpen(true);
    };

    const handleDelete = async (orderId: string) => {
        if (window.confirm('Are you sure you want to delete this order? All associated financial records will also be removed.')) {
            try {
                await deleteOrder(orderId);
            } catch (error) {
                console.error("Failed to delete order:", error);
                alert(`Error: ${(error as Error).message}`);
            }
        }
    };

    const handleRevert = async (orderId: string) => {
        if (window.confirm('Are you sure you want to revert this delivery? This will reverse the financial transaction (Debit Customer, Credit Courier) and reset the order to Pending.')) {
            try {
                await revertDelivery(orderId);
                alert('Order reverted successfully! Check Vendor Ledger for credit adjustment.');
            } catch (error) {
                alert(`Error: ${(error as Error).message}`);
            }
        }
    };

    const handleOpenCancellation = (order: CustomerOrder) => {
        setSelectedOrderForCancel(order);
        setIsCancellationModalOpen(true);
    }

    // Selection Logic
    const handleSelectOrder = (orderId: string) => {
        setSelectedOrderIds(prev => {
            const newSet = new Set(prev);
            if (newSet.has(orderId)) newSet.delete(orderId);
            else newSet.add(orderId);
            return newSet;
        });
    };

    const handleSelectAll = () => {
        if (selectedOrderIds.size === processedOrders.length) {
            setSelectedOrderIds(new Set());
        } else {
            setSelectedOrderIds(new Set(processedOrders.map(o => o.id)));
        }
    };

    const handleBatchDelivery = async (courierVendorId: string) => {
        try {
            await processBatchDelivery(Array.from(selectedOrderIds), courierVendorId);
            setIsBatchModalOpen(false);
            setSelectedOrderIds(new Set());
            alert('Batch delivery processed. Financials posted to Vendor Ledger (Account 1502).');
        } catch (error) {
            alert(`Error: ${(error as Error).message}`);
        }
    };
    
    return (
        <div className="space-y-6 relative">
            <div className="relative z-20 flex flex-col md:flex-row justify-between items-center gap-4 p-4 bg-white/60 backdrop-blur-md border border-white/50 rounded-2xl shadow-sm">
                 <div className="relative w-full md:max-w-md">
                    <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input 
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Search by ID, name, phone or agent..."
                        className="w-full h-11 bg-white/80 border border-white/60 rounded-xl shadow-inner pl-10 pr-4 text-slate-800 text-sm focus:ring-2 focus:ring-sky-300/60 focus:outline-none transition"
                    />
                </div>
                
                <div className="flex items-center gap-3 w-full md:w-auto">
                    <div className="relative">
                        <select
                            value={filters.agentId || ''}
                            onChange={(e) => setFilters(prev => ({ ...prev, agentId: e.target.value || null }))}
                            className="h-11 pl-3 pr-8 bg-white/70 border border-white/60 rounded-xl text-sm font-medium text-slate-600 focus:ring-2 focus:ring-sky-300/60 focus:outline-none shadow-sm cursor-pointer appearance-none"
                        >
                            <option value="">All Agents</option>
                            {agents.map(agent => (
                                <option key={agent.id} value={agent.id}>{agent.name}</option>
                            ))}
                        </select>
                        <ChevronDown size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                    </div>

                    <button 
                        onClick={() => setIsModalOpen(true)}
                        className="flex items-center justify-center gap-2 w-full md:w-auto h-11 px-5 text-sm font-bold bg-gradient-to-r from-sky-500 to-cyan-500 text-white rounded-xl shadow hover:shadow-lg active:scale-[0.98] transition-all"
                    >
                        <Plus size={18} />
                        <span>New Order</span>
                    </button>
                    <div className="relative" ref={dropdownRef}>
                         <button onClick={() => setIsToggleDropdownOpen(prev => !prev)} className="flex items-center justify-center h-11 w-11 bg-white/70 border border-white/60 rounded-xl shadow-sm hover:bg-white/90 transition-colors">
                            <Settings2 size={18} className="text-slate-600" />
                        </button>
                        {isToggleDropdownOpen && (
                            <div className="absolute top-full right-0 mt-2 w-64 bg-white/90 backdrop-blur-md border border-white/50 rounded-xl shadow-lg p-2 z-50 max-h-80 overflow-y-auto">
                                <p className="text-xs font-semibold text-slate-500 px-2 pt-1 pb-2">Toggle & Reorder Columns</p>
                                {columnOrder.map((key, index) => (
                                     <div key={key} className="flex items-center justify-between px-2 py-1.5 hover:bg-sky-100/50 rounded-md group">
                                         <label className="flex items-center space-x-2 cursor-pointer flex-1 select-none">
                                            <input type="checkbox" checked={visibleColumns[key as ColumnKeys]} onChange={() => handleColumnToggle(key as ColumnKeys)} className="h-4 w-4 rounded border-slate-300 text-sky-500 focus:ring-sky-500" />
                                            <span className="text-sm text-slate-700">{COLUMN_CONFIG[key as ColumnKeys].header}</span>
                                        </label>
                                        <div className="flex items-center opacity-0 group-hover:opacity-100 transition-opacity">
                                            <button onClick={(e) => moveColumn(key, 'up', e)} disabled={index === 0} className="p-1 text-slate-400 hover:text-sky-600 disabled:opacity-30 hover:bg-slate-200 rounded"><ChevronUp size={14}/></button>
                                            <button onClick={(e) => moveColumn(key, 'down', e)} disabled={index === columnOrder.length - 1} className="p-1 text-slate-400 hover:text-sky-600 disabled:opacity-30 hover:bg-slate-200 rounded"><ChevronDown size={14}/></button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                </div>
            </div>
            
            {/* Tabs */}
            <div className="flex gap-6 border-b border-slate-200 dark:border-slate-700 pb-px">
                <button 
                    onClick={() => setActiveTab('pending')}
                    className={`pb-2 text-sm font-medium transition-colors relative ${activeTab === 'pending' ? 'text-sky-600 dark:text-sky-400' : 'text-slate-500 hover:text-slate-700'}`}
                >
                    Pending Workspace
                    {activeTab === 'pending' && <motion.div layoutId="tab-underline" className="absolute left-0 right-0 bottom-0 h-0.5 bg-sky-500" />}
                </button>
                <button 
                    onClick={() => setActiveTab('history')}
                    className={`pb-2 text-sm font-medium transition-colors relative ${activeTab === 'history' ? 'text-sky-600 dark:text-sky-400' : 'text-slate-500 hover:text-slate-700'}`}
                >
                    History / Archive
                    {activeTab === 'history' && <motion.div layoutId="tab-underline" className="absolute left-0 right-0 bottom-0 h-0.5 bg-sky-500" />}
                </button>
            </div>

             <div className="bg-white/65 backdrop-blur-xl border border-white/50 rounded-2xl shadow-[0_10px_40px_rgba(0,0,0,0.06)] overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="w-full min-w-[1200px]">
                        <thead>
                            <tr className="border-b border-white/60">
                                {activeTab === 'pending' && (
                                    <th className="px-4 py-3 w-12 text-center">
                                        <input type="checkbox" 
                                            checked={selectedOrderIds.size === processedOrders.length && processedOrders.length > 0}
                                            onChange={handleSelectAll}
                                            className="h-4 w-4 rounded border-slate-300 text-sky-500 focus:ring-sky-500 cursor-pointer"
                                        />
                                    </th>
                                )}
                                {columnOrder.map(key => {
                                    // Hide 'Delivered By' if not in History tab
                                    if (key === 'deliveredBy' && activeTab !== 'history') return null;
                                    if (!visibleColumns[key]) return null;
                                    
                                    return (
                                     <th key={key} className="px-4 py-3 text-left text-xs font-semibold tracking-wider text-slate-500 uppercase">
                                        <div onClick={() => COLUMN_CONFIG[key].sortable && requestSort(key)} className="flex items-center gap-1 cursor-pointer">
                                            <span>{COLUMN_CONFIG[key].header}</span>
                                            {COLUMN_CONFIG[key].sortable && getSortIcon(key)}
                                        </div>
                                    </th>
                                )})}
                                <th className="px-4 py-3 text-right text-xs font-semibold tracking-wider text-slate-500 uppercase">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                             {processedOrders.map((order) => {
                                const pStatus = getPaymentStatus(order);
                                const lStatus = order.status;
                                const due = order.totalPrice - order.paidAmount;
                                const isSelected = selectedOrderIds.has(order.id);

                                return (
                                    <tr key={order.id} className={`hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors ${isSelected ? 'bg-sky-50/40' : ''}`}>
                                        {activeTab === 'pending' && (
                                            <td className="px-4 py-3 text-center">
                                                <input type="checkbox" 
                                                    checked={isSelected}
                                                    onChange={() => handleSelectOrder(order.id)}
                                                    className="h-4 w-4 rounded border-slate-300 text-sky-500 focus:ring-sky-500 cursor-pointer"
                                                />
                                            </td>
                                        )}
                                        {columnOrder.map((colKey, index) => {
                                            if (colKey === 'deliveredBy' && activeTab !== 'history') return null;
                                            if (!visibleColumns[colKey]) return null;

                                            let content: React.ReactNode;
                                            switch (colKey) {
                                                case 'orderId': content = <span className="font-mono text-slate-700 dark:text-slate-300">{order.id}</span>; break;
                                                case 'customer': content = <div><p className="font-semibold text-slate-800 dark:text-slate-200">{order.customerName}</p><p className="text-xs text-slate-500">{order.customerPhone}</p></div>; break;
                                                case 'agent': content = order.agentName ? <span className="px-2 py-0.5 bg-indigo-50 text-indigo-700 rounded-md text-xs font-semibold">{order.agentName}</span> : <span className="text-slate-400 text-xs">-</span>; break;
                                                case 'itemCount': content = <span className="font-bold text-slate-700 bg-slate-100 px-2 py-1 rounded text-xs">{order.itemCount || 1}</span>; break;
                                                case 'totalPrice': content = <span className="font-mono text-slate-600 dark:text-slate-400">{formatCurrency(order.totalPrice)}</span>; break;
                                                case 'paidAmount': content = <span className="font-mono text-green-600 dark:text-green-400">{formatCurrency(order.paidAmount)}</span>; break;
                                                case 'due': content = <span className="font-mono text-red-600 dark:text-red-400">{formatCurrency(due)}</span>; break;
                                                case 'paymentStatus': content = <span className={`px-2 py-1 text-xs font-semibold leading-tight rounded-full ${getPaymentStatusColor(pStatus)}`}>{pStatus}</span>; break;
                                                case 'logisticsStatus': content = <span className={`px-2 py-1 text-xs font-semibold leading-tight rounded-full ${getLogisticsStatusColor(lStatus)}`}>{lStatus}</span>; break;
                                                case 'receiptNumber': content = <span className="font-mono text-slate-500 dark:text-slate-400">{order.receiptNumber || 'N/A'}</span>; break;
                                                case 'orderDate': content = new Date(order.orderDate).toLocaleDateString(); break;
                                                case 'date': content = new Date(order.createdAt).toLocaleDateString(); break;
                                                case 'estDueDate': content = order.estimatedDueDate ? new Date(order.estimatedDueDate).toLocaleDateString() : 'N/A'; break;
                                                case 'productLink': content = order.productLink ? <a href={order.productLink} target="_blank" rel="noopener noreferrer" className="text-sky-500 hover:text-sky-700"><ExternalLink size={16} /></a> : 'N/A'; break;
                                                case 'orderNotes': content = <span className="max-w-xs truncate" title={order.orderDescription}>{order.orderDescription || 'N/A'}</span>; break;
                                                case 'logisticsId': content = <span className="font-mono">{order.logisticsId || 'N/A'}</span>; break;
                                                case 'deliveredBy': content = order.courierVendorName ? <span className="font-semibold text-slate-700">{order.courierVendorName}</span> : <span className="text-slate-400">-</span>; break;
                                                default: content = null;
                                            }
                                            return <td key={colKey} className="px-4 py-3 text-sm text-slate-500 dark:text-slate-400">{content}</td>;
                                        })}
                                        <td className="px-4 py-3 text-right">
                                            <div className="flex items-center justify-end gap-3 text-slate-500 dark:text-slate-400">
                                                {activeTab === 'pending' && (
                                                    <button onClick={() => handleOpenCancellation(order)} className="text-rose-500 hover:text-rose-700" title="Cancel / Return">
                                                        <XCircle size={16} />
                                                    </button>
                                                )}
                                                {activeTab === 'history' && order.status === OrderStatus.Delivered && (
                                                    <button onClick={() => handleRevert(order.id)} className="text-orange-500 hover:text-orange-700" title="Revert Delivery (Undo)">
                                                        <RotateCcw size={16} />
                                                    </button>
                                                )}
                                                <button onClick={() => handleEdit(order)} className="hover:text-sky-600 dark:hover:text-sky-400" title="Edit Order"><Pencil size={16} /></button>
                                                <button onClick={() => handleDelete(order.id)} className="hover:text-red-600 dark:hover:text-red-400" title="Delete Order"><Trash2 size={16} /></button>
                                            </div>
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                    {processedOrders.length === 0 && (
                        <div className="text-center py-12 text-slate-500">
                            No orders found in this view.
                        </div>
                    )}
                </div>
             </div>

            {/* Bulk Action Bar */}
            <AnimatePresence>
                {selectedOrderIds.size > 0 && activeTab === 'pending' && (
                    <motion.div 
                        initial={{ y: 50, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        exit={{ y: 50, opacity: 0 }}
                        className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 bg-white/80 backdrop-blur-xl border border-white/50 rounded-2xl shadow-xl p-2 px-4 flex items-center gap-4"
                    >
                        <span className="text-sm font-bold text-slate-700 bg-slate-100 px-2 py-1 rounded-md">{selectedOrderIds.size} Selected</span>
                        <div className="h-6 w-px bg-slate-200"></div>
                        <button 
                            onClick={() => setIsBatchModalOpen(true)}
                            className="flex items-center gap-2 text-sm font-semibold text-sky-700 hover:bg-sky-50 px-3 py-2 rounded-lg transition-colors"
                        >
                            <Truck size={16} />
                            <span>Mark Delivered & Collected</span>
                        </button>
                        <button onClick={() => setSelectedOrderIds(new Set())} className="text-slate-400 hover:text-slate-600 p-1 rounded-full">
                            <X size={18} />
                        </button>
                    </motion.div>
                )}
            </AnimatePresence>

            <AddOrderModal isOpen={isModalOpen} onClose={() => { setIsModalOpen(false); setEditingOrder(null); }} editingOrder={editingOrder} onSave={handleSaveOrder} />
            <BatchDeliveryModal 
                isOpen={isBatchModalOpen} 
                onClose={() => setIsBatchModalOpen(false)} 
                onConfirm={handleBatchDelivery}
                selectedCount={selectedOrderIds.size}
            />
            {selectedOrderForCancel && (
                <CancellationWizardModal
                    isOpen={isCancellationModalOpen}
                    onClose={() => setIsCancellationModalOpen(false)}
                    order={selectedOrderForCancel}
                />
            )}
        </div>
    );
};

export default Orders;
