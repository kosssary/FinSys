

import React from 'react';

const ReportCard: React.FC<{ title: string; description: string }> = ({ title, description }) => (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow duration-300">
        <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-2">{title}</h3>
        <p className="text-gray-600 dark:text-gray-400 text-sm mb-4">{description}</p>
        <button className="px-3 py-1 text-sm font-medium tracking-wide text-white capitalize transition-colors duration-200 transform bg-blue-600 rounded-md hover:bg-blue-500 focus:outline-none focus:ring focus:ring-blue-300 focus:ring-opacity-80">
            Generate Report
        </button>
    </div>
);


const Reports: React.FC = () => {
    const availableReports = [
        { title: 'Profitability Report', description: 'Displays net profit per order, customer, or date range.' },
        { title: 'Sales Report', description: 'Tracks overall and per-customer sales volume.' },
        { title: 'Expense Report', description: 'Categorizes operational expenses by type and period.' },
        { title: 'Account Statements', description: 'View all transactions for any financial account.' },
        { title: 'A/R Aging Report', description: 'Lists overdue receivables and payment delays.' },
        { title: 'Monthly Profit Distribution (توزیع الأرباح)', description: 'Calculates and displays profit allocation for each shareholder.' },
    ];
    
    return (
        <div>
            <p className="text-gray-600 dark:text-gray-400 mb-8">
                Generate financial and accounting reports for analysis, compliance, and review.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {availableReports.map(report => (
                    <ReportCard key={report.title} title={report.title} description={report.description} />
                ))}
            </div>
        </div>
    );
};

export default Reports;