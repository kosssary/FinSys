
import React, { useState, useMemo, useEffect } from 'react';
import { useData } from '../context/DataContext';
import { Vendor } from '../types';
import AddVendorModal from '../components/modals/AddVendorModal';
import { Plus, Search, ArrowUp, ArrowDown, Pencil, Trash2 } from 'lucide-react';

type ColumnKeys = 'id' | 'name' | 'contactPerson' | 'phone' | 'address';

const Vendors: React.FC = () => {
    const { getVendors, deleteVendor, _version } = useData();
    const [vendors, setVendors] = useState<Vendor[]>([]);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingVendor, setEditingVendor] = useState<Vendor | null>(null);
    const [searchQuery, setSearchQuery] = useState('');
    const [sortConfig, setSortConfig] = useState<{ key: ColumnKeys; direction: 'ascending' | 'descending' } | null>({ key: 'name', direction: 'ascending' });

    useEffect(() => {
        getVendors().then(setVendors);
    }, [_version]);

    const handleOpenModal = (vendor: Vendor | null) => {
        setEditingVendor(vendor);
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setEditingVendor(null);
        setIsModalOpen(false);
    };

    const handleDelete = async (vendorId: string) => {
        if (window.confirm('Are you sure you want to delete this vendor? This action cannot be undone.')) {
            try {
                await deleteVendor(vendorId);
            } catch (error) {
                alert(`Error: ${(error as Error).message}`);
            }
        }
    };

    const filteredAndSortedVendors = useMemo(() => {
        let processed = [...vendors];
        
        if (searchQuery) {
            processed = vendors.filter(vendor =>
                (vendor.name && vendor.name.toLowerCase().includes(searchQuery.toLowerCase())) ||
                (vendor.phone && vendor.phone.includes(searchQuery)) ||
                (vendor.contactPerson && vendor.contactPerson.toLowerCase().includes(searchQuery.toLowerCase())) ||
                vendor.id.toLowerCase().includes(searchQuery.toLowerCase())
            );
        }

        if (sortConfig) {
            processed.sort((a, b) => {
                const aVal = a[sortConfig.key] || '';
                const bVal = b[sortConfig.key] || '';
                if (aVal < bVal) return sortConfig.direction === 'ascending' ? -1 : 1;
                if (aVal > bVal) return sortConfig.direction === 'ascending' ? 1 : -1;
                return 0;
            });
        }
        
        return processed;
    }, [vendors, searchQuery, sortConfig]);

    const requestSort = (key: ColumnKeys) => {
        let direction: 'ascending' | 'descending' = 'ascending';
        if (sortConfig && sortConfig.key === key && sortConfig.direction === 'ascending') {
            direction = 'descending';
        }
        setSortConfig({ key, direction });
    };

    const getSortIcon = (key: ColumnKeys) => {
        if (!sortConfig || sortConfig.key !== key) return null;
        return sortConfig.direction === 'ascending' ? <ArrowUp size={14} /> : <ArrowDown size={14} />;
    };
    
    const headers: { key: ColumnKeys; label: string }[] = [
        { key: 'id', label: 'Vendor ID' },
        { key: 'name', label: 'Name' },
        { key: 'contactPerson', label: 'Contact Person' },
        { key: 'phone', label: 'Phone' },
        { key: 'address', label: 'Address' },
    ];

    return (
        <div className="space-y-6">
            <div className="relative z-20 flex flex-col md:flex-row justify-between items-center gap-4 p-4 bg-white/60 backdrop-blur-md border border-white/50 rounded-2xl shadow-sm">
                 <div className="relative w-full md:max-w-md">
                    <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input 
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Search by ID, name or phone..."
                        className="w-full h-11 bg-white/80 border border-white/60 rounded-xl shadow-inner pl-10 pr-4 text-slate-800 text-sm focus:ring-2 focus:ring-sky-300/60 focus:outline-none transition"
                    />
                </div>
                <div className="flex items-center gap-3 w-full md:w-auto">
                    <button 
                        onClick={() => handleOpenModal(null)}
                        className="flex items-center justify-center gap-2 w-full md:w-auto h-11 px-5 text-sm font-bold bg-gradient-to-r from-sky-500 to-cyan-500 text-white rounded-xl shadow hover:shadow-lg active:scale-[0.98] transition-all"
                    >
                        <Plus size={18} />
                        <span>New Vendor</span>
                    </button>
                </div>
            </div>

            <div className="bg-white/65 backdrop-blur-xl border border-white/50 rounded-2xl shadow-[0_10px_40px_rgba(0,0,0,0.06)]">
                <table className="w-full min-w-[900px]">
                    <thead>
                        <tr className="border-b border-white/60">
                            {headers.map(header => (
                                <th key={header.key} className="px-4 py-3 text-left text-xs font-semibold tracking-wider text-slate-500 uppercase">
                                    <button onClick={() => requestSort(header.key)} className="w-full flex items-center gap-2 group">
                                        <span>{header.label}</span>
                                        {getSortIcon(header.key)}
                                    </button>
                                </th>
                            ))}
                             <th className="px-4 py-3 text-left text-xs font-semibold tracking-wider text-slate-500 uppercase">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-white/60">
                        {filteredAndSortedVendors.map((vendor) => (
                            <tr key={vendor.id} className="hover:bg-sky-100/30 transition-colors duration-150">
                                <td className="px-4 py-3 text-sm font-mono text-slate-700">{vendor.id}</td>
                                <td className="px-4 py-3 font-semibold text-sm text-slate-800">{vendor.name || 'N/A'}</td>
                                <td className="px-4 py-3 text-sm text-slate-500">{vendor.contactPerson || 'N/A'}</td>
                                <td className="px-4 py-3 text-sm text-slate-500">{vendor.phone || 'N/A'}</td>
                                <td className="px-4 py-3 text-sm text-slate-500">{vendor.address || 'N/A'}</td>
                                <td className="px-4 py-3">
                                    <div className="flex items-center gap-4">
                                        <button onClick={() => handleOpenModal(vendor)} className="text-slate-500 hover:text-sky-600 transition-colors" title="Edit Vendor">
                                            <Pencil size={16} />
                                        </button>
                                        <button onClick={() => handleDelete(vendor.id)} className="text-slate-500 hover:text-red-600 transition-colors" title="Delete Vendor">
                                            <Trash2 size={16} />
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                 {filteredAndSortedVendors.length === 0 && (
                    <div className="text-center py-16 text-slate-500">
                        <p>No vendors found matching your criteria.</p>
                    </div>
                )}
            </div>

            <AddVendorModal 
                isOpen={isModalOpen} 
                onClose={handleCloseModal}
                editingVendor={editingVendor}
            />
        </div>
    );
};

export default Vendors;
