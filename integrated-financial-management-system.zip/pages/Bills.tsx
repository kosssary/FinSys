import React, { useState, useMemo, useEffect, Fragment } from 'react';
import { useData } from '../context/DataContext';
import { Bill, BillStatus, BillPayment } from '../types';
import BillFormModal from '../components/modals/BillFormModal';
import RecordBillPaymentModal from '../components/modals/RecordBillPaymentModal';
import { Plus, Search, DollarSign, Edit, Trash2, Calendar, AlertTriangle, Clock, ChevronDown, CheckCircle, XCircle, Expand } from 'lucide-react';
import { GlassModal } from '../components/ui/GlassModal';

const getStatusAppearance = (status: BillStatus) => {
    switch (status) {
        case BillStatus.Paid: return 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300';
        case BillStatus.PartiallyPaid: return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-300';
        case BillStatus.AwaitingPayment: return 'bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-300';
        case BillStatus.Draft: return 'bg-slate-200 text-slate-600 dark:bg-slate-700 dark:text-slate-300';
        default: return 'bg-slate-200 text-slate-600';
    }
};

const formatCurrency = (value: number) => new Intl.NumberFormat('en-US').format(value);

const KpiCard: React.FC<{ title: string, value: number, icon: React.ReactNode, description: string, color: string }> = ({ title, value, icon, description, color }) => (
    <div className="glowing-card p-5 flex flex-col justify-between">
        <div className="flex justify-between items-center">
            <h3 className="font-semibold text-slate-700 dark:text-slate-300">{title}</h3>
            <div className={`text-slate-500 dark:text-slate-400 opacity-80`} style={{color}}>{icon}</div>
        </div>
        <div>
            <p className="text-3xl font-bold font-mono mt-2 text-slate-800 dark:text-white" style={{color, textShadow: `0 0 12px ${color}40`}}>${formatCurrency(value)}</p>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">{description}</p>
        </div>
    </div>
);

const PaymentHistoryContent: React.FC<{ payments: BillPayment[], onVoidPayment: (paymentId: string) => void; }> = ({ payments, onVoidPayment }) => {
    const handleVoid = (paymentId: string) => {
        if (window.confirm('Are you sure you want to void this payment? This will reverse the transaction and cannot be undone.')) {
            onVoidPayment(paymentId);
        }
    }
    return (
        <div className="space-y-1 text-sm">
            {payments.length === 0 ? <p className="text-slate-500 text-xs text-center py-4">No payments recorded.</p> : payments.map(p => (
                <div key={p.id} className={`flex justify-between items-center p-2 rounded-md ${p.status === 'Voided' ? 'bg-red-100/30 text-slate-500' : 'bg-white/50'}`}>
                    <div>
                        <p className={p.status === 'Voided' ? 'line-through' : ''}>{new Date(p.paymentDate).toLocaleDateString()}</p>
                        <p className="text-xs text-slate-500">{p.referenceNumber} {p.status === 'Voided' && '(Voided)'}</p>
                    </div>
                    <div className="flex items-center gap-4">
                        <span className={`font-mono font-semibold ${p.status === 'Voided' ? 'line-through' : ''}`}>{formatCurrency(p.amount)}</span>
                        {p.status === 'Active' && <button onClick={() => handleVoid(p.id)} className="text-red-500 hover:text-red-700 text-xs font-bold">Void</button>}
                    </div>
                </div>
            ))}
        </div>
    );
};

const BillRow: React.FC<{
    bill: Bill;
    onEdit: (bill: Bill) => void;
    onDelete: (billId: string) => void;
    onRecordPayment: (bill: Bill) => void;
    onVoidPayment: (paymentId: string) => void;
    onViewHistory: (bill: Bill) => void;
}> = ({ bill, onEdit, onDelete, onRecordPayment, onVoidPayment, onViewHistory }) => {
    const [isExpanded, setIsExpanded] = useState(false);
    const balance = bill.totalAmount - bill.paidAmount;

    return (
        <Fragment>
            <tr className="border-b border-white/5 last:border-b-0 hover:bg-sky-900/10 transition-colors">
                <td className="px-4 py-3" onClick={() => setIsExpanded(!isExpanded)}>
                    <div className="flex items-center cursor-pointer">
                        <ChevronDown size={16} className={`mr-2 text-slate-400 transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
                        <p className="font-semibold text-slate-800 dark:text-slate-200">{bill.vendorName}</p>
                    </div>
                </td>
                <td className="px-4 py-3 text-slate-500 dark:text-slate-400 font-mono">{bill.billNumber}</td>
                <td className="px-4 py-3">
                    <p>Bill: {new Date(bill.billDate).toLocaleDateString()}</p>
                    <p className="text-xs text-rose-500">Due: {new Date(bill.dueDate).toLocaleDateString()}</p>
                </td>
                <td className="px-4 py-3 text-right font-mono text-slate-700 dark:text-slate-300">{formatCurrency(bill.totalAmount)}</td>
                <td className="px-4 py-3 text-right font-mono text-green-600 dark:text-green-400">{formatCurrency(bill.paidAmount)}</td>
                <td className="px-4 py-3 text-right font-mono font-bold text-rose-600 dark:text-rose-400">{formatCurrency(balance)}</td>
                <td className="px-4 py-3 text-center">
                    <span className={`px-2 py-1 text-xs font-semibold leading-tight rounded-full ${getStatusAppearance(bill.status)}`}>
                        {bill.status}
                    </span>
                </td>
                <td className="px-4 py-3 text-right">
                    <div className="flex items-center justify-end gap-3">
                        {bill.status !== BillStatus.Paid && (
                            <button onClick={() => onRecordPayment(bill)} className="flex items-center gap-1 text-sm text-green-600 hover:text-green-800 dark:text-green-400 dark:hover:text-green-300 font-semibold" title="Record Payment">
                                <DollarSign size={14} />
                            </button>
                        )}
                        <button onClick={() => onEdit(bill)} className="text-slate-500 hover:text-sky-600 dark:hover:text-sky-400" title="Edit Bill"><Edit size={16} /></button>
                        <button onClick={() => onDelete(bill.id)} className="text-slate-500 hover:text-red-600 dark:hover:text-red-400" title="Delete Bill"><Trash2 size={16} /></button>
                    </div>
                </td>
            </tr>
            {isExpanded && (
                <tr className="bg-slate-50/50 dark:bg-slate-800/20">
                    <td colSpan={8} className="p-4">
                        <div className="grid grid-cols-2 gap-6">
                            <div>
                                <h4 className="text-sm font-bold text-slate-600 mb-2">Bill Lines</h4>
                                <div className="space-y-1 text-sm">
                                    {bill.lines.map((line, idx) => (
                                        <div key={idx} className="flex justify-between items-center p-2 rounded-md bg-white/50">
                                            <span>{line.description}</span>
                                            <span className="font-mono font-semibold">{formatCurrency(line.amount)}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                            <div>
                                <div className="flex justify-between items-center mb-2">
                                    <h4 className="text-sm font-bold text-slate-600">Payment History</h4>
                                    <button onClick={() => onViewHistory(bill)} className="text-slate-500 hover:text-sky-600" title="Expand View"><Expand size={16}/></button>
                                </div>
                                <PaymentHistoryContent payments={bill.payments} onVoidPayment={onVoidPayment} />
                            </div>
                        </div>
                    </td>
                </tr>
            )}
        </Fragment>
    );
};


const Bills: React.FC = () => {
    const { getBills, deleteBill, voidBillPayment, _version } = useData();
    const [bills, setBills] = useState<Bill[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState('');

    const [isFormModalOpen, setIsFormModalOpen] = useState(false);
    const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
    const [isHistoryModalOpen, setIsHistoryModalOpen] = useState(false);
    const [selectedBill, setSelectedBill] = useState<Bill | null>(null);

    useEffect(() => {
        setIsLoading(true);
        getBills().then(setBills).finally(() => setIsLoading(false));
    }, [_version]);

    const handleNewBill = () => {
        setSelectedBill(null);
        setIsFormModalOpen(true);
    };

    const handleEditBill = (bill: Bill) => {
        setSelectedBill(bill);
        setIsFormModalOpen(true);
    };

    const handleRecordPayment = (bill: Bill) => {
        setSelectedBill(bill);
        setIsPaymentModalOpen(true);
    };

    const handleViewHistory = (bill: Bill) => {
        setSelectedBill(bill);
        setIsHistoryModalOpen(true);
    };

    const handleDeleteBill = async (billId: string) => {
        if (window.confirm('Are you sure you want to delete this bill? All associated accounting entries will be reversed.')) {
            try {
                await deleteBill(billId);
            } catch (error) {
                console.error("Failed to delete bill:", error);
                alert(`Error: ${(error as Error).message}`);
            }
        }
    };
    
    const handleVoidPayment = async (paymentId: string) => {
        try {
            await voidBillPayment(paymentId);
            // If the history modal is open, we need to refresh its content
            if (isHistoryModalOpen && selectedBill) {
                // This is a bit of a hack; ideally, data context would update the bill object directly
                // For now, we refetch and find the bill again
                const updatedBills = await getBills();
                const updatedBill = updatedBills.find(b => b.id === selectedBill.id);
                if (updatedBill) setSelectedBill(updatedBill);
            }
        } catch (error) {
            console.error("Failed to void payment:", error);
            alert(`Error: ${(error as Error).message}`);
        }
    };

    const filteredBills = useMemo(() => {
        if (!searchQuery) return bills;
        const lowerQuery = searchQuery.toLowerCase();
        return bills.filter(bill =>
            bill.vendorName.toLowerCase().includes(lowerQuery) ||
            bill.billNumber.toLowerCase().includes(lowerQuery) ||
            bill.id.toLowerCase().includes(lowerQuery)
        );
    }, [bills, searchQuery]);
    
    const kpiData = useMemo(() => {
        const today = new Date();
        today.setHours(0,0,0,0); // For accurate date comparison
        const startOfWeek = new Date(today);
        startOfWeek.setDate(today.getDate() - today.getDay());
        const endOfWeek = new Date(startOfWeek);
        endOfWeek.setDate(startOfWeek.getDate() + 6);

        let totalOverdue = 0;
        let totalUnpaid = 0;
        let dueThisWeek = 0;

        bills.forEach(bill => {
            const balance = bill.totalAmount - bill.paidAmount;
            if (balance > 0) {
                totalUnpaid += balance;
                const dueDate = new Date(bill.dueDate);
                dueDate.setHours(0,0,0,0);
                if (dueDate < today) {
                    totalOverdue += balance;
                }
                if (dueDate >= startOfWeek && dueDate <= endOfWeek) {
                    dueThisWeek += balance;
                }
            }
        });
        return { totalOverdue, totalUnpaid, dueThisWeek };
    }, [bills]);

    return (
        <div className="space-y-6">
             <style>{`
                .glowing-card {
                    position: relative;
                    background-color: var(--glass-bg);
                    backdrop-filter: blur(30px);
                    border: 1px solid var(--glass-border);
                    border-radius: 22px;
                    box-shadow: 0 8px 32px 0 var(--glass-shadow);
                    overflow: hidden;
                }
                .dark .glowing-card::before {
                    content: "";
                    position: absolute;
                    inset: -1px;
                    border-radius: 22px;
                    background: conic-gradient(from 180deg at 50% 50%, rgba(56, 189, 248, 0.15) 0%, rgba(168, 85, 247, 0.15) 33%, rgba(236, 72, 153, 0.15) 66%, rgba(56, 189, 248, 0.15) 100%);
                    filter: blur(12px);
                    z-index: -1;
                    opacity: 0.8;
                }
            `}</style>
            {/* KPI Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <KpiCard title="Total Unpaid" value={kpiData.totalUnpaid} icon={<Clock size={20}/>} description="All outstanding supplier bills" color="#64748b"/>
                <KpiCard title="Due This Week" value={kpiData.dueThisWeek} icon={<Calendar size={20}/>} description="Bills requiring payment soon" color="#3b82f6"/>
                <KpiCard title="Total Overdue" value={kpiData.totalOverdue} icon={<AlertTriangle size={20}/>} description="Bills past their due date" color="#ef4444"/>
            </div>

            {/* Toolbar & Table */}
            <div className="glowing-card p-0">
                <div className="flex justify-between items-center p-4 border-b border-white/10">
                    <div className="relative w-full max-w-sm">
                        <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                        <input
                            type="text"
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            placeholder="Search by supplier, bill #..."
                            className="w-full h-10 bg-black/5 dark:bg-white/5 border border-white/10 rounded-lg shadow-inner pl-10 pr-4 text-sm focus:ring-2 focus:ring-sky-300/60 focus:outline-none transition"
                        />
                    </div>
                    <button onClick={handleNewBill} className="flex items-center gap-2 px-4 py-2 text-sm font-bold bg-gradient-to-r from-sky-500 to-cyan-500 text-white rounded-lg shadow-md hover:shadow-lg active:scale-[0.98] transition-all">
                        <Plus size={16} />
                        New Bill
                    </button>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full min-w-[1000px] text-sm">
                        <thead>
                            <tr className="border-b border-white/10">
                                <th className="th-cell">Supplier</th>
                                <th className="th-cell">Bill #</th>
                                <th className="th-cell">Dates</th>
                                <th className="th-cell text-right">Total</th>
                                <th className="th-cell text-right">Paid</th>
                                <th className="th-cell text-right">Balance Due</th>
                                <th className="th-cell text-center">Status</th>
                                <th className="th-cell text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredBills.map(bill => (
                                <BillRow 
                                    key={bill.id}
                                    bill={bill}
                                    onEdit={handleEditBill}
                                    onDelete={handleDeleteBill}
                                    onRecordPayment={handleRecordPayment}
                                    onVoidPayment={handleVoidPayment}
                                    onViewHistory={handleViewHistory}
                                />
                            ))}
                        </tbody>
                    </table>
                     {isLoading && <div className="text-center p-10 text-slate-500">Loading bills...</div>}
                     {!isLoading && filteredBills.length === 0 && <div className="text-center p-10 text-slate-500">No bills found.</div>}
                </div>
            </div>

            {isFormModalOpen && <BillFormModal isOpen={isFormModalOpen} onClose={() => setIsFormModalOpen(false)} editingBill={selectedBill} />}
            {isPaymentModalOpen && selectedBill && <RecordBillPaymentModal isOpen={isPaymentModalOpen} onClose={() => setIsPaymentModalOpen(false)} bill={selectedBill} />}
            {isHistoryModalOpen && selectedBill && (
                <GlassModal
                    isOpen={isHistoryModalOpen}
                    onClose={() => setIsHistoryModalOpen(false)}
                    title={`Payment History for Bill #${selectedBill.billNumber}`}
                    subtitle={`From: ${selectedBill.vendorName}`}
                    footer={<div/>}
                >
                    <div className="p-4">
                        <PaymentHistoryContent payments={selectedBill.payments} onVoidPayment={handleVoidPayment} />
                    </div>
                </GlassModal>
            )}
            <style>{`.th-cell { padding: 0.75rem 1rem; font-size: 0.75rem; color: #64748b; text-transform: uppercase; font-weight: 600; } .dark .th-cell { color: #94a3b8; }`}</style>
        </div>
    );
};

export default Bills;