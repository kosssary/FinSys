
import React, { useState, useEffect } from 'react';
import { useData } from '../context/DataContext';
import { Employee } from '../types';
import { useNavigate } from 'react-router-dom';
import AddEmployeeModal from '../components/modals/AddEmployeeModal';
import { Plus, Search, User, LayoutGrid, List, MoreHorizontal, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

type EmployeeWithBalance = Employee & { advanceBalance: number };

const formatCurrency = (value: number) => new Intl.NumberFormat('en-US').format(value);

// --- 1. COMPACT CARD COMPONENT ---
const CompactEmployeeCard: React.FC<{ employee: EmployeeWithBalance; onClick: () => void }> = ({ employee, onClick }) => {
    const getInitials = (name: string) => name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
    const hasDebt = employee.advanceBalance > 0;

    return (
        <motion.div 
            whileHover={{ y: -4, scale: 1.01 }}
            onClick={onClick}
            className="group relative bg-white/70 dark:bg-slate-800/70 backdrop-blur-xl border border-white/50 dark:border-slate-700 rounded-2xl shadow-sm hover:shadow-xl hover:border-sky-300/50 transition-all duration-300 cursor-pointer overflow-hidden"
        >
            <div className="p-5 flex items-center gap-4">
                {/* Avatar */}
                <div className="relative flex-shrink-0">
                    <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-slate-100 to-slate-200 dark:from-slate-700 dark:to-slate-600 flex items-center justify-center text-slate-600 dark:text-slate-200 text-lg font-bold shadow-inner border border-white/50">
                        {getInitials(employee.fullName)}
                    </div>
                    <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white dark:border-slate-800 ${employee.isActive ? 'bg-emerald-500' : 'bg-slate-400'}`} />
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                    <h3 className="text-base font-bold text-slate-800 dark:text-white truncate group-hover:text-sky-600 transition-colors">{employee.fullName}</h3>
                    <p className="text-xs font-medium text-slate-500 dark:text-slate-400 truncate">{employee.position}</p>
                </div>

                {/* Arrow Icon */}
                <div className="text-slate-300 group-hover:text-sky-500 transition-colors">
                    <ArrowRight size={20} />
                </div>
            </div>

            {/* Metrics Footer */}
            <div className="px-5 py-3 bg-white/40 dark:bg-slate-900/30 border-t border-slate-100 dark:border-slate-700/50 flex justify-between items-center">
                <div className="flex flex-col">
                    <span className="text-[10px] uppercase font-bold text-slate-400">Salary</span>
                    <span className="text-sm font-mono font-semibold text-slate-700 dark:text-slate-300">${formatCurrency(employee.basicMonthlySalary)}</span>
                </div>
                <div className="h-8 w-px bg-slate-200 dark:bg-slate-700/50" />
                <div className="flex flex-col items-end">
                    <span className="text-[10px] uppercase font-bold text-slate-400">Balance</span>
                    <span className={`text-sm font-mono font-bold ${hasDebt ? 'text-rose-500' : 'text-emerald-600'}`}>
                        ${formatCurrency(employee.advanceBalance)}
                    </span>
                </div>
            </div>
        </motion.div>
    );
};

// --- 2. TABLE ROW COMPONENT ---
const EmployeeTableRow: React.FC<{ employee: EmployeeWithBalance; onClick: () => void }> = ({ employee, onClick }) => {
    const getInitials = (name: string) => name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
    
    return (
        <tr onClick={onClick} className="border-b border-slate-100 dark:border-slate-700/50 hover:bg-sky-50/50 dark:hover:bg-slate-800/50 transition-colors cursor-pointer group">
            <td className="px-6 py-4">
                <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-slate-100 dark:bg-slate-700 flex items-center justify-center text-xs font-bold text-slate-600 dark:text-slate-300">
                        {getInitials(employee.fullName)}
                    </div>
                    <div>
                        <p className="text-sm font-bold text-slate-800 dark:text-white">{employee.fullName}</p>
                    </div>
                </div>
            </td>
            <td className="px-6 py-4 text-sm text-slate-600 dark:text-slate-400">{employee.position}</td>
            <td className="px-6 py-4">
                <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
                    employee.isActive ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400' : 'bg-slate-100 text-slate-800 dark:bg-slate-700 dark:text-slate-300'
                }`}>
                    {employee.isActive ? 'Active' : 'Inactive'}
                </span>
            </td>
            <td className="px-6 py-4 text-right font-mono text-sm text-slate-600 dark:text-slate-300">${formatCurrency(employee.basicMonthlySalary)}</td>
            <td className="px-6 py-4 text-right">
                <span className={`font-mono text-sm font-bold ${employee.advanceBalance > 0 ? 'text-rose-500' : 'text-emerald-600'}`}>
                    ${formatCurrency(employee.advanceBalance)}
                </span>
            </td>
            <td className="px-6 py-4 text-right text-slate-400 group-hover:text-sky-500">
                <ArrowRight size={16} />
            </td>
        </tr>
    );
};

// --- MAIN COMPONENT ---
const Employees: React.FC = () => {
    const { getEmployeesWithBalance, _version } = useData();
    const navigate = useNavigate();
    const [employees, setEmployees] = useState<EmployeeWithBalance[]>([]);
    const [filteredEmployees, setFilteredEmployees] = useState<EmployeeWithBalance[]>([]);
    const [searchQuery, setSearchQuery] = useState('');
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');

    useEffect(() => {
        getEmployeesWithBalance().then(data => {
            setEmployees(data);
            setFilteredEmployees(data);
        });
    }, [_version]);

    useEffect(() => {
        const query = searchQuery.toLowerCase();
        const filtered = employees.filter(emp => 
            emp.fullName.toLowerCase().includes(query) || 
            emp.position.toLowerCase().includes(query)
        );
        setFilteredEmployees(filtered);
    }, [searchQuery, employees]);

    return (
        <div className="space-y-6 pb-20">
            {/* Header Controls */}
            <div className="flex flex-col md:flex-row justify-between items-center gap-4 bg-white/60 dark:bg-slate-800/60 backdrop-blur-xl border border-white/50 dark:border-slate-700/50 rounded-2xl p-3 shadow-sm">
                
                {/* Search */}
                <div className="relative w-full md:max-w-md">
                    <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input 
                        type="text" 
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Search employees..." 
                        className="w-full h-10 bg-white/50 dark:bg-slate-900/50 border border-white/40 dark:border-slate-700 rounded-xl pl-10 pr-4 text-sm text-slate-800 dark:text-white focus:ring-2 focus:ring-sky-500/20 focus:outline-none transition-all"
                    />
                </div>

                <div className="flex items-center gap-3 w-full md:w-auto">
                    {/* View Toggles */}
                    <div className="flex bg-slate-100 dark:bg-slate-700/50 p-1 rounded-lg border border-slate-200 dark:border-slate-600">
                        <button 
                            onClick={() => setViewMode('grid')}
                            className={`p-2 rounded-md transition-all ${viewMode === 'grid' ? 'bg-white dark:bg-slate-600 shadow-sm text-sky-600 dark:text-sky-400' : 'text-slate-400 hover:text-slate-600'}`}
                        >
                            <LayoutGrid size={18} />
                        </button>
                        <button 
                            onClick={() => setViewMode('table')}
                            className={`p-2 rounded-md transition-all ${viewMode === 'table' ? 'bg-white dark:bg-slate-600 shadow-sm text-sky-600 dark:text-sky-400' : 'text-slate-400 hover:text-slate-600'}`}
                        >
                            <List size={18} />
                        </button>
                    </div>

                    {/* Add Button */}
                    <button
                        onClick={() => setIsModalOpen(true)}
                        className="flex items-center gap-2 px-5 py-2.5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-xl font-bold text-sm shadow-lg hover:scale-105 active:scale-95 transition-all"
                    >
                        <Plus size={18} />
                        <span>Add Employee</span>
                    </button>
                </div>
            </div>

            {/* Content Area */}
            {filteredEmployees.length > 0 ? (
                <>
                    {viewMode === 'grid' ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
                            <AnimatePresence mode="popLayout">
                                {filteredEmployees.map(emp => (
                                    <CompactEmployeeCard 
                                        key={emp.id} 
                                        employee={emp} 
                                        onClick={() => navigate(`/employees/${emp.id}`)} 
                                    />
                                ))}
                            </AnimatePresence>
                        </div>
                    ) : (
                        <div className="bg-white/70 dark:bg-slate-800/70 backdrop-blur-xl border border-white/50 dark:border-slate-700 rounded-2xl shadow-sm overflow-hidden">
                            <div className="overflow-x-auto">
                                <table className="w-full text-left">
                                    <thead className="bg-slate-50/50 dark:bg-slate-900/30 border-b border-slate-200 dark:border-slate-700">
                                        <tr>
                                            <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Employee</th>
                                            <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Role</th>
                                            <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Status</th>
                                            <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Salary</th>
                                            <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Balance</th>
                                            <th className="px-6 py-4"></th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-slate-100 dark:divide-slate-700">
                                        {filteredEmployees.map(emp => (
                                            <EmployeeTableRow 
                                                key={emp.id} 
                                                employee={emp} 
                                                onClick={() => navigate(`/employees/${emp.id}`)} 
                                            />
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    )}
                </>
            ) : (
                <div className="flex flex-col items-center justify-center py-32 text-slate-400">
                    <div className="w-20 h-20 bg-slate-100 dark:bg-slate-800 rounded-full flex items-center justify-center mb-4">
                        <User size={32} className="opacity-40" />
                    </div>
                    <p className="text-lg font-semibold text-slate-600 dark:text-slate-300">No employees found</p>
                    <p className="text-sm">Try adjusting your search.</p>
                </div>
            )}

            <AddEmployeeModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
        </div>
    );
};

export default Employees;
