import React, { useState, useEffect, useMemo, Fragment } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useData } from '../context/DataContext';
import { SupplierBundle, CustomerOrder } from '../types';
import AddBundleModal from '../components/modals/AddBundleModal';
import { GlassCard } from '../components/ui/GlassCard';
import { Plus, Search, ChevronDown, ArrowUp, ArrowDown, Pencil, Trash2, CheckCircle2, XCircle } from 'lucide-react';
import { GlassButton } from '../components/ui/GlassButton';

const formatCurrency = (value: number) => new Intl.NumberFormat('en-US').format(value);

type SortConfig = { key: keyof SupplierBundle | 'orderCount'; direction: 'ascending' | 'descending' };

const BundleRow: React.FC<{ 
    bundle: SupplierBundle; 
    orders: CustomerOrder[];
    onEdit: (bundle: SupplierBundle) => void;
    onDelete: (bundleId: string) => void;
    onOrderDoubleClick: (order: CustomerOrder) => void;
}> = ({ bundle, orders, onEdit, onDelete, onOrderDoubleClick }) => {
    const [isExpanded, setIsExpanded] = useState(false);

    return (
        <Fragment>
            <tr className="hover:bg-sky-100/30 transition-colors duration-150 border-b border-white/60">
                <td className="px-4 py-3" onClick={() => setIsExpanded(!isExpanded)}>
                    <div className="flex items-center cursor-pointer">
                        <ChevronDown size={16} className={`mr-2 text-slate-400 transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
                        <div>
                            <p className="font-semibold text-sm text-slate-800">{bundle.name}</p>
                            <p className="text-sm text-slate-500 font-mono">{bundle.id}</p>
                        </div>
                    </div>
                </td>
                <td className="px-4 py-3 text-base text-slate-700 font-mono">{bundle.logisticsReferenceId}</td>
                <td className="px-4 py-3 text-base text-center text-slate-700 font-semibold">{bundle.orderIds.length}</td>
                <td className="px-4 py-3 text-base text-center text-slate-800">{formatCurrency(bundle.totalCost)} $</td>
                <td className="px-4 py-3 text-sm text-slate-500">{new Date(bundle.createdAt).toLocaleDateString()}</td>
                <td className="px-4 py-3 text-center">
                     <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold leading-tight rounded-full ${
                        bundle.paymentRecorded 
                        ? 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300' 
                        : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-300'
                    }`}>
                        {bundle.paymentRecorded ? <CheckCircle2 size={12} /> : <XCircle size={12} />}
                        {bundle.paymentRecorded ? 'Recorded' : 'Not Recorded'}
                    </span>
                </td>
                <td className="px-4 py-3">
                    <div className="flex items-center gap-4">
                        <button onClick={() => onEdit(bundle)} className="text-slate-500 hover:text-sky-600 transition-colors" title="Edit Bundle">
                            <Pencil size={16} />
                        </button>
                        <button onClick={() => onDelete(bundle.id)} className="text-slate-500 hover:text-red-600 transition-colors" title="Delete Bundle">
                            <Trash2 size={16} />
                        </button>
                    </div>
                </td>
            </tr>
            {isExpanded && (
                <tr className="bg-sky-50/20">
                    <td colSpan={7} className="p-0">
                        <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: 'auto', opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            transition={{ duration: 0.2 }}
                            className="overflow-hidden p-4"
                        >
                            <div className="grid grid-cols-5 gap-2 px-2 py-1 text-xs font-bold text-slate-500">
                                <span>Order ID</span>
                                <span className="col-span-1">Customer</span>
                                <span className="text-right">Total</span>
                                <span className="text-right">Paid</span>
                                <span className="text-right">Due</span>
                            </div>
                            <div className="bg-white/50 rounded-lg p-1 space-y-1">
                                {orders.map(order => (
                                    <div key={order.id} onDoubleClick={() => onOrderDoubleClick(order)} className="grid grid-cols-5 gap-2 p-2 rounded-md hover:bg-white/70 text-sm cursor-pointer">
                                        <span className="font-mono text-slate-600">{order.id}</span>
                                        <span className="text-slate-700 font-medium col-span-1 truncate">{order.customerName}</span>
                                        <span className="text-right font-semibold text-slate-800">{formatCurrency(order.totalPrice)}</span>
                                        <span className="text-right text-emerald-600">{formatCurrency(order.paidAmount)}</span>
                                        <span className="text-right text-rose-600">{formatCurrency(order.totalPrice - order.paidAmount)}</span>
                                    </div>
                                ))}
                            </div>
                        </motion.div>
                    </td>
                </tr>
            )}
        </Fragment>
    );
};

const Bundles: React.FC = () => {
    const { getBundles, getOrders, deleteBundle, _version } = useData();
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingBundle, setEditingBundle] = useState<SupplierBundle | null>(null);
    const [bundles, setBundles] = useState<SupplierBundle[]>([]);
    const [orders, setOrders] = useState<CustomerOrder[]>([]);
    const [searchQuery, setSearchQuery] = useState('');
    const [sortConfig, setSortConfig] = useState<SortConfig>({ key: 'createdAt', direction: 'descending' });
    const navigate = useNavigate();

    useEffect(() => {
        Promise.all([getBundles(), getOrders()]).then(([b, o]) => {
            setBundles(b);
            setOrders(o);
        });
    }, [_version]);

    const handleOpenModal = (bundle: SupplierBundle | null) => {
        setEditingBundle(bundle);
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setEditingBundle(null);
    };

    const handleDelete = async (bundleId: string) => {
        if (window.confirm('Are you sure you want to delete this bundle? This will un-bundle all associated orders and reverse the financial transaction.')) {
            try {
                await deleteBundle(bundleId);
            } catch (error) {
                console.error('Failed to delete bundle:', error);
                alert(`Error: ${(error as Error).message}`);
            }
        }
    };

    const handleOrderDoubleClick = (order: CustomerOrder) => {
        navigate('/orders', { state: { search: order.id } });
    };

    const requestSort = (key: SortConfig['key']) => {
        let direction: 'ascending' | 'descending' = 'ascending';
        if (sortConfig && sortConfig.key === key && sortConfig.direction === 'ascending') {
            direction = 'descending';
        }
        setSortConfig({ key, direction });
    };

    const getSortIcon = (key: SortConfig['key']) => {
        if (!sortConfig || sortConfig.key !== key) return null;
        return sortConfig.direction === 'ascending' ? <ArrowUp size={14} /> : <ArrowDown size={14} />;
    };

    const processedBundles = useMemo(() => {
        let processed = [...bundles];

        if (searchQuery) {
            const lowerQuery = searchQuery.toLowerCase();
            processed = processed.filter(bundle =>
                bundle.id.toLowerCase().includes(lowerQuery) ||
                bundle.name.toLowerCase().includes(lowerQuery) ||
                bundle.logisticsReferenceId.toLowerCase().includes(lowerQuery)
            );
        }

        processed.sort((a, b) => {
            let aVal: any, bVal: any;
            const key = sortConfig.key;

            if (key === 'orderCount') { aVal = a.orderIds.length; bVal = b.orderIds.length; }
            else { aVal = a[key as keyof SupplierBundle]; bVal = b[key as keyof SupplierBundle]; }

            if (aVal < bVal) return sortConfig.direction === 'ascending' ? -1 : 1;
            if (aVal > bVal) return sortConfig.direction === 'ascending' ? 1 : -1;
            return 0;
        });

        return processed;
    }, [bundles, searchQuery, sortConfig]);

    const getOrdersForBundle = (bundle: SupplierBundle) => {
        return orders.filter(o => bundle.orderIds.includes(o.id));
    };
    
    const headers: { key: SortConfig['key']; label: string, isNumeric?: boolean }[] = [
        { key: 'name', label: 'Bundle Name' },
        { key: 'logisticsReferenceId', label: 'Logistics Ref ID' },
        { key: 'orderCount', label: '# Orders', isNumeric: true },
        { key: 'totalCost', label: 'Total Cost', isNumeric: true },
        { key: 'createdAt', label: 'Created Date' },
        { key: 'paymentRecorded', label: 'Payment' },
    ];

    return (
        <div className="space-y-6">
            <GlassCard
                title="Supplier Bundles"
                actions={
                    <div className="flex items-center gap-3">
                        <div className="relative w-full max-w-xs">
                            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                            <input type="text" value={searchQuery} onChange={e => setSearchQuery(e.target.value)} placeholder="Filter bundles..." className="w-full h-9 bg-white/60 border border-white/50 rounded-lg shadow-inner pl-9 pr-3 text-sm focus:ring-1 focus:ring-sky-300/60 focus:outline-none" />
                        </div>
                        <GlassButton variant="primary" onClick={() => handleOpenModal(null)} className="h-11">
                            <Plus size={16} className="mr-2"/>
                            <span>New Bundle</span>
                        </GlassButton>
                    </div>
                }
                bodyClassName="p-0"
            >
                <div className="overflow-auto">
                    <table className="w-full min-w-[800px]">
                        <thead>
                            <tr className="border-b border-white/60">
                                {headers.map((h) => (
                                    <th key={h.key} className={`px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider ${h.isNumeric ? 'text-center' : 'text-left'}`}>
                                        <button onClick={() => requestSort(h.key)} className={`flex items-center gap-1 group ${h.isNumeric ? 'mx-auto' : ''}`}>
                                            <span>{h.label}</span>
                                            {getSortIcon(h.key)}
                                        </button>
                                    </th>
                                ))}
                                <th className="px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider text-left">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {processedBundles.map((bundle) => (
                                <BundleRow key={bundle.id} bundle={bundle} orders={getOrdersForBundle(bundle)} onEdit={handleOpenModal} onDelete={handleDelete} onOrderDoubleClick={handleOrderDoubleClick} />
                            ))}
                        </tbody>
                    </table>
                </div>
                {processedBundles.length === 0 && (
                    <div className="text-center py-16 text-slate-500">
                        <p>No bundles found. Create one to get started.</p>
                    </div>
                )}
            </GlassCard>

            <AddBundleModal 
                isOpen={isModalOpen} 
                onClose={handleCloseModal}
                editingBundle={editingBundle}
            />
        </div>
    );
};

export default Bundles;