import React, { useState, useEffect, useCallback } from 'react';
import { useData } from '../context/DataContext';
import { FinancialSummaryReportData } from '../types';
import { motion, AnimatePresence } from 'framer-motion';
import { RefreshCw, Calendar, ArrowRight, FileSpreadsheet, FileText } from 'lucide-react';

// --- HELPER FUNCTIONS ---
const formatAccountantNumber = (value: number | undefined | null, decimals = 2): string => {
    if (value == null || isNaN(value)) {
        return '0.00';
    }
    const isNegative = value < 0;
    const formatted = new Intl.NumberFormat('en-US', {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals,
    }).format(Math.abs(value));
    return isNegative ? `(${formatted})` : formatted;
};


// --- UI COMPONENTS ---
const GlowingCard: React.FC<{ children: React.ReactNode; className?: string; title?: string }> = ({ children, className = '', title }) => (
    <div className={`glowing-card ${className}`}>
        {title && <h3 className="text-base font-semibold text-slate-700 dark:text-slate-200 mb-4">{title}</h3>}
        {children}
    </div>
);

const KpiTile: React.FC<{ title: string; value: string; glowColor: string }> = ({ title, value, glowColor }) => (
    <div className="relative p-4 bg-white/5 backdrop-blur-[40px] border border-white/10 rounded-2xl text-center">
        <div className="absolute inset-0 border-2 border-transparent rounded-2xl" style={{
            background: `radial-gradient(circle at 50% 100%, ${glowColor}, transparent 70%)`,
            opacity: 0.6,
            zIndex: -1,
        }} />
        <p className="text-sm text-slate-500 dark:text-slate-400 font-semibold">{title}</p>
        <p className="text-xl font-bold text-slate-800 dark:text-white mt-1">{value}</p>
    </div>
);

const ReportRow: React.FC<{ label: string; value: number; isSub?: boolean; isTotal?: boolean; isLarge?: boolean }> = ({ label, value, isSub, isTotal, isLarge }) => (
    <div className={`flex justify-between items-center ${isTotal ? 'py-2 border-t border-white/20 mt-2' : 'py-1.5'}`}>
        <p className={`text-sm ${isSub ? 'pl-4' : ''} ${isTotal ? 'font-bold' : ''} text-slate-600 dark:text-slate-300`}>{label}</p>
        <p className={`font-mono ${isLarge ? 'text-xl font-bold' : 'text-base font-semibold'} ${value < 0 ? 'text-red-500' : 'text-slate-800 dark:text-slate-100'}`}>
            {formatAccountantNumber(value)}
        </p>
    </div>
);


// --- MAIN PAGE COMPONENT ---
const FinancialSummary: React.FC = () => {
    const { getFinancialSummaryReport, _version } = useData();
    const [data, setData] = useState<FinancialSummaryReportData | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');

    const setDatePreset = useCallback((preset: string) => {
        const now = new Date();
        let start = new Date(), end = new Date();
        switch (preset) {
            case 'This Quarter': const quarter = Math.floor(now.getMonth() / 3); start = new Date(now.getFullYear(), quarter * 3, 1); end = new Date(now.getFullYear(), quarter * 3 + 3, 0); break;
            case 'This Year': start = new Date(now.getFullYear(), 0, 1); end = new Date(); break;
            case 'This Month': default: start = new Date(now.getFullYear(), now.getMonth(), 1); end = new Date(now.getFullYear(), now.getMonth() + 1, 0); break;
        }
        setStartDate(start.toISOString().split('T')[0]);
        setEndDate(end.toISOString().split('T')[0]);
    }, []);

    useEffect(() => { setDatePreset('This Month'); }, [setDatePreset]);

    const fetchData = useCallback(async () => {
        if (!startDate || !endDate) return;
        setIsLoading(true);
        try {
            const result = await getFinancialSummaryReport(startDate, endDate);
            setData(result);
        } catch (e) {
            console.error("Failed to fetch summary data:", e);
            setData(null);
        } finally {
            setIsLoading(false);
        }
    }, [startDate, endDate, getFinancialSummaryReport]);

    useEffect(() => { fetchData(); }, [fetchData, _version]);
    
    const handleExportExcel = () => {
        if (!data) return;
        const XLSX = (window as any).XLSX;
        if (!XLSX) return alert("Excel export library not available.");

        const rows = [
            [{ v: "Financial Summary", s: { font: { bold: true, sz: 16 } } }],
            [`For the period: ${new Date(startDate).toLocaleDateString()}`],
            [],
            [{ v: "Income Overview", s: { font: { bold: true, sz: 14 } } }],
            ["Total Revenue", data.income.totalRevenue],
            ["Cost of Goods Sold (COGS)", data.income.cogs],
            [{v: "Gross Profit", s: {font: {bold: true}}}, {v: data.income.grossProfit, s: {font: {bold: true}}}],
            ["Operating Expenses", data.income.operatingExpenses],
            [{v: "Net Profit", s: {font: {bold: true, sz: 12}}}, {v: data.income.netProfit, s: {font: {bold: true, sz: 12}}}],
            [],
            [{ v: "Balance Sheet Summary", s: { font: { bold: true, sz: 14 } } }],
            ["Total Assets", data.balanceSheet.totalAssets],
            ["Total Liabilities", data.balanceSheet.totalLiabilities],
            ["Total Equity", data.balanceSheet.totalEquity],
            [],
            [{ v: "Cash Flow Overview", s: { font: { bold: true, sz: 14 } } }],
            ["Operating Cash Flow", data.cashFlow.operating],
            ["Investing Cash Flow", data.cashFlow.investing],
            ["Financing Cash Flow", data.cashFlow.financing],
            [],
            [{ v: "Key Performance Indicators", s: { font: { bold: true, sz: 14 } } }],
            ["Gross Margin %", {t:'n', v: data.kpis.grossMargin / 100, z: '0.00%'}],
            ["Net Profit %", {t:'n', v: data.kpis.netMargin / 100, z: '0.00%'}],
            ["Current Ratio", data.kpis.currentRatio],
            ["Quick Ratio", data.kpis.quickRatio],
            ["Debt-to-Equity Ratio", data.kpis.debtToEquity],
        ];
        
        rows.forEach((row: any[]) => {
            if (typeof row[1] === 'number') {
                row[1] = { t: 'n', v: row[1], z: '#,##0.00;[Red](#,##0.00)' };
            }
        });

        const ws = XLSX.utils.aoa_to_sheet(rows);
        ws['!cols'] = [{ wch: 30 }, { wch: 20 }];
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Financial Summary");
        XLSX.writeFile(wb, `FinancialSummary_${endDate}.xlsx`);
    };

    const handleExportPdf = () => {
        if (!data) return;
        const { jsPDF } = (window as any).jspdf;
        if (!jsPDF) return alert("PDF export library not available.");
        const doc = new jsPDF();
        let cursorY = 20;

        // Header
        doc.setFontSize(22);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor('#1e293b');
        doc.text('Financial Summary', 15, cursorY);
        cursorY += 8;
        doc.setFontSize(10);
        doc.setFont('helvetica', 'normal');
        doc.setTextColor('#64748b');
        doc.text(`For the period from ${new Date(startDate).toLocaleDateString()} to ${new Date(endDate).toLocaleDateString()}`, 15, cursorY);
        cursorY += 15;

        // KPI Cards
        const kpis = [
            { title: "Gross Margin", value: `${formatAccountantNumber(data.kpis.grossMargin, 1)}%` },
            { title: "Net Margin", value: `${formatAccountantNumber(data.kpis.netMargin, 1)}%` },
            { title: "Current Ratio", value: formatAccountantNumber(data.kpis.currentRatio, 2) },
            { title: "Debt-to-Equity", value: formatAccountantNumber(data.kpis.debtToEquity, 2) },
        ];
        const cardWidth = (doc.internal.pageSize.getWidth() - 30 - (kpis.length - 1) * 5) / kpis.length;
        let cardX = 15;
        kpis.forEach(kpi => {
            doc.setFillColor(248, 250, 252);
            doc.setDrawColor(226, 232, 240);
            doc.roundedRect(cardX, cursorY, cardWidth, 20, 3, 3, 'FD');
            doc.setFontSize(8);
            doc.setTextColor('#64748b');
            doc.text(kpi.title, cardX + cardWidth / 2, cursorY + 7, { align: 'center' });
            doc.setFontSize(12);
            doc.setFont('helvetica', 'bold');
            doc.setTextColor('#1e293b');
            doc.text(kpi.value, cardX + cardWidth / 2, cursorY + 15, { align: 'center' });
            cardX += cardWidth + 5;
        });
        cursorY += 30;

        // Main Content using autoTable
        (doc as any).autoTable({
            startY: cursorY,
            body: [
                [{ content: 'Income Overview', colSpan: 2, styles: { fontStyle: 'bold', fillColor: [241, 245, 249] } }],
                ['Total Revenue', { content: formatAccountantNumber(data.income.totalRevenue), styles: { halign: 'right' } }],
                ['Cost of Goods Sold', { content: formatAccountantNumber(data.income.cogs), styles: { halign: 'right' } }],
                [{ content: 'Gross Profit', styles: { fontStyle: 'bold' } }, { content: formatAccountantNumber(data.income.grossProfit), styles: { halign: 'right', fontStyle: 'bold' } }],
                ['Operating Expenses', { content: formatAccountantNumber(data.income.operatingExpenses), styles: { halign: 'right' } }],
                [{ content: 'Net Profit', styles: { fontStyle: 'bold' } }, { content: formatAccountantNumber(data.income.netProfit), styles: { halign: 'right', fontStyle: 'bold' } }],
                [{ content: '', colSpan: 2, styles: { minCellHeight: 5 } }], // Spacer
                
                [{ content: 'Balance Sheet Summary', colSpan: 2, styles: { fontStyle: 'bold', fillColor: [241, 245, 249] } }],
                ['Total Assets', { content: formatAccountantNumber(data.balanceSheet.totalAssets), styles: { halign: 'right' } }],
                ['Total Liabilities', { content: formatAccountantNumber(data.balanceSheet.totalLiabilities), styles: { halign: 'right' } }],
                ['Total Equity', { content: formatAccountantNumber(data.balanceSheet.totalEquity), styles: { halign: 'right' } }],
                [{ content: '', colSpan: 2, styles: { minCellHeight: 5 } }], // Spacer

                [{ content: 'Cash Flow Overview', colSpan: 2, styles: { fontStyle: 'bold', fillColor: [241, 245, 249] } }],
                ['Operating Cash Flow', { content: formatAccountantNumber(data.cashFlow.operating), styles: { halign: 'right' } }],
                ['Investing Cash Flow', { content: formatAccountantNumber(data.cashFlow.investing), styles: { halign: 'right' } }],
                ['Financing Cash Flow', { content: formatAccountantNumber(data.cashFlow.financing), styles: { halign: 'right' } }],
            ],
            theme: 'grid',
        });

        doc.save(`FinancialSummary_${endDate}.pdf`);
    };

    return (
        <div className="space-y-6">
            <style>{`
                .glowing-card {
                    position: relative;
                    background-color: var(--glass-bg);
                    backdrop-filter: blur(30px);
                    border: 1px solid var(--glass-border);
                    border-radius: 22px;
                    box-shadow: 0 8px 32px 0 var(--glass-shadow);
                }
                .dark .glowing-card::before {
                    content: "";
                    position: absolute;
                    inset: -1px;
                    border-radius: 22px;
                    background: conic-gradient(from 180deg at 50% 50%, rgba(56, 189, 248, 0.2) 0%, rgba(168, 85, 247, 0.2) 33%, rgba(236, 72, 153, 0.2) 66%, rgba(56, 189, 248, 0.2) 100%);
                    filter: blur(16px);
                    z-index: -1;
                }
            `}</style>

            {/* Header */}
            <header className="flex flex-col md:flex-row justify-end items-start md:items-center gap-4">
                <div className="relative z-10 bg-white/60 dark:bg-slate-800/50 backdrop-blur-xl border border-white/20 dark:border-white/10 rounded-2xl shadow-sm p-2 flex items-center gap-2">
                    <Calendar className="text-slate-500 ml-2" size={20} />
                    <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="h-10 bg-transparent border-none rounded-lg px-2 text-sm text-slate-800 dark:text-slate-200 focus:ring-0 focus:outline-none" />
                    <ArrowRight size={16} className="text-slate-400"/>
                    <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className="h-10 bg-transparent border-none rounded-lg px-2 text-sm text-slate-800 dark:text-slate-200 focus:ring-0 focus:outline-none" />
                    <div className="pl-2 border-l border-white/20 dark:border-white/10 flex items-center gap-1">
                        {['This Month', 'This Quarter', 'This Year'].map(p => (
                            <button key={p} onClick={() => setDatePreset(p)} className="px-2 py-1 text-xs font-semibold text-slate-600 dark:text-slate-300 rounded-md hover:bg-black/5 dark:hover:bg-white/5 transition-colors">
                                {p}
                            </button>
                        ))}
                    </div>
                    <button onClick={fetchData} disabled={isLoading} className="h-10 w-10 flex items-center justify-center text-slate-700 dark:text-slate-200 bg-white/50 dark:bg-white/10 rounded-lg border border-white/40 dark:border-white/20 hover:bg-white/70 dark:hover:bg-white/20 transition-colors disabled:opacity-50">
                        <RefreshCw size={16} className={isLoading ? 'animate-spin' : ''} />
                    </button>
                </div>
            </header>

            <AnimatePresence mode="wait">
                {isLoading ? (
                     <motion.div key="loader" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="text-center p-20 text-slate-500">
                        <p>Generating Financial Summary...</p>
                    </motion.div>
                ) : !data ? (
                    <motion.div key="error" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="text-center p-20 text-rose-500">
                        <p>Could not load data for the selected period.</p>
                    </motion.div>
                ) : (
                    <motion.div key="data" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
                        {/* KPIs */}
                        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                            <KpiTile title="Gross Margin %" value={`${formatAccountantNumber(data.kpis.grossMargin, 1)}%`} glowColor="rgba(5, 150, 105, 0.4)" />
                            <KpiTile title="Net Profit %" value={`${formatAccountantNumber(data.kpis.netMargin, 1)}%`} glowColor="rgba(2, 132, 199, 0.4)" />
                            <KpiTile title="Current Ratio" value={formatAccountantNumber(data.kpis.currentRatio, 2)} glowColor="rgba(217, 119, 6, 0.4)" />
                            <KpiTile title="Quick Ratio" value={formatAccountantNumber(data.kpis.quickRatio, 2)} glowColor="rgba(217, 119, 6, 0.4)" />
                            <KpiTile title="Debt-to-Equity" value={formatAccountantNumber(data.kpis.debtToEquity, 2)} glowColor="rgba(192, 38, 211, 0.4)" />
                        </div>

                        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                            {/* Income */}
                            <GlowingCard className="lg:col-span-3 p-6" title="Income Overview">
                                <div className="space-y-2">
                                    <ReportRow label="Total Revenue" value={data.income.totalRevenue} />
                                    <ReportRow label="Cost of Goods Sold (COGS)" value={data.income.cogs} />
                                    <ReportRow label="Gross Profit" value={data.income.grossProfit} isTotal />
                                    <ReportRow label="Operating Expenses" value={data.income.operatingExpenses} />
                                </div>
                                <div className="text-center mt-6 py-4 bg-white/10 rounded-xl">
                                    <p className="text-sm font-semibold text-slate-500 dark:text-slate-400">Net Profit</p>
                                    <p className={`font-mono text-4xl font-bold mt-1 ${data.income.netProfit < 0 ? 'text-red-500' : 'text-sky-600 dark:text-sky-400'}`}>
                                        {formatAccountantNumber(data.income.netProfit)}
                                    </p>
                                </div>
                            </GlowingCard>

                            {/* Assets */}
                            <GlowingCard className="p-6" title="Assets Summary">
                                <div className="space-y-1">
                                    <ReportRow label="Current Assets" value={data.balanceSheet.currentAssets} />
                                    <ReportRow label="Non-Current Assets" value={data.balanceSheet.nonCurrentAssets} />
                                    <ReportRow label="Total Assets" value={data.balanceSheet.totalAssets} isTotal isLarge />
                                </div>
                            </GlowingCard>

                            {/* Liabilities */}
                            <GlowingCard className="p-6" title="Liabilities Summary">
                                <div className="space-y-1">
                                    <ReportRow label="Current Liabilities" value={data.balanceSheet.currentLiabilities} />
                                    <ReportRow label="Long-term Liabilities" value={data.balanceSheet.longTermLiabilities} />
                                    <ReportRow label="Total Liabilities" value={data.balanceSheet.totalLiabilities} isTotal isLarge />
                                </div>
                            </GlowingCard>

                            {/* Equity */}
                            <GlowingCard className="p-6" title="Equity Summary">
                                <div className="space-y-1">
                                    <ReportRow label="Owner’s Capital" value={data.balanceSheet.ownersCapital} />
                                    <ReportRow label="Retained Earnings" value={data.balanceSheet.retainedEarnings} />
                                    <ReportRow label="Current Year Profit" value={data.balanceSheet.currentYearProfit} />
                                    <ReportRow label="Total Equity" value={data.balanceSheet.totalEquity} isTotal isLarge />
                                </div>
                            </GlowingCard>

                             {/* Cash Flow */}
                             <GlowingCard className="lg:col-span-3 p-6" title="Cash Flow Overview">
                                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                                    <ReportRow label="Operating Cash Flow" value={data.cashFlow.operating} />
                                    <ReportRow label="Investing Cash Flow" value={data.cashFlow.investing} />
                                    <ReportRow label="Financing Cash Flow" value={data.cashFlow.financing} />
                                    <ReportRow label="Net Cash Position" value={data.cashFlow.netPosition} isTotal />
                                </div>
                            </GlowingCard>
                        </div>
                        <motion.div
                            initial={{ y: 50, opacity: 0 }}
                            animate={{ y: 0, opacity: 1 }}
                            transition={{ delay: 0.2, type: 'spring', stiffness: 100 }}
                            className="fixed bottom-6 right-6 z-40"
                        >
                            <div className="bg-white/70 backdrop-blur-md border border-white/50 rounded-full shadow-lg flex items-center gap-1 p-2">
                                <button onClick={handleExportExcel} className="flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold text-emerald-800 hover:bg-emerald-100/50 transition-colors" title="Export to Excel">
                                    <FileSpreadsheet size={16} />
                                    <span>Excel</span>
                                </button>
                                <button onClick={handleExportPdf} className="flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold text-sky-800 hover:bg-sky-100/50 transition-colors" title="Export to PDF">
                                    <FileText size={16} />
                                    <span>PDF</span>
                                </button>
                            </div>
                        </motion.div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
};

export default FinancialSummary;