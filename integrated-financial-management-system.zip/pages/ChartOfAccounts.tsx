
import React, { useState, useEffect, Fragment, useMemo } from 'react';
import { useData } from '../context/DataContext';
import { Account } from '../types';
import { useNavigate } from 'react-router-dom';
import AddAccountModal from '../components/modals/AddAccountModal';
import { GlassCard } from '../components/ui/GlassCard';
import { GlassButton } from '../components/ui/GlassButton';
import { 
    Folder, FolderOpen, FileText, ChevronRight, ChevronDown, 
    Plus, Edit3, FileSpreadsheet, Search, MoreHorizontal, LayoutList 
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const formatCurrency = (value: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value);

const AccountRow: React.FC<{ 
    account: Account; 
    level: number; 
    onAdd: (parent: Account | null) => void; 
    onEdit: (account: Account) => void;
    searchQuery: string; 
}> = ({ account, level, onAdd, onEdit, searchQuery }) => {
    // If searching, expand all. Otherwise, default to collapsed for deep levels.
    const [isExpanded, setIsExpanded] = useState(level < 1 || searchQuery.length > 0);
    const navigate = useNavigate();

    useEffect(() => {
        if (searchQuery.length > 0) setIsExpanded(true);
    }, [searchQuery]);

    const hasChildren = account.children && account.children.length > 0;
    const isMatch = searchQuery ? (
        account.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        account.code.includes(searchQuery) ||
        account.nameKurdish.toLowerCase().includes(searchQuery.toLowerCase())
    ) : true;

    // If searching, hide non-matching rows (unless they are parents of matching rows - complex logic simplified here to just hide non-matches if leaf)
    if (searchQuery && !isMatch && !hasChildren) return null;

    return (
        <Fragment>
            <motion.tr 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="hover:bg-sky-50/40 dark:hover:bg-slate-800/40 transition-colors border-b border-slate-100/50 dark:border-slate-700/50 group"
            >
                <td className="py-3 pl-4 pr-2">
                    <div style={{ paddingLeft: `${level * 24}px` }} className="flex items-center">
                        <div className="w-6 h-6 flex-shrink-0 mr-2 flex items-center justify-center">
                            {hasChildren ? (
                                <button 
                                    onClick={() => setIsExpanded(!isExpanded)} 
                                    className="text-slate-400 hover:text-sky-600 transition-colors focus:outline-none"
                                >
                                    {isExpanded ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
                                </button>
                            ) : (
                                <span className="w-4 h-4 block" />
                            )}
                        </div>
                        
                        <div className={`flex items-center gap-3 ${level === 0 ? 'font-bold text-slate-800' : 'text-slate-700'}`}>
                            <div className={`p-1.5 rounded-lg ${hasChildren ? 'bg-sky-100/50 text-sky-600' : 'bg-slate-100/50 text-slate-500'}`}>
                                {hasChildren ? (isExpanded ? <FolderOpen size={16} /> : <Folder size={16} />) : <FileText size={16} />}
                            </div>
                            <span className="px-2 py-0.5 rounded-md bg-slate-100/80 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-mono text-slate-600 dark:text-slate-400 font-bold">
                                {account.code}
                            </span>
                            <div>
                                <div className="flex items-baseline gap-2">
                                    <span className="text-sm">{account.name}</span>
                                    <span className="text-xs text-slate-400 font-normal tracking-wide hidden sm:inline-block">{account.nameKurdish}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </td>
                <td className="px-4 py-3 text-sm">
                    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                        account.category === 'Asset' ? 'bg-emerald-50 text-emerald-700' :
                        account.category === 'Liability' ? 'bg-amber-50 text-amber-700' :
                        account.category === 'Equity' ? 'bg-purple-50 text-purple-700' :
                        account.category === 'Revenue' ? 'bg-blue-50 text-blue-700' :
                        'bg-rose-50 text-rose-700'
                    }`}>
                        {account.category}
                    </span>
                </td>
                <td className="px-4 py-3 text-right">
                    <span className={`font-mono text-sm font-semibold ${
                        hasChildren ? 'text-slate-800' : (account.balance < 0 ? 'text-rose-600' : 'text-slate-700')
                    }`}>
                        {formatCurrency(account.balance)}
                    </span>
                </td>
                <td className="px-4 py-3 text-right">
                    <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button 
                            onClick={() => onAdd(account)} 
                            className="p-1.5 text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                            title="Add Sub-Account"
                        >
                            <Plus size={16} />
                        </button>
                        <button 
                            onClick={() => onEdit(account)} 
                            className="p-1.5 text-sky-600 hover:bg-sky-50 rounded-lg transition-colors"
                            title="Edit Account"
                        >
                            <Edit3 size={16} />
                        </button>
                        <button 
                            onClick={() => navigate(`/accounts/${account.id}/ledger`)} 
                            className="p-1.5 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                            title="View Ledger"
                        >
                            <FileSpreadsheet size={16} />
                        </button>
                    </div>
                </td>
            </motion.tr>
            <AnimatePresence>
                {isExpanded && hasChildren && account.children?.map(child => (
                    <AccountRow 
                        key={child.id} 
                        account={child} 
                        level={level + 1} 
                        onAdd={onAdd} 
                        onEdit={onEdit} 
                        searchQuery={searchQuery}
                    />
                ))}
            </AnimatePresence>
        </Fragment>
    );
};

const ChartOfAccounts: React.FC = () => {
    const { getAccounts, _version } = useData();
    const [accountsTree, setAccountsTree] = useState<Account[]>([]);
    const [searchQuery, setSearchQuery] = useState('');
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingAccount, setEditingAccount] = useState<Account | null>(null);
    const [parentForNewAccount, setParentForNewAccount] = useState<Account | null>(null);

    useEffect(() => {
        getAccounts().then(setAccountsTree);
    }, [_version]);

    const handleOpenModalForNew = (parent: Account | null = null) => {
        setParentForNewAccount(parent);
        setEditingAccount(null);
        setIsModalOpen(true);
    };

    const handleOpenModalForEdit = (account: Account) => {
        setEditingAccount(account);
        setParentForNewAccount(null);
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setEditingAccount(null);
        setParentForNewAccount(null);
    };

    return (
        <div className="space-y-6 pb-20">
            {/* Header & Actions */}
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
                        <LayoutList className="text-sky-500" />
                        Chart of Accounts
                    </h1>
                    <p className="text-sm text-slate-500">Manage your financial structure</p>
                </div>
                
                <div className="flex items-center gap-3 w-full md:w-auto">
                    <div className="relative flex-1 md:w-64">
                        <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                        <input 
                            type="text" 
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            placeholder="Search accounts..."
                            className="w-full h-11 bg-white/60 border border-white/50 rounded-xl shadow-sm pl-10 pr-4 text-sm focus:ring-2 focus:ring-sky-300/60 focus:outline-none transition"
                        />
                    </div>
                    <GlassButton variant="primary" onClick={() => handleOpenModalForNew(null)}>
                        <Plus size={18} className="mr-2" /> Add Root Account
                    </GlassButton>
                </div>
            </div>

            {/* Tree Table */}
            <GlassCard className="overflow-hidden min-h-[600px]" bodyClassName="p-0">
                <div className="overflow-x-auto">
                    <table className="w-full min-w-[800px] text-left border-collapse">
                        <thead>
                            <tr className="bg-slate-50/80 border-b border-slate-200/80 text-xs uppercase tracking-wider text-slate-500 font-semibold">
                                <th className="py-4 pl-6 pr-4 w-[50%]">Account Name</th>
                                <th className="px-4 py-4 w-[15%]">Type</th>
                                <th className="px-4 py-4 text-right w-[20%]">Balance</th>
                                <th className="px-4 py-4 text-right w-[15%]">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100/50">
                            {accountsTree.length > 0 ? (
                                accountsTree.map(account => (
                                    <AccountRow 
                                        key={account.id} 
                                        account={account} 
                                        level={0} 
                                        onAdd={handleOpenModalForNew} 
                                        onEdit={handleOpenModalForEdit} 
                                        searchQuery={searchQuery}
                                    />
                                ))
                            ) : (
                                <tr>
                                    <td colSpan={4} className="p-12 text-center text-slate-400">
                                        No accounts found. Start by adding a root account.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </GlassCard>

            <AddAccountModal
                isOpen={isModalOpen}
                onClose={handleCloseModal}
                editingAccount={editingAccount}
                parentAccount={parentForNewAccount}
            />
        </div>
    );
};

export default ChartOfAccounts;
