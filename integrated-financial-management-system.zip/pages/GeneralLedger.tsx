
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useLocation } from 'react-router-dom';
import { useData } from '../context/DataContext';
import { Transaction, Account, AccountCategory } from '../types';
import { motion, AnimatePresence } from 'framer-motion';
import { Calendar, Filter, Search, ChevronDown, ArrowUp, ArrowDown, FileText, FileSpreadsheet, Expand, X } from 'lucide-react';

// --- TYPE DEFINITIONS ---
interface LedgerRowData {
    id: string;
    date: Date;
    accountId: string;
    accountCode: string;
    accountName: string;
    accountCategory: AccountCategory;
    description: string;
    reference: string;
    debit: number;
    credit: number;
    runningBalance: number;
}

type SortConfig = {
    key: keyof LedgerRowData;
    direction: 'ascending' | 'descending';
};

// --- HELPER FUNCTIONS ---
const formatCurrency = (value: number) => {
    const isNegative = value < 0;
    const formatted = new Intl.NumberFormat('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    }).format(Math.abs(value));
    return isNegative ? `(${formatted})` : formatted;
};

// --- UI COMPONENTS ---

const Header: React.FC<{
    startDate: string; setStartDate: (d: string) => void;
    endDate: string; setEndDate: (d: string) => void;
    onDatePreset: (preset: string) => void;
    searchQuery: string; setSearchQuery: (q: string) => void;
    categoryFilter: Set<AccountCategory>; setCategoryFilter: (c: Set<AccountCategory>) => void;
}> = ({ startDate, setStartDate, endDate, setEndDate, onDatePreset, searchQuery, setSearchQuery, categoryFilter, setCategoryFilter }) => {
    
    const [isFilterOpen, setIsFilterOpen] = useState(false);

    const handleCategoryToggle = (category: AccountCategory) => {
        const newSet = new Set(categoryFilter);
        if (newSet.has(category)) {
            newSet.delete(category);
        } else {
            newSet.add(category);
        }
        setCategoryFilter(newSet);
    };
    
    return (
        <div className="relative z-30 bg-white/60 backdrop-blur-xl border border-white/50 rounded-2xl shadow-sm p-4 flex flex-col lg:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
                <Calendar className="text-slate-500" size={20} />
                <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="h-10 bg-white/70 border border-white/50 rounded-lg shadow-inner px-3 text-sm text-slate-800 focus:ring-1 focus:ring-sky-300/60 focus:outline-none" />
                <span className="text-slate-500">-</span>
                <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className="h-10 bg-white/70 border border-white/50 rounded-lg shadow-inner px-3 text-sm text-slate-800 focus:ring-1 focus:ring-sky-300/60 focus:outline-none" />
            </div>
            <div className="flex items-center gap-2">
                {['This Month', 'Last Month', 'This Quarter', 'This Year'].map(preset => (
                    <button key={preset} onClick={() => onDatePreset(preset)} className="px-3 py-1.5 text-xs font-semibold text-slate-600 rounded-lg hover:bg-white/50 transition-colors">{preset}</button>
                ))}
            </div>
            <div className="flex items-center gap-4">
                <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                    <input type="text" value={searchQuery} onChange={e => setSearchQuery(e.target.value)} placeholder="Search..." className="h-10 bg-white/70 border border-white/50 rounded-lg shadow-inner pl-9 pr-4 text-sm text-slate-800 focus:ring-1 focus:ring-sky-300/60 focus:outline-none" />
                </div>
                <div className="relative">
                    <button onClick={() => setIsFilterOpen(!isFilterOpen)} className="flex items-center gap-2 px-3 py-1.5 text-sm font-semibold text-slate-700 bg-white/50 rounded-lg border border-white/40 hover:bg-white/70 transition-colors h-10">
                        <Filter size={16} />
                        <span>Filter</span>
                        <ChevronDown size={16} className={`transition-transform ${isFilterOpen ? 'rotate-180' : ''}`} />
                         {categoryFilter.size > 0 && <div className="absolute -top-1 -right-1 w-4 h-4 bg-sky-500 text-white text-xs rounded-full flex items-center justify-center">{categoryFilter.size}</div>}
                    </button>
                    <AnimatePresence>
                    {isFilterOpen && (
                        <motion.div initial={{opacity: 0, y: -10}} animate={{opacity: 1, y: 0}} exit={{opacity: 0, y: -10}} className="absolute top-full right-0 mt-2 w-56 bg-white/80 backdrop-blur-lg border border-white/50 rounded-lg shadow-2xl p-2">
                            {Object.values(AccountCategory).map(cat => (
                                <label key={cat} className="flex items-center gap-2 p-2 rounded hover:bg-sky-100/50 cursor-pointer">
                                    <input type="checkbox" checked={categoryFilter.has(cat)} onChange={() => handleCategoryToggle(cat)} className="h-4 w-4 rounded border-slate-300 text-sky-500 focus:ring-sky-500"/>
                                    <span className="text-sm text-slate-700">{cat}</span>
                                </label>
                            ))}
                        </motion.div>
                    )}
                    </AnimatePresence>
                </div>
            </div>
        </div>
    );
};

const SummaryCard: React.FC<{ title: string; value: number; colorClass: string; }> = ({ title, value, colorClass }) => (
    <div className="bg-white/60 backdrop-blur-xl border border-white/50 rounded-2xl shadow-sm p-4 md:p-3 lg:p-4">
        <p className="text-xs lg:text-sm font-medium text-slate-500">{title}</p>
        <p className={`text-xl lg:text-2xl font-bold font-mono mt-1 ${colorClass}`}>{formatCurrency(value)}</p>
    </div>
);

const LedgerTableContent: React.FC<{
    paginatedRows: LedgerRowData[];
    isLoading: boolean;
    sortConfig: SortConfig;
    handleSort: (key: keyof LedgerRowData) => void;
    currentPage: number;
    totalPages: number;
    setCurrentPage: React.Dispatch<React.SetStateAction<number>>;
    totalRows: number;
    rowsPerPage: number;
    isExpanded: boolean;
    onExpandClick?: () => void;
    onCloseClick?: () => void;
}> = ({
    paginatedRows, isLoading, sortConfig, handleSort, currentPage, totalPages, setCurrentPage,
    totalRows, rowsPerPage, isExpanded, onExpandClick, onCloseClick
}) => {
    return (
        <div className="flex-1 flex flex-col overflow-hidden">
             <div className="flex-shrink-0 flex items-center justify-between p-3 border-b border-white/50">
                <h3 className="font-semibold text-slate-700 px-1">Transactions</h3>
                {isExpanded ? (
                    <button onClick={onCloseClick} className="p-2 rounded-lg text-slate-500 hover:bg-slate-200/50" title="Close"><X size={18} /></button>
                ) : (
                    onExpandClick && <button onClick={onExpandClick} className="p-2 rounded-lg text-slate-500 hover:bg-slate-200/50" title="Expand View"><Expand size={18} /></button>
                )}
            </div>
            <div className="flex-1 overflow-auto">
                <table className="w-full min-w-[1200px] text-sm">
                    <thead className="sticky top-0 bg-white/70 backdrop-blur-md z-10">
                        <tr>
                            {['date', 'accountName', 'description', 'reference', 'debit', 'credit', 'runningBalance'].map(key => (
                                <th key={key} className="px-4 py-3 text-left text-xs font-semibold tracking-wider text-slate-500 uppercase">
                                    <button onClick={() => handleSort(key as keyof LedgerRowData)} className="flex items-center gap-2 group">
                                        {key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}
                                        {sortConfig.key === key && (sortConfig.direction === 'ascending' ? <ArrowUp size={14} className="opacity-50 group-hover:opacity-100" /> : <ArrowDown size={14} className="opacity-50 group-hover:opacity-100" />)}
                                    </button>
                                </th>
                            ))}
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200/70">
                        {isLoading ? (
                            <tr><td colSpan={7} className="text-center py-10 text-slate-500">Loading transactions...</td></tr>
                        ) : paginatedRows.length === 0 ? (
                            <tr><td colSpan={7} className="text-center py-10 text-slate-500">No transactions found for the selected criteria.</td></tr>
                        ) : paginatedRows.map(row => (
                            <tr key={row.id} className="hover:bg-sky-100/40 transition-colors">
                                <td className="px-4 py-3 text-slate-600">{row.date.toLocaleDateString()}</td>
                                <td className="px-4 py-3">
                                    <div className="font-semibold text-slate-800">{row.accountName}</div>
                                    <div className="text-xs text-slate-500 font-mono">{row.accountCode}</div>
                                </td>
                                <td className="px-4 py-3 text-slate-700 max-w-sm truncate" title={row.description}>{row.description}</td>
                                <td className="px-4 py-3 font-mono text-slate-500">{row.reference}</td>
                                <td className="px-4 py-3 font-mono text-rose-600 text-right">{row.debit > 0 ? formatCurrency(row.debit) : '-'}</td>
                                <td className="px-4 py-3 font-mono text-emerald-600 text-right">{row.credit > 0 ? formatCurrency(row.credit) : '-'}</td>
                                <td className="px-4 py-3 font-mono font-semibold text-slate-700 text-right">{formatCurrency(row.runningBalance)}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            <div className="flex-shrink-0 flex items-center justify-between p-3 border-t border-white/50 text-xs text-slate-500">
                <span>Showing {(currentPage - 1) * rowsPerPage + 1} - {Math.min(currentPage * rowsPerPage, totalRows)} of {totalRows}</span>
                <span>Page {currentPage} of {totalPages || 1}</span>
                <div className="flex gap-2">
                    <button onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={currentPage === 1} className="px-3 py-1.5 rounded-lg bg-white/40 hover:bg-white/60 border border-white/50 disabled:opacity-40 disabled:cursor-not-allowed">Prev</button>
                    <button onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages} className="px-3 py-1.5 rounded-lg bg-white/40 hover:bg-white/60 border border-white/50 disabled:opacity-40 disabled:cursor-not-allowed">Next</button>
                </div>
            </div>
        </div>
    );
};


const GeneralLedger: React.FC = () => {
    const { getTransactions, getAccountsList, _version } = useData();
    const location = useLocation();
    const [isLoading, setIsLoading] = useState(true);
    
    // Raw Data State
    const [allTransactions, setAllTransactions] = useState<Transaction[]>([]);
    const [accountMap, setAccountMap] = useState<Map<string, Account>>(new Map());

    // Filter & UI State
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');
    const [searchQuery, setSearchQuery] = useState('');
    const [categoryFilter, setCategoryFilter] = useState<Set<AccountCategory>>(new Set());
    const [sortConfig, setSortConfig] = useState<SortConfig>({ key: 'date', direction: 'ascending' });
    const [currentPage, setCurrentPage] = useState(1);
    const [isExpandedView, setIsExpandedView] = useState(false);

    const rowsPerPage = isExpandedView ? 50 : 20;

    const setDatePreset = useCallback((preset: string) => {
        const now = new Date();
        let start = new Date(), end = new Date();
        switch (preset) {
            case 'This Month': start = new Date(now.getFullYear(), now.getMonth(), 1); end = new Date(now.getFullYear(), now.getMonth() + 1, 0); break;
            case 'Last Month': start = new Date(now.getFullYear(), now.getMonth() - 1, 1); end = new Date(now.getFullYear(), now.getMonth(), 0); break;
            case 'This Quarter': const quarter = Math.floor(now.getMonth() / 3); start = new Date(now.getFullYear(), quarter * 3, 1); end = new Date(now.getFullYear(), quarter * 3 + 3, 0); break;
            case 'This Year': start = new Date(now.getFullYear(), 0, 1); end = new Date(now.getFullYear(), 11, 31); break;
        }
        setStartDate(start.toISOString().split('T')[0]);
        setEndDate(end.toISOString().split('T')[0]);
    }, []);

    useEffect(() => { 
        if (!location.state?.startDate) {
            setDatePreset('This Month'); 
        }
    }, [setDatePreset, location.state]);
    
    useEffect(() => {
        setIsLoading(true);
        Promise.all([getTransactions(), getAccountsList()]).then(([txns, accs]) => {
            setAllTransactions(txns);
            const accMap = new Map(accs.map(a => [a.id, a]));
            setAccountMap(accMap);
            
            // Handle drill-down state from navigation
            if (location.state?.selectedAccountId) {
                const account = accMap.get(location.state.selectedAccountId);
                if (account) {
                    setSearchQuery(account.code);
                }
            }
            if (location.state?.startDate) {
                setStartDate(location.state.startDate);
            }
            if (location.state?.endDate) {
                setEndDate(location.state.endDate);
            }

            setIsLoading(false);
        });
    }, [_version, location.state]);

    const processedData = useMemo<{
        ledgerRows: LedgerRowData[],
        totalDebit: number,
        totalCredit: number,
        netMovement: number
    }>(() => {
        if (!startDate || !endDate || accountMap.size === 0) {
            return { ledgerRows: [], totalDebit: 0, totalCredit: 0, netMovement: 0 };
        }

        const start = new Date(startDate); start.setHours(0,0,0,0);
        const end = new Date(endDate); end.setHours(23,59,59,999);
        
        const openingBalances = new Map<string, number>();
        allTransactions.forEach(tx => {
            const txDate = new Date(tx.date);
            if (txDate < start) {
                const account = accountMap.get(tx.accountId);
                if (account) {
                    const isDebitNature = [AccountCategory.Asset, AccountCategory.COGS, AccountCategory.OperatingExpense].includes(account.category);
                    const amount = isDebitNature ? (tx.type === 'Debit' ? tx.amount : -tx.amount) : (tx.type === 'Credit' ? tx.amount : -tx.amount);
                    openingBalances.set(tx.accountId, (openingBalances.get(tx.accountId) || 0) + amount);
                }
            }
        });
        
        let periodTransactions = allTransactions.filter(tx => {
            const txDate = new Date(tx.date);
            const account = accountMap.get(tx.accountId);
            if (!account || txDate < start || txDate > end) return false;
            if (categoryFilter.size > 0 && !categoryFilter.has(account.category)) return false;
            if (searchQuery && !(tx.description.toLowerCase().includes(searchQuery.toLowerCase()) || tx.receiptNumber?.toLowerCase().includes(searchQuery.toLowerCase()) || account.name.toLowerCase().includes(searchQuery.toLowerCase()) || account.code.includes(searchQuery))) return false;
            return true;
        });

        periodTransactions.sort((a, b) => {
            const aAccount = accountMap.get(a.accountId);
            const bAccount = accountMap.get(b.accountId);
            let aVal, bVal;

            if (sortConfig.key === 'date') {
                const aTime = new Date(a.date).getTime();
                const bTime = new Date(b.date).getTime();
                if(aTime !== bTime) return aTime - bTime;
                return (a.voucherNumber || '').localeCompare(b.voucherNumber || '');
            }
             if (sortConfig.key === 'accountName') {
                aVal = aAccount?.name || '';
                bVal = bAccount?.name || '';
            } else {
                aVal = a[sortConfig.key as keyof Transaction] || '';
                bVal = b[sortConfig.key as keyof Transaction] || '';
            }

            if (aVal < bVal) return sortConfig.direction === 'ascending' ? -1 : 1;
            if (aVal > bVal) return sortConfig.direction === 'ascending' ? 1 : -1;
            return 0;
        });

        if (sortConfig.direction === 'descending') periodTransactions.reverse();

        const runningBalances = new Map<string, number>(openingBalances);
        let totalDebit = 0;
        let totalCredit = 0;
        
        const ledgerRows: LedgerRowData[] = periodTransactions.map(tx => {
            const account = accountMap.get(tx.accountId)!;
            const isDebitNature = [AccountCategory.Asset, AccountCategory.COGS, AccountCategory.OperatingExpense].includes(account.category);
            const currentBalance = runningBalances.get(tx.accountId) || 0;
            const amount = isDebitNature ? (tx.type === 'Debit' ? tx.amount : -tx.amount) : (tx.type === 'Credit' ? tx.amount : -tx.amount);
            const newBalance = currentBalance + amount;
            runningBalances.set(tx.accountId, newBalance);

            if (tx.type === 'Debit') totalDebit += tx.amount;
            else totalCredit += tx.amount;

            return {
                id: tx.id,
                date: new Date(tx.date),
                accountId: tx.accountId,
                accountCode: account.code,
                accountName: account.name,
                accountCategory: account.category,
                description: tx.description,
                reference: tx.voucherNumber,
                debit: tx.type === 'Debit' ? tx.amount : 0,
                credit: tx.type === 'Credit' ? tx.amount : 0,
                runningBalance: newBalance,
            };
        });

        return { ledgerRows, totalDebit, totalCredit, netMovement: totalDebit - totalCredit };

    }, [allTransactions, accountMap, startDate, endDate, searchQuery, categoryFilter, sortConfig]);

    const paginatedRows = useMemo(() => {
        const start = (currentPage - 1) * rowsPerPage;
        return processedData.ledgerRows.slice(start, start + rowsPerPage);
    }, [processedData.ledgerRows, currentPage, rowsPerPage]);

    const totalPages = Math.ceil(processedData.ledgerRows.length / rowsPerPage);

    const handleSort = (key: keyof LedgerRowData) => {
        const direction = (sortConfig.key === key && sortConfig.direction === 'ascending') ? 'descending' : 'ascending';
        setSortConfig({ key, direction });
    };

    const handleExport = (format: 'excel' | 'pdf') => {
        if (format === 'excel') {
            const XLSX = (window as any).XLSX;
            if (!XLSX) { alert("Excel export library is not available."); return; }
            const dataToExport = processedData.ledgerRows.map(row => ({
                Date: row.date.toLocaleDateString(), 'Account Code': row.accountCode, 'Account Name': row.accountName,
                Description: row.description, Reference: row.reference, Debit: row.debit || null,
                Credit: row.credit || null, 'Running Balance': row.runningBalance
            }));
            const worksheet = XLSX.utils.json_to_sheet(dataToExport);
            const workbook = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(workbook, worksheet, 'GeneralLedger');
            XLSX.writeFile(workbook, `GeneralLedger_${endDate}.xlsx`);
        } else {
            const { jsPDF } = (window as any).jspdf;
            if (!jsPDF) { alert("PDF export library is not available."); return; }
            const doc = new jsPDF({ orientation: 'landscape' });
            
            const pageWidth = doc.internal.pageSize.getWidth();
            const pageHeight = doc.internal.pageSize.getHeight();
            const margin = 15;

            const summaryStats = [
                { title: 'Total Debits', value: processedData.totalDebit, color: '#e11d48' },
                { title: 'Total Credits', value: processedData.totalCredit, color: '#16a34a' },
                { title: 'Net Movement', value: processedData.netMovement, color: '#475569' },
                { title: '# Transactions', value: processedData.ledgerRows.length, color: '#0ea5e9' }
            ];

            const header = (data: any) => {
                // Main Header
                doc.setFillColor(15, 23, 42); // slate-900
                doc.rect(0, 0, pageWidth, 25, 'F');
                doc.setFontSize(16);
                doc.setTextColor(255, 255, 255);
                doc.setFont('helvetica', 'bold');
                doc.text('General Ledger Report', margin, 15);
                
                doc.setFontSize(10);
                doc.setFont('helvetica', 'normal');
                doc.setTextColor(203, 213, 225); // slate-300
                doc.text(`For the period: ${startDate} to ${endDate}`, pageWidth - margin, 15, { align: 'right' });
            };
            
            const footer = (data: any) => {
                const pageCount = doc.internal.getNumberOfPages();
                doc.setFontSize(8);
                doc.setTextColor(100, 116, 139); // slate-500
                doc.text(`Page ${data.pageNumber} of ${pageCount}`, pageWidth / 2, pageHeight - 10, { align: 'center' });
                doc.text(`Generated on: ${new Date().toLocaleString()}`, margin, pageHeight - 10);
                doc.text(`FMS Analytics`, pageWidth - margin, pageHeight - 10, { align: 'right' });
            };

            // Summary Cards
            let cardX = margin;
            const cardY = 35;
            const cardWidth = (pageWidth - margin * 2 - 10 * 3) / 4;
            const cardHeight = 25;

            summaryStats.forEach(stat => {
                doc.setFillColor(248, 250, 252); // slate-50
                doc.setDrawColor(226, 232, 240); // slate-200
                doc.roundedRect(cardX, cardY, cardWidth, cardHeight, 3, 3, 'FD');

                doc.setFontSize(9);
                doc.setTextColor(100, 116, 139); // slate-500
                doc.text(stat.title, cardX + 5, cardY + 8);

                doc.setFontSize(14);
                doc.setFont('helvetica', 'bold');
                doc.setTextColor(stat.color);
                const valueText = stat.title === '# Transactions' ? stat.value.toString() : formatCurrency(stat.value);
                doc.text(valueText, cardX + 5, cardY + 18);

                cardX += cardWidth + 10;
            });
            
            const bodyData = processedData.ledgerRows.map(row => ([
                row.date.toLocaleDateString(),
                `${row.accountCode}\n${row.accountName}`,
                row.description,
                row.reference,
                row.debit > 0 ? formatCurrency(row.debit) : '-',
                row.credit > 0 ? formatCurrency(row.credit) : '-',
                formatCurrency(row.runningBalance)
            ]));

            (doc as any).autoTable({
                startY: cardY + cardHeight + 10,
                head: [['Date', 'Account', 'Description', 'Reference', 'Debit', 'Credit', 'Balance']],
                body: bodyData,
                theme: 'grid',
                headStyles: { 
                    fillColor: [45, 55, 72], // gray-700
                    textColor: [255, 255, 255],
                    fontStyle: 'bold'
                },
                foot: [['', '', '', 'Total', formatCurrency(processedData.totalDebit), formatCurrency(processedData.totalCredit), '']],
                footStyles: { fontStyle: 'bold', fillColor: [241, 245, 249] },
                alternateRowStyles: { fillColor: [248, 250, 252] },
                didDrawPage: (data: any) => {
                    header(data);
                    footer(data);
                },
                didParseCell: (data: any) => {
                    if (data.section === 'body') {
                        // Debit column
                        if (data.column.index === 4 && data.cell.raw !== '-') {
                            data.cell.styles.textColor = '#e11d48';
                        }
                        // Credit column
                        if (data.column.index === 5 && data.cell.raw !== '-') {
                            data.cell.styles.textColor = '#16a34a';
                        }
                         // Balance column
                        if (data.column.index === 6) {
                            data.cell.styles.fontStyle = 'bold';
                        }
                    }
                },
                columnStyles: {
                    4: { halign: 'right' },
                    5: { halign: 'right' },
                    6: { halign: 'right' }
                },
                margin: { top: 28, bottom: 20 }
            });

            doc.save(`GeneralLedger_${endDate}.pdf`);
        }
    };
    
    useEffect(() => {
        setCurrentPage(1);
    }, [searchQuery, categoryFilter, startDate, endDate, rowsPerPage]);

    return (
        <div className="flex flex-col h-full space-y-4">
            <Header 
                startDate={startDate} setStartDate={setStartDate} 
                endDate={endDate} setEndDate={setEndDate}
                onDatePreset={setDatePreset}
                searchQuery={searchQuery} setSearchQuery={setSearchQuery}
                categoryFilter={categoryFilter} setCategoryFilter={setCategoryFilter}
            />
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <SummaryCard title="Total Debits" value={processedData.totalDebit} colorClass="text-rose-600" />
                <SummaryCard title="Total Credits" value={processedData.totalCredit} colorClass="text-emerald-600" />
                <SummaryCard title="Net Movement" value={processedData.netMovement} colorClass={processedData.netMovement >= 0 ? 'text-slate-800 dark:text-slate-200' : 'text-rose-600'} />
                <SummaryCard title="# Transactions" value={processedData.ledgerRows.length} colorClass="text-sky-600" />
            </div>

            <div className="bg-white/65 backdrop-blur-xl border border-white/50 rounded-2xl shadow-[0_10px_40px_rgba(0,0,0,0.06)] flex-1 flex flex-col overflow-hidden">
                <LedgerTableContent 
                    paginatedRows={paginatedRows}
                    isLoading={isLoading}
                    sortConfig={sortConfig}
                    handleSort={handleSort}
                    currentPage={currentPage}
                    totalPages={totalPages}
                    setCurrentPage={setCurrentPage}
                    totalRows={processedData.ledgerRows.length}
                    rowsPerPage={rowsPerPage}
                    isExpanded={false}
                    onExpandClick={() => setIsExpandedView(true)}
                />
            </div>
            
            <motion.div
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.5, type: 'spring', stiffness: 100 }}
                className="fixed bottom-6 right-6 z-40"
            >
                <div className="bg-white/70 backdrop-blur-md border border-white/50 rounded-full shadow-lg flex items-center gap-1 p-2">
                    <button onClick={() => handleExport('excel')} className="flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold text-emerald-800 hover:bg-emerald-100/50 transition-colors" title="Export to Excel">
                        <FileSpreadsheet size={16} />
                        <span>Excel</span>
                    </button>
                    <button onClick={() => handleExport('pdf')} className="flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold text-sky-800 hover:bg-sky-100/50 transition-colors" title="Export to PDF">
                        <FileText size={16} />
                        <span>PDF</span>
                    </button>
                </div>
            </motion.div>

            <AnimatePresence>
                {isExpandedView && (
                    <motion.div
                        className="fixed inset-0 z-50 bg-slate-100/50 dark:bg-slate-900/50 backdrop-blur-sm p-4"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        onClick={() => setIsExpandedView(false)}
                    >
                        <motion.div
                            className="bg-white/65 backdrop-blur-xl border border-white/50 rounded-2xl shadow-2xl w-full h-full flex flex-col overflow-hidden"
                            initial={{ scale: 0.95 }}
                            animate={{ scale: 1 }}
                            exit={{ scale: 0.95 }}
                            onClick={e => e.stopPropagation()}
                        >
                             <LedgerTableContent 
                                paginatedRows={paginatedRows}
                                isLoading={isLoading}
                                sortConfig={sortConfig}
                                handleSort={handleSort}
                                currentPage={currentPage}
                                totalPages={totalPages}
                                setCurrentPage={setCurrentPage}
                                totalRows={processedData.ledgerRows.length}
                                rowsPerPage={rowsPerPage}
                                isExpanded={true}
                                onCloseClick={() => setIsExpandedView(false)}
                            />
                        </motion.div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
};

export default GeneralLedger;
