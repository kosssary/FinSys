
import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Calendar, RefreshCw, ChevronDown, FileText, FileSpreadsheet } from 'lucide-react';
import { useData } from '../context/DataContext';
import { CashFlowStatementData } from '../types';

// --- TYPES ---
interface ReportRowItem {
    label: string;
    value: number;
    accountId?: string;
    isSubItem?: boolean;
    isHeader?: boolean;
}

// --- HELPER FUNCTIONS ---
const formatCurrency = (value: number) => {
    const isNegative = value < 0;
    const formatted = new Intl.NumberFormat('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    }).format(Math.abs(value));
    return isNegative ? `(${formatted})` : formatted;
};

// --- UI COMPONENTS ---
const CashMovementAnalysis: React.FC<{ data: CashFlowStatementData }> = ({ data }) => {
    const [lang, setLang] = useState<'en' | 'ku' | 'ar'>('en');
    const { operating, investing, financing, summary } = data;
    const increased = summary.netChange >= 0;

    const summaries = {
        en: {
            position: `During this period, the company's total cash ${increased ? 'increased' : 'decreased'} by ${formatCurrency(summary.netChange)}, moving from a starting balance of ${formatCurrency(summary.cashAtBeginning)} to an ending balance of ${formatCurrency(summary.cashAtEnd)}.`,
            ops_positive: `The core business operations were cash-positive, generating ${formatCurrency(operating.total)}. This indicates a healthy ability to generate cash from our main activities.`,
            ops_negative: `The core business operations were cash-negative, consuming ${formatCurrency(Math.abs(operating.total))}. This suggests that while we may be profitable on paper, our daily activities are using more cash than they are bringing in.`,
            invest_finance: `We invested ${formatCurrency(Math.abs(investing.total))} in new assets and ${financing.total >= 0 ? 'raised' : 'paid'} ${formatCurrency(Math.abs(financing.total))} through financing activities.`
        },
        ku: {
            position: `لەم ماوەیەدا، کۆی پارەی نەختینەی کۆمپانیا بە بڕی ${formatCurrency(summary.netChange)} ${increased ? 'زیادیکرد' : 'کەمیکرد'}، لە باڵانسی سەرەتایی ${formatCurrency(summary.cashAtBeginning)} گەیشتە باڵانسی کۆتایی ${formatCurrency(summary.cashAtEnd)}.`,
            ops_positive: `چالاکییە سەرەکییەکانی کارکردن داهاتی نەختینەیی ئەرێنی بوو، بە بەرهەمهێنانی ${formatCurrency(operating.total)}. ئەمە نیشانەی توانایەکی تەندروستە بۆ بەرهەمهێنانی پارەی نەختینە لە چالاکییە سەرەکییەکانمانەوە.`,
            ops_negative: `چالاکییە سەرەکییەکانی کارکردن داهاتی نەختینەیی نەرێنی بوو، بە بەکارهێنانی ${formatCurrency(Math.abs(operating.total))}. ئەمە پێشنیاری ئەوە دەکات کە چالاکییە ڕۆژانەکانمان پارەی زیاتر بەکاردەهێنن لەوەی دەیهێنن.`,
            invest_finance: `ئێمە بڕی ${formatCurrency(Math.abs(investing.total))}مان لە دارایی نوێدا وەبەرهێنا و بڕی ${formatCurrency(Math.abs(financing.total))}مان لە ڕێگەی چالاکییەکانی داراییەوە ${financing.total >= 0 ? 'بەدەستهێنا' : 'دا'}.`
        },
        ar: {
            position: `خلال هذه الفترة، إجمالي النقد للشركة ${increased ? 'زاد' : 'انخفض'} بمقدار ${formatCurrency(summary.netChange)}، منتقلاً من رصيد افتتاحي قدره ${formatCurrency(summary.cashAtBeginning)} إلى رصيد ختامي قدره ${formatCurrency(summary.cashAtEnd)}.`,
            ops_positive: `كانت العمليات التجارية الأساسية إيجابية من حيث التدفق النقدي، حيث ولّدت ${formatCurrency(operating.total)}. وهذا يشير إلى قدرة صحية على توليد النقد من أنشطتنا الرئيسية.`,
            ops_negative: `كانت العمليات التجارية الأساسية سلبية من حيث التدفق النقدي، حيث استهلكت ${formatCurrency(Math.abs(operating.total))}. وهذا يشير إلى أن أنشطتنا اليومية تستخدم نقداً أكثر مما تجلبه.`,
            invest_finance: `استثمرنا ${formatCurrency(Math.abs(investing.total))} في أصول جديدة وقمنا بـ ${financing.total >= 0 ? 'جمع' : 'دفع'} ${formatCurrency(Math.abs(financing.total))} من خلال أنشطة التمويل.`
        }
    };
    
    const currentSummary = summaries[lang];

    return (
        <div className="bg-white/60 backdrop-blur-xl border border-white/50 rounded-2xl shadow-sm p-6 mb-4 relative">
            <div className="flex justify-between items-start">
                 <h2 className="text-lg font-bold text-slate-800">Cash Movement Analysis <span className="font-normal text-slate-500">(شیکردنەوەی جوڵەی پارە)</span></h2>
                <div className="flex items-center gap-1 bg-slate-200/50 dark:bg-slate-700/50 p-1 rounded-md">
                    <button onClick={() => setLang('en')} className={`px-2 py-0.5 text-xs font-bold rounded ${lang === 'en' ? 'bg-white dark:bg-slate-800 text-sky-600' : 'text-slate-500'}`}>EN</button>
                    <button onClick={() => setLang('ku')} className={`px-2 py-0.5 text-xs font-bold rounded ${lang === 'ku' ? 'bg-white dark:bg-slate-800 text-sky-600' : 'text-slate-500'}`}>KU</button>
                    <button onClick={() => setLang('ar')} className={`px-2 py-0.5 text-xs font-bold rounded ${lang === 'ar' ? 'bg-white dark:bg-slate-800 text-sky-600' : 'text-slate-500'}`}>AR</button>
                </div>
            </div>
            <div dir={lang === 'ar' || lang === 'ku' ? 'rtl' : 'ltr'} className="mt-4 space-y-2 text-sm text-slate-600">
                <p>
                    {currentSummary.position.split(formatCurrency(summary.netChange))[0]}
                    <strong className={increased ? 'text-emerald-600' : 'text-rose-600'}>{formatCurrency(summary.netChange)}</strong>
                    {currentSummary.position.split(formatCurrency(summary.netChange))[1]}
                </p>
                <p>{operating.total >= 0 ? currentSummary.ops_positive : currentSummary.ops_negative}</p>
                <p>{currentSummary.invest_finance}</p>
            </div>
        </div>
    );
};


const Header: React.FC<{
    startDate: string; setStartDate: (d: string) => void;
    endDate: string; setEndDate: (d: string) => void;
    onDatePreset: (preset: string) => void;
    onRefresh: () => void;
    isLoading: boolean;
}> = ({ startDate, setStartDate, endDate, setEndDate, onDatePreset, onRefresh, isLoading }) => {
    return (
        <div className="relative z-10 bg-white/60 backdrop-blur-xl border border-white/50 rounded-2xl shadow-sm p-4 flex flex-col lg:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
                <Calendar className="text-slate-500" size={20} />
                <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="h-10 bg-white/70 border border-white/50 rounded-lg shadow-inner px-3 text-sm text-slate-800 focus:ring-1 focus:ring-sky-300/60 focus:outline-none" />
                <span className="text-slate-500">-</span>
                <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className="h-10 bg-white/70 border border-white/50 rounded-lg shadow-inner px-3 text-sm text-slate-800 focus:ring-1 focus:ring-sky-300/60 focus:outline-none" />
            </div>
            <div className="flex items-center gap-2">
                {['This Quarter', 'This Year', 'Last Year'].map(preset => (
                    <button key={preset} onClick={() => onDatePreset(preset)} className="px-3 py-1.5 text-xs font-semibold text-slate-600 rounded-lg hover:bg-white/50 transition-colors">{preset}</button>
                ))}
            </div>
            <button onClick={onRefresh} disabled={isLoading} className="h-10 px-4 flex items-center gap-2 text-sm font-semibold text-slate-700 bg-white/50 rounded-lg border border-white/40 hover:bg-white/70 transition-colors disabled:opacity-50">
                <RefreshCw size={14} className={isLoading ? 'animate-spin' : ''} />
                <span>Refresh</span>
            </button>
        </div>
    );
};

const SummaryCard: React.FC<{ title: string; value: number; colorClass: string; }> = ({ title, value, colorClass }) => (
    <div className="bg-white/60 backdrop-blur-xl border border-white/50 rounded-2xl shadow-sm p-4 md:p-3 lg:p-4">
        <p className="text-xs lg:text-sm font-medium text-slate-500">{title}</p>
        <p className={`text-xl lg:text-2xl font-bold font-mono mt-1 ${colorClass}`}>{formatCurrency(value)}</p>
    </div>
);

const ReportRow: React.FC<{ item: ReportRowItem; onDrillDown: (accountId: string, label: string) => void; }> = ({ item, onDrillDown }) => {
    const canDrillDown = !!item.accountId;
    const content = (
        <div className={`flex justify-between py-2 border-b border-slate-200/50 ${item.isSubItem ? 'pl-6' : ''}`}>
            <span className={`text-sm ${item.isHeader && item.value === 0 ? 'font-bold text-slate-600' : 'text-slate-700'}`}>
                {item.label}
            </span>
            {/* Only hide value if it's a header AND the value is zero (for the 'Adjustments' title) */}
            {!(item.isHeader && item.value === 0) && (
                <span className={`font-mono text-sm ${item.isHeader ? 'font-bold' : ''} ${item.value < 0 ? 'text-rose-600' : 'text-slate-800'}`}>
                    {formatCurrency(item.value)}
                </span>
            )}
        </div>
    );

    if (canDrillDown) {
        return <button onClick={() => onDrillDown(item.accountId!, item.label)} className="w-full text-left hover:bg-sky-100/30 rounded-md transition-colors">{content}</button>;
    }
    return content;
};

const ReportSection: React.FC<{ title: string; total: number; items: ReportRowItem[]; onDrillDown: (accountId: string, label: string) => void }> = ({ title, total, items, onDrillDown }) => {
    const [isExpanded, setIsExpanded] = useState(true);
    return (
        <div className="bg-white/65 backdrop-blur-xl border border-white/50 rounded-2xl shadow-sm overflow-hidden">
            <button onClick={() => setIsExpanded(!isExpanded)} className="w-full flex justify-between items-center p-4 bg-slate-100/60 dark:bg-slate-800/30 hover:bg-slate-200/60 dark:hover:bg-slate-700/30 border-b border-white/60 dark:border-black/20 transition-colors">
                <h3 className="font-bold text-slate-800">{title}</h3>
                <div className="flex items-center gap-4">
                    <span className="font-mono font-bold text-lg text-sky-700">{formatCurrency(total)}</span>
                    <ChevronDown size={20} className={`text-slate-500 transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
                </div>
            </button>
            <AnimatePresence>
                {isExpanded && (
                    <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
                        <div className="p-4">
                            {items.map((item, index) => <ReportRow key={index} item={item} onDrillDown={onDrillDown} />)}
                            <div className="flex justify-between pt-3 mt-2">
                                <span className="font-bold text-sm text-slate-800">Net Cash from {title.split(' ')[0]} Activities</span>
                                <span className={`font-mono font-bold text-sm ${total < 0 ? 'text-rose-600' : 'text-slate-800'}`}>{formatCurrency(total)}</span>
                            </div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
};

// --- MAIN PAGE COMPONENT ---
const CashFlowStatement: React.FC = () => {
    const { getCashFlowStatement, _version } = useData();
    const navigate = useNavigate();
    const [isLoading, setIsLoading] = useState(true);
    const [data, setData] = useState<CashFlowStatementData | null>(null);

    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');

    const setDatePreset = useCallback((preset: string) => {
        const now = new Date();
        let start = new Date(), end = new Date();
        switch (preset) {
            case 'This Quarter': const quarter = Math.floor(now.getMonth() / 3); start = new Date(now.getFullYear(), quarter * 3, 1); end = new Date(now.getFullYear(), quarter * 3 + 3, 0); break;
            case 'Last Year': start = new Date(now.getFullYear() - 1, 0, 1); end = new Date(now.getFullYear() - 1, 11, 31); break;
            case 'This Year': default: start = new Date(now.getFullYear(), 0, 1); end = new Date(); break;
        }
        setStartDate(start.toISOString().split('T')[0]);
        setEndDate(end.toISOString().split('T')[0]);
    }, []);

    useEffect(() => { setDatePreset('This Year'); }, [setDatePreset]);
    
    const fetchData = useCallback(async () => {
        if (!startDate || !endDate) return;
        setIsLoading(true);
        try {
            const result = await getCashFlowStatement(startDate, endDate);
            setData(result);
        } catch (e) {
            console.error("Failed to fetch cash flow data:", e);
            setData(null);
        } finally {
            setIsLoading(false);
        }
    }, [startDate, endDate, getCashFlowStatement]);

    useEffect(() => {
        fetchData();
    }, [fetchData, _version]);

    const handleDrillDown = (accountId: string, label: string) => {
        navigate('/general-ledger', {
            state: {
                selectedAccountId: accountId, // This is the key the General Ledger page expects
                startDate: startDate,
                endDate: endDate
            }
        });
    };

    const handleExport = (format: 'excel' | 'pdf') => {
        if (!data) return;
        
        if (format === 'excel') {
            const XLSX = (window as any).XLSX;
            if (!XLSX) return alert("Excel library not found.");

            const wb = XLSX.utils.book_new();
            
            const createSection = (title: string, items: ReportRowItem[], total: number) => {
                const rows: any[][] = [[{v: title, s: { font: { bold: true }, fill: { fgColor: { rgb: "FFFDE9E9" }}}}], ['Description', 'Amount']];
                items.forEach(item => {
                    if(!item.isHeader) rows.push([item.isSubItem ? `  ${item.label}` : item.label, {t: 'n', v: item.value}]);
                });
                rows.push([`Net Cash from ${title}`, { t: 'n', v: total, s: { font: { bold: true } } }]);
                rows.push([]); // Spacer
                return rows;
            };

            const operating = createSection('Operating Activities', data.operating.items, data.operating.total);
            const investing = createSection('Investing Activities', data.investing.items, data.investing.total);
            const financing = createSection('Financing Activities', data.financing.items, data.financing.total);

            const summary = [
                ['Summary', ''],
                ['Cash at Beginning of Period', {t: 'n', v: data.summary.cashAtBeginning}],
                ['Net Increase/Decrease in Cash', {t: 'n', v: data.summary.netChange}],
                ['Cash at End of Period', {t: 'n', v: data.summary.cashAtEnd}],
            ];

            const allRows = [...operating, ...investing, ...financing, ...summary];

            const ws = XLSX.utils.aoa_to_sheet(allRows);
            ws['!cols'] = [{ wch: 40 }, { wch: 20 }];
            
            XLSX.utils.book_append_sheet(wb, ws, 'Cash Flow');
            XLSX.writeFile(wb, `CashFlowStatement_${endDate}.xlsx`);

        } else if (format === 'pdf') {
            const { jsPDF } = (window as any).jspdf;
            if (!jsPDF) return alert("PDF library not found.");
            
            const doc = new jsPDF();
            let cursorY = 20;

            doc.setFontSize(18);
            doc.setFont('helvetica', 'bold');
            doc.text('Cash Flow Statement', 15, cursorY);
            cursorY += 8;
            doc.setFontSize(10);
            doc.setFont('helvetica', 'normal');
            doc.text(`For the period: ${startDate} to ${endDate}`, 15, cursorY);
            cursorY += 15;

            const addSection = (title: string, items: ReportRowItem[], total: number) => {
                doc.setFontSize(12);
                doc.setFont('helvetica', 'bold');
                doc.text(title, 15, cursorY);
                cursorY += 7;

                items.forEach(item => {
                    if (item.isHeader) return;
                    doc.setFontSize(10);
                    doc.setFont('helvetica', 'normal');
                    doc.text(item.label, item.isSubItem ? 25 : 20, cursorY);
                    doc.text(formatCurrency(item.value), 195, cursorY, { align: 'right' });
                    cursorY += 7;
                });
                
                doc.setDrawColor(200);
                doc.line(15, cursorY, 195, cursorY);
                cursorY += 5;
                doc.setFont('helvetica', 'bold');
                doc.text(`Net Cash from ${title}`, 15, cursorY);
                doc.text(formatCurrency(total), 195, cursorY, { align: 'right' });
                cursorY += 10;
            };

            addSection('Operating Activities', data.operating.items, data.operating.total);
            addSection('Investing Activities', data.investing.items, data.investing.total);
            addSection('Financing Activities', data.financing.items, data.financing.total);

            doc.setDrawColor(0);
            doc.line(15, cursorY, 195, cursorY);
            cursorY += 8;

            doc.setFont('helvetica', 'normal');
            doc.text('Cash at Beginning of Period', 15, cursorY);
            doc.text(formatCurrency(data.summary.cashAtBeginning), 195, cursorY, { align: 'right' });
            cursorY += 7;
            doc.text('Net Increase/Decrease in Cash', 15, cursorY);
            doc.text(formatCurrency(data.summary.netChange), 195, cursorY, { align: 'right' });
            cursorY += 7;
            doc.setFont('helvetica', 'bold');
            doc.text('Cash at End of Period', 15, cursorY);
            doc.text(formatCurrency(data.summary.cashAtEnd), 195, cursorY, { align: 'right' });
            
            doc.save(`CashFlowStatement_${endDate}.pdf`);
        }
    };


    return (
        <div className="flex flex-col h-full space-y-4">
            <Header 
                startDate={startDate} setStartDate={setStartDate} 
                endDate={endDate} setEndDate={setEndDate}
                onDatePreset={setDatePreset}
                onRefresh={fetchData}
                isLoading={isLoading}
            />
            
            <AnimatePresence>
                {isLoading && (
                     <motion.div key="loader" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex-1 flex items-center justify-center">
                         <p className="text-slate-500">Generating Report...</p>
                    </motion.div>
                )}
                {data && !isLoading && (
                    <motion.div key="data" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
                        <CashMovementAnalysis data={data} />
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                            <SummaryCard title="Operating Cash Flow" value={data.operating.total} colorClass={data.operating.total >= 0 ? 'text-emerald-600' : 'text-rose-600'} />
                            <SummaryCard title="Investing Cash Flow" value={data.investing.total} colorClass={data.investing.total >= 0 ? 'text-emerald-600' : 'text-rose-600'} />
                            <SummaryCard title="Financing Cash Flow" value={data.financing.total} colorClass={data.financing.total >= 0 ? 'text-emerald-600' : 'text-rose-600'} />
                            <SummaryCard title="Net Cash Change" value={data.summary.netChange} colorClass={data.summary.netChange >= 0 ? 'text-sky-600' : 'text-rose-600'} />
                        </div>
                        
                        <div className="space-y-4">
                            <ReportSection title="Operating Activities" total={data.operating.total} items={data.operating.items} onDrillDown={handleDrillDown} />
                            <ReportSection title="Investing Activities" total={data.investing.total} items={data.investing.items} onDrillDown={handleDrillDown} />
                            <ReportSection title="Financing Activities" total={data.financing.total} items={data.financing.items} onDrillDown={handleDrillDown} />
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4">
                            <div className="bg-white/60 backdrop-blur-xl border border-white/50 rounded-2xl p-4 text-center">
                                <p className="text-sm font-medium text-slate-500">Cash at Beginning of Period</p>
                                <p className="text-xl font-bold font-mono mt-1 text-slate-800">{formatCurrency(data.summary.cashAtBeginning)}</p>
                            </div>
                            <div className="bg-white/60 backdrop-blur-xl border border-white/50 rounded-2xl p-4 text-center">
                                <p className="text-sm font-medium text-slate-500">Net Increase/Decrease in Cash</p>
                                <p className={`text-xl font-bold font-mono mt-1 ${data.summary.netChange >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>{formatCurrency(data.summary.netChange)}</p>
                            </div>
                            <div className="bg-sky-100/50 backdrop-blur-xl border border-sky-200/50 rounded-2xl p-4 text-center">
                                <p className="text-sm font-bold text-sky-800">Cash at End of Period</p>
                                <p className="text-2xl font-extrabold font-mono mt-1 text-sky-800">{formatCurrency(data.summary.cashAtEnd)}</p>
                            </div>
                        </div>

                    </motion.div>
                )}
             </AnimatePresence>

            <motion.div
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.5, type: 'spring', stiffness: 100 }}
                className="fixed bottom-6 right-6 z-40"
            >
                <div className="bg-white/70 backdrop-blur-md border border-white/50 rounded-full shadow-lg flex items-center gap-1 p-2">
                    <button onClick={() => handleExport('excel')} className="flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold text-emerald-800 hover:bg-emerald-100/50 transition-colors" title="Export to Excel">
                        <FileSpreadsheet size={16} />
                        <span>Excel</span>
                    </button>
                    <button onClick={() => handleExport('pdf')} className="flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold text-sky-800 hover:bg-sky-100/50 transition-colors" title="Export to PDF">
                        <FileText size={16} />
                        <span>PDF</span>
                    </button>
                </div>
            </motion.div>
        </div>
    );
};

export default CashFlowStatement;