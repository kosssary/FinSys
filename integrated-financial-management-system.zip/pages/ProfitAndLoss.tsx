
import React, { useState, useEffect, useCallback, Fragment } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Calendar, RefreshCw, ChevronDown, FileText, FileSpreadsheet } from 'lucide-react';
import { useData } from '../context/DataContext';
import { ProfitAndLossData, HierarchicalPnlNode } from '../types';

// --- HELPER FUNCTIONS ---
const formatCurrency = (value: number) => {
    const isNegative = value < 0;
    const formatted = new Intl.NumberFormat('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    }).format(Math.abs(value));
    return isNegative ? `(${formatted})` : formatted;
};

// --- UI COMPONENTS ---

const PerformanceSummary: React.FC<{ data: ProfitAndLossData }> = ({ data }) => {
    const [lang, setLang] = useState<'en' | 'ku' | 'ar'>('en');
    const netProfitMargin = data.totalRevenue !== 0 ? (data.netProfit / data.totalRevenue) * 100 : 0;
    const grossProfitMargin = data.totalRevenue !== 0 ? (data.grossProfit / data.totalRevenue) * 100 : 0;

    let largestExpenseCategory = { name: 'N/A', percentage: 0 };
    if (data.expensesTree && data.expensesTree.children.length > 0 && data.totalExpenses > 0) {
        const topLevelExpenses = data.expensesTree.children;
        const largest = topLevelExpenses.reduce((max, cat) => cat.total > max.total ? cat : max, topLevelExpenses[0] || { total: 0, name: 'N/A' } as HierarchicalPnlNode);
        if (largest.total > 0) {
            largestExpenseCategory = {
                name: largest.name,
                percentage: (largest.total / data.totalExpenses) * 100,
            };
        }
    }
    
    const summaries = {
        en: {
            profitable: `During this period, the company was profitable, generating a net profit of ${formatCurrency(data.netProfit)}. This represents a ${netProfitMargin.toFixed(1)}% net profit margin.`,
            loss: `During this period, the company operated at a loss of ${formatCurrency(data.netProfit)}. Key factors contributing to this may be high expenses or lower-than-expected revenue.`,
            drivers: `The primary driver of our results was a Total Revenue of ${formatCurrency(data.totalRevenue)}. Our Gross Profit Margin was ${grossProfitMargin.toFixed(1)}%, indicating the core profitability of our sales.`,
            expenses: `Operating Expenses totaled ${formatCurrency(data.totalExpenses)}. The largest expense category was ${largestExpenseCategory.name}, accounting for ${largestExpenseCategory.percentage.toFixed(0)}% of total expenses.`
        },
        ku: {
            profitable: `لەم ماوەیەدا، کۆمپانیا قازانجی کردووە، قازانجێکی سافی بە بڕی ${formatCurrency(data.netProfit)} بەدەستهێناوە. ئەمە ڕێژەی ${netProfitMargin.toFixed(1)}%ی قازانجی سافی پێکدەهێنێت.`,
            loss: `لەم ماوەیەدا، کۆمپانیا بە زیانێکی ${formatCurrency(data.netProfit)} کاری کردووە. هۆکارە سەرەکییەکان لەوانەیە خەرجی بەرز یان داهاتی کەمتر لە چاوەڕوانکراو بێت.`,
            drivers: `هۆکاری سەرەکیی ئەنجامەکانمان کۆی داهات بوو بە بڕی ${formatCurrency(data.totalRevenue)}. ڕێژەی قازانجی گشتی ${grossProfitMargin.toFixed(1)}% بوو، کە نیشاندەری قازانجی بنەڕەتیی فرۆشەکانمانە.`,
            expenses: `کۆی خەرجییە کارپێکەرییەکان ${formatCurrency(data.totalExpenses)} بوو. گەورەترین پۆلی خەرجی بریتی بوو لە ${largestExpenseCategory.name}، کە ${largestExpenseCategory.percentage.toFixed(0)}%ی کۆی خەرجییەکانی پێکدەهێنا.`
        },
        ar: {
            profitable: `خلال هذه الفترة، كانت الشركة رابحة، حيث حققت ربحًا صافيًا قدره ${formatCurrency(data.netProfit)}. وهذا يمثل هامش ربح صافٍ بنسبة ${netProfitMargin.toFixed(1)}%.`,
            loss: `خلال هذه الفترة، عملت الشركة بخسارة قدرها ${formatCurrency(data.netProfit)}. قد تكون العوامل الرئيسية المساهمة في ذلك هي النفقات المرتفعة أو الإيرادات الأقل من المتوقع.`,
            drivers: `كان المحرك الأساسي لنتائجنا هو إجمالي الإيرادات البالغ ${formatCurrency(data.totalRevenue)}. بلغ هامش الربح الإجمالي لدينا ${grossProfitMargin.toFixed(1)}%، مما يشير إلى الربحية الأساسية لمبيعاتنا.`,
            expenses: `بلغ إجمالي النفقات التشغيلية ${formatCurrency(data.totalExpenses)}. وكانت أكبر فئة نفقات هي ${largestExpenseCategory.name}، والتي تمثل ${largestExpenseCategory.percentage.toFixed(0)}% من إجمالي النفقات.`
        }
    };

    const currentSummary = summaries[lang];

    return (
        <div className="bg-white/60 backdrop-blur-xl border border-white/50 rounded-2xl shadow-sm p-6 mb-4 relative">
            <div className="flex justify-between items-start">
                <h2 className="text-lg font-bold text-slate-800">Performance Summary <span className="font-normal text-slate-500">(پوختەی ئەدای دارایی)</span></h2>
                 <div className="flex items-center gap-1 bg-slate-200/50 dark:bg-slate-700/50 p-1 rounded-md">
                    <button onClick={() => setLang('en')} className={`px-2 py-0.5 text-xs font-bold rounded ${lang === 'en' ? 'bg-white dark:bg-slate-800 text-sky-600' : 'text-slate-500'}`}>EN</button>
                    <button onClick={() => setLang('ku')} className={`px-2 py-0.5 text-xs font-bold rounded ${lang === 'ku' ? 'bg-white dark:bg-slate-800 text-sky-600' : 'text-slate-500'}`}>KU</button>
                    <button onClick={() => setLang('ar')} className={`px-2 py-0.5 text-xs font-bold rounded ${lang === 'ar' ? 'bg-white dark:bg-slate-800 text-sky-600' : 'text-slate-500'}`}>AR</button>
                </div>
            </div>
            <div dir={lang === 'ar' || lang === 'ku' ? 'rtl' : 'ltr'} className="mt-4 space-y-2 text-sm text-slate-600">
                <p>{data.netProfit >= 0 ? currentSummary.profitable : currentSummary.loss}</p>
                <p>{currentSummary.drivers}</p>
                {data.totalExpenses > 0 && <p>{currentSummary.expenses}</p>}
            </div>
        </div>
    );
};

const Header: React.FC<{
    startDate: string; setStartDate: (d: string) => void;
    endDate: string; setEndDate: (d: string) => void;
    onDatePreset: (preset: string) => void;
    onRefresh: () => void;
    isLoading: boolean;
}> = ({ startDate, setStartDate, endDate, setEndDate, onDatePreset, onRefresh, isLoading }) => {
    return (
        <div className="relative z-10 bg-white/60 backdrop-blur-xl border border-white/50 rounded-2xl shadow-sm p-4 flex flex-col lg:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
                <Calendar className="text-slate-500" size={20} />
                <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="h-10 bg-white/70 border border-white/50 rounded-lg shadow-inner px-3 text-sm text-slate-800 focus:ring-1 focus:ring-sky-300/60 focus:outline-none" />
                <span className="text-slate-500">-</span>
                <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className="h-10 bg-white/70 border border-white/50 rounded-lg shadow-inner px-3 text-sm text-slate-800 focus:ring-1 focus:ring-sky-300/60 focus:outline-none" />
            </div>
            <div className="flex items-center gap-2">
                {['This Month', 'This Quarter', 'This Year'].map(preset => (
                    <button key={preset} onClick={() => onDatePreset(preset)} className="px-3 py-1.5 text-xs font-semibold text-slate-600 rounded-lg hover:bg-white/50 transition-colors">{preset}</button>
                ))}
            </div>
            <button onClick={onRefresh} disabled={isLoading} className="h-10 px-4 flex items-center gap-2 text-sm font-semibold text-slate-700 bg-white/50 rounded-lg border border-white/40 hover:bg-white/70 transition-colors disabled:opacity-50">
                <RefreshCw size={14} className={isLoading ? 'animate-spin' : ''} />
                <span>Refresh</span>
            </button>
        </div>
    );
};

const ReportTreeRow: React.FC<{ node: HierarchicalPnlNode; level: number; onDrillDown: (accountId: string) => void; }> = ({ node, level, onDrillDown }) => {
    const [isExpanded, setIsExpanded] = useState(level < 2);
    const hasChildren = node.children && node.children.length > 0;
    
    const isPostable = !hasChildren;

    const handleDrillDown = () => {
        if(isPostable) {
            onDrillDown(node.id)
        }
    }

    return (
        <Fragment>
            <div 
                className={`flex justify-between items-center py-2.5 px-3 rounded-md transition-colors ${isPostable ? 'hover:bg-sky-100/40 dark:hover:bg-sky-900/30 cursor-pointer' : 'font-semibold bg-slate-100/60 dark:bg-slate-800/30'}`}
                style={{ paddingLeft: `${level * 1.5}rem` }}
                onClick={handleDrillDown}
            >
                <div className="flex items-center">
                    {hasChildren && (
                         <button onClick={(e) => {e.stopPropagation(); setIsExpanded(!isExpanded)}} className="mr-2 text-slate-400 hover:text-slate-700 p-1 -ml-1">
                            <ChevronDown size={16} className={`transition-transform duration-200 ${isExpanded ? 'rotate-180' : ''}`} />
                        </button>
                    )}
                     <span className={`text-sm ${level < 2 ? 'font-semibold text-slate-800' : 'text-slate-600'}`}>
                        {node.name}
                    </span>
                </div>
                 <span className={`font-mono text-sm min-w-[120px] text-right ${node.total < 0 ? 'text-rose-600' : 'text-slate-800'}`}>
                    {formatCurrency(node.total)}
                </span>
            </div>
            <AnimatePresence>
            {isExpanded && hasChildren && (
                 <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden pl-4">
                    {node.children.map(child => <ReportTreeRow key={child.id} node={child} level={level + 1} onDrillDown={onDrillDown}/>)}
                </motion.div>
            )}
            </AnimatePresence>
        </Fragment>
    );
}

const SummaryRow: React.FC<{label: string; value: number; isEmphasized?: boolean; isNet?: boolean}> = ({ label, value, isEmphasized, isNet }) => {
    const valueColor = value < 0 ? 'text-rose-600' : (isNet ? 'text-sky-600' : 'text-slate-800');
    return (
        <div className={`flex justify-between items-center py-3 ${isEmphasized ? 'border-t border-white/50 pt-3' : ''}`}>
            <span className={`text-sm ${isEmphasized ? 'font-bold text-slate-800' : 'text-slate-600'}`}>{label}</span>
            <span className={`font-mono text-sm ${isEmphasized ? 'font-bold' : 'font-semibold'} ${valueColor}`}>{formatCurrency(value)}</span>
        </div>
    );
};

// --- MAIN PAGE COMPONENT ---
const ProfitAndLoss: React.FC = () => {
    const { getProfitAndLoss, _version } = useData();
    const navigate = useNavigate();
    const [isLoading, setIsLoading] = useState(true);
    const [data, setData] = useState<ProfitAndLossData | null>(null);

    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');

    const setDatePreset = useCallback((preset: string) => {
        const now = new Date();
        let start = new Date(), end = new Date();
        switch (preset) {
            case 'This Month': start = new Date(now.getFullYear(), now.getMonth(), 1); end = new Date(now.getFullYear(), now.getMonth() + 1, 0); break;
            case 'This Quarter': const quarter = Math.floor(now.getMonth() / 3); start = new Date(now.getFullYear(), quarter * 3, 1); end = new Date(now.getFullYear(), quarter * 3 + 3, 0); break;
            case 'This Year': default: start = new Date(now.getFullYear(), 0, 1); end = new Date(); break;
        }
        setStartDate(start.toISOString().split('T')[0]);
        setEndDate(end.toISOString().split('T')[0]);
    }, []);

    useEffect(() => { setDatePreset('This Year'); }, [setDatePreset]);
    
    const fetchData = useCallback(async () => {
        if (!startDate || !endDate) return;
        setIsLoading(true);
        try {
            const result = await getProfitAndLoss(startDate, endDate);
            setData(result);
        } catch (e) {
            console.error("Failed to fetch P&L data:", e);
            setData(null);
        } finally {
            setIsLoading(false);
        }
    }, [startDate, endDate, getProfitAndLoss]);

    useEffect(() => { fetchData(); }, [fetchData, _version]);

    const handleDrillDown = (accountId: string) => {
        navigate('/general-ledger', {
            state: {
                searchQuery: accountId,
                startDate,
                endDate
            }
        });
    };

    const handleExport = (format: 'excel' | 'pdf') => {
        // Placeholder for export functionality
        alert(`Export to ${format} is not yet implemented.`);
    };

    const mainContent = isLoading ? (
        <div className="flex-1 flex items-center justify-center p-10 text-slate-500">Generating Report...</div>
    ) : data ? (
        <>
        <PerformanceSummary data={data} />
         <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-8">
                 <div className="bg-white/65 backdrop-blur-xl border border-white/50 rounded-2xl shadow-sm p-6 space-y-2">
                    <ReportTreeRow node={data.revenueTree} level={0} onDrillDown={handleDrillDown} />
                    <ReportTreeRow node={data.cogsTree} level={0} onDrillDown={handleDrillDown} />
                    <ReportTreeRow node={data.expensesTree} level={0} onDrillDown={handleDrillDown} />
                </div>
            </div>
            <div className="lg:col-span-4">
                 <div className="sticky top-6 bg-white/65 backdrop-blur-xl border border-white/50 rounded-2xl shadow-sm p-6">
                    <h3 className="text-lg font-bold text-slate-800 mb-2">Summary</h3>
                    <div className="space-y-1">
                        <SummaryRow label="Total Revenue" value={data.totalRevenue} />
                        <SummaryRow label="Cost of Goods Sold" value={data.totalCogs} />
                        <SummaryRow label="Gross Profit" value={data.grossProfit} isEmphasized />
                        <SummaryRow label="Operating Expenses" value={data.totalExpenses} />
                        <div className="bg-sky-100/60 rounded-lg p-3 -mx-3 mt-2">
                             <div className="flex justify-between items-center">
                                <span className="font-extrabold text-sky-800">NET PROFIT</span>
                                <span className={`font-mono text-lg font-extrabold ${data.netProfit < 0 ? 'text-rose-600' : 'text-sky-700'}`}>{formatCurrency(data.netProfit)}</span>
                             </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </>
    ) : (
        <div className="flex-1 flex items-center justify-center p-10 text-rose-500">Failed to load report data.</div>
    );

    return (
        <div className="flex flex-col h-full space-y-4">
            <Header 
                startDate={startDate} setStartDate={setStartDate} 
                endDate={endDate} setEndDate={setEndDate}
                onDatePreset={setDatePreset}
                onRefresh={fetchData}
                isLoading={isLoading}
            />
            
            <AnimatePresence mode="wait">
                <motion.div key={isLoading ? 'loader' : 'data'} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                    {mainContent}
                </motion.div>
            </AnimatePresence>

            <motion.div
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.5, type: 'spring', stiffness: 100 }}
                className="fixed bottom-6 right-6 z-40"
            >
                <div className="bg-white/70 backdrop-blur-md border border-white/50 rounded-full shadow-lg flex items-center gap-1 p-2">
                    <button onClick={() => handleExport('excel')} className="flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold text-emerald-800 hover:bg-emerald-100/50 transition-colors" title="Export to Excel">
                        <FileSpreadsheet size={16} />
                    </button>
                    <button onClick={() => handleExport('pdf')} className="flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold text-sky-800 hover:bg-sky-100/50 transition-colors" title="Export to PDF">
                        <FileText size={16} />
                    </button>
                </div>
            </motion.div>
        </div>
    );
};

export default ProfitAndLoss;
