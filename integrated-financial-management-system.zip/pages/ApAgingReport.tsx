

import React, { useState, useEffect, useMemo } from 'react';
import { useData } from '../context/DataContext';
import { ApAgingReportData } from '../types';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertTriangle, Clock, ShieldCheck, Search } from 'lucide-react';

const formatCurrency = (value: number) => new Intl.NumberFormat('en-US').format(value);

const KpiCard: React.FC<{ title: string, value: number, icon: React.ReactNode, description: string, color: string }> = ({ title, value, icon, description, color }) => (
    <div className="glowing-card p-5 flex flex-col justify-between">
        <div className="flex justify-between items-center">
            <h3 className="font-semibold text-slate-700 dark:text-slate-300">{title}</h3>
            <div className={`text-slate-500 dark:text-slate-400 opacity-80`} style={{color}}>{icon}</div>
        </div>
        <div>
            <p className="text-3xl font-bold font-mono mt-2 text-slate-800 dark:text-white" style={{color, textShadow: `0 0 12px ${color}40`}}>${formatCurrency(value)}</p>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">{description}</p>
        </div>
    </div>
);


const ApAgingReport: React.FC = () => {
    const { getApAgingReport, _version } = useData();
    const [reportData, setReportData] = useState<ApAgingReportData | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState('');

    useEffect(() => {
        setIsLoading(true);
        getApAgingReport().then(setReportData).finally(() => setIsLoading(false));
    }, [_version]);

    const filteredVendors = useMemo(() => {
        if (!reportData) return [];
        if (!searchQuery) return reportData.byVendor;
        const lowerQuery = searchQuery.toLowerCase();
        return reportData.byVendor.filter(vendor => 
            vendor.vendorName.toLowerCase().includes(lowerQuery)
        );
    }, [reportData, searchQuery]);
    
    const buckets = [
        { key: 'current', label: 'Current' },
        { key: '_1_30_days', label: '1-30 Days' },
        { key: '_31_60_days', label: '31-60 Days' },
        { key: '_61_90_days', label: '61-90 Days' },
        { key: 'over_90_days', label: '90+ Days' },
    ];

    return (
        <div className="space-y-6">
            <style>{`
                .glowing-card {
                    position: relative;
                    background-color: var(--glass-bg);
                    backdrop-filter: blur(30px);
                    border: 1px solid var(--glass-border);
                    border-radius: 22px;
                    box-shadow: 0 8px 32px 0 var(--glass-shadow);
                    overflow: hidden;
                }
                .dark .glowing-card::before {
                    content: "";
                    position: absolute;
                    inset: -1px;
                    border-radius: 22px;
                    background: conic-gradient(from 180deg at 50% 50%, rgba(56, 189, 248, 0.15) 0%, rgba(168, 85, 247, 0.15) 33%, rgba(236, 72, 153, 0.15) 66%, rgba(56, 189, 248, 0.15) 100%);
                    filter: blur(12px);
                    z-index: -1;
                    opacity: 0.8;
                }
            `}</style>
            <AnimatePresence mode="wait">
                {isLoading ? (
                     <motion.div key="loader" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="text-center p-20 text-slate-500">
                        <p>Generating A/P Aging Report...</p>
                    </motion.div>
                ) : !reportData ? (
                    <motion.div key="error" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="text-center p-20 text-rose-500">
                        <p>Could not load report data.</p>
                    </motion.div>
                ) : (
                    <motion.div key="data" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                            <KpiCard title="Total Accounts Payable" value={reportData.buckets.total} icon={<Clock size={20}/>} description="All outstanding bills" color="#64748b"/>
                            <KpiCard title="Current" value={reportData.buckets.current} icon={<ShieldCheck size={20}/>} description="Bills not yet due" color="#10b981"/>
                            <KpiCard title="Overdue" value={reportData.buckets.total - reportData.buckets.current} icon={<AlertTriangle size={20}/>} description="Bills past due date" color="#ef4444"/>
                        </div>

                        <div className="glowing-card p-0">
                             <div className="flex justify-between items-center p-4 border-b border-white/10">
                                <h2 className="text-lg font-bold text-slate-800 dark:text-white">Aging by Supplier</h2>
                                <div className="relative w-full max-w-xs">
                                    <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                                    <input
                                        type="text"
                                        value={searchQuery}
                                        onChange={(e) => setSearchQuery(e.target.value)}
                                        placeholder="Search by supplier name..."
                                        className="w-full h-10 bg-black/5 dark:bg-white/5 border border-white/10 rounded-lg shadow-inner pl-10 pr-4 text-sm focus:ring-2 focus:ring-sky-300/60 focus:outline-none transition"
                                    />
                                </div>
                            </div>
                            <div className="overflow-x-auto">
                                <table className="w-full min-w-[800px] text-sm">
                                    <thead>
                                        <tr className="border-b border-white/10">
                                            <th className="th-cell">Supplier</th>
                                            {buckets.map(b => <th key={b.key} className="th-cell text-right">{b.label}</th>)}
                                            <th className="th-cell text-right">Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {filteredVendors.map(vendor => (
                                            <tr key={vendor.vendorId} className="border-b border-white/5 last:border-b-0 hover:bg-sky-900/10 transition-colors">
                                                <td className="px-4 py-3 font-semibold text-slate-800 dark:text-slate-200">{vendor.vendorName}</td>
                                                {buckets.map(b => (
                                                    <td key={b.key} className="px-4 py-3 text-right font-mono text-slate-600 dark:text-slate-300">
                                                        {vendor.buckets[b.key as keyof typeof vendor.buckets] > 0 ? formatCurrency(vendor.buckets[b.key as keyof typeof vendor.buckets]) : '-'}
                                                    </td>
                                                ))}
                                                <td className="px-4 py-3 text-right font-mono font-bold text-sky-700 dark:text-sky-400">{formatCurrency(vendor.totalDue)}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                    <tfoot>
                                        <tr className="border-t-2 border-white/20 font-bold text-slate-900 dark:text-white bg-black/5 dark:bg-white/5">
                                            <td className="px-4 py-3">Total</td>
                                             {buckets.map(b => (
                                                <td key={b.key} className="px-4 py-3 text-right font-mono">
                                                    {formatCurrency(reportData.buckets[b.key as keyof typeof reportData.buckets])}
                                                </td>
                                            ))}
                                            <td className="px-4 py-3 text-right font-mono text-lg text-sky-600 dark:text-sky-300">{formatCurrency(reportData.buckets.total)}</td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>

            <style>{`.th-cell { padding: 0.75rem 1rem; font-size: 0.75rem; color: #64748b; text-transform: uppercase; font-weight: 600; } .dark .th-cell { color: #94a3b8; }`}</style>
        </div>
    );
};

export default ApAgingReport;