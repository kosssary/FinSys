import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useData } from '../context/DataContext';
import { AccountLedger as AccountLedgerType, Transaction } from '../types';

const AccountLedger: React.FC = () => {
    const { accountId } = useParams<{ accountId: string }>();
    const { getAccountLedger, _version } = useData();
    
    const [startDate, setStartDate] = useState(new Date(new Date().setMonth(new Date().getMonth() - 1)).toISOString().split('T')[0]);
    const [endDate, setEndDate] = useState(new Date().toISOString().split('T')[0]);
    
    const [ledger, setLedger] = useState<AccountLedgerType | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const generateReport = async () => {
            if (!accountId) {
                setError('Account ID is missing.');
                return;
            }
            setIsLoading(true);
            setError(null);
            setLedger(null);
            try {
                const report = await getAccountLedger(accountId, startDate, endDate);
                setLedger(report);
            } catch (err) {
                console.error(err);
                setError('Failed to generate the ledger.');
            } finally {
                setIsLoading(false);
            }
        };
        generateReport();
    }, [accountId, startDate, endDate, _version]);

    const formatCurrency = (value: number) => {
        return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value);
    };

    return (
        <div>
            <div className="mb-6">
                <Link to="/chart-of-accounts" className="text-blue-500 hover:underline text-sm">&larr; Back to Chart of Accounts</Link>
                {ledger && <p className="text-lg text-gray-500 dark:text-gray-400 mt-2">{ledger.accountCode} - {ledger.accountName}</p>}
            </div>

            {/* Filter Section */}
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4 mb-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                     <div>
                        <label htmlFor="startDate" className="block text-sm font-medium text-gray-700 dark:text-gray-300">From Date</label>
                        <input type="date" id="startDate" value={startDate} onChange={e => setStartDate(e.target.value)} className="mt-1 input-field" />
                    </div>
                    <div>
                        <label htmlFor="endDate" className="block text-sm font-medium text-gray-700 dark:text-gray-300">To Date</label>
                        <input type="date" id="endDate" value={endDate} onChange={e => setEndDate(e.target.value)} className="mt-1 input-field" />
                    </div>
                </div>
                 {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
            </div>

            {isLoading && <p>Loading ledger...</p>}

            {/* Report Display Section */}
            {ledger && (
                <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md mt-6">
                     <div className="p-6 border-b dark:border-gray-700 grid grid-cols-2 lg:grid-cols-4 gap-4 text-center">
                        <div>
                            <p className="text-sm text-gray-500 dark:text-gray-400 uppercase tracking-wider">Opening Balance</p>
                            <p className="text-2xl font-semibold text-gray-800 dark:text-white">{formatCurrency(ledger.openingBalance)}</p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-500 dark:text-gray-400 uppercase tracking-wider">Total Debit</p>
                            <p className="text-2xl font-semibold text-red-500">{formatCurrency(ledger.totalDebit)}</p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-500 dark:text-gray-400 uppercase tracking-wider">Total Credit</p>
                            <p className="text-2xl font-semibold text-green-500">{formatCurrency(ledger.totalCredit)}</p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-500 dark:text-gray-400 uppercase tracking-wider">Closing Balance</p>
                            <p className="text-2xl font-bold text-blue-600 dark:text-blue-400">{formatCurrency(ledger.closingBalance)}</p>
                        </div>
                    </div>
                    <div className="overflow-x-auto">
                        <table className="w-full min-w-[700px]">
                            <thead className="bg-gray-50 dark:bg-gray-900/50">
                                <tr>
                                    <th className="th-cell">Date</th>
                                    <th className="th-cell">Voucher #</th>
                                    <th className="th-cell">Description</th>
                                    <th className="th-cell text-right">Debit</th>
                                    <th className="th-cell text-right">Credit</th>
                                    <th className="th-cell text-right">Balance</th>
                                </tr>
                            </thead>
                            <tbody className="bg-white dark:bg-gray-800">
                                <tr className="bg-gray-50 dark:bg-gray-700/50 font-semibold text-sm">
                                    <td colSpan={5} className="px-6 py-3 text-right text-gray-600 dark:text-gray-300">Opening Balance</td>
                                    <td className="px-6 py-3 text-right font-mono text-gray-800 dark:text-gray-100">{formatCurrency(ledger.openingBalance)}</td>
                                </tr>
                                {ledger.transactions.map((txn, index) => {
                                    const debit = txn.type === 'Debit' ? txn.amount : 0;
                                    const credit = txn.type === 'Credit' ? txn.amount : 0;
                                    // This running balance calculation needs to be more robust based on account category
                                    const runningBalance = ledger.openingBalance + ledger.transactions.slice(0, index + 1).reduce((acc, t) => acc + (t.type === 'Debit' ? t.amount : -t.amount), 0);
                                    return (
                                        <tr key={txn.id} className="border-b border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/30">
                                            <td className="td-cell">{new Date(txn.date).toLocaleDateString()}</td>
                                            <td className="td-cell font-mono">{txn.voucherNumber}</td>
                                            <td className="td-cell max-w-xs truncate">{txn.description}</td>
                                            <td className="td-cell text-right font-mono text-red-600">{debit > 0 ? formatCurrency(debit) : '-'}</td>
                                            <td className="td-cell text-right font-mono text-green-600">{credit > 0 ? formatCurrency(credit) : '-'}</td>
                                            <td className="td-cell text-right font-mono font-semibold">{formatCurrency(runningBalance)}</td>
                                        </tr>
                                    );
                                })}
                                 <tr className="bg-gray-200 dark:bg-gray-900 font-bold">
                                    <td colSpan={5} className="px-6 py-4 text-right text-gray-800 dark:text-white uppercase tracking-wider">Closing Balance</td>
                                    <td className="px-6 py-4 text-right font-mono text-lg text-blue-600 dark:text-blue-400">{formatCurrency(ledger.closingBalance)}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            )}
             <style>{`
                .input-field { display: block; width: 100%; padding: 0.5rem 0.75rem; color: #1f2937; background-color: white; border: 1px solid #D1D5DB; border-radius: 0.375rem; }
                .dark .input-field { color: #d1d5db; background-color: #374151; border-color: #4B5563; }
                .th-cell { padding: 0.75rem 1.5rem; text-align: left; font-size: 0.75rem; color: #6B7280; text-transform: uppercase; font-weight: 600; } .dark .th-cell { color: #9CA3AF; }
                .td-cell { padding: 1rem 1.5rem; white-space: nowrap; font-size: 0.875rem; color: #4B5563; } .dark .td-cell { color: #D1D5DB; }
            `}</style>
        </div>
    );
};

export default AccountLedger;