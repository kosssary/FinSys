import React, { useState, useEffect, useCallback } from 'react';
import { useData } from '../context/DataContext';
import { BalanceSheetData, BalanceSheetGroup, BalanceSheetAccount } from '../types';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Calendar, RefreshCw, CheckCircle2, XCircle, FileSpreadsheet, FileText } from 'lucide-react';

// --- Helper Functions ---
const formatCurrency = (value: number) => {
    const isNegative = value < 0;
    const formatted = new Intl.NumberFormat('en-US').format(Math.abs(value));
    return isNegative ? `(${formatted})` : formatted;
};

// --- Child Components ---

const ReportRow: React.FC<{ name: string; balance: number; onDrillDown?: () => void; isSub?: boolean }> = ({ name, balance, onDrillDown, isSub }) => {
    const content = (
        <div className={`flex justify-between items-center py-2 ${isSub ? 'pl-4' : ''}`}>
            <span className="text-sm text-slate-600 dark:text-slate-300">{name}</span>
            <span className={`font-mono text-sm ${balance < 0 ? 'text-rose-600' : 'text-slate-800 dark:text-slate-100'}`}>
                {formatCurrency(balance)}
            </span>
        </div>
    );
    return onDrillDown ? (
        <button onClick={onDrillDown} className="w-full text-left rounded-md hover:bg-slate-200/20 dark:hover:bg-slate-700/20 transition-colors">
            {content}
        </button>
    ) : content;
};

const ReportGroup: React.FC<{ group: BalanceSheetGroup; onDrillDown: (accountId: string) => void; }> = ({ group, onDrillDown }) => (
    <div className="mb-4">
        <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">{group.title}</h4>
        <div className="space-y-0">
            {group.accounts.map(acc => (
                <ReportRow key={acc.id} name={acc.name} balance={acc.balance} onDrillDown={() => onDrillDown(acc.id)} isSub />
            ))}
        </div>
        <div className="flex justify-between items-center pt-2 mt-2 border-t border-slate-200/50 dark:border-slate-700/50">
            <span className="text-sm font-bold text-slate-700 dark:text-slate-200">Total {group.title}</span>
            <span className="font-mono font-bold text-slate-900 dark:text-white">{formatCurrency(group.total)}</span>
        </div>
    </div>
);

// --- Main Component ---
const BalanceSheet: React.FC = () => {
    const { getBalanceSheet, _version } = useData();
    const navigate = useNavigate();

    const [asOfDate, setAsOfDate] = useState(new Date().toISOString().split('T')[0]);
    const [data, setData] = useState<BalanceSheetData | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    const fetchData = useCallback(async () => {
        setIsLoading(true);
        try {
            const result = await getBalanceSheet(asOfDate);
            setData(result);
        } catch (error) {
            console.error("Failed to fetch balance sheet:", error);
            setData(null);
        } finally {
            setIsLoading(false);
        }
    }, [asOfDate, getBalanceSheet]);

    useEffect(() => {
        fetchData();
    }, [asOfDate, _version, fetchData]);

    const handleDrillDown = (accountId: string) => {
        navigate('/general-ledger', {
            state: {
                searchQuery: accountId,
                endDate: asOfDate,
                startDate: new Date(new Date(asOfDate).getFullYear(), 0, 1).toISOString().split('T')[0]
            }
        });
    };

    const handleExportExcel = () => {
        if (!data) return;
        const XLSX = (window as any).XLSX;
        if (!XLSX) return alert("Excel export library not available.");

        const rows = [
            [{ v: "Balance Sheet", s: { font: { bold: true, sz: 16 } } }],
            [`As of ${new Date(asOfDate).toLocaleDateString()}`],
            [],
            [{ v: "Assets", s: { font: { bold: true, sz: 14 } } }],
            [{ v: data.assets.currentAssets.title, s: { font: { italic: true } } }],
            ...data.assets.currentAssets.accounts.map(acc => [`  ${acc.name}`, acc.balance]),
            [{ v: `Total ${data.assets.currentAssets.title}`, s: { font: { bold: true } } }, { v: data.assets.currentAssets.total, s: { font: { bold: true } } }],
            [],
            [{ v: data.assets.nonCurrentAssets.title, s: { font: { italic: true } } }],
            ...data.assets.nonCurrentAssets.accounts.map(acc => [`  ${acc.name}`, acc.balance]),
            [{ v: `Total ${data.assets.nonCurrentAssets.title}`, s: { font: { bold: true } } }, { v: data.assets.nonCurrentAssets.total, s: { font: { bold: true } } }],
            [],
            [{ v: "Total Assets", s: { font: { bold: true, sz: 14 } } }, { v: data.assets.totalAssets, s: { font: { bold: true, sz: 14 } } }],
            [],
            [{ v: "Liabilities & Equity", s: { font: { bold: true, sz: 14 } } }],
            [{ v: data.liabilitiesAndEquity.currentLiabilities.title, s: { font: { italic: true } } }],
            ...data.liabilitiesAndEquity.currentLiabilities.accounts.map(acc => [`  ${acc.name}`, acc.balance]),
            [{ v: `Total ${data.liabilitiesAndEquity.currentLiabilities.title}`, s: { font: { bold: true } } }, { v: data.liabilitiesAndEquity.currentLiabilities.total, s: { font: { bold: true } } }],
            [],
            [{ v: data.liabilitiesAndEquity.nonCurrentLiabilities.title, s: { font: { italic: true } } }],
            ...data.liabilitiesAndEquity.nonCurrentLiabilities.accounts.map(acc => [`  ${acc.name}`, acc.balance]),
            [{ v: `Total ${data.liabilitiesAndEquity.nonCurrentLiabilities.title}`, s: { font: { bold: true } } }, { v: data.liabilitiesAndEquity.nonCurrentLiabilities.total, s: { font: { bold: true } } }],
            [],
            [{ v: "Total Liabilities", s: { font: { bold: true } } }, { v: data.liabilitiesAndEquity.totalLiabilities, s: { font: { bold: true } } }],
            [],
            [{ v: data.liabilitiesAndEquity.equity.title, s: { font: { italic: true } } }],
            ...data.liabilitiesAndEquity.equity.accounts.map(acc => [`  ${acc.name}`, acc.balance]),
            [{ v: `Total ${data.liabilitiesAndEquity.equity.title}`, s: { font: { bold: true } } }, { v: data.liabilitiesAndEquity.totalEquity, s: { font: { bold: true } } }],
            [],
            [{ v: "Total Liabilities & Equity", s: { font: { bold: true, sz: 14 } } }, { v: data.liabilitiesAndEquity.totalLiabilitiesAndEquity, s: { font: { bold: true, sz: 14 } } }],
        ];

        rows.forEach((row: any[]) => {
            if (typeof row[1] === 'number') {
                row[1] = { t: 'n', v: row[1], z: '#,##0.00;[Red](#,##0.00)' };
            }
        });

        const ws = XLSX.utils.aoa_to_sheet(rows);
        ws['!cols'] = [{ wch: 40 }, { wch: 20 }];
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Balance Sheet");
        XLSX.writeFile(wb, `BalanceSheet_${asOfDate}.xlsx`);
    };
    
    const handleExportPdf = () => {
        if (!data) return;
        const { jsPDF } = (window as any).jspdf;
        if (!jsPDF) return alert("PDF export library not available.");
        const doc = new jsPDF();
        let cursorY = 20;

        // Header
        doc.setFontSize(18);
        doc.setFont('helvetica', 'bold');
        doc.text('Balance Sheet', 15, cursorY);
        cursorY += 8;
        doc.setFontSize(10);
        doc.setFont('helvetica', 'normal');
        doc.text(`As of ${new Date(asOfDate).toLocaleDateString()}`, 15, cursorY);
        cursorY += 15;

        // Two-column layout
        const leftColumnX = 15;
        const rightColumnX = 110;
        const columnWidth = 85;
        let leftY = cursorY;
        let rightY = cursorY;

        const generateSection = (title: string, accounts: BalanceSheetAccount[], total: number, startX: number, startY: number) => {
            (doc as any).autoTable({
                startY: startY,
                head: [[title, 'Amount']],
                body: accounts.map(acc => [acc.name, { content: formatCurrency(acc.balance), styles: { halign: 'right' } }]),
                foot: [[`Total ${title}`, { content: formatCurrency(total), styles: { halign: 'right' } }]],
                theme: 'plain',
                headStyles: { fontStyle: 'bold', fillColor: [241, 245, 249], textColor: [30, 41, 59] },
                footStyles: { fontStyle: 'bold' },
                tableWidth: columnWidth,
                margin: { left: startX }
            });
            return (doc as any).lastAutoTable.finalY + 5;
        };
        
        // Left Column: Assets
        leftY = generateSection(data.assets.currentAssets.title, data.assets.currentAssets.accounts, data.assets.currentAssets.total, leftColumnX, leftY);
        leftY = generateSection(data.assets.nonCurrentAssets.title, data.assets.nonCurrentAssets.accounts, data.assets.nonCurrentAssets.total, leftColumnX, leftY);
        doc.setFontSize(12);
        doc.setFont('helvetica', 'bold');
        doc.text('Total Assets', leftColumnX, leftY);
        doc.text(formatCurrency(data.assets.totalAssets), leftColumnX + columnWidth, leftY, { align: 'right' });

        // Right Column: Liabilities & Equity
        rightY = generateSection(data.liabilitiesAndEquity.currentLiabilities.title, data.liabilitiesAndEquity.currentLiabilities.accounts, data.liabilitiesAndEquity.currentLiabilities.total, rightColumnX, rightY);
        rightY = generateSection(data.liabilitiesAndEquity.nonCurrentLiabilities.title, data.liabilitiesAndEquity.nonCurrentLiabilities.accounts, data.liabilitiesAndEquity.nonCurrentLiabilities.total, rightColumnX, rightY);
        doc.setFontSize(10);
        doc.setFont('helvetica', 'bold');
        doc.text('Total Liabilities', rightColumnX, rightY);
        doc.text(formatCurrency(data.liabilitiesAndEquity.totalLiabilities), rightColumnX + columnWidth, rightY, { align: 'right' });
        rightY += 10;
        rightY = generateSection(data.liabilitiesAndEquity.equity.title, data.liabilitiesAndEquity.equity.accounts, data.liabilitiesAndEquity.totalEquity, rightColumnX, rightY);
        doc.setFontSize(12);
        doc.setFont('helvetica', 'bold');
        doc.text('Total Liabilities & Equity', rightColumnX, rightY);
        doc.text(formatCurrency(data.liabilitiesAndEquity.totalLiabilitiesAndEquity), rightColumnX + columnWidth, rightY, { align: 'right' });
        
        // Balance check
        cursorY = Math.max(leftY, rightY) + 20;
        doc.setDrawColor(200);
        doc.line(15, cursorY, 195, cursorY);
        cursorY += 10;
        doc.setFontSize(12);
        doc.setFont('helvetica', 'bold');
        if (data.isBalanced) {
            doc.setTextColor(34, 197, 94); // green-500
            doc.text('✓ Balanced', 105, cursorY, { align: 'center' });
        } else {
            doc.setTextColor(239, 68, 68); // red-500
            doc.text('✗ Unbalanced', 105, cursorY, { align: 'center' });
        }
        
        doc.save(`BalanceSheet_${asOfDate}.pdf`);
    };


    return (
        <div className="space-y-6">
            <div className="flex flex-col md:flex-row justify-end items-start md:items-center gap-4">
                <div className="relative z-10 bg-white/60 backdrop-blur-xl border border-white/50 rounded-2xl shadow-sm p-2 flex items-center gap-2">
                    <Calendar className="text-slate-500 ml-2" size={20} />
                    <input type="date" value={asOfDate} onChange={e => setAsOfDate(e.target.value)} className="h-10 bg-transparent border-none rounded-lg px-3 text-sm text-slate-800 focus:ring-0 focus:outline-none" />
                    <button onClick={fetchData} disabled={isLoading} className="h-10 px-4 flex items-center gap-2 text-sm font-semibold text-slate-700 bg-white/50 rounded-lg border border-white/40 hover:bg-white/70 transition-colors disabled:opacity-50">
                        <RefreshCw size={14} className={isLoading ? 'animate-spin' : ''} />
                    </button>
                </div>
            </div>

            <AnimatePresence mode="wait">
                {isLoading ? (
                    <motion.div key="loader" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="text-center p-20 text-slate-500">
                        Generating Balance Sheet...
                    </motion.div>
                ) : !data ? (
                    <motion.div key="error" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="text-center p-20 text-rose-500">
                        Could not load data for the selected date.
                    </motion.div>
                ) : (
                    <motion.div key="data" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            {/* Assets */}
                            <div className="bg-white/65 backdrop-blur-xl border border-white/50 rounded-2xl shadow-[0_10px_40px_rgba(0,0,0,0.06)] p-6 space-y-4">
                                <h2 className="text-xl font-bold text-slate-800 dark:text-white pb-2 border-b border-slate-200/50 dark:border-slate-700/50">Assets</h2>
                                <ReportGroup group={data.assets.currentAssets} onDrillDown={handleDrillDown} />
                                <ReportGroup group={data.assets.nonCurrentAssets} onDrillDown={handleDrillDown} />
                                <div className="flex justify-between items-center pt-3 mt-3 border-t-2 border-slate-300/70 dark:border-slate-600/70">
                                    <span className="text-lg font-bold text-sky-800 dark:text-sky-300">Total Assets</span>
                                    <span className="font-mono font-extrabold text-lg text-sky-800 dark:text-sky-300" style={{ textShadow: '0 0 8px rgba(56, 189, 248, 0.5)' }}>
                                        {formatCurrency(data.assets.totalAssets)}
                                    </span>
                                </div>
                            </div>
                            
                            {/* Liabilities & Equity */}
                            <div className="bg-white/65 backdrop-blur-xl border border-white/50 rounded-2xl shadow-[0_10px_40px_rgba(0,0,0,0.06)] p-6 space-y-4">
                                <h2 className="text-xl font-bold text-slate-800 dark:text-white pb-2 border-b border-slate-200/50 dark:border-slate-700/50">Liabilities & Equity</h2>
                                <ReportGroup group={data.liabilitiesAndEquity.currentLiabilities} onDrillDown={handleDrillDown} />
                                <ReportGroup group={data.liabilitiesAndEquity.nonCurrentLiabilities} onDrillDown={handleDrillDown} />
                                <div className="flex justify-between items-center pt-2 mt-2 border-t border-slate-200/50 dark:border-slate-700/50">
                                    <span className="text-sm font-bold text-slate-700 dark:text-slate-200">Total Liabilities</span>
                                    <span className="font-mono font-bold text-slate-900 dark:text-white">{formatCurrency(data.liabilitiesAndEquity.totalLiabilities)}</span>
                                </div>
                                <div className="mt-6">
                                    <ReportGroup group={data.liabilitiesAndEquity.equity} onDrillDown={handleDrillDown} />
                                </div>
                                <div className="flex justify-between items-center pt-3 mt-3 border-t-2 border-slate-300/70 dark:border-slate-600/70">
                                    <span className="text-lg font-bold text-sky-800 dark:text-sky-300">Total Liabilities & Equity</span>
                                    <span className="font-mono font-extrabold text-lg text-sky-800 dark:text-sky-300" style={{ textShadow: '0 0 8px rgba(56, 189, 248, 0.5)' }}>
                                        {formatCurrency(data.liabilitiesAndEquity.totalLiabilitiesAndEquity)}
                                    </span>
                                </div>
                            </div>
                        </div>

                        {/* Summary Card */}
                        <div className="max-w-3xl mx-auto">
                            <div className="bg-white/65 backdrop-blur-xl border border-white/50 rounded-2xl shadow-lg p-6 text-center">
                                 <div className={`flex items-center justify-center gap-2 text-xl font-bold mb-4 ${data.isBalanced ? 'text-emerald-600' : 'text-rose-600'}`}>
                                    {data.isBalanced ? <CheckCircle2 /> : <XCircle />}
                                    <span>{data.isBalanced ? 'Balanced' : 'Unbalanced'}</span>
                                </div>
                                <p className="font-mono text-slate-600 dark:text-slate-300">
                                    {formatCurrency(data.assets.totalAssets)} = {formatCurrency(data.liabilitiesAndEquity.totalLiabilities)} + {formatCurrency(data.liabilitiesAndEquity.totalEquity)}
                                </p>
                                <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mt-1">
                                    Assets = Liabilities + Equity
                                </p>
                            </div>
                        </div>
                         <motion.div
                            initial={{ y: 50, opacity: 0 }}
                            animate={{ y: 0, opacity: 1 }}
                            transition={{ delay: 0.2, type: 'spring', stiffness: 100 }}
                            className="fixed bottom-6 right-6 z-40"
                        >
                            <div className="bg-white/70 backdrop-blur-md border border-white/50 rounded-full shadow-lg flex items-center gap-1 p-2">
                                <button onClick={handleExportExcel} className="flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold text-emerald-800 hover:bg-emerald-100/50 transition-colors" title="Export to Excel">
                                    <FileSpreadsheet size={16} />
                                    <span>Excel</span>
                                </button>
                                <button onClick={handleExportPdf} className="flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold text-sky-800 hover:bg-sky-100/50 transition-colors" title="Export to PDF">
                                    <FileText size={16} />
                                    <span>PDF</span>
                                </button>
                            </div>
                        </motion.div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
};

export default BalanceSheet;