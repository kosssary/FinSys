
import React from 'react';
import {
    LayoutGrid,
    TrendingUp,
    ShoppingCart,
    Wallet,
    Truck,
    Users,
    Settings,
    BookUser,
    FileText,
    Gift, // Added for Rewards
    PieChart, // Added for Analytics
    Percent,
    ShieldCheck,
    Activity // Added for Audit Log
} from 'lucide-react';

export const MODULE_NAMES = {
    DASHBOARD: 'Dashboard',
    SALES: 'Sales',
    PURCHASING: 'Purchasing',
    CONTACTS: 'Contacts',
    FINANCE: 'Financials',
    REPORTS: 'Reports',
    OPERATIONS: 'Operations',
    HR: 'Human Resources',
    SETTINGS: 'Settings',
    SECURITY: 'Security' // New module for roles/permissions
};

export const SIDEBAR_CONFIG = [
  {
    key: 'dashboard',
    title: 'Dashboard',
    icon: <LayoutGrid size={20} />,
    path: '/',
    module: MODULE_NAMES.DASHBOARD,
    permissionScope: 'dashboard'
  },
  {
    key: 'sales',
    title: 'Sales',
    icon: <TrendingUp size={20} />,
    module: MODULE_NAMES.SALES,
    subItems: [
      { title: 'Order Analytics', path: '/sales/analytics', icon: <PieChart size={16} />, permissionScope: 'sales.analytics' },
      { title: 'Orders', path: '/orders', permissionScope: 'sales.orders' },
      { title: 'Bundles', path: '/bundles', permissionScope: 'sales.bundles' },
      { title: 'Rewards Tracker', path: '/rewards-tracker', icon: <Gift size={16} />, permissionScope: 'sales.rewards' },
      { title: 'A/R Intelligence', path: '/receivables', permissionScope: 'sales.receivables' },
    ],
  },
  {
    key: 'purchasing',
    title: 'Purchasing',
    icon: <ShoppingCart size={20} />,
    module: MODULE_NAMES.PURCHASING,
    subItems: [
      { title: 'Supplier Bills', path: '/supplier-bills', permissionScope: 'purchasing.bills' },
      { title: 'Pay Bills', path: '/pay-bills', permissionScope: 'purchasing.pay_bills' },
      { title: 'Bill Payments List', path: '/bill-payments', permissionScope: 'purchasing.payments_list' },
    ],
  },
  {
    key: 'contacts',
    title: 'Contacts',
    icon: <BookUser size={20} />,
    module: MODULE_NAMES.CONTACTS,
    subItems: [
      { title: 'Customers', path: '/customers', permissionScope: 'contacts.customers' },
      { title: 'Vendors', path: '/vendors', permissionScope: 'contacts.vendors' },
      { title: 'Agents', path: '/agents', permissionScope: 'contacts.agents' },
      { title: 'Partners', path: '/partners', permissionScope: 'contacts.partners' },
    ],
  },
  {
    key: 'financials',
    title: 'Financials',
    icon: <Wallet size={20} />,
    module: MODULE_NAMES.FINANCE,
    subItems: [
      { type: 'header', title: 'Transactions' },
      { title: 'Receipts', path: '/receipts', permissionScope: 'finance.receipts' },
      { title: 'Expenses', path: '/expenses', permissionScope: 'finance.expenses' },
      { title: 'Journal Vouchers', path: '/journal-vouchers', permissionScope: 'finance.journal' },
      { title: 'Profit Distribution', path: '/profit-distribution', icon: <Percent size={16} />, permissionScope: 'finance.profit_distribution' },
      { type: 'header', title: 'Accounting' },
      { title: 'General Ledger', path: '/general-ledger', permissionScope: 'finance.general_ledger' },
      { title: 'Trial Balance', path: '/trial-balance', permissionScope: 'finance.trial_balance' },
    ],
  },
  {
    key: 'reports',
    title: 'Reports',
    icon: <FileText size={20} />,
    module: MODULE_NAMES.REPORTS,
    subItems: [
      { title: 'Financial Summary', path: '/financial-summary', permissionScope: 'reports.financial_summary' },
      { title: 'Profit & Loss', path: '/profit-and-loss', permissionScope: 'reports.profit_loss' },
      { title: 'Cash Flow Statement', path: '/cash-flow-statement', permissionScope: 'reports.cash_flow' },
      { title: 'Party Statements', path: '/party-statements', permissionScope: 'reports.party_statements' },
      { title: 'Balance Sheet', path: '/balance-sheet', permissionScope: 'reports.balance_sheet' },
      { title: 'A/P Aging Report', path: '/reports/ap-aging', permissionScope: 'reports.ap_aging' },
    ],
  },
  {
    key: 'operations',
    title: 'Operations',
    icon: <Truck size={20} />,
    module: MODULE_NAMES.OPERATIONS,
    subItems: [
        { title: 'Internal Transport', path: '/internal-transport', permissionScope: 'operations.transport'},
        { title: 'Warehouse Management', path: '/warehouse-management', permissionScope: 'operations.warehouse'}
    ]
  },
  {
    key: 'people',
    title: 'Human Resources',
    icon: <Users size={20} />,
    module: MODULE_NAMES.HR,
    subItems: [
      { title: 'Employees', path: '/employees', permissionScope: 'hr.employees' },
      { title: 'Payroll', path: '/payroll', permissionScope: 'hr.payroll' },
    ],
  },
  {
    key: 'settings',
    title: 'Settings',
    icon: <Settings size={20} />,
    module: MODULE_NAMES.SETTINGS,
    subItems: [
      { title: 'Chart of Accounts', path: '/chart-of-accounts', permissionScope: 'settings.coa' },
      { title: 'System Settings', path: '/system-settings', permissionScope: 'settings.system' },
      { title: 'Roles & Permissions', path: '/settings/roles', icon: <ShieldCheck size={16} />, module: MODULE_NAMES.SECURITY, permissionScope: 'settings.roles' },
      { title: 'User Management', path: '/settings/users', icon: <Users size={16} />, module: MODULE_NAMES.SECURITY, permissionScope: 'settings.users' },
      { title: 'Audit Log', path: '/settings/audit-log', icon: <Activity size={16} />, module: MODULE_NAMES.SECURITY, permissionScope: 'settings.audit' },
    ],
  },
];


export const IQ_CITIES = [
    "Anbar", "Babil", "Baghdad", "Basra", "Dhi Qar", "Diyala", "Dohuk",
    "Erbil", "Karbala", "Kirkuk", "Maysan", "Mosul", "Muthanna", "Najaf",
    "Qadisiyyah", "Saladin", "Sulaymaniyah", "Wasit"
].sort();