
import React, { createContext, useState, useEffect, ReactNode, useContext } from 'react';

export enum Theme {
    Light = 'light',
    Dark = 'dark',
}

interface ThemeContextType {
    theme: Theme;
    setTheme: (theme: Theme) => void;
}

export const ThemeContext = createContext<ThemeContextType>({
    theme: Theme.Light,
    setTheme: () => {},
});

export const ThemeProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [theme, setTheme] = useState<Theme>(() => {
        const savedTheme = localStorage.getItem('theme');
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        if (savedTheme && (savedTheme === 'dark' || savedTheme === 'light')) {
            return savedTheme as Theme;
        }
        return prefersDark ? Theme.Dark : Theme.Light;
    });

    useEffect(() => {
        const root = window.document.documentElement;
        root.classList.remove(Theme.Light, Theme.Dark);
        root.classList.add(theme);
        localStorage.setItem('theme', theme);
    }, [theme]);

    return (
        <ThemeContext.Provider value={{ theme, setTheme }}>
            {children}
        </ThemeContext.Provider>
    );
};

export const useTheme = () => useContext(ThemeContext);
