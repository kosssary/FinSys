
import React, { createContext, useContext, useState, ReactNode, useEffect, useCallback, useMemo } from 'react';
import { CustomerOrder, SupplierBundle, Transaction, Account, Shareholder, DailyReconciliation, Voucher, Employee, OrderStatus, Customer, ReceiptVoucherPayload, DisbursementVoucherPayload, Vendor, AdvancedTrialBalanceData, AccountCategory, Bill, BillPayment, RewardClaim, RewardMonthConfig, PartnerMetric, User, Role, PermissionAction, ActivityLog, ActionType } from '../types';
import { getApi, IDataApi } from '../services/mockApi';

interface DataContextType extends Omit<IDataApi, 'login'> {
    _version: number;
    exchangeRate: number;
    updateExchangeRate: (rate: number) => void;
    
    // Auth
    currentUser: User | null;
    isLoadingAuth: boolean;
    login: (email: string, password: string) => Promise<void>;
    logout: () => void;
    checkPermission: (module: string, action: PermissionAction) => boolean;

    // ... (Existing methods mapped here)
    addOrder: IDataApi['addOrder'];
    updateOrder: IDataApi['updateOrder'];
    deleteOrder: IDataApi['deleteOrder'];
    updateOrderStatus: IDataApi['updateOrderStatus'];
    addReceipt: (voucherData: ReceiptVoucherPayload) => Promise<Voucher>;
    addDisbursement: (voucherData: DisbursementVoucherPayload) => Promise<Voucher>;
    addJournalVoucher: IDataApi['addJournalVoucher'];
    updateReceipt: IDataApi['updateReceipt'];
    updateDisbursement: IDataApi['updateDisbursement'];
    updateJournalVoucher: IDataApi['updateJournalVoucher'];
    deleteVoucher: IDataApi['deleteVoucher'];
    addBundle: IDataApi['addBundle'];
    updateBundle: IDataApi['updateBundle'];
    deleteBundle: IDataApi['deleteBundle'];
    addCustomer: IDataApi['addCustomer'];
    updateCustomer: IDataApi['updateCustomer'];
    deleteCustomer: IDataApi['deleteCustomer'];
    addVendor: IDataApi['addVendor'];
    updateVendor: IDataApi['updateVendor'];
    deleteVendor: IDataApi['deleteVendor'];
    getVendors: IDataApi['getVendors'];
    getAgents: IDataApi['getAgents'];
    addAgent: IDataApi['addAgent'];
    updateAgent: IDataApi['updateAgent'];
    deleteAgent: IDataApi['deleteAgent'];
    addAccount: IDataApi['addAccount'];
    updateAccount: IDataApi['updateAccount'];
    deleteAccount: IDataApi['deleteAccount'];
    addShareholder: IDataApi['addShareholder'];
    updateShareholder: IDataApi['updateShareholder'];
    deleteShareholder: IDataApi['deleteShareholder'];
    addEmployee: IDataApi['addEmployee'];
    recordEmployeeAdvance: IDataApi['recordEmployeeAdvance'];
    finalizePayroll: IDataApi['finalizePayroll'];
    payPayroll: IDataApi['payPayroll'];
    getVendorsWithBalance: IDataApi['getVendorsWithBalance'];
    getCashFlowStatement: IDataApi['getCashFlowStatement'];
    getBalanceSheet: IDataApi['getBalanceSheet'];
    getFinancialSummaryReport: IDataApi['getFinancialSummaryReport'];
    getAdvancedTrialBalance: (startDateStr: string, endDateStr: string, categoryFilter: Set<AccountCategory>, showZeroBalance: boolean) => Promise<AdvancedTrialBalanceData>;
    getBills: IDataApi['getBills'];
    addBill: IDataApi['addBill'];
    updateBill: IDataApi['updateBill'];
    deleteBill: IDataApi['deleteBill'];
    getOpenBillsForVendor: (vendorId: string) => Promise<Bill[]>;
    recordBillPayment: (paymentData: { billId: string; paymentDate: Date; amount: number; paymentAccountId: string; referenceNumber: string; notes?: string; }[]) => Promise<void>;
    getApAgingReport: IDataApi['getApAgingReport'];
    getStatementForVendor: IDataApi['getStatementForVendor'];
    getBillPayments: IDataApi['getBillPayments'];
    voidBillPayment: IDataApi['voidBillPayment'];
    processBatchDelivery: IDataApi['processBatchDelivery'];
    revertDelivery: IDataApi['revertDelivery'];
    getRewardClaims: IDataApi['getRewardClaims'];
    getRewardMonthConfigs: IDataApi['getRewardMonthConfigs'];
    upsertRewardMonthConfig: IDataApi['upsertRewardMonthConfig'];
    recognizeRewardPoints: IDataApi['recognizeRewardPoints'];
    processOrderCancellation: IDataApi['processOrderCancellation'];
    getNetProfitForPeriod: IDataApi['getNetProfitForPeriod'];
    getPartnerMetrics: IDataApi['getPartnerMetrics'];
    distributePeriodProfit: IDataApi['distributePeriodProfit'];
    
    // RBAC Methods
    getRoles: IDataApi['getRoles'];
    saveRole: IDataApi['saveRole'];
    deleteRole: IDataApi['deleteRole'];
    getUsers: IDataApi['getUsers'];
    inviteUser: IDataApi['inviteUser'];
    updateUserRole: IDataApi['updateUserRole'];
    deleteUser: IDataApi['deleteUser'];
    updateUser: IDataApi['updateUser'];
    updateProfile: IDataApi['updateProfile'];
    register: IDataApi['register'];

    // Audit
    getActivityLogs: IDataApi['getActivityLogs'];
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [api, setApi] = useState<IDataApi | null>(null);
    const [version, setVersion] = useState(0);
    const [exchangeRate, setExchangeRate] = useState(() => {
        const saved = localStorage.getItem('exchangeRate');
        return saved ? parseFloat(saved) : 1500;
    });
    
    // Auth State
    const [currentUser, setCurrentUser] = useState<User | null>(null);
    const [isLoadingAuth, setIsLoadingAuth] = useState(true);
    const [userPermissions, setUserPermissions] = useState<Role['permissions']>({});

    useEffect(() => {
        getApi().then(apiInstance => {
            setApi(apiInstance);
            // Check for existing session
            const storedUser = localStorage.getItem('currentUser');
            if (storedUser) {
                const user = JSON.parse(storedUser);
                setCurrentUser(user);
                // Hydrate permissions
                apiInstance.getRoleById(user.roleId).then(role => {
                    if (role) setUserPermissions(role.permissions);
                    setIsLoadingAuth(false);
                });
            } else {
                setIsLoadingAuth(false);
            }
        });
    }, []);

    const forceUpdate = useCallback(() => setVersion(v => v + 1), []);

    const updateExchangeRate = useCallback((rate: number) => {
        setExchangeRate(rate);
        localStorage.setItem('exchangeRate', rate.toString());
    }, []);

    // --- Helper to Log Activity ---
    const logActivity = useCallback(async (action: ActionType, module: string, description: string, targetId?: string) => {
        if (!api || !currentUser) return;
        try {
            await api.logAction({
                userId: currentUser.id,
                userName: currentUser.name,
                userRole: currentUser.roleName || 'Unknown',
                action,
                module,
                description,
                targetId
            });
        } catch (e) {
            console.error("Failed to log activity", e);
        }
    }, [api, currentUser]);

    // --- Auth Methods ---
    const login = useCallback(async (email: string, pass: string) => {
        if (!api) throw new Error("API not ready");
        const user = await api.login(email, pass);
        if (user) {
            setCurrentUser(user);
            localStorage.setItem('currentUser', JSON.stringify(user));
            const role = await api.getRoleById(user.roleId);
            if (role) setUserPermissions(role.permissions);
            // Manual log call here because currentUser isn't set yet in the callback context
            await api.logAction({
                userId: user.id,
                userName: user.name,
                userRole: role?.name || 'User',
                action: 'Login',
                module: 'Auth',
                description: 'User logged in successfully'
            });
        } else {
            throw new Error("Invalid credentials or account not active.");
        }
    }, [api]);

    const logout = useCallback(() => {
        if (currentUser) {
            logActivity('Logout', 'Auth', 'User logged out');
        }
        setCurrentUser(null);
        setUserPermissions({});
        localStorage.removeItem('currentUser');
    }, [currentUser, logActivity]);

    const checkPermission = useCallback((module: string, action: PermissionAction): boolean => {
        if (currentUser?.roleId === 'role-super-admin') return true;
        if (!userPermissions) return false;
        const modulePerms = userPermissions[module];
        if (!modulePerms) return false;
        return modulePerms.includes(action);
    }, [userPermissions, currentUser]);


    // --- Mapped API Methods with Middleware Logging ---
    
    const addOrder = useCallback<IDataApi['addOrder']>(async (...args) => { 
        if (!api) throw new Error("API not ready"); 
        const result = await api.addOrder(...args); 
        await logActivity('Create', 'Orders', `Created order for ${result.customerName}`, result.id);
        forceUpdate(); 
        return result; 
    }, [api, forceUpdate, logActivity]);

    const updateOrder = useCallback<IDataApi['updateOrder']>(async (...args) => { 
        if (!api) throw new Error("API not ready"); 
        const result = await api.updateOrder(...args); 
        await logActivity('Edit', 'Orders', `Updated order details`, result.id);
        forceUpdate(); 
        return result; 
    }, [api, forceUpdate, logActivity]);

    const deleteOrder = useCallback<IDataApi['deleteOrder']>(async (...args) => { 
        if (!api) throw new Error("API not ready"); 
        await api.deleteOrder(...args); 
        await logActivity('Delete', 'Orders', `Deleted order`, args[0]);
        forceUpdate(); 
    }, [api, forceUpdate, logActivity]);

    const updateOrderStatus = useCallback<IDataApi['updateOrderStatus']>(async (...args) => { 
        if (!api) throw new Error("API not ready"); 
        await api.updateOrderStatus(...args); 
        await logActivity('Status Change', 'Orders', `Updated order status to ${args[1]}`, args[0]);
        forceUpdate(); 
    }, [api, forceUpdate, logActivity]);

    const addReceipt = useCallback<DataContextType['addReceipt']>(async (voucherData) => { 
        if (!api) throw new Error("API not ready"); 
        const result = await api.addReceipt(voucherData); 
        await logActivity('Create', 'Financials', `Created Receipt Voucher ${result.voucherNumber}`, result.voucherId);
        forceUpdate(); 
        return result; 
    }, [api, forceUpdate, logActivity]);

    const addDisbursement = useCallback<DataContextType['addDisbursement']>(async (voucherData) => { 
        if (!api) throw new Error("API not ready"); 
        const result = await api.addDisbursement(voucherData); 
        await logActivity('Create', 'Financials', `Created Disbursement Voucher ${result.voucherNumber}`, result.voucherId);
        forceUpdate(); 
        return result; 
    }, [api, forceUpdate, logActivity]);

    const addJournalVoucher = useCallback<IDataApi['addJournalVoucher']>(async (...args) => { 
        if (!api) throw new Error("API not ready"); 
        const result = await api.addJournalVoucher(...args); 
        await logActivity('Create', 'Financials', `Created Journal Voucher ${result.voucherNumber}`, result.voucherId);
        forceUpdate(); 
        return result; 
    }, [api, forceUpdate, logActivity]);

    const finalizePayroll = useCallback<IDataApi['finalizePayroll']>(async (...args) => { 
        if (!api) throw new Error("API not ready"); 
        await api.finalizePayroll(...args); 
        await logActivity('Approve', 'Payroll', `Finalized payroll for ${args[0].period}`, args[0].id);
        forceUpdate(); 
    }, [api, forceUpdate, logActivity]);

    const addBundle = useCallback<IDataApi['addBundle']>(async (...args) => { 
        if (!api) throw new Error("API not ready"); 
        const result = await api.addBundle(...args); 
        await logActivity('Create', 'Sales', `Created Bundle ${result.name}`, result.id);
        forceUpdate(); 
        return result; 
    }, [api, forceUpdate, logActivity]);

    const addBill = useCallback<IDataApi['addBill']>(async (...args) => { 
        if (!api) throw new Error("API not ready"); 
        const result = await api.addBill(...args); 
        await logActivity('Create', 'Purchasing', `Recorded Bill ${result.billNumber} from ${result.vendorName}`, result.id);
        forceUpdate(); 
        return result; 
    }, [api, forceUpdate, logActivity]);

    // Standard methods (no log or low priority)
    const updateReceipt = useCallback<IDataApi['updateReceipt']>(async (...args) => { if (!api) throw new Error("API not ready"); await api.updateReceipt(...args); forceUpdate(); }, [api, forceUpdate]);
    const updateDisbursement = useCallback<IDataApi['updateDisbursement']>(async (...args) => { if (!api) throw new Error("API not ready"); await api.updateDisbursement(...args); forceUpdate(); }, [api, forceUpdate]);
    const updateJournalVoucher = useCallback<IDataApi['updateJournalVoucher']>(async (...args) => { if (!api) throw new Error("API not ready"); await api.updateJournalVoucher(...args); forceUpdate(); }, [api, forceUpdate]);
    const deleteVoucher = useCallback<IDataApi['deleteVoucher']>(async (...args) => { 
        if (!api) throw new Error("API not ready"); 
        await api.deleteVoucher(...args); 
        await logActivity('Delete', 'Financials', `Deleted voucher`, args[0]);
        forceUpdate(); 
    }, [api, forceUpdate, logActivity]);
    const updateBundle = useCallback<IDataApi['updateBundle']>(async (...args) => { if (!api) throw new Error("API not ready"); await api.updateBundle(...args); forceUpdate(); }, [api, forceUpdate]);
    const deleteBundle = useCallback<IDataApi['deleteBundle']>(async (...args) => { if (!api) throw new Error("API not ready"); await api.deleteBundle(...args); forceUpdate(); }, [api, forceUpdate]);
    const addCustomer = useCallback<IDataApi['addCustomer']>(async (...args) => { if (!api) throw new Error("API not ready"); const result = await api.addCustomer(...args); forceUpdate(); return result; }, [api, forceUpdate]);
    const updateCustomer = useCallback<IDataApi['updateCustomer']>(async (...args) => { if (!api) throw new Error("API not ready"); await api.updateCustomer(...args); forceUpdate(); }, [api, forceUpdate]);
    const deleteCustomer = useCallback<IDataApi['deleteCustomer']>(async (...args) => { if (!api) throw new Error("API not ready"); await api.deleteCustomer(...args); forceUpdate(); }, [api, forceUpdate]);
    const addVendor = useCallback<IDataApi['addVendor']>(async (...args) => { if (!api) throw new Error("API not ready"); const result = await api.addVendor(...args); forceUpdate(); return result; }, [api, forceUpdate]);
    const updateVendor = useCallback<IDataApi['updateVendor']>(async (...args) => { if (!api) throw new Error("API not ready"); await api.updateVendor(...args); forceUpdate(); }, [api, forceUpdate]);
    const deleteVendor = useCallback<IDataApi['deleteVendor']>(async (...args) => { if (!api) throw new Error("API not ready"); await api.deleteVendor(...args); forceUpdate(); }, [api, forceUpdate]);
    const getVendors = useCallback<IDataApi['getVendors']>(async () => { if (!api) throw new Error("API not ready"); return api.getVendors(); }, [api]);
    const addAgent = useCallback<IDataApi['addAgent']>(async (...args) => { if (!api) throw new Error("API not ready"); const result = await api.addAgent(...args); forceUpdate(); return result; }, [api, forceUpdate]);
    const updateAgent = useCallback<IDataApi['updateAgent']>(async (...args) => { if (!api) throw new Error("API not ready"); await api.updateAgent(...args); forceUpdate(); }, [api, forceUpdate]);
    const deleteAgent = useCallback<IDataApi['deleteAgent']>(async (...args) => { if (!api) throw new Error("API not ready"); await api.deleteAgent(...args); forceUpdate(); }, [api, forceUpdate]);
    const getAgents = useCallback<IDataApi['getAgents']>(async () => { if (!api) throw new Error("API not ready"); return api.getAgents(); }, [api]);
    const addAccount = useCallback<IDataApi['addAccount']>(async (...args) => { if (!api) throw new Error("API not ready"); const result = await api.addAccount(...args); forceUpdate(); return result; }, [api, forceUpdate]);
    const updateAccount = useCallback<IDataApi['updateAccount']>(async (...args) => { if (!api) throw new Error("API not ready"); await api.updateAccount(...args); forceUpdate(); }, [api, forceUpdate]);
    const deleteAccount = useCallback<IDataApi['deleteAccount']>(async (...args) => { if (!api) throw new Error("API not ready"); await api.deleteAccount(...args); forceUpdate(); }, [api, forceUpdate]);
    const addShareholder = useCallback<IDataApi['addShareholder']>(async (...args) => { if (!api) throw new Error("API not ready"); const result = await api.addShareholder(...args); forceUpdate(); return result; }, [api, forceUpdate]);
    const updateShareholder = useCallback<IDataApi['updateShareholder']>(async (...args) => { if (!api) throw new Error("API not ready"); await api.updateShareholder(...args); forceUpdate(); }, [api, forceUpdate]);
    const deleteShareholder = useCallback<IDataApi['deleteShareholder']>(async (...args) => { if (!api) throw new Error("API not ready"); await api.deleteShareholder(...args); forceUpdate(); }, [api, forceUpdate]);
    const addEmployee = useCallback<IDataApi['addEmployee']>(async (...args) => { if (!api) throw new Error("API not ready"); const result = await api.addEmployee(...args); forceUpdate(); return result; }, [api, forceUpdate]);
    const recordEmployeeAdvance = useCallback<IDataApi['recordEmployeeAdvance']>(async (...args) => { if (!api) throw new Error("API not ready"); await api.recordEmployeeAdvance(...args); forceUpdate(); }, [api, forceUpdate]);
    const payPayroll = useCallback<IDataApi['payPayroll']>(async (...args) => { 
        if (!api) throw new Error("API not ready"); 
        await api.payPayroll(...args); 
        await logActivity('Create', 'Payroll', 'Recorded salary payment', args[0]);
        forceUpdate(); 
    }, [api, forceUpdate, logActivity]);
    const getVendorsWithBalance = useCallback<IDataApi['getVendorsWithBalance']>(async (...args) => { if (!api) throw new Error("API not ready"); return api.getVendorsWithBalance(...args); }, [api]);
    const getCashFlowStatement = useCallback<IDataApi['getCashFlowStatement']>(async (...args) => { if (!api) throw new Error("API not ready"); return api.getCashFlowStatement(...args); }, [api]);
    const getBalanceSheet = useCallback<IDataApi['getBalanceSheet']>(async (...args) => { if (!api) throw new Error("API not ready"); return api.getBalanceSheet(...args); }, [api]);
    const getFinancialSummaryReport = useCallback<IDataApi['getFinancialSummaryReport']>(async (...args) => { if (!api) throw new Error("API not ready"); return api.getFinancialSummaryReport(...args); }, [api]);
    const getAdvancedTrialBalance = useCallback<IDataApi['getAdvancedTrialBalance']>(async (...args) => { if (!api) throw new Error("API not ready"); return api.getAdvancedTrialBalance(...args); }, [api]);
    const getBills = useCallback<IDataApi['getBills']>(async (...args) => { if (!api) throw new Error("API not ready"); return api.getBills(...args); }, [api]);
    const updateBill = useCallback<IDataApi['updateBill']>(async (...args) => { if (!api) throw new Error("API not ready"); const result = await api.updateBill(...args); forceUpdate(); return result; }, [api, forceUpdate]);
    const deleteBill = useCallback<IDataApi['deleteBill']>(async (...args) => { if (!api) throw new Error("API not ready"); await api.deleteBill(...args); forceUpdate(); }, [api, forceUpdate]);
    const getOpenBillsForVendor = useCallback<IDataApi['getOpenBillsForVendor']>(async (...args) => { if (!api) throw new Error("API not ready"); return api.getOpenBillsForVendor(...args); }, [api]);
    const recordBillPayment = useCallback<IDataApi['recordBillPayment']>(async (...args) => { if (!api) throw new Error("API not ready"); await api.recordBillPayment(...args); forceUpdate(); }, [api, forceUpdate]);
    const getApAgingReport = useCallback<IDataApi['getApAgingReport']>(async (...args) => { if (!api) throw new Error("API not ready"); return api.getApAgingReport(...args); }, [api]);
    const getStatementForVendor = useCallback<IDataApi['getStatementForVendor']>(async (...args) => { if (!api) throw new Error("API not ready"); return api.getStatementForVendor(...args); }, [api]);
    const getBillPayments = useCallback<IDataApi['getBillPayments']>(async (...args) => { if (!api) throw new Error("API not ready"); return api.getBillPayments(...args); }, [api]);
    const voidBillPayment = useCallback<IDataApi['voidBillPayment']>(async (...args) => { if (!api) throw new Error("API not ready"); await api.voidBillPayment(...args); forceUpdate(); }, [api, forceUpdate]);
    const processBatchDelivery = useCallback<IDataApi['processBatchDelivery']>(async (...args) => { if (!api) throw new Error("API not ready"); await api.processBatchDelivery(...args); forceUpdate(); }, [api, forceUpdate]);
    const revertDelivery = useCallback<IDataApi['revertDelivery']>(async (...args) => { 
        if (!api) throw new Error("API not ready"); 
        await api.revertDelivery(...args); 
        await logActivity('Status Change', 'Orders', `Reverted delivery status`, args[0]);
        forceUpdate(); 
    }, [api, forceUpdate, logActivity]);
    const getRewardClaims = useCallback<IDataApi['getRewardClaims']>(async (...args) => { if (!api) throw new Error("API not ready"); return api.getRewardClaims(...args); }, [api]);
    const getRewardMonthConfigs = useCallback<IDataApi['getRewardMonthConfigs']>(async (...args) => { if (!api) throw new Error("API not ready"); return api.getRewardMonthConfigs(...args); }, [api]);
    const upsertRewardMonthConfig = useCallback<IDataApi['upsertRewardMonthConfig']>(async (...args) => { if (!api) throw new Error("API not ready"); await api.upsertRewardMonthConfig(...args); forceUpdate(); }, [api, forceUpdate]);
    const recognizeRewardPoints = useCallback<IDataApi['recognizeRewardPoints']>(async (...args) => { if (!api) throw new Error("API not ready"); await api.recognizeRewardPoints(...args); forceUpdate(); }, [api, forceUpdate]);
    const processOrderCancellation = useCallback<IDataApi['processOrderCancellation']>(async (orderId, scenario) => { if (!api) throw new Error("API not ready"); const result = await api.processOrderCancellation(orderId, scenario); forceUpdate(); return result; }, [api, forceUpdate]);
    const getNetProfitForPeriod = useCallback<IDataApi['getNetProfitForPeriod']>(async (startDateStr, endDateStr) => { if (!api) throw new Error("API not ready"); return api.getNetProfitForPeriod(startDateStr, endDateStr); }, [api]);
    const getPartnerMetrics = useCallback<IDataApi['getPartnerMetrics']>(async () => { if (!api) throw new Error("API not ready"); return api.getPartnerMetrics(); }, [api]);
    const distributePeriodProfit = useCallback<IDataApi['distributePeriodProfit']>(async (date, distributions) => { if (!api) throw new Error("API not ready"); await api.distributePeriodProfit(date, distributions); forceUpdate(); }, [api, forceUpdate]);
    
    // RBAC
    const getRoles = useCallback<IDataApi['getRoles']>(async () => { if (!api) throw new Error("API not ready"); return api.getRoles(); }, [api]);
    const saveRole = useCallback<IDataApi['saveRole']>(async (role) => { if (!api) throw new Error("API not ready"); const res = await api.saveRole(role); forceUpdate(); return res; }, [api, forceUpdate]);
    const deleteRole = useCallback<IDataApi['deleteRole']>(async (id) => { if (!api) throw new Error("API not ready"); await api.deleteRole(id); forceUpdate(); }, [api, forceUpdate]);
    const getUsers = useCallback<IDataApi['getUsers']>(async () => { if (!api) throw new Error("API not ready"); return api.getUsers(); }, [api]);
    const inviteUser = useCallback<IDataApi['inviteUser']>(async (...args) => { if (!api) throw new Error("API not ready"); const res = await api.inviteUser(...args); forceUpdate(); return res; }, [api, forceUpdate]);
    const updateUserRole = useCallback<IDataApi['updateUserRole']>(async (...args) => { if (!api) throw new Error("API not ready"); await api.updateUserRole(...args); forceUpdate(); }, [api, forceUpdate]);
    const deleteUser = useCallback<IDataApi['deleteUser']>(async (id) => { if (!api) throw new Error("API not ready"); await api.deleteUser(id); forceUpdate(); }, [api, forceUpdate]);
    const updateUser = useCallback<IDataApi['updateUser']>(async (...args) => { if (!api) throw new Error("API not ready"); await api.updateUser(...args); forceUpdate(); }, [api, forceUpdate]);
    const updateProfile = useCallback<IDataApi['updateProfile']>(async (...args) => { if (!api) throw new Error("API not ready"); await api.updateProfile(...args); forceUpdate(); }, [api, forceUpdate]);
    const register = useCallback<IDataApi['register']>(async (...args) => { if (!api) throw new Error("API not ready"); const res = await api.register(...args); forceUpdate(); return res; }, [api, forceUpdate]);

    const getActivityLogs = useCallback<IDataApi['getActivityLogs']>(async () => { if (!api) throw new Error("API not ready"); return api.getActivityLogs(); }, [api]);

    const value = useMemo(() => {
        if (!api) {
            return undefined;
        }
        return {
            ...api,
            _version: version,
            exchangeRate,
            updateExchangeRate,
            // Auth
            currentUser,
            isLoadingAuth,
            login,
            logout,
            checkPermission,
            // RBAC Methods mapped
            getRoles, saveRole, deleteRole, getUsers, inviteUser, updateUserRole, deleteUser, updateUser, updateProfile, register,
            // Other methods mapped
            addOrder, updateOrder, deleteOrder, updateOrderStatus, 
            addReceipt: addReceipt as IDataApi['addReceipt'], addDisbursement: addDisbursement as IDataApi['addDisbursement'], addJournalVoucher, 
            updateReceipt, updateDisbursement, updateJournalVoucher, deleteVoucher, 
            addBundle, updateBundle, deleteBundle, addCustomer, updateCustomer, deleteCustomer, 
            addVendor, updateVendor, deleteVendor, getVendors, addAgent, updateAgent, deleteAgent, getAgents,
            addAccount, updateAccount, deleteAccount, 
            addShareholder, updateShareholder, deleteShareholder,
            addEmployee, recordEmployeeAdvance, finalizePayroll, payPayroll,
            getVendorsWithBalance, getCashFlowStatement, getBalanceSheet, getFinancialSummaryReport,
            getAdvancedTrialBalance,
            getBills, addBill, updateBill, deleteBill, getOpenBillsForVendor, recordBillPayment, getApAgingReport, getStatementForVendor,
            getBillPayments, voidBillPayment, processBatchDelivery, revertDelivery,
            getRewardClaims, getRewardMonthConfigs, upsertRewardMonthConfig, recognizeRewardPoints, processOrderCancellation,
            getNetProfitForPeriod, getPartnerMetrics, distributePeriodProfit,
            getActivityLogs
        };
    }, [
        api, version, exchangeRate, updateExchangeRate, 
        currentUser, isLoadingAuth, login, logout, checkPermission,
        addOrder, updateOrder, deleteOrder, updateOrderStatus, addReceipt, addDisbursement, addJournalVoucher, 
        updateReceipt, updateDisbursement, updateJournalVoucher, deleteVoucher, 
        addBundle, updateBundle, deleteBundle, addCustomer, updateCustomer, deleteCustomer, 
        addVendor, updateVendor, deleteVendor, getVendors, addAgent, updateAgent, deleteAgent, getAgents,
        addAccount, updateAccount, deleteAccount, 
        addShareholder, updateShareholder, deleteShareholder,
        addEmployee, recordEmployeeAdvance, finalizePayroll, payPayroll,
        getVendorsWithBalance, getCashFlowStatement, getBalanceSheet, getFinancialSummaryReport,
        getAdvancedTrialBalance,
        getBills, addBill, updateBill, deleteBill, getOpenBillsForVendor, recordBillPayment, getApAgingReport, getStatementForVendor,
        getBillPayments, voidBillPayment, processBatchDelivery, revertDelivery,
        getRewardClaims, getRewardMonthConfigs, upsertRewardMonthConfig, recognizeRewardPoints, processOrderCancellation,
        getNetProfitForPeriod, getPartnerMetrics, distributePeriodProfit,
        getRoles, saveRole, deleteRole, getUsers, inviteUser, updateUserRole, deleteUser, updateUser, updateProfile, register,
        getActivityLogs
    ]);


    if (!value) {
        return (
            <div className="flex items-center justify-center h-screen bg-gray-100 dark:bg-gray-900">
                <div className="text-center">
                    <h2 className="text-xl font-semibold text-gray-700 dark:text-gray-200">Loading System...</h2>
                    <p className="text-gray-500 dark:text-gray-400">Please wait a moment.</p>
                </div>
            </div>
        );
    }

    return (
        <DataContext.Provider value={value}>
            {children}
        </DataContext.Provider>
    );
};

export const useData = (): DataContextType => {
    const context = useContext(DataContext);
    if (!context) {
        throw new Error('useData must be used within a DataProvider');
    }
    return context;
};
