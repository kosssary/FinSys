
export enum OrderStatus {
    Pending = 'Pending',
    Bundled = 'Bundled',
    InTransit = 'In Transit',
    InWarehouse = 'In Warehouse',
    OutForDelivery = 'Out for Delivery',
    Delivered = 'Delivered',
    Paid = 'Paid',
    Cancelled = 'Cancelled',
    Stocked = 'Stocked', // For items kept in inventory after cancellation
    Returned = 'Returned' // For items returned by customer
}

export enum PaymentStatus {
    NotPaid = 'Not Paid',
    PartiallyPaid = 'Partially Paid',
    FullyPaid = 'Fully Paid'
}

// --- ACTIVITY LOG TYPES ---
export type ActionType = 'Create' | 'Edit' | 'Delete' | 'Login' | 'Logout' | 'Approve' | 'Reject' | 'Status Change';

export interface ActivityLog {
    id: string;
    timestamp: Date;
    userId: string;
    userName: string;
    userRole: string;
    action: ActionType;
    module: string; // e.g., 'Orders', 'Payroll', 'Auth'
    targetId?: string; // e.g., 'ORD-1001'
    description: string;
}

// --- AUTH & RBAC TYPES ---

export type PermissionAction = 'view' | 'create' | 'edit' | 'delete' | 'approve';

export interface Permission {
    [moduleName: string]: PermissionAction[];
}

export interface Role {
    id: string;
    name: string;
    description: string;
    permissions: Permission;
    isSystem?: boolean; // If true, cannot be deleted (e.g. Super Admin)
}

export interface User {
    id: string;
    name: string;
    email: string;
    password?: string; // Admin needs to see this, though usually not secure in real apps
    roleId: string;
    roleName?: string; // Denormalized for display
    avatar?: string;
    status: 'Active' | 'Pending' | 'Invited' | 'Disabled';
    lastLogin?: Date;
    createdAt?: Date;
}

export interface Agent {
    id: string;
    name: string;
    phone: string;
    commissionRate?: number; // Percentage
    createdAt: Date;
}

export interface CustomerOrder {
    id: string;
    customerId: string;
    customerName: string;
    customerPhone: string;
    customerPhone2?: string;
    agentId?: string; // Reference to the Agent who brought the order
    agentName?: string; // Denormalized name for display
    productLink?: string;
    orderDescription?: string;
    totalPrice: number;
    logisticsId?: string;
    bundleId?: string;
    status: OrderStatus;
    createdAt: Date;
    orderDate: Date;
    paidAmount: number;
    receiptNumber?: string;
    estimatedDueDate?: Date;
    internalShippingCost?: number; // Cost if company pays for shipping
    courierVendorId?: string; // Track which courier delivered this
    courierVendorName?: string; // Display name for history
    itemCount?: number; // Number of physical items in the order
}

export interface SupplierBundle {
    id: string;
    name: string;
    logisticsReferenceId: string;
    totalCost: number;
    paymentAccountId: string;
    orderIds: string[];
    createdAt: Date;
    paymentRecorded: boolean;
}

export enum TransactionType {
    Debit = 'Debit',
    Credit = 'Credit'
}

export interface Transaction {
    id: string;
    accountId: string;
    date: Date;
    description: string;
    amount: number;
    type: TransactionType;
    referenceId?: string; // e.g., OrderID, BundleID
    partyName?: string; // "Received from" or "Paid to"
    customerId?: string;
    vendorId?: string;
    agentId?: string;
    employeeId?: string;
    receiptNumber?: string; // Physical receipt number from voucher
    voucherId: string; // Groups multiple transactions into a single voucher
    voucherNumber: string; // User-facing voucher number (e.g., RV-001)
}

export enum PaymentMethodType {
    Cash = 'Cash',
    Bank = 'Bank',
    EWallet = 'E-Wallet',
    MasterCard = 'MasterCard',
    MobileCredit = 'Mobile Credit'
}

export enum AccountCategory {
    Asset = 'Asset',
    Liability = 'Liability',
    Equity = 'Equity',
    Revenue = 'Revenue',
    COGS = 'Cost of Goods Sold',
    OperatingExpense = 'Operating Expense',
}

export enum AccountType {
    Cash = 'Cash',
    Bank = 'Bank or Credit Card',
    EWallet = 'E-Wallet',
    MobileCredit = 'Mobile Credit',
    AccountsReceivable = 'Accounts Receivable',
    OtherCurrentAsset = 'Other Current Asset',
    FixedAsset = 'Fixed Asset',
    AccountsPayable = 'Accounts Payable',
    OtherCurrentLiability = 'Other Current Liability',
    Equity = 'Equity',
    Revenue = 'Revenue',
    COGS = 'Cost of Goods Sold',
    OperatingExpense = 'Operating Expense',
}

export interface Account {
    id: string;
    code: string;
    name: string;
    nameKurdish: string;
    parentId: string | null;
    category: AccountCategory;
    accountType: AccountType;
    balance: number;
    isDeletable: boolean; 
    shareholderId?: string;
    // For frontend tree structure
    children?: Account[];
    isPostable: boolean;
    // For smart filtering
    pathCodes: string[];
    isActive: boolean;
    isLocked: boolean;
}


export interface Shareholder {
    id:string;
    name: string;
    profitSharePercentage: number;
    capitalContributions: number;
}

export interface DailyReconciliation {
    id: string;
    date: Date;
    agentName: string;
    expectedAmount: number;
    actualAmount: number;
}

export interface Customer {
    id: string;
    name?: string;
    phone1: string;
    phone2?: string;
    address: string;
    createdAt: Date;
    email?: string;
}

export interface Vendor {
    id: string;
    name: string;
    contactPerson?: string;
    phone?: string;
    address?: string;
}

export interface PartyStatement {
    partyId: string;
    partyName: string;
    partyPhone: string;
    partyType: 'customer' | 'vendor';
    startDate: string;
    endDate: string;
    openingBalance: number;
    closingBalance: number;
    totalDebit: number; // For the period
    totalCredit: number; // For the period
    statementRows: (Transaction & { balance: number })[];
}

export interface AccountLedger {
    accountId: string;
    accountName: string;
    accountCode: string;
    startDate: string;
    endDate: string;
    openingBalance: number;
    closingBalance: number;
    totalDebit: number;
    totalCredit: number;
    transactions: Transaction[];
}

export interface GeneralLedgerNode {
    account: Account;
    openingBalance: number;
    closingBalance: number;
    totalDebit: number;
    totalCredit: number;
    transactions: Transaction[];
    level: number;
    isPostable: boolean;
    children: GeneralLedgerNode[];
}

// Unified Smart Voucher line types
export type PartyEntity = { id: string; type: 'customer' | 'vendor' | 'employee' | 'shareholder'; name: string };
export type SmartVoucherLineEntity = { id: string; type: 'customer' | 'vendor' | 'account' | 'employee' | 'shareholder'; name: string };

export interface SmartVoucherLine {
    entity: SmartVoucherLineEntity | null;
    description: string;
    amount: string;
    referenceId?: string;
}
export interface ReceiptVoucherPayload {
    date: Date;
    accountId: string; // Deposit To account
    referenceNumber?: string;
    lines: {
// Use SmartVoucherLineEntity to allow accounts as payers.
        payerEntity: SmartVoucherLineEntity;
        accountId: string; // The contra-account (e.g., A/R, Revenue)
        amount: number;
        description: string;
// Add referenceId to handle receipt numbers consistently.
        referenceId?: string;
    }[];
}
export interface DisbursementVoucherPayload {
    date: Date;
    accountId: string; // Paid From account
    referenceNumber?: string;
    lines: {
// Use SmartVoucherLineEntity to allow accounts as payees.
        payeeEntity: SmartVoucherLineEntity;
        accountId: string; // The contra-account (e.g., Expense, Asset)
        amount: number;
        description: string;
// Add referenceId for consistency.
        referenceId?: string;
    }[];
}


export interface VoucherLine {
    partyId: string;
// Align partyType with the more flexible SmartVoucherLineEntity type.
    partyType: SmartVoucherLineEntity['type'];
    partyName: string; // denormalized for easier display
    accountId: string; // contra-account
    description: string;
    amount: number;
// Add referenceId to store identifiers like receipt numbers.
    referenceId?: string;
}

export interface Voucher {
    voucherId: string;
    voucherNumber: string;
    date: Date;
    accountId: string; // The primary asset account (Debit for Receipt, Credit for Disbursement)
    type: TransactionType;
    referenceNumber?: string;
    lines: VoucherLine[];
    totalAmount: number;
}


export interface JournalVoucherLine {
    accountId: string;
    description: string;
    debit: number;
    credit: number;
    customerId?: string;
    vendorId?: string;
    agentId?: string;
    employeeId?: string;
    partyName?: string;
    referenceId?: string; 
}

export interface JournalVoucher {
    voucherId: string;
    voucherNumber: string;
    date: Date;
    description: string; // General description for the whole JV
    referenceNumber?: string;
    lines: JournalVoucherLine[];
    sourceReference?: {
        type: 'Order' | 'Receipt' | 'Disbursement' | 'Bundle' | 'Payroll' | 'Bill' | 'BillPayment' | 'Revert' | 'RewardClaim' | 'ProfitDistribution';
        id: string;
    };
    status?: 'Posted' | 'Voided';
}

export interface FinancialSummaryReportData {
    income: {
        totalRevenue: number;
        cogs: number;
        grossProfit: number;
        operatingExpenses: number;
        netProfit: number;
    };
    balanceSheet: {
        currentAssets: number;
        nonCurrentAssets: number;
        totalAssets: number;
        currentLiabilities: number;
        longTermLiabilities: number;
        totalLiabilities: number;
        ownersCapital: number;
        retainedEarnings: number;
        currentYearProfit: number;
        totalEquity: number;
    };
    cashFlow: {
        operating: number;
        investing: number;
        financing: number;
        netPosition: number;
    };
    kpis: {
        grossMargin: number; // percentage
        netMargin: number; // percentage
        currentRatio: number;
        quickRatio: number;
        debtToEquity: number;
    };
}


export interface HierarchicalPnlNode {
    id: string;
    name: string;
    code: string;
    total: number;
    children: HierarchicalPnlNode[];
}

export interface ProfitAndLossData {
    revenueTree: HierarchicalPnlNode;
    cogsTree: HierarchicalPnlNode;
    expensesTree: HierarchicalPnlNode;
    totalRevenue: number;
    totalCogs: number;
    grossProfit: number;
    totalExpenses: number;
    netProfit: number;
}


export interface CashFlowStatementData {
    operating: {
        total: number;
        items: { label: string; value: number; accountId?: string; isSubItem?: boolean; isHeader?: boolean }[];
    };
    investing: {
        total: number;
        items: { label: string; value: number; accountId?: string }[];
    };
    financing: {
        total: number;
        items: { label: string; value: number; accountId?: string }[];
    };
    summary: {
        netChange: number;
        cashAtBeginning: number;
        cashAtEnd: number;
    };
}


// --- Dashboard Types ---
export interface Kpi {
    value: number;
    comparison: number; // Percentage change vs. previous period
    sparkline: { date: string; value: number }[];
}

export interface DashboardData {
    // KPIs
    netProfit: Kpi;
    totalRevenue: Kpi;
    grossProfitMargin: Kpi;
    totalExpenses: Kpi;
    newOrders: Kpi;
    averageOrderValue: Kpi;

    // Widgets
    keyBalances: {
        cash: number;
        banks: number;
        eWallets: number;
    };
    capitalAllocation: {
        accountsReceivable: number;
        goodsInTransit: number;
    };
    topUnpaidInvoices: {
        customerId: string;
        customerName: string;
        orderId: string;
        amountDue: number;
        daysOverdue: number;
    }[];
    recentTransactions: Transaction[];

    // Charts
    financialTrend: { date: string; revenue: number; profit: number; expenses: number }[];
    cashFlowTrend: { date: string; cashIn: number; cashOut: number }[];
    expenseBreakdown: { name: string; value: number; accountId: string }[];
}


// --- Employee & Payroll Types ---
export interface Employee {
    id: string;
    fullName: string;
    position: string;
    startDate: Date;
    basicMonthlySalary: number;
    paymentMethod: string; // e.g., 'Cash', 'Bank Transfer', could be enum
    isActive: boolean;
}

export enum EmployeeLedgerTransactionType {
    AdvanceTaken = 'Advance / Loan Taken',
    SalaryAccrued = 'Salary Accrued',
    AdvanceRepayment = 'Advance Repayment',
    SalaryPaid = 'Salary Paid'
}

export interface EmployeeLedgerEntry {
    id: string;
    employeeId: string;
    date: Date;
    transactionType: EmployeeLedgerTransactionType;
    description: string;
    debit: number;
    credit: number;
    referenceVoucherId: string;
}

export interface PayrollEmployee {
    employeeId: string;
    employeeName: string;
    basicSalary: number;
    bonus: number;
    advanceBalance: number; // Opening advance balance for the period
    deduction: number;
    netSalary: number;
}

export interface Payroll {
    id: string;
    period: string; // e.g., "2024-07"
    processingDate: Date;
    status: 'Draft' | 'Finalized' | 'Paid';
    employees: PayrollEmployee[];
    totalGrossSalary: number;
    totalBonuses: number;
    totalDeductions: number;
    totalNetSalary: number;
    accrualJournalId?: string;
    paymentJournalId?: string;
}

// --- Balance Sheet Types ---
export interface BalanceSheetAccount {
    name: string;
    id: string;
    balance: number;
}

export interface BalanceSheetGroup {
    title: string;
    total: number;
    accounts: BalanceSheetAccount[];
}

export interface BalanceSheetData {
    assets: {
        currentAssets: BalanceSheetGroup;
        nonCurrentAssets: BalanceSheetGroup;
        totalAssets: number;
    };
    liabilitiesAndEquity: {
        currentLiabilities: BalanceSheetGroup;
        nonCurrentLiabilities: BalanceSheetGroup;
        totalLiabilities: number;
        equity: BalanceSheetGroup;
        totalEquity: number;
        totalLiabilitiesAndEquity: number;
    };
    isBalanced: boolean;
}

// --- Trial Balance Types ---
export interface AdvancedTrialBalanceRow {
    account: Account;
    openingDr: number;
    openingCr: number;
    periodDebit: number;
    periodCredit: number;
    closingDr: number;
    closingCr: number;
}

export interface AdvancedTrialBalanceData {
    groups: Partial<Record<AccountCategory, AdvancedTrialBalanceRow[]>>;
    totals: {
        openingDr: number;
        openingCr: number;
        periodDebit: number;
        periodCredit: number;
        closingDr: number;
        closingCr: number;
    };
}

// --- Accounts Payable (Bills) Types ---
export enum BillStatus {
    Draft = 'Draft',
    AwaitingPayment = 'Awaiting Payment',
    PartiallyPaid = 'Partially Paid',
    Paid = 'Paid',
}

export interface BillLine {
    accountId: string;
    description: string;
    amount: number;
}

export interface BillPayment {
    id: string;
    paymentDate: Date;
    amount: number;
    paymentAccountId: string; // e.g., Cash, Bank
    voucherId: string; // The ID of the Disbursement Voucher
    referenceNumber: string; // The physical voucher number from the user
// FIX: Add status to BillPayment to track if a payment is active or voided.
    status: 'Active' | 'Voided';
}

export interface Bill {
    id: string;
    vendorId: string;
    vendorName: string;
    billNumber: string; // Supplier's invoice number
    billDate: Date;
    dueDate: Date;
    totalAmount: number;
    paidAmount: number;
    status: BillStatus;
    lines: BillLine[];
    payments: BillPayment[];
    notes?: string;
    attachments?: any[]; // Placeholder for file attachments
    journalVoucherId: string; // The JV that recorded the accrual (Debit Expense, Credit AP)
}

export interface ApAgingReportData {
    buckets: {
        current: number;
        _1_30_days: number;
        _31_60_days: number;
        _61_90_days: number;
        over_90_days: number;
        total: number;
    };
    bills: (Bill & { daysOverdue: number })[];
    byVendor: {
        vendorId: string;
        vendorName: string;
        totalDue: number;
        buckets: Omit<ApAgingReportData['buckets'], 'dueThisWeek'>;
    }[];
}

// --- Rewards & Points Tracker ---
export interface RewardMonthConfig {
    period: string; // YYYY-MM
    pointsPerItem: number;
    valuePerPoint: number; // e.g. 1.0 means $1 per 100 points
}

export interface RewardClaim {
    id: string;
    period: string; // YYYY-MM
    claimDate: Date;
    amount: number;
    totalItems: number;
    // Snapshot values at time of claim
    appliedPointsPerItem: number;
    appliedValuePerPoint: number;
    journalVoucherId: string;
}

// --- Profit Distribution ---
export interface PartnerMetric {
    id: string;
    name: string;
    totalCapital: number;
    totalProfitShare: number;
    totalDrawings: number;
    netBalance: number;
}