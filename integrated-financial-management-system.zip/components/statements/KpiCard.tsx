import React from 'react';
import { motion } from 'framer-motion';

interface KpiCardProps {
    title: string;
    value: number;
    color?: 'rose' | 'emerald' | 'sky' | 'slate';
    trend?: string;
}

const colorClasses = {
    rose: 'text-rose-600',
    emerald: 'text-emerald-600',
    sky: 'text-sky-600',
    slate: 'text-slate-600'
};

const formatCurrency = (value: number) => {
     const isNegative = value < 0;
    const formatted = new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
    }).format(Math.abs(value));
    return isNegative ? `(${formatted.substring(1)})` : formatted;
};

export const KpiCard: React.FC<KpiCardProps> = ({ title, value, color = 'slate', trend }) => {
    return (
        <div className="bg-white/65 backdrop-blur-lg border border-white/50 rounded-2xl shadow-sm p-5">
            <h3 className="text-sm font-semibold text-slate-500">{title}</h3>
            <p className={`text-3xl font-bold font-mono mt-2 ${colorClasses[color]}`}>
                {formatCurrency(value)}
            </p>
            {trend && <p className="text-xs text-slate-400 mt-1">{trend}</p>}
        </div>
    );
};
