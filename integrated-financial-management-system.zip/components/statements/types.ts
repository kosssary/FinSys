import { Customer, Vendor } from '../../types';

export type Party = (Customer | Vendor) & { type: 'customer' | 'vendor' };

export interface StatementTransaction {
    id: string;
    date: string;
    description: string;
    type: 'Order' | 'Payment' | 'Refund' | 'Adjustment' | 'Bill' | 'Bill Payment';
    debit: number;
    credit: number;
    balance: number;
    notes?: string;
    sourceId: string; // Order ID or Voucher ID
    sourceType: 'Order' | 'Receipt' | 'Disbursement' | 'Bill'; 
}

export interface StatementContext {
    party: Party;
    fromDate: string;
    toDate: string;
    openingBalance: number;
    closingBalance: number;
    totalDebit: number;
    totalCredit: number;
    transactions: StatementTransaction[];
}