import { StatementContext } from '../types';

declare const window: any;

const formatCurrency = (value: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value);

export const exportAnalyticsPdf = async (context: StatementContext, chartPanelElement: HTMLElement, html2canvas: any): Promise<void> => {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ orientation: 'p', unit: 'mm', format: 'a4' });

    const pageW = doc.internal.pageSize.getWidth();
    const margin = 15;
    let cursorY = 20;

    // --- 1. Header ---
    doc.setFontSize(22);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor('#1e293b'); // slate-800
    doc.text('Financial Statement', margin, cursorY);
    cursorY += 10;
    
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor('#64748b'); // slate-500
    doc.text(`Party: ${context.party.name} (${context.party.id})`, margin, cursorY);
    doc.text(`Generated: ${new Date().toLocaleString()}`, pageW - margin, cursorY, { align: 'right' });
    cursorY += 5;
    doc.text(`Period: ${new Date(context.fromDate).toLocaleDateString()} to ${new Date(context.toDate).toLocaleDateString()}`, margin, cursorY);
    cursorY += 8;
    doc.setDrawColor('#e2e8f0'); // slate-200
    doc.line(margin, cursorY, pageW - margin, cursorY);
    cursorY += 15;

    // --- 2. KPI Summary ---
    doc.autoTable({
        startY: cursorY,
        theme: 'plain',
        body: [
             [
                { content: 'Opening Balance:', styles: { fontStyle: 'bold' } }, { content: formatCurrency(context.openingBalance), styles: { halign: 'right'} },
                { content: 'Total Debit:', styles: { fontStyle: 'bold' } }, { content: formatCurrency(context.totalDebit), styles: { halign: 'right', textColor: '#dc2626' } },
             ],
             [
                { content: 'Closing Balance:', styles: { fontStyle: 'bold' } }, { content: formatCurrency(context.closingBalance), styles: { halign: 'right', textColor: '#0284c7' } },
                { content: 'Total Credit:', styles: { fontStyle: 'bold' } }, { content: formatCurrency(context.totalCredit), styles: { halign: 'right', textColor: '#16a34a' } },
             ]
        ],
    });
    cursorY = doc.lastAutoTable.finalY + 15;

    // --- 3. Charts Snapshot ---
    try {
        const canvas = await html2canvas(chartPanelElement, { scale: 2, backgroundColor: null });
        const imgData = canvas.toDataURL('image/png');
        const imgProps = doc.getImageProperties(imgData);
        const imgWidth = pageW - margin * 2;
        const imgHeight = (imgProps.height * imgWidth) / imgProps.width;
        
        doc.addImage(imgData, 'PNG', margin, cursorY, imgWidth, imgHeight);
        cursorY += imgHeight + 15;
    } catch(e) {
        console.error("Could not render charts to PDF:", e);
        doc.text("Charts could not be rendered in this export.", margin, cursorY);
        cursorY += 10;
    }


    // --- 4. Transactions Table ---
    doc.addPage();
    cursorY = 20;

    // Professional Header for Transaction Details
    doc.setFontSize(16);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor('#ffffff'); // white
    doc.setFillColor('#334155'); // slate-700
    doc.rect(margin, cursorY - 7, pageW - (margin * 2), 11, 'F');
    doc.text('Transaction Details', margin + 4, cursorY);
    doc.setTextColor('#1e293b'); // reset color back to dark
    cursorY += 10;
    
    const tableData = [
        [
            new Date(context.fromDate).toLocaleDateString(),
            'Opening Balance',
            '-',
            '-',
            formatCurrency(context.openingBalance)
        ],
        ...context.transactions.map(t => [
            new Date(t.date).toLocaleDateString(),
            t.description,
            t.debit > 0 ? formatCurrency(t.debit) : '-',
            t.credit > 0 ? formatCurrency(t.credit) : '-',
            formatCurrency(t.balance)
        ])
    ];
    
    doc.autoTable({
        startY: cursorY,
        head: [['Date', 'Description', 'Debit', 'Credit', 'Balance']],
        body: tableData,
        theme: 'striped',
        headStyles: { 
            fillColor: '#334155', // slate-700
            textColor: '#ffffff',
            fontStyle: 'bold'
        },
        styles: { 
            fontSize: 8,
            cellPadding: 2.5,
        },
        alternateRowStyles: { 
            fillColor: '#f8fafc' // slate-50
        },
        columnStyles: {
            0: { cellWidth: 20 },
            1: { cellWidth: 'auto' },
            2: { halign: 'center', cellWidth: 25 },
            3: { halign: 'center', cellWidth: 25 },
            4: { halign: 'center', cellWidth: 30 },
        },
        didParseCell: (data: any) => {
            // Header row styling
            if (data.row.section === 'head') {
                data.cell.styles.textColor = '#ffffff';
                data.cell.styles.fontStyle = 'bold';
                return;
            }

            // Opening Balance row styling (index 0 of body)
            if (data.row.index === 0) {
                data.cell.styles.fontStyle = 'bold';
                data.cell.styles.fillColor = '#f1f5f9'; // slate-100
                data.cell.styles.textColor = '#0f172a'; // slate-900
                if (data.column.index === 4) { // Balance column
                    data.cell.styles.textColor = '#0284c7'; // sky-600
                }
                return;
            }
            
            // Regular transaction rows styling
            if (data.column.index === 2 && data.cell.raw !== '-') { data.cell.styles.textColor = '#dc2626'; } // rose
            if (data.column.index === 3 && data.cell.raw !== '-') { data.cell.styles.textColor = '#16a34a'; } // emerald
            if (data.column.index === 4) { 
                data.cell.styles.fontStyle = 'bold'; 
                data.cell.styles.textColor = '#0284c7'; // sky-600
            }
        }
    });

    // --- 5. Footer ---
    const pageCount = doc.internal.getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        doc.setFontSize(8);
        doc.setTextColor('#94a3b8'); // slate-400
        doc.text(`Page ${i} of ${pageCount}`, pageW - margin, doc.internal.pageSize.getHeight() - 10, { align: 'right' });
        doc.text(`FinSys Analytics Workspace`, margin, doc.internal.pageSize.getHeight() - 10);
    }

    doc.save(`Statement_Analytics_${context.party.id}_${context.toDate}.pdf`);
};