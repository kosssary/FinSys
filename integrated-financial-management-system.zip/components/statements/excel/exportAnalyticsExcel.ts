import { StatementContext } from '../types';

declare const window: any;

export const exportAnalyticsExcel = (context: StatementContext): void => {
    const XLSX = window.XLSX;
    
    // --- 1. Create Summary Data ---
    const summary_data = [
        { A: "Party Name", B: context.party.name },
        { A: "Party ID", B: context.party.id },
        { A: "Period From", B: new Date(context.fromDate).toLocaleDateString() },
        { A: "Period To", B: new Date(context.toDate).toLocaleDateString() },
        {},
        { A: "Opening Balance", B: context.openingBalance },
        { A: "Total Debit", B: context.totalDebit },
        { A: "Total Credit", B: context.totalCredit },
        { A: "Closing Balance", B: context.closingBalance },
    ];
    
    const summary_ws = XLSX.utils.json_to_sheet(summary_data, { skipHeader: true });
    
    // Format summary numbers
    for (let i = 5; i < 9; i++) {
        summary_ws[`B${i + 1}`].z = '"$"#,##0.00';
    }
    
    summary_ws['!cols'] = [{ wch: 20 }, { wch: 30 }];

    // --- 2. Create Transaction Data ---
    const transactions_data = context.transactions.map(t => ({
        Date: new Date(t.date),
        Description: t.description,
        Debit: t.debit > 0 ? t.debit : null,
        Credit: t.credit > 0 ? t.credit : null,
        Balance: t.balance,
    }));
    
    const transactions_ws = XLSX.utils.json_to_sheet(transactions_data);
    
    // Format transaction numbers and date
    transactions_ws['!cols'] = [{ wch: 12 }, { wch: 50 }, { wch: 15 }, { wch: 15 }, { wch: 18 }];
    transactions_data.forEach((_, index) => {
        const row = index + 2;
        transactions_ws[`A${row}`].z = 'yyyy-mm-dd';
        transactions_ws[`C${row}`].z = '"$"#,##0.00';
        transactions_ws[`D${row}`].z = '"$"#,##0.00';
        transactions_ws[`E${row}`].z = '"$"#,##0.00';
    });
    
    // Freeze the header row
    transactions_ws['!freeze'] = { y: 1 };

    // --- 3. Create Workbook and Download ---
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, summary_ws, "Summary");
    XLSX.utils.book_append_sheet(wb, transactions_ws, "Transactions");
    
    const fileName = `Statement_Analytics_${context.party.id}_${context.toDate}.xlsx`;
    XLSX.writeFile(wb, fileName);
};