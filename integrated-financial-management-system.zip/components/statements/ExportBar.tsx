import React from 'react';
import { motion } from 'framer-motion';
import { FileSpreadsheet, FileText, Share2 } from 'lucide-react';

interface ExportBarProps {
    onExportExcel: () => void;
    onExportPdf: () => void;
    onShare: () => void;
}

export const ExportBar: React.FC<ExportBarProps> = ({ onExportExcel, onExportPdf, onShare }) => {
    return (
        <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.5, type: 'spring', stiffness: 100 }}
            className="fixed bottom-6 right-6 z-40"
        >
            <div className="bg-white/70 backdrop-blur-md border border-white/50 rounded-full shadow-lg flex items-center gap-1 p-2">
                <button onClick={onExportExcel} className="flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold text-emerald-800 hover:bg-emerald-100/50 transition-colors" title="Export to Excel">
                    <FileSpreadsheet size={16} />
                    <span>Excel</span>
                </button>
                 <button onClick={onExportPdf} className="flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold text-sky-800 hover:bg-sky-100/50 transition-colors" title="Export to PDF">
                    <FileText size={16} />
                    <span>PDF</span>
                </button>
                 <button onClick={onShare} className="flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold text-slate-600 hover:bg-slate-200/50 transition-colors" title="Share Report">
                    <Share2 size={16} />
                </button>
            </div>
        </motion.div>
    );
};
