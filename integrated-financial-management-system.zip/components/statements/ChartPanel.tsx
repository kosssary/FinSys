import React from 'react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, PieChart, Pie, Cell, Legend, BarChart, Bar } from 'recharts';
import { GlassCard } from '../ui/GlassCard';
import { StatementContext } from './types';

const formatCurrency = (value: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value);

const CustomTooltip: React.FC<any> = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
        return (
            <div className="bg-white/80 backdrop-blur-sm p-3 rounded-lg shadow-lg border border-white/50">
                <p className="text-xs text-slate-500">{label}</p>
                <p className="text-sm font-bold text-slate-800">{`${payload[0].name}: ${formatCurrency(payload[0].value)}`}</p>
            </div>
        );
    }
    return null;
};

export const ChartPanel: React.FC<{ context: StatementContext }> = ({ context }) => {
    const { transactions, totalDebit, totalCredit } = context;

    const balanceTrendData = transactions.map(t => ({
        date: new Date(t.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }),
        Balance: t.balance,
    }));
    
    const compositionData = [
        { name: 'Total Debit', value: totalDebit },
        { name: 'Total Credit', value: totalCredit },
    ];
    
    const cashFlowData = transactions.map(t => ({
        date: new Date(t.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }),
        Inflow: t.credit,
        Outflow: t.debit,
    }));

    const COLORS = ['#10b981', '#ef4444']; // Emerald, Rose

    return (
        <GlassCard title="Visual Summary">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[250px]">
                {/* Balance Trend */}
                <div className="lg:col-span-2">
                     <h4 className="text-sm font-semibold text-slate-600 mb-2">Balance Trend</h4>
                     <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={balanceTrendData} margin={{ top: 5, right: 20, left: -10, bottom: 20 }}>
                            <defs>
                                <linearGradient id="colorBalance" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="#0ea5e9" stopOpacity={0.6}/>
                                    <stop offset="95%" stopColor="#0ea5e9" stopOpacity={0}/>
                                </linearGradient>
                            </defs>
                            <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} />
                            <YAxis tick={{ fontSize: 10, fill: '#64748b' }} tickFormatter={(val: number) => `$${(val/1000)}k`} axisLine={false} tickLine={false} />
                            <Tooltip content={<CustomTooltip />} />
                            <Area type="monotone" dataKey="Balance" stroke="#0284c7" strokeWidth={2} fillOpacity={1} fill="url(#colorBalance)" />
                        </AreaChart>
                     </ResponsiveContainer>
                </div>
                {/* Debit/Credit Composition */}
                <div>
                     <h4 className="text-sm font-semibold text-slate-600 mb-2">Debit vs. Credit</h4>
                     <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                            <Pie data={compositionData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={50} outerRadius={70} paddingAngle={5}>
                                {compositionData.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} stroke="none" />)}
                            </Pie>
                            <Tooltip formatter={(value: number) => formatCurrency(value)} />
                            <Legend wrapperStyle={{ fontSize: '12px' }} iconSize={8} />
                        </PieChart>
                    </ResponsiveContainer>
                </div>
            </div>
        </GlassCard>
    );
};
