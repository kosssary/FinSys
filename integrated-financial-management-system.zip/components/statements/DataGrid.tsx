import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { GlassCard } from '../ui/GlassCard';
import { StatementContext, StatementTransaction } from './types';
import { ArrowUpDown, Search, ChevronLeft, ChevronRight, Expand, X } from 'lucide-react';

const formatCurrency = (value: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value);

type SortConfig = { key: keyof StatementTransaction; direction: 'asc' | 'desc' };

export const DataGrid: React.FC<{
    context: StatementContext;
    isExpandedView?: boolean;
    onExpandClick?: () => void;
    onCloseExpandedView?: () => void;
}> = ({ context, isExpandedView = false, onExpandClick, onCloseExpandedView }) => {
    const navigate = useNavigate();
    const [filter, setFilter] = useState('');
    const [sortConfig, setSortConfig] = useState<SortConfig>({ key: 'date', direction: 'asc' });
    const [currentPage, setCurrentPage] = useState(1);
    const rowsPerPage = isExpandedView ? 25 : 10;

    const filteredAndSortedData = useMemo(() => {
        let data = [...context.transactions];
        if (filter) {
            const lowerFilter = filter.toLowerCase();
            data = data.filter(t => t.description.toLowerCase().includes(lowerFilter));
        }

        data.sort((a, b) => {
            const aVal = a[sortConfig.key];
            const bVal = b[sortConfig.key];
            if (aVal < bVal) return sortConfig.direction === 'asc' ? -1 : 1;
            if (aVal > bVal) return sortConfig.direction === 'asc' ? 1 : -1;
            return 0;
        });

        return data;
    }, [context.transactions, filter, sortConfig]);

    const paginatedData = useMemo(() => {
        const start = (currentPage - 1) * rowsPerPage;
        return filteredAndSortedData.slice(start, start + rowsPerPage);
    }, [filteredAndSortedData, currentPage, rowsPerPage]);

    const totalPages = Math.ceil(filteredAndSortedData.length / rowsPerPage);

    const handleSort = (key: keyof StatementTransaction) => {
        setSortConfig(prev => ({
            key,
            direction: prev.key === key && prev.direction === 'asc' ? 'desc' : 'asc'
        }));
    };
    
    const handleRowDoubleClick = (transaction: StatementTransaction) => {
        if (transaction.sourceType === 'Order') {
            navigate('/orders', { state: { search: transaction.sourceId } });
        } else if (transaction.sourceType === 'Receipt') {
            navigate('/receipts', { state: { voucherId: transaction.sourceId } });
        } else if (transaction.sourceType === 'Disbursement') {
            navigate('/disbursements', { state: { voucherId: transaction.sourceId } });
        } else if (transaction.sourceType === 'Bill') {
            navigate('/supplier-bills', { state: { search: transaction.sourceId } });
        }
    };

    const headers: { key: keyof StatementTransaction; label: string; sortable: boolean }[] = [
        { key: 'date', label: 'Date', sortable: true },
        { key: 'description', label: 'Description', sortable: true },
        { key: 'debit', label: 'Debit', sortable: true },
        { key: 'credit', label: 'Credit', sortable: true },
        { key: 'balance', label: 'Balance', sortable: true },
    ];

    return (
        <GlassCard bodyClassName={`p-0 ${isExpandedView ? 'flex flex-col h-full' : ''}`}>
            <div className="flex justify-between items-center p-4 border-b border-white/50">
                <h3 className="text-base font-semibold text-slate-700">Transactions</h3>
                <div className="flex items-center gap-2">
                    <div className="relative w-full max-w-xs">
                        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                        <input type="text" value={filter} onChange={e => setFilter(e.target.value)} placeholder="Filter by description..." className="w-full h-9 bg-white/60 border border-white/50 rounded-lg shadow-inner pl-9 pr-3 text-sm focus:ring-1 focus:ring-sky-300/60 focus:outline-none" />
                    </div>
                    {onExpandClick && (
                        <button onClick={onExpandClick} className="p-2 rounded-lg text-slate-500 hover:bg-slate-200/50 dark:hover:bg-slate-700/50 transition-colors" title="Expand View">
                            <Expand size={18} />
                        </button>
                    )}
                    {isExpandedView && onCloseExpandedView && (
                         <button onClick={onCloseExpandedView} className="p-2 rounded-lg text-slate-500 hover:bg-slate-200/50 dark:hover:bg-slate-700/50" title="Close">
                            <X size={20} />
                        </button>
                    )}
                </div>
            </div>
            <div className={`overflow-auto ${isExpandedView ? 'flex-1' : ''}`}>
                <table className="w-full text-sm">
                    <thead className="sticky top-0 z-10 bg-white/75 backdrop-blur-md">
                        <tr className="border-b border-white/50">
                            {headers.map(h => {
                                const isCenter = ['debit', 'credit', 'balance'].includes(h.key);
                                return (
                                <th key={h.key} className={`px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider ${isCenter ? 'text-center' : 'text-left'}`}>
                                    <button onClick={() => h.sortable && handleSort(h.key)} className={`flex items-center gap-1 group ${isCenter ? 'mx-auto' : ''}`}>
                                        {h.label}
                                        {h.sortable && <ArrowUpDown size={12} className="opacity-50 group-hover:opacity-100" />}
                                    </button>
                                </th>
                                );
                            })}
                        </tr>
                    </thead>
                    <tbody>
                        {currentPage === 1 && (
                             <tr className="border-b border-white/50 bg-slate-50/50 dark:bg-slate-800/20">
                                <td className="px-4 py-3 text-slate-600 dark:text-slate-300 font-semibold">{new Date(context.fromDate).toLocaleDateString()}</td>
                                <td className="px-4 py-3 text-slate-800 dark:text-slate-100 font-bold">Opening Balance</td>
                                <td className="px-4 py-3 font-mono text-center">-</td>
                                <td className="px-4 py-3 font-mono text-center">-</td>
                                <td className="px-4 py-3 font-mono text-center font-bold text-sky-700 dark:text-sky-400">{formatCurrency(context.openingBalance)}</td>
                            </tr>
                        )}
                        {paginatedData.map(t => (
                            <tr key={t.id} onDoubleClick={() => handleRowDoubleClick(t)} className="border-b border-white/50 hover:bg-sky-100/30 transition-colors cursor-pointer">
                                <td className="px-4 py-3 text-slate-600">{new Date(t.date).toLocaleDateString()}</td>
                                <td className="px-4 py-3 text-slate-800 font-medium max-w-sm truncate">{t.description}</td>
                                <td className="px-4 py-3 font-mono text-center font-semibold text-rose-600">{t.debit > 0 ? formatCurrency(t.debit) : '-'}</td>
                                <td className="px-4 py-3 font-mono text-center font-semibold text-emerald-600">{t.credit > 0 ? formatCurrency(t.credit) : '-'}</td>
                                <td className="px-4 py-3 font-mono text-center font-bold text-sky-600">{formatCurrency(t.balance)}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            <div className="flex justify-between items-center p-3 border-t border-white/50 text-xs text-slate-500">
                <p>Showing {paginatedData.length > 0 ? (currentPage - 1) * rowsPerPage + 1 : 0}-{(currentPage - 1) * rowsPerPage + paginatedData.length} of {filteredAndSortedData.length} transactions</p>
                <div className="flex items-center gap-2">
                    <button onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={currentPage === 1} className="p-1 disabled:opacity-50"><ChevronLeft size={16} /></button>
                    <span>Page {currentPage} of {totalPages || 1}</span>
                     <button onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages || totalPages === 0} className="p-1 disabled:opacity-50"><ChevronRight size={16} /></button>
                </div>
            </div>
        </GlassCard>
    );
};