import React, { useState, useMemo } from 'react';
import { GlassCard } from '../ui/GlassCard';
import { GlassButton } from '../ui/GlassButton';
import { Customer, Vendor } from '../../types';
import { ChevronDown, Search } from 'lucide-react';

type Party = (Customer | Vendor) & { balance: number, type: 'customer' | 'vendor' };

interface StatementHeaderProps {
    parties: Party[];
    selectedParty: Party | null;
    onPartyChange: (party: Party | null) => void;
    startDate: string;
    onStartDateChange: (date: string) => void;
    endDate: string;
    onEndDateChange: (date: string) => void;
    onGenerate: () => void;
    isLoading: boolean;
}

const SearchablePartySelect: React.FC<{
    parties: Party[],
    selected: Party | null,
    onSelect: (party: Party) => void
}> = ({ parties, selected, onSelect }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [query, setQuery] = useState('');

    const filteredParties = useMemo(() => {
        if (!query) return parties;
        const lowerQuery = query.toLowerCase();
        return parties.filter(p => 
            p.id.toLowerCase().includes(lowerQuery) ||
            p.name?.toLowerCase().includes(lowerQuery) ||
            ('phone1' in p && p.phone1.includes(lowerQuery)) ||
            ('phone' in p && p.phone?.includes(lowerQuery))
        );
    }, [query, parties]);

    return (
        <div className="relative z-50">
            <button type="button" onClick={() => setIsOpen(!isOpen)} className="relative w-full h-11 text-left bg-white/80 border border-white/60 rounded-xl shadow-inner pl-10 pr-10 text-slate-800 text-sm focus:ring-2 focus:ring-sky-300/60 focus:outline-none transition">
                <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                {selected ? `${selected.name} (${selected.id})` : <span className="text-slate-500">Select a customer or vendor</span>}
                <ChevronDown size={16} className={`absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
            </button>

            {isOpen && (
                <div className="absolute top-full mt-1 w-full bg-white/80 backdrop-blur-md border border-white/50 rounded-xl shadow-lg p-2">
                    <input 
                        type="text"
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                        placeholder="Search..."
                        className="w-full h-9 bg-white/80 border border-white/60 rounded-lg shadow-inner px-3 mb-2 text-sm focus:ring-1 focus:ring-sky-300/60 focus:outline-none"
                    />
                    <ul className="max-h-48 overflow-y-auto">
                        {filteredParties.map(party => (
                            <li key={party.id} onClick={() => { onSelect(party); setIsOpen(false); setQuery(''); }} className="px-3 py-2 text-sm rounded-md hover:bg-sky-100/50 cursor-pointer flex justify-between">
                                <span>{party.name} ({party.id})</span>
                                <span className={`text-xs font-semibold px-1.5 py-0.5 rounded-full ${party.type === 'customer' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800'}`}>{party.type}</span>
                            </li>
                        ))}
                    </ul>
                </div>
            )}
        </div>
    );
};

export const StatementHeader: React.FC<StatementHeaderProps> = ({
    parties, selectedParty, onPartyChange,
    startDate, onStartDateChange,
    endDate, onEndDateChange,
    onGenerate, isLoading
}) => {
    return (
        <GlassCard className="relative z-20">
            <div className="grid grid-cols-12 gap-4 items-end">
                <div className="col-span-12 md:col-span-4">
                    <label className="text-xs font-semibold text-slate-600 mb-1 block">Customer or Vendor</label>
                    <SearchablePartySelect parties={parties} selected={selectedParty} onSelect={onPartyChange} />
                </div>
                <div className="col-span-6 md:col-span-3">
                     <label className="text-xs font-semibold text-slate-600 mb-1 block">From Date</label>
                    <input type="date" value={startDate} onChange={e => onStartDateChange(e.target.value)} className="w-full h-11 bg-white/80 border border-white/60 rounded-xl shadow-inner px-3 text-slate-800 text-sm focus:ring-2 focus:ring-sky-300/60 focus:outline-none transition" />
                </div>
                 <div className="col-span-6 md:col-span-3">
                    <label className="text-xs font-semibold text-slate-600 mb-1 block">To Date</label>
                    <input type="date" value={endDate} onChange={e => onEndDateChange(e.target.value)} className="w-full h-11 bg-white/80 border border-white/60 rounded-xl shadow-inner px-3 text-slate-800 text-sm focus:ring-2 focus:ring-sky-300/60 focus:outline-none transition" />
                </div>
                <div className="col-span-12 md:col-span-2 flex justify-end">
                    <GlassButton variant="primary" onClick={onGenerate} disabled={isLoading || !selectedParty} className="w-full h-11">
                        {isLoading ? 'Generating...' : 'Generate'}
                    </GlassButton>
                </div>
            </div>
        </GlassCard>
    );
};