
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface MonthlyChartProps {
    data: { month: string; profit: number; expenses: number }[];
}

const MonthlyChart: React.FC<MonthlyChartProps> = ({ data }) => {
    return (
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-md h-96">
            <h3 className="text-lg font-semibold text-gray-700 dark:text-gray-200 mb-4">Monthly Profit & Expense</h3>
            <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(107, 114, 128, 0.3)" />
                    <XAxis dataKey="month" tick={{ fill: '#9CA3AF' }} />
                    <YAxis tick={{ fill: '#9CA3AF' }} />
                    <Tooltip
                        contentStyle={{
                            backgroundColor: '#374151',
                            borderColor: '#4B5563'
                        }}
                    />
                    <Legend wrapperStyle={{ color: '#9CA3AF' }}/>
                    <Bar dataKey="profit" fill="#10B981" />
                    <Bar dataKey="expenses" fill="#EF4444" />
                </BarChart>
            </ResponsiveContainer>
        </div>
    );
};

export default MonthlyChart;
