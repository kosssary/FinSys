
import React, { useState, useContext, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { SIDEBAR_CONFIG } from '../../constants';
import { ChevronDown, Moon, Sun, LogOut, User as UserIcon } from 'lucide-react';
import { ThemeContext, Theme } from '../../context/ThemeContext';
import Switch from '../ui/Switch';
import { useData } from '../../context/DataContext';
import { UserProfileModal } from '../modals/UserProfileModal';

const isSubItemActive = (subItems: any[] | undefined, pathname: string) => {
    if (!subItems) return false;
    return subItems.some(item => 'path' in item && pathname.startsWith(item.path));
};

const Logo = () => (
    <div className="flex items-center space-x-3 px-3 mb-8">
        <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" className="flex-shrink-0">
            <defs>
                <linearGradient id="logo-grad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#0ea5e9" />
                    <stop offset="100%" stopColor="#06b6d4" />
                </linearGradient>
            </defs>
            <rect width="40" height="40" rx="10" fill="url(#logo-grad)"/>
            <rect x="10" y="8" width="6" height="24" rx="3" fill="white" fillOpacity="0.9"/>
            <rect x="10" y="8" width="18" height="6" rx="3" fill="white" fillOpacity="0.9"/>
            <rect x="10" y="17" width="12" height="6" rx="3" fill="white" fillOpacity="0.9"/>
        </svg>
        <span className="text-2xl font-bold text-slate-800 dark:text-white">FMS</span>
    </div>
);

const SidebarItem: React.FC<{ item: any, isParentActive: boolean }> = ({ item, isParentActive }) => {
    const { pathname } = useLocation();
    const [isOpen, setIsOpen] = useState(isParentActive);
    const { checkPermission } = useData();

    useEffect(() => {
        if (isParentActive) setIsOpen(true);
    }, [isParentActive]);

    const hasSubItems = item.subItems && item.subItems.length > 0;

    // Filter sub-items based on granular permissions
    const visibleSubItems = hasSubItems ? item.subItems.filter((subItem: any) => {
        if (subItem.type === 'header') return true; 
        
        // 1. Check specific scope if available (e.g., reports.profit_loss)
        if (subItem.permissionScope) {
            return checkPermission(subItem.permissionScope, 'view');
        }
        
        // 2. Fallback to parent module (e.g., reports)
        if (item.module) {
            return checkPermission(item.module, 'view');
        }
        
        return true;
    }) : [];

    // Remove headers if they have no visible children following them
    const cleanedSubItems = visibleSubItems.filter((sub: any, index: number, array: any[]) => {
        if (sub.type === 'header') {
            const nextItem = array[index + 1];
            return nextItem && nextItem.type !== 'header';
        }
        return true;
    });

    // If parent has sub-items definition but no children are visible allowed, hide parent entirely
    if (hasSubItems && cleanedSubItems.length === 0) {
        return null;
    }

    // If parent has no sub-items (single link), check its own permission
    if (!hasSubItems) {
        const scope = item.permissionScope || item.module;
        if (scope && !checkPermission(scope, 'view')) {
            return null;
        }
    }

    if (hasSubItems) {
        return (
            <div>
                <div
                    onClick={() => setIsOpen(prev => !prev)}
                    className={`relative w-full flex justify-between items-center p-3 rounded-lg text-left transition-colors duration-200 cursor-pointer group ${
                        isParentActive
                            ? 'text-slate-800 dark:text-white'
                            : 'text-slate-500 dark:text-slate-400 hover:bg-black/5 dark:hover:bg-white/5'
                    }`}
                >
                    <div className="flex items-center">
                        <div className={`relative z-10 transition-colors duration-200 ${isParentActive ? 'text-sky-500' : 'group-hover:text-slate-600 dark:group-hover:text-slate-300'}`}>
                            {item.icon}
                        </div>
                        <span className={`relative z-10 ml-4 text-sm font-semibold`}>{item.title}</span>
                    </div>
                    <ChevronDown
                        size={16}
                        className={`relative z-10 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`}
                    />
                </div>
                <AnimatePresence initial={false}>
                    {isOpen && (
                        <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: 'auto', opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            transition={{ duration: 0.3, ease: 'easeInOut' }}
                            className="overflow-hidden ml-4 pl-4 border-l border-slate-200 dark:border-slate-700/50"
                        >
                            <div className="py-2 flex flex-col space-y-1">
                            {cleanedSubItems.map((subItem: any) => {
                                if (subItem.type === 'header') {
                                    return <h4 key={subItem.title} className="px-3 pt-3 pb-1 text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">{subItem.title}</h4>;
                                }
                                return (
                                <NavLink
                                    key={subItem.path}
                                    to={subItem.path}
                                    className={({ isActive }) =>
                                        `block relative px-3 py-2 text-sm rounded-md transition-all duration-200 ${
                                            isActive
                                                ? 'text-sky-600 dark:text-sky-300 font-semibold'
                                                : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-black/5 dark:hover:bg-white/5'
                                        }`
                                    }
                                >
                                  {({ isActive }) => (
                                      <>
                                          {isActive && <motion.div layoutId="sidebar-active-sub" className="absolute inset-0 bg-sky-500/10 dark:bg-sky-500/20 rounded-md" />}
                                          <span className="relative flex items-center gap-2">
                                              {subItem.icon && React.cloneElement(subItem.icon, { size: 14 })}
                                              {subItem.title}
                                          </span>
                                      </>
                                  )}
                                </NavLink>
                                );
                            })}
                            </div>
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>
        );
    }

    return (
        <NavLink
            to={item.path || '#'}
            className="group flex items-center p-3 rounded-lg transition-all duration-200 relative text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
        >
             {({ isActive }) => (
                <>
                    {isActive && <motion.div layoutId="sidebar-active" className="absolute inset-0 bg-gradient-to-r from-sky-400 to-cyan-400 rounded-lg shadow-lg shadow-sky-500/30" />}
                    <div className={`relative z-10 ${isActive ? 'text-white' : ''}`}>
                        {item.icon}
                    </div>
                    <span className={`relative z-10 ml-4 text-sm font-semibold ${isActive ? 'text-white' : ''}`}>{item.title}</span>
                </>
             )}
        </NavLink>
    );
};

const Sidebar: React.FC = () => {
    const { theme, setTheme } = useContext(ThemeContext);
    const { currentUser, logout } = useData();
    const location = useLocation();
    const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);

    const toggleTheme = () => {
        setTheme(theme === Theme.Light ? Theme.Dark : Theme.Light);
    };

    return (
        <aside className="relative w-[280px] flex-shrink-0 flex flex-col p-4 m-4 bg-[--sidebar-bg] backdrop-blur-xl border border-[--sidebar-border] rounded-2xl shadow-2xl shadow-[--glass-shadow] overflow-hidden">
             <Logo />
            
            <nav className="flex-1 space-y-1.5 overflow-y-auto pr-1 -mr-1">
                 {SIDEBAR_CONFIG.map((item) => {
                    const isParentActive = item.path ? location.pathname === item.path : isSubItemActive(item.subItems, location.pathname);
                    return <SidebarItem key={item.key} item={item} isParentActive={isParentActive} />;
                 })}
            </nav>

            <div className="mt-auto pt-4 space-y-3">
                {/* User Profile Widget */}
                {currentUser && (
                    <div className="flex items-center gap-3 p-3 bg-white/50 dark:bg-slate-800/50 rounded-xl border border-white/40 dark:border-slate-700 cursor-pointer hover:bg-white/70 transition-colors" onClick={() => setIsProfileModalOpen(true)}>
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-400 to-sky-400 flex items-center justify-center text-white font-bold shadow-sm">
                            {currentUser.name.charAt(0).toUpperCase()}
                        </div>
                        <div className="flex-1 min-w-0">
                            <p className="text-sm font-bold text-slate-800 dark:text-white truncate">{currentUser.name}</p>
                            <p className="text-xs text-slate-500 dark:text-slate-400 truncate">{currentUser.roleName}</p>
                        </div>
                        <button onClick={(e) => { e.stopPropagation(); logout(); }} className="p-2 text-slate-400 hover:text-rose-500 transition-colors" title="Logout">
                            <LogOut size={18} />
                        </button>
                    </div>
                )}

                <div className="flex items-center justify-between p-2 bg-black/5 dark:bg-white/5 rounded-lg">
                    <div className="flex items-center text-sm font-semibold text-slate-600 dark:text-slate-300">
                         {theme === Theme.Light ? <Sun size={18} className="mr-2 text-yellow-500" /> : <Moon size={18} className="mr-2 text-blue-400" />}
                        <span className="font-semibold">{theme === Theme.Light ? 'Light Mode' : 'Dark Mode'}</span>
                    </div>
                    <Switch isChecked={theme === Theme.Dark} onChange={toggleTheme} />
                </div>
            </div>
            <UserProfileModal isOpen={isProfileModalOpen} onClose={() => setIsProfileModalOpen(false)} />
        </aside>
    );
};

export default Sidebar;
