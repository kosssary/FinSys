
import React, { useState } from 'react';
import { Bell, User, RefreshCw } from 'lucide-react';
import { useData } from '../../context/DataContext';

interface HeaderProps {
    title: string;
}

const Header: React.FC<HeaderProps> = ({ title }) => {
    const { exchangeRate, updateExchangeRate } = useData();
    const [tempRate, setTempRate] = useState(exchangeRate.toString());

    const handleRateBlur = () => {
        const newRate = parseFloat(tempRate);
        if (!isNaN(newRate) && newRate > 0) {
            updateExchangeRate(newRate);
        } else {
            setTempRate(exchangeRate.toString());
        }
    };

    const handleKeyDown = (e: React.KeyboardEvent) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            (e.target as HTMLInputElement).blur();
        }
    };

    return (
        <header className="relative flex-shrink-0 flex items-center justify-between p-3 mx-4 mt-4 bg-[--sidebar-bg] backdrop-blur-xl border border-[--sidebar-border] rounded-2xl shadow-lg shadow-[--glass-shadow]">
            <h1 className="text-xl font-bold text-slate-800 dark:text-white pl-4">{title}</h1>
            <div className="flex items-center space-x-4">
                <div className="hidden md:flex items-center gap-2 bg-white/50 dark:bg-slate-800/50 px-3 py-1.5 rounded-xl border border-white/30 dark:border-slate-700 shadow-sm">
                    <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">1 USD =</span>
                    <div className="relative">
                        <input 
                            type="number" 
                            value={tempRate}
                            onChange={(e) => setTempRate(e.target.value)}
                            onBlur={handleRateBlur}
                            onKeyDown={handleKeyDown}
                            className="w-20 bg-transparent font-mono font-bold text-slate-800 dark:text-white text-right focus:outline-none border-b border-transparent focus:border-sky-500 transition-colors"
                        />
                        <span className="text-xs font-bold text-slate-500 dark:text-slate-400 ml-1">IQD</span>
                    </div>
                    <RefreshCw size={12} className="text-slate-400" />
                </div>

                <button className="px-4 py-2 text-sm font-semibold bg-white/60 dark:bg-white/10 rounded-full hover:bg-white dark:hover:bg-white/20 transition-colors shadow-sm border border-white/50 dark:border-white/10">
                    Upgrade
                </button>
                <button className="p-2.5 rounded-full text-slate-500 dark:text-slate-400 hover:bg-black/5 dark:hover:bg-white/5 transition-colors">
                    <Bell size={20} />
                </button>
                <div className="w-10 h-10 bg-gradient-to-br from-sky-400 to-cyan-400 rounded-full flex items-center justify-center text-white font-bold text-sm shadow-md shadow-sky-500/30">
                    <User size={20}/>
                </div>
            </div>
        </header>
    );
};

export default Header;
