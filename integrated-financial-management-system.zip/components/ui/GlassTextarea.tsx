import React, { useRef, useEffect } from 'react';

interface GlassTextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
    id: string;
    label: string;
    icon?: React.ReactNode;
    error?: string;
}

export const GlassTextarea: React.FC<GlassTextareaProps> = ({ id, label, icon, error, value, ...props }) => {
    const hasValue = value && String(value).length > 0;
    const textareaRef = useRef<HTMLTextAreaElement>(null);

    useEffect(() => {
        if (textareaRef.current) {
            textareaRef.current.style.height = 'auto';
            textareaRef.current.style.height = `${textareaRef.current.scrollHeight}px`;
        }
    }, [value]);

    return (
        <div className="relative group">
            <div className="absolute left-3 top-5 text-slate-400 group-focus-within:text-sky-500 transition-colors pointer-events-none">
                {icon}
            </div>
            <textarea
                id={id}
                ref={textareaRef}
                placeholder={label}
                value={value}
                rows={3}
                className={`
                    peer w-full bg-white/70 border border-white/60 rounded-xl shadow-inner placeholder-transparent
                    pl-10 pr-4 pt-6 pb-2 text-slate-800 text-sm font-medium resize-none overflow-hidden
                    focus:ring-2 focus:ring-sky-300/60 focus:outline-none transition
                    ${error ? 'border-rose-400/80 focus:ring-rose-300/60' : ''}
                `}
                {...props}
            />
            <label
                htmlFor={id}
                className={`
                    absolute left-10 top-5 text-slate-500 text-sm pointer-events-none transition-all
                    peer-placeholder-shown:top-5 peer-placeholder-shown:text-sm
                    peer-focus:top-2 peer-focus:text-xs peer-focus:text-slate-500
                    ${hasValue ? 'top-2 text-xs' : ''}
                    ${error ? 'text-rose-600' : ''}
                `}
            >
                {label}
            </label>
            {error && <p className="text-xs text-rose-600 mt-1 ml-1">{error}</p>}
        </div>
    );
};
