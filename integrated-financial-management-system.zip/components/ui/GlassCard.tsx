import React, { ReactNode } from 'react';

interface GlassCardProps {
    children: ReactNode;
    className?: string;
    title?: string;
    actions?: ReactNode;
    bodyClassName?: string;
}

export const GlassCard: React.FC<GlassCardProps> = ({ children, className = '', title, actions, bodyClassName = 'p-6' }) => {
    return (
        <div className={`bg-white/70 backdrop-blur-xl border border-white/40 rounded-2xl shadow-[0_10px_40px_rgba(0,0,0,0.05)] ${className}`}>
            {(title || actions) && (
                 <div className="flex justify-between items-center px-6 pt-5 pb-4 border-b border-white/50">
                    {title && <h2 className="text-lg font-semibold text-slate-800 tracking-tight">{title}</h2>}
                    {actions && <div>{actions}</div>}
                </div>
            )}
            <div className={bodyClassName}>
                {children}
            </div>
        </div>
    );
};
