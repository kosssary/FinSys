import React from 'react';

interface GlassButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
    variant: 'primary' | 'secondary';
    children: React.ReactNode;
}

export const GlassButton: React.FC<GlassButtonProps> = ({ variant, children, className, ...props }) => {
    const baseClasses = "flex items-center justify-center rounded-xl px-5 py-3 text-sm font-bold transition-all duration-200 active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed";

    const variantClasses = {
        primary: "bg-gradient-to-r from-sky-500 to-cyan-500 text-white shadow hover:shadow-lg hover:-translate-y-0.5 focus:ring-2 focus:ring-sky-300/80 focus:outline-none",
        secondary: "bg-white/70 border border-white/60 text-slate-700 shadow-sm hover:bg-white/90 focus:ring-2 focus:ring-sky-300/60 focus:outline-none",
    };

    return (
        <button className={`${baseClasses} ${variantClasses[variant]} ${className}`} {...props}>
            {children}
        </button>
    );
};