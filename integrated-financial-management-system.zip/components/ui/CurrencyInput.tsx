
import React, { useState, useEffect } from 'react';
import { useData } from '../../context/DataContext';
import { CircleDollarSign, RefreshCw } from 'lucide-react';

interface CurrencyInputProps {
    value: string | number;
    onChange: (value: string) => void;
    onConversion?: (iqdAmount: number, rate: number) => void;
    placeholder?: string;
    disabled?: boolean;
    className?: string;
    wrapperClassName?: string;
    compact?: boolean;
}

const formatCurrency = (value: number) => new Intl.NumberFormat('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(value);
const formatIQD = (value: number) => new Intl.NumberFormat('en-US').format(value);

export const CurrencyInput: React.FC<CurrencyInputProps> = ({ 
    value, 
    onChange, 
    onConversion, 
    placeholder = "0.00", 
    disabled, 
    className,
    wrapperClassName,
    compact = false
}) => {
    const { exchangeRate } = useData();
    const [mode, setMode] = useState<'USD' | 'IQD'>('USD');
    const [iqdValue, setIqdValue] = useState<string>('');
    
    // Reset IQD input when switching to USD mode or if value is cleared externally
    useEffect(() => {
        if (mode === 'USD' && !value) {
            setIqdValue('');
        }
    }, [value, mode]);

    const handleIqdChange = (val: string) => {
        // Remove commas for calculation
        const rawVal = val.replace(/,/g, '');
        setIqdValue(rawVal);
        
        const iqdNum = parseFloat(rawVal);
        
        if (!isNaN(iqdNum) && exchangeRate > 0) {
            const usdVal = iqdNum / exchangeRate;
            // Pass precise USD value to parent immediately for calculation
            onChange(usdVal.toString());
        } else {
            onChange('');
        }
    };

    const handleIqdBlur = () => {
        const iqdNum = parseFloat(iqdValue.replace(/,/g, ''));
        if (!isNaN(iqdNum) && exchangeRate > 0 && onConversion) {
            // Only trigger the note update when user finishes typing
            onConversion(iqdNum, exchangeRate);
        }
    };

    const handleModeToggle = (e: React.MouseEvent) => {
        e.preventDefault(); // Prevent form submission
        e.stopPropagation();
        setMode(prev => prev === 'USD' ? 'IQD' : 'USD');
        setIqdValue(''); // Clear temp IQD input on toggle
    };

    // Styling logic
    const baseInputClass = "bg-transparent border-none outline-none font-mono text-sm w-full h-full";
    const compactInputClass = `${baseInputClass} text-right pr-16`; // Extra padding for toggle
    const standardInputClass = `peer w-full h-14 bg-white/70 border border-white/60 rounded-xl shadow-inner pl-10 pr-20 pt-4 text-slate-800 text-sm font-medium focus:ring-2 focus:ring-sky-300/60 focus:outline-none transition [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none`;

    const inputClass = className || (compact ? compactInputClass : standardInputClass);
    
    const wrapperClass = wrapperClassName || (compact 
        ? "relative w-full h-9 bg-white/60 border border-slate-300/50 rounded-lg flex items-center overflow-hidden"
        : "relative group");

    return (
        <div className={wrapperClass}>
            {/* Standard Mode Icon */}
            {!compact && (
                <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none z-10">
                    {mode === 'USD' ? <CircleDollarSign size={16} /> : <span className="text-xs font-bold text-emerald-600">IQD</span>}
                </div>
            )}

            {mode === 'USD' ? (
                <input
                    type="number"
                    value={value}
                    onChange={e => onChange(e.target.value)}
                    disabled={disabled}
                    placeholder={placeholder}
                    className={inputClass}
                    step="0.01"
                />
            ) : (
                <input
                    type="number"
                    value={iqdValue}
                    onChange={e => handleIqdChange(e.target.value)}
                    onBlur={handleIqdBlur}
                    disabled={disabled}
                    placeholder="IQD Amount"
                    className={inputClass + (compact ? " !text-emerald-700" : " !text-emerald-700")}
                />
            )}

            {/* Toggle Button */}
            <div className={`absolute top-1/2 -translate-y-1/2 z-20 ${compact ? 'right-1' : 'right-3'}`}>
                <button
                    type="button"
                    onClick={handleModeToggle}
                    disabled={disabled}
                    className={`flex items-center gap-1 px-1.5 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wide border transition-all shadow-sm ${
                        mode === 'USD' 
                        ? 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200' 
                        : 'bg-emerald-100 text-emerald-600 border-emerald-200 hover:bg-emerald-200'
                    }`}
                >
                    {mode === 'IQD' && <RefreshCw size={10} className="animate-spin-slow" />}
                    {mode}
                </button>
            </div>

            {/* Conversion Hint (Standard Mode Only) */}
            {!compact && mode === 'IQD' && !isNaN(Number(value)) && Number(value) > 0 && (
                <div className="absolute right-20 top-1/2 -translate-y-1/2 text-xs text-slate-400 font-mono pointer-events-none bg-white/80 px-1 rounded">
                    ≈ ${formatCurrency(Number(value))}
                </div>
            )}

            {/* Floating Label (Standard Mode Only) */}
            {!compact && (
                <label className={`absolute left-10 top-1/2 -translate-y-1/2 text-slate-500 text-sm pointer-events-none transition-all ${value || mode === 'IQD' ? 'top-3 text-xs' : ''}`}>
                    {mode === 'USD' ? (placeholder.includes('*') ? 'Amount *' : 'Amount') : `Amount (1$ = ${formatIQD(exchangeRate)})`}
                </label>
            )}
        </div>
    );
};
