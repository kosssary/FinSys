import React, { useState, useEffect, useMemo } from 'react';
import { Account } from '../../types';

const formatCurrency = (value: number) => new Intl.NumberFormat('en-US').format(value);

export const SearchableAccountInput: React.FC<{
    value: string; // accountId
    accounts: any[];
    onSelect: (account: any) => void;
    disabled?: boolean;
    placeholder?: string;
    className?: string;
    onDoubleClick?: () => void;
}> = ({ value, accounts, onSelect, disabled, placeholder = "Search by code or name", className, onDoubleClick }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [isOpen, setIsOpen] = useState(false);

    const selectedAccount = useMemo(() => accounts.find(a => a.id === value), [value, accounts]);

    useEffect(() => {
        if (selectedAccount) {
            setSearchTerm(`${selectedAccount.code ? `${selectedAccount.code} - ` : ''}${selectedAccount.name}`);
        } else {
            setSearchTerm('');
        }
    }, [selectedAccount]);

    const filteredAccounts = useMemo(() => {
        if (!searchTerm || (selectedAccount && `${selectedAccount.code ? `${selectedAccount.code} - ` : ''}${selectedAccount.name}` === searchTerm)) {
            return [];
        }
        
        const lowerCaseSearch = searchTerm.toLowerCase();
        return accounts.filter(acc =>
            acc.name.toLowerCase().includes(lowerCaseSearch) ||
            (acc.nameKurdish && acc.nameKurdish.toLowerCase().includes(lowerCaseSearch)) ||
            (acc.code && acc.code.includes(searchTerm))
        );
    }, [searchTerm, accounts, selectedAccount]);

    const handleSelect = (account: Account) => {
        setIsOpen(false);
        onSelect(account);
    };

    const handleBlur = () => {
        setTimeout(() => {
            setIsOpen(false);
            if (searchTerm === '' && selectedAccount) {
                onSelect({ id: '' } as Account); 
            } else if (selectedAccount) {
                setSearchTerm(`${selectedAccount.code ? `${selectedAccount.code} - ` : ''}${selectedAccount.name}`);
            }
        }, 150);
    };
    
    return (
        <div className="relative">
            <input
                type="text"
                value={searchTerm}
                onChange={e => {
                    setSearchTerm(e.target.value);
                    setIsOpen(true);
                }}
                onFocus={() => setIsOpen(true)}
                onBlur={handleBlur}
                onDoubleClick={onDoubleClick}
                className={`input-table ${className || ''}`}
                autoComplete="off"
                disabled={disabled}
                placeholder={placeholder}
            />
            {isOpen && filteredAccounts.length > 0 && (
                <ul className="absolute z-50 w-full bg-white dark:bg-gray-900 border dark:border-gray-600 rounded-md mt-1 shadow-lg max-h-40 overflow-auto">
                    {filteredAccounts.map(account => (
                        <li key={account.id} onMouseDown={() => handleSelect(account)} className="px-3 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer text-sm">
                            <div className="flex justify-between items-center">
                                <div>
                                    <span className="font-semibold">{account.code ? `${account.code} - ` : ''}{account.name}</span>
                                    {account.nameKurdish && <span className="text-xs text-gray-500 ml-2">({account.nameKurdish})</span>}
                                </div>
                                {typeof account.balance === 'number' && (
                                    <span className="font-mono text-xs text-slate-500">{formatCurrency(account.balance)} $</span>
                                )}
                            </div>
                        </li>
                    ))}
                </ul>
            )}
        </div>
    )
};