import React from 'react';
import { LucideIcon } from 'lucide-react';

interface GlassFieldProps extends React.InputHTMLAttributes<HTMLInputElement> {
    id: string;
    label: string;
    icon?: React.ReactNode;
    adornment?: string;
    error?: string;
}

export const GlassField: React.FC<GlassFieldProps> = ({ id, label, type = 'text', icon, adornment, error, ...props }) => {
    const hasValue = props.value && String(props.value).length > 0;
    
    return (
        <div className="relative group">
            <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-sky-500 transition-colors pointer-events-none">
                {icon}
            </div>
            <input
                id={id}
                type={type}
                placeholder={label} // Placeholder is used for the floating label effect
                className={`
                    peer w-full h-14 bg-white/70 border border-white/60 rounded-xl shadow-inner placeholder-transparent
                    pl-10 pr-4 pt-4 text-slate-800 text-sm font-medium
                    focus:ring-2 focus:ring-sky-300/60 focus:outline-none transition
                    ${error ? 'border-rose-400/80 focus:ring-rose-300/60' : ''}
                    ${adornment ? 'pr-14' : ''}
                `}
                {...props}
            />
            <label
                htmlFor={id}
                className={`
                    absolute left-10 top-1/2 -translate-y-1/2 text-slate-500 text-sm pointer-events-none transition-all
                    peer-placeholder-shown:top-1/2 peer-placeholder-shown:text-sm
                    peer-focus:top-3 peer-focus:text-xs peer-focus:text-slate-500
                    ${hasValue ? 'top-3 text-xs' : ''}
                    ${error ? 'text-rose-600' : ''}
                `}
            >
                {label}
            </label>
            {adornment && (
                <div className="absolute right-3 top-1/2 -translate-y-1/2 bg-slate-200/70 text-slate-600 text-xs font-semibold px-2 py-1 rounded-md pointer-events-none">
                    {adornment}
                </div>
            )}
            {error && <p className="text-xs text-rose-600 mt-1 ml-1">{error}</p>}
        </div>
    );
};
