import React, { useState, useMemo, useRef, useEffect } from 'react';
import { ChevronDown, Search } from 'lucide-react';

// Custom hook to detect clicks outside a component
const useClickOutside = (ref: React.RefObject<HTMLDivElement>, handler: () => void) => {
    useEffect(() => {
        const listener = (event: MouseEvent | TouchEvent) => {
            if (!ref.current || ref.current.contains(event.target as Node)) return;
            handler();
        };
        document.addEventListener('mousedown', listener);
        document.addEventListener('touchstart', listener);
        return () => {
            document.removeEventListener('mousedown', listener);
            document.removeEventListener('touchstart', listener);
        };
    }, [ref, handler]);
};

interface Option {
    value: string;
    label: string;
    details?: string;
}

interface GlassSearchableSelectProps {
    id: string;
    label: string;
    icon?: React.ReactNode;
    options: Option[];
    selected: Option | null;
    onSelect: (option: Option | null) => void;
    disabled?: boolean;
    error?: string;
}

export const GlassSearchableSelect: React.FC<GlassSearchableSelectProps> = ({ id, label, icon, options, selected, onSelect, disabled, error }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [query, setQuery] = useState('');
    const wrapperRef = useRef<HTMLDivElement>(null);
    useClickOutside(wrapperRef, () => setIsOpen(false));

    const filteredOptions = useMemo(() => {
        if (!query) return options;
        const lowerQuery = query.toLowerCase();
        return options.filter(opt => opt.label.toLowerCase().includes(lowerQuery));
    }, [query, options]);
    
    return (
        <div ref={wrapperRef} className="relative group">
            <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-sky-500 transition-colors pointer-events-none z-10">
                {icon}
            </div>
            <button
                type="button"
                id={id}
                onClick={() => !disabled && setIsOpen(!isOpen)}
                disabled={disabled}
                className={`
                    peer w-full h-14 bg-white/70 border border-white/60 rounded-xl shadow-inner text-left
                    pl-10 pr-10 pt-4 font-medium
                    focus:ring-2 focus:ring-sky-300/60 focus:outline-none transition
                    ${error ? 'border-rose-400/80 focus:ring-rose-300/60' : ''}
                    ${!selected ? 'text-transparent' : 'text-slate-800 text-sm'}
                `}
            >
                {selected ? selected.label : ''}
            </button>
             <label
                htmlFor={id}
                className={`
                    absolute left-10 text-slate-500 pointer-events-none transition-all
                    peer-focus:top-3 peer-focus:text-xs peer-focus:text-slate-500
                    ${selected || isOpen ? 'top-3 text-xs' : 'top-1/2 -translate-y-1/2 text-sm'}
                    ${error ? 'text-rose-600' : ''}
                `}
            >
                {label}
            </label>
            <div className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none">
                <ChevronDown size={18} className={`transition-transform ${isOpen ? 'rotate-180' : ''}`} />
            </div>

            {isOpen && (
                <div className="absolute top-full mt-1 w-full bg-white/80 backdrop-blur-md border border-white/50 rounded-xl shadow-lg p-2 z-30">
                    <div className="relative">
                        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                        <input 
                            type="text"
                            value={query}
                            onChange={(e) => setQuery(e.target.value)}
                            placeholder="Search..."
                            autoFocus
                            className="w-full h-9 bg-white/80 border border-white/60 rounded-lg shadow-inner pl-9 pr-3 mb-2 text-sm focus:ring-1 focus:ring-sky-300/60 focus:outline-none"
                        />
                    </div>
                    <ul className="max-h-48 overflow-y-auto">
                        {filteredOptions.length > 0 ? filteredOptions.map(option => (
                            <li key={option.value} onClick={() => { onSelect(option); setIsOpen(false); setQuery(''); }} className="px-3 py-2 text-sm rounded-md hover:bg-sky-100/50 cursor-pointer">
                                <p className="font-semibold text-slate-800">{option.label}</p>
                                {option.details && <p className="text-xs text-slate-500">{option.details}</p>}
                            </li>
                        )) : (
                            <li className="px-3 py-2 text-sm text-slate-500">No options found.</li>
                        )}
                    </ul>
                </div>
            )}
             {error && <p className="text-xs text-rose-600 mt-1 ml-1">{error}</p>}
        </div>
    );
};