import React from 'react';
import { motion } from 'framer-motion';

interface SwitchProps {
    isChecked: boolean;
    onChange: () => void;
}

const Switch: React.FC<SwitchProps> = ({ isChecked, onChange }) => {
    return (
        <div
            onClick={onChange}
            className={`flex items-center w-10 h-5 px-0.5 rounded-full cursor-pointer transition-colors ${
                isChecked ? 'bg-sky-500 justify-end' : 'bg-slate-300 dark:bg-slate-700/50 justify-start'
            }`}
        >
            <motion.div
                layout
                transition={{ type: 'spring', stiffness: 700, damping: 30 }}
                className="w-4 h-4 bg-white rounded-full shadow"
            />
        </div>
    );
};

export default Switch;