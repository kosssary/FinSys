
import React from 'react';
import { Customer } from '../../types';
import { User, Phone, Link, Edit3, CircleDollarSign, Calendar, CheckCircle2, XCircle, Package } from 'lucide-react';

interface OrderSummaryCardProps {
    formData: {
        selectedCustomer: Customer | null;
        productLink: string;
        orderDescription: string;
        totalPrice: string;
        paidAmount: string;
        estimatedDueDate: string;
        itemCount?: string;
    };
}

const formatCurrency = (value: number | string) => {
    const num = Number(value) || 0;
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(num);
};

const getDomainFromUrl = (url: string) => {
    try {
        return new URL(url).hostname.replace('www.', '');
    } catch {
        return 'Invalid Link';
    }
};

const ChecklistItem: React.FC<{ label: string; isComplete: boolean }> = ({ label, isComplete }) => (
    <div className="flex items-center text-sm">
        {isComplete ? (
            <CheckCircle2 size={16} className="text-green-500 mr-2 flex-shrink-0" />
        ) : (
            <XCircle size={16} className="text-slate-400 mr-2 flex-shrink-0" />
        )}
        <span className={isComplete ? 'text-slate-700' : 'text-slate-500'}>{label}</span>
    </div>
);

export const OrderSummaryCard: React.FC<OrderSummaryCardProps> = ({ formData }) => {
    const { selectedCustomer, productLink, orderDescription, totalPrice, paidAmount, estimatedDueDate, itemCount } = formData;

    const total = parseFloat(totalPrice) || 0;
    const deposit = parseFloat(paidAmount) || 0;
    const balance = total - deposit;
    const count = parseInt(itemCount || '0');

    const readiness = {
        customer: !!selectedCustomer,
        price: total > 0,
        dueDate: !!estimatedDueDate,
        items: count > 0,
    };

    return (
        <div className="sticky top-6 bg-white/55 backdrop-blur-lg border border-white/50 rounded-2xl shadow-[0_8px_30px_rgba(0,0,0,0.04)] p-5 space-y-6 h-full">
            {/* Customer Summary */}
            <div className="flex items-center space-x-3">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-sky-100 to-cyan-100 flex items-center justify-center text-sky-600 font-bold text-lg">
                    {selectedCustomer?.name ? selectedCustomer.name.charAt(0).toUpperCase() : <User />}
                </div>
                <div>
                    <p className="font-bold text-slate-800">{selectedCustomer?.name || 'No Customer Selected'}</p>
                    <p className="text-xs text-slate-500 flex items-center">
                        <Phone size={12} className="mr-1" />
                        {selectedCustomer?.phone1 || 'xxx-xxx-xxxx'}
                    </p>
                </div>
            </div>

            {/* Order Snapshot */}
            <div>
                <h4 className="summary-header">Order Snapshot</h4>
                <div className="summary-item">
                    <Link size={14} className="text-slate-400" />
                    <span className="text-sm font-medium text-slate-700 truncate">{productLink ? getDomainFromUrl(productLink) : 'No product link'}</span>
                </div>
                <div className="summary-item">
                    <Package size={14} className="text-slate-400" />
                    <span className="text-sm font-medium text-slate-700">{count > 0 ? `${count} Items` : 'No quantity set'}</span>
                </div>
                <div className="summary-item">
                    <Edit3 size={14} className="text-slate-400" />
                    <p className="text-sm text-slate-500 truncate">{orderDescription || 'No order notes'}</p>
                </div>
            </div>

            {/* Payment Summary */}
            <div>
                <h4 className="summary-header">Payment</h4>
                <div className="space-y-2">
                    <div className="flex justify-between items-baseline"><span className="text-sm text-slate-500">Total Price</span><span className="font-mono font-semibold text-slate-800">{formatCurrency(total)}</span></div>
                    <div className="flex justify-between items-baseline"><span className="text-sm text-slate-500">Deposit</span><span className="font-mono text-slate-600">{formatCurrency(deposit)}</span></div>
                    <div className="flex justify-between items-baseline pt-2 border-t border-white/60"><span className="font-bold text-slate-800">Balance Due</span><span className="font-mono font-bold text-lg text-sky-600">{formatCurrency(balance)}</span></div>
                </div>
                <div className="flex items-center justify-center space-x-2 mt-4 bg-sky-50 text-sky-700 rounded-lg p-2 text-sm font-semibold">
                    <Calendar size={14} />
                    <span>Due on {estimatedDueDate ? new Date(estimatedDueDate).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : 'N/A'}</span>
                </div>
            </div>

            {/* Readiness Checklist */}
            <div>
                <h4 className="summary-header">Readiness</h4>
                <div className="space-y-2">
                    <ChecklistItem label="Customer chosen" isComplete={readiness.customer} />
                    <ChecklistItem label="Price set" isComplete={readiness.price} />
                    <ChecklistItem label="Quantity set" isComplete={readiness.items} />
                    <ChecklistItem label="Due date set" isComplete={readiness.dueDate} />
                </div>
            </div>

            <style>{`
                .summary-header {
                    font-size: 0.75rem; /* text-xs */
                    font-weight: 700; /* font-bold */
                    color: #64748b; /* slate-500 */
                    text-transform: uppercase;
                    letter-spacing: 0.05em;
                    margin-bottom: 0.5rem; /* mb-2 */
                }
                .summary-item {
                    display: flex;
                    align-items: center;
                    gap: 0.5rem; /* space-x-2 */
                    padding: 0.25rem 0;
                }
            `}</style>
        </div>
    );
};
