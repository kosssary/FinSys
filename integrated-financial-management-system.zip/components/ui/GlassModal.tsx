import React, { ReactNode, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';

interface GlassModalProps {
    isOpen: boolean;
    onClose: () => void;
    title: string;
    subtitle: string;
    children: ReactNode;
    footer: ReactNode;
}

export const GlassModal: React.FC<GlassModalProps> = ({ isOpen, onClose, title, subtitle, children, footer }) => {
    
    useEffect(() => {
        const handleEsc = (event: KeyboardEvent) => {
            if (event.key === 'Escape') {
                onClose();
            }
        };
        window.addEventListener('keydown', handleEsc);
        return () => window.removeEventListener('keydown', handleEsc);
    }, [onClose]);

    useEffect(() => {
        if (isOpen) {
            document.body.style.overflow = 'hidden';
        } else {
            document.body.style.overflow = 'auto';
        }
        return () => { document.body.style.overflow = 'auto'; };
    }, [isOpen]);

    return (
        <AnimatePresence>
            {isOpen && (
                <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="fixed inset-0 z-50 flex items-center justify-center bg-white/30 backdrop-blur-sm p-4"
                    onClick={onClose}
                    aria-modal="true"
                    role="dialog"
                >
                    <motion.div
                        initial={{ scale: 0.98, opacity: 0, y: 10 }}
                        animate={{ scale: 1, opacity: 1, y: 0 }}
                        exit={{ scale: 0.98, opacity: 0, y: 10 }}
                        transition={{ duration: 0.25, ease: 'easeOut' }}
                        className="relative w-full max-w-6xl h-[90vh] flex flex-col bg-white/65 backdrop-blur-xl border border-white/50 rounded-2xl shadow-[0_10px_40px_rgba(0,0,0,0.06)]"
                        onClick={(e) => e.stopPropagation()}
                    >
                        {/* Header */}
                        <div className="flex-shrink-0 px-6 pt-6 pb-4 flex justify-between items-start">
                            <div>
                                <h2 id="modal-title" className="text-xl font-bold text-slate-800">{title}</h2>
                                <p className="text-sm text-slate-500 mt-1">{subtitle}</p>
                            </div>
                            <button
                                onClick={onClose}
                                className="p-1 rounded-full text-slate-500 hover:bg-white/50 hover:text-slate-800 transition-colors"
                                aria-label="Close modal"
                            >
                                <X size={20} />
                            </button>
                        </div>

                        {/* Body */}
                        <div className="flex-1 px-6 overflow-y-auto" aria-labelledby="modal-title">
                            {children}
                        </div>

                        {/* Footer */}
                        <div className="flex-shrink-0 mt-auto px-6 py-4 flex justify-between items-center bg-white/40 border-t border-white/40 backdrop-blur-sm sticky bottom-0 rounded-b-2xl">
                           {footer}
                        </div>
                    </motion.div>
                </motion.div>
            )}
        </AnimatePresence>
    );
};
