
import React, { useState, useMemo, useRef, useEffect } from 'react';
import { Search, XCircle, PlusCircle } from 'lucide-react';
import { SmartVoucherLineEntity } from '../../types';

export interface DataItem {
    id: string;
    name: string;
    subtext?: string;
    value?: number | string;
}

export interface DataGroup {
    type: string;
    title: string;
    items: DataItem[];
}

interface UnifiedSearchableSelectProps {
    value: string | null;
    onSelect: (item: SmartVoucherLineEntity | null) => void;
    groups: DataGroup[];
    placeholder?: string;
    disabled?: boolean;
    isCompact?: boolean;
    icon?: React.ReactNode;
    onQuickAdd?: () => void;
}

const useClickOutside = (ref: React.RefObject<HTMLDivElement>, handler: () => void) => {
    useEffect(() => {
        const listener = (event: MouseEvent | TouchEvent) => {
            if (!ref.current || ref.current.contains(event.target as Node)) return;
            handler();
        };
        document.addEventListener('mousedown', listener);
        document.addEventListener('touchstart', listener);
        return () => {
            document.removeEventListener('mousedown', listener);
            document.removeEventListener('touchstart', listener);
        };
    }, [ref, handler]);
};

export const UnifiedSearchableSelect: React.FC<UnifiedSearchableSelectProps> = ({
    value,
    onSelect,
    groups,
    placeholder = "Search...",
    disabled = false,
    isCompact = false,
    icon,
    onQuickAdd,
}) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [isOpen, setIsOpen] = useState(false);
    const wrapperRef = useRef<HTMLDivElement>(null);
    useClickOutside(wrapperRef, () => setIsOpen(false));

    const selectedItem = useMemo(() => {
        if (!value) return null;
        for (const group of groups) {
            const item = group.items.find(i => i.id === value);
            if (item) {
                return { id: item.id, type: group.type, name: item.name };
            }
        }
        return null;
    }, [value, groups]);

    useEffect(() => {
        setSearchTerm(selectedItem?.name || '');
    }, [selectedItem]);

    const filteredGroups = useMemo(() => {
        if (!searchTerm || (selectedItem && selectedItem.name === searchTerm && !isOpen)) {
            return [];
        }
        const lowerCaseSearch = searchTerm.toLowerCase();
        return groups.map(group => ({
            ...group,
            items: group.items.filter(item =>
                item.name.toLowerCase().includes(lowerCaseSearch) ||
                (item.subtext && item.subtext.toLowerCase().includes(lowerCaseSearch)) ||
                item.id.toLowerCase().includes(lowerCaseSearch)
            )
        })).filter(group => group.items.length > 0);
    }, [searchTerm, groups, selectedItem, isOpen]);

    const handleSelect = (item: DataItem, type: string) => {
        onSelect({ id: item.id, type: type as SmartVoucherLineEntity['type'], name: item.name });
        setIsOpen(false);
    };

    const handleClear = (e: React.MouseEvent) => {
        e.stopPropagation();
        onSelect(null);
    };

    const handleQuickAddClick = () => {
        setIsOpen(false);
        onQuickAdd?.();
    };

    const inputClasses = isCompact
        ? "w-full bg-transparent border border-slate-300/70 focus:bg-white/50 rounded-lg p-2 pr-8 outline-none focus:ring-1 ring-inset focus:ring-sky-300/60 transition"
        : "peer w-full h-14 bg-white/40 border border-white/50 rounded-2xl shadow-inner placeholder-transparent pl-12 pr-10 pt-4 text-slate-800 text-sm font-medium focus:ring-2 focus:ring-sky-300/60 focus:outline-none transition disabled:bg-slate-50/50";

    const labelClasses = isCompact ? "hidden" : `absolute left-12 top-1/2 -translate-y-1/2 text-slate-500 text-sm pointer-events-none transition-all duration-200 peer-placeholder-shown:top-1/2 peer-placeholder-shown:text-sm peer-focus:top-3.5 peer-focus:text-xs ${(selectedItem || searchTerm) ? 'top-3.5 text-xs' : ''}`;

    const iconClasses = isCompact ? "hidden" : `absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-sky-500 transition-colors pointer-events-none z-10`;

    return (
        <div className="relative group" ref={wrapperRef}>
            {!isCompact && <div className={iconClasses}>{icon || <Search size={18}/>}</div>}
            <input
                type="text"
                value={searchTerm}
                onChange={e => { setSearchTerm(e.target.value); setIsOpen(true); }}
                onFocus={() => setIsOpen(true)}
                disabled={disabled}
                placeholder={isCompact ? placeholder : " "}
                className={inputClasses}
                id="unified-search"
            />
            {!isCompact && <label htmlFor="unified-search" className={labelClasses}>{placeholder}</label>}
            {(selectedItem || searchTerm) && !disabled && (
                <button type="button" onClick={handleClear} className={`absolute ${isCompact ? 'right-2' : 'right-3'} top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1`}>
                    <XCircle size={isCompact ? 14 : 16}/>
                </button>
            )}

            {isOpen && !disabled && (filteredGroups.length > 0 || searchTerm || onQuickAdd) && (
                <div className={`absolute top-full mt-1 w-full bg-white/80 backdrop-blur-md border border-white/50 rounded-xl shadow-lg p-2 z-50 max-h-60 overflow-y-auto`}>
                    {filteredGroups.length === 0 && searchTerm && !onQuickAdd && <p className="p-3 text-sm text-slate-500">No results found.</p>}
                    {filteredGroups.map(group => (
                        <div key={group.type}>
                            <p className="px-3 py-1 text-xs font-bold text-slate-500 uppercase">{group.title}</p>
                            <ul>
                                {group.items.map(item => (
                                    <li key={item.id} onMouseDown={() => handleSelect(item, group.type)} className="p-3 hover:bg-sky-100/50 rounded-lg cursor-pointer">
                                        <div className="flex justify-between items-center">
                                            <div>
                                                <p className="font-semibold text-sm text-slate-800">{item.name}</p>
                                                {item.subtext && <p className="text-xs text-slate-500">{item.subtext}</p>}
                                            </div>
                                            {item.value !== undefined && <p className="text-xs font-mono text-slate-600">{typeof item.value === 'number' ? `${item.value.toFixed(2)} $` : item.value}</p>}
                                        </div>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    ))}
                    {onQuickAdd && (
                         <div
                            onMouseDown={handleQuickAddClick}
                            className="flex items-center gap-2 p-3 text-sky-600 hover:bg-sky-100/50 rounded-lg cursor-pointer font-semibold text-sm border-t border-slate-200/80 mt-1"
                        >
                            <PlusCircle size={16} />
                            <span>Add New Payee...</span>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
};
