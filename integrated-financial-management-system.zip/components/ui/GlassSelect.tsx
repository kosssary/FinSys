import React from 'react';
import { ChevronDown } from 'lucide-react';

interface GlassSelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
    id: string;
    label: string;
    icon?: React.ReactNode;
    error?: string;
    children: React.ReactNode;
}

export const GlassSelect: React.FC<GlassSelectProps> = ({ id, label, icon, error, children, ...props }) => {
    const hasValue = props.value && String(props.value).length > 0;

    return (
        <div className="relative group">
            <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-sky-500 transition-colors pointer-events-none z-10">
                {icon}
            </div>
            <select
                id={id}
                className={`
                    peer w-full h-14 bg-white/70 border border-white/60 rounded-xl shadow-inner appearance-none
                    pl-10 pr-10 pt-4 font-medium
                    focus:ring-2 focus:ring-sky-300/60 focus:outline-none transition
                    ${error ? 'border-rose-400/80 focus:ring-rose-300/60' : ''}
                    ${!hasValue ? 'text-transparent' : 'text-slate-800 text-sm'}
                `}
                {...props}
            >
                {children}
            </select>
            <label
                htmlFor={id}
                className={`
                    absolute left-10 text-slate-500 pointer-events-none transition-all
                    group-focus-within:top-3 group-focus-within:text-xs group-focus-within:text-slate-500
                    ${hasValue ? 'top-3 text-xs' : 'top-1/2 -translate-y-1/2 text-sm'}
                    ${error ? 'text-rose-600' : ''}
                `}
            >
                {label}
            </label>
            <div className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none">
                <ChevronDown size={18} />
            </div>
            {error && <p className="text-xs text-rose-600 mt-1 ml-1">{error}</p>}
        </div>
    );
};