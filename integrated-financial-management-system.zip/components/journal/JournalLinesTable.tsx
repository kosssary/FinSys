import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Account, JournalVoucherLine } from '@/types';
import { SearchableAccountInput } from '@/components/ui/SearchableAccountInput';
import { Plus, XCircle, Calculator } from 'lucide-react';

const safeEval = (expr: string): number | null => { try { if (!/^[0-9+\-*/.() ]+$/.test(expr)) return null; const result = new Function(`return ${expr}`)(); return typeof result === 'number' ? result : null; } catch (error) { return null; } };

interface JournalLinesTableProps {
    lines: (JournalVoucherLine & { clientId: string })[];
    setLines: React.Dispatch<React.SetStateAction<(JournalVoucherLine & { clientId: string })[]>>;
    accounts: Account[];
    disabled: boolean;
    onOpenAccountModal: (index: number) => void;
    onDescriptionDoubleClick: (index: number, value: string) => void;
}

export const JournalLinesTable: React.FC<JournalLinesTableProps> = ({ lines, setLines, accounts, disabled, onOpenAccountModal, onDescriptionDoubleClick }) => {
    
    const handleLineChange = (index: number, field: keyof JournalVoucherLine, value: any) => {
        setLines(ls => ls.map((l, i) => {
            if (i !== index) return l;
            const updatedLine = { ...l, [field]: value };
            if (field === 'debit' && Number(value) > 0) updatedLine.credit = 0;
            if (field === 'credit' && Number(value) > 0) updatedLine.debit = 0;
            return updatedLine;
        }));
    };

    const addLine = () => setLines(ls => [...ls, { clientId: `line-${ls.length}-${Date.now()}`, accountId: '', description: '', debit: 0, credit: 0 }]);
    const removeLine = (index: number) => { if (lines.length > 2) setLines(ls => ls.filter((_, i) => i !== index)); };

    return (
        <div className="bg-white/50 backdrop-blur-2xl border border-white/40 rounded-3xl shadow-[0_8px_50px_rgba(0,0,0,0.06)] overflow-hidden">
            <div className="min-w-[900px]">
                {/* Header */}
                <div className="grid grid-cols-12 gap-4 px-6 py-3 text-xs font-bold text-slate-500 uppercase tracking-wider border-b border-white/60">
                    <div className="col-span-4 text-left">Account</div>
                    <div className="col-span-2 text-left">Debit</div>
                    <div className="col-span-2 text-left">Credit</div>
                    <div className="col-span-3 text-left">Description</div>
                    <div className="col-span-1"></div>
                </div>
                {/* Body */}
                <div className="divide-y divide-white/40">
                    <AnimatePresence>
                        {lines.map((line, index) => (
                            <motion.div
                                key={line.clientId}
                                layout
                                initial={{ opacity: 0, y: -10 }}
                                animate={{ opacity: 1, y: 0 }}
                                exit={{ opacity: 0, x: -20 }}
                                transition={{ duration: 0.3, ease: 'easeInOut' }}
                                className="grid grid-cols-12 gap-4 px-6 py-2 items-center group"
                            >
                                <div className="col-span-4"><SearchableAccountInput value={line.accountId} accounts={accounts} onSelect={(acc) => handleLineChange(index, 'accountId', acc.id)} disabled={disabled} className="input-grid" onDoubleClick={() => !disabled && onOpenAccountModal(index)}/></div>
                                <div className="col-span-2"><input type="text" value={line.debit || ''} onChange={e => handleLineChange(index, 'debit', e.target.value)} onBlur={e => handleLineChange(index, 'debit', (safeEval(e.target.value) || '').toString())} disabled={disabled} className="input-grid text-center" placeholder="0.00" /></div>
                                <div className="col-span-2"><input type="text" value={line.credit || ''} onChange={e => handleLineChange(index, 'credit', e.target.value)} onBlur={e => handleLineChange(index, 'credit', (safeEval(e.target.value) || '').toString())} disabled={disabled} className="input-grid text-center" placeholder="0.00" /></div>
                                <div className="col-span-3"><input type="text" value={line.description} onChange={e => handleLineChange(index, 'description', e.target.value)} onDoubleClick={() => !disabled && onDescriptionDoubleClick(index, line.description)} disabled={disabled} className="input-grid" placeholder="Line description..." /></div>
                                <div className="col-span-1 text-center">{!disabled && <button type="button" onClick={() => removeLine(index)} className="text-slate-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition"><XCircle size={18}/></button>}</div>
                            </motion.div>
                        ))}
                    </AnimatePresence>
                </div>
                {!disabled && (
                    <div className="flex justify-center py-3">
                        <motion.button whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.98 }} type="button" onClick={addLine} className="flex items-center gap-1.5 text-sm font-semibold text-sky-600 bg-white/50 border border-white/60 rounded-full px-4 py-2 shadow-sm hover:shadow-md transition-shadow">
                            <Plus size={16}/> Add Line
                        </motion.button>
                    </div>
                )}
            </div>
             <style>{`
                .input-grid { width: 100%; height: 40px; background: rgba(255,255,255,0.7); border: 1px solid rgba(255,255,255,0.6); border-radius: 0.75rem; box-shadow: inset 0 1px 2px 0 rgb(0 0 0 / 0.05); padding-left: 1rem; padding-right: 1rem; color: #1e293b; font-size: 0.875rem; transition: all 0.2s; }
                .input-grid:focus { outline: none; box-shadow: inset 0 1px 2px 0 rgb(0 0 0 / 0.05), 0 0 0 2px #7dd3fc; }
                .input-grid:disabled { background-color: transparent; box-shadow: none; border-color: rgba(203, 213, 225, 0.5); }
                .input-grid::placeholder { color: #94a3b8; }
            `}</style>
        </div>
    );
};