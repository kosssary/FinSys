
import React from 'react';
import { motion } from 'framer-motion';

interface JournalSummaryCardProps {
    totalDebit: number;
    totalCredit: number;
}

const formatCurrency = (value: number) => new Intl.NumberFormat('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(value);

const AnimatedNumber: React.FC<{ value: number }> = ({ value }) => {
    // Basic number format, will animate with Framer Motion's layout transition
    return <span>{formatCurrency(value)}</span>;
};

export const JournalSummaryCard: React.FC<JournalSummaryCardProps> = ({ totalDebit, totalCredit }) => {
    const difference = totalDebit - totalCredit;
    const isBalanced = Math.abs(difference) < 0.001 && totalDebit > 0;

    const balanceColor = isBalanced
        ? 'from-emerald-50/80 to-white'
        : (difference !== 0 ? 'from-rose-50/80 to-white' : 'from-slate-50/80 to-white');

    const balanceTextColor = isBalanced
        ? 'text-emerald-600'
        : (difference !== 0 ? 'text-rose-600' : 'text-slate-600');

    return (
        <motion.div
            layout
            className={`bg-gradient-to-br ${balanceColor} backdrop-blur-2xl border border-white/40 rounded-3xl shadow-[0_8px_50px_rgba(0,0,0,0.06)] p-6 space-y-3`}
        >
            <div className="flex justify-between items-baseline">
                <span className="text-sm font-semibold text-slate-500">Debit Total</span>
                <span className="font-mono font-bold text-lg text-slate-800"><AnimatedNumber value={totalDebit} /></span>
            </div>
            <div className="flex justify-between items-baseline">
                <span className="text-sm font-semibold text-slate-500">Credit Total</span>
                <span className="font-mono font-bold text-lg text-slate-800"><AnimatedNumber value={totalCredit} /></span>
            </div>
            <div className={`flex justify-between items-baseline pt-3 border-t-2 border-dashed border-white/80`}>
                <span className={`text-sm font-bold ${balanceTextColor}`}>{isBalanced ? 'Balanced' : 'Difference'}</span>
                <span className={`font-mono font-extrabold text-lg ${balanceTextColor}`}>
                    <AnimatedNumber value={difference} />
                </span>
            </div>
        </motion.div>
    );
};
