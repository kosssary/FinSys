
import React from 'react';
import { useData } from '../../context/DataContext';
import { PermissionAction } from '../../types';

interface AccessGuardProps {
    module: string;
    action: PermissionAction;
    fallback?: React.ReactNode;
    children: React.ReactNode;
}

export const AccessGuard: React.FC<AccessGuardProps> = ({ module, action, fallback = null, children }) => {
    const { checkPermission } = useData();

    if (checkPermission(module, action)) {
        return <>{children}</>;
    }

    return <>{fallback}</>;
};
