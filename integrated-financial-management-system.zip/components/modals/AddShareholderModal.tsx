import React, { useState, useEffect } from 'react';
import { useData } from '../../context/DataContext';
import { Shareholder } from '../../types';

interface AddShareholderModalProps {
    isOpen: boolean;
    onClose: () => void;
    shareholder?: Shareholder | null;
}

const AddShareholderModal: React.FC<AddShareholderModalProps> = ({ isOpen, onClose, shareholder }) => {
    const { addShareholder, updateShareholder, deleteShareholder } = useData();
    const [name, setName] = useState('');
    const [profitShare, setProfitShare] = useState('');
    const [capital, setCapital] = useState('');

    const isEditing = !!shareholder;

    useEffect(() => {
        if (isOpen) {
            if (isEditing && shareholder) {
                setName(shareholder.name);
                setProfitShare(String(shareholder.profitSharePercentage));
                setCapital(String(shareholder.capitalContributions));
            } else {
                setName('');
                setProfitShare('');
                setCapital('');
            }
        }
    }, [isOpen, shareholder, isEditing]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!name || !profitShare || !capital) {
            alert('Please fill all fields.');
            return;
        }

        const shareholderData = {
            name,
            profitSharePercentage: parseFloat(profitShare),
            capitalContributions: parseFloat(capital),
        };

        try {
            if (isEditing && shareholder) {
                await updateShareholder({ ...shareholderData, id: shareholder.id });
            } else {
                await addShareholder(shareholderData);
            }
            onClose();
        } catch (error) {
            console.error("Failed to save shareholder:", error);
            alert(`Error: ${(error as Error).message}`);
        }
    };
    
    const handleDelete = async () => {
        if (!isEditing || !shareholder) return;

        if (window.confirm(`Are you sure you want to delete shareholder "${shareholder.name}"? This will also remove their associated accounts if they have no transactions.`)) {
            try {
                await deleteShareholder(shareholder.id);
                onClose();
            } catch (error) {
                console.error("Failed to delete shareholder:", error);
                alert(`Error: ${(error as Error).message}`);
            }
        }
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-60" aria-modal="true" role="dialog">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-md transform transition-all">
                <div className="flex justify-between items-center px-6 py-4 border-b dark:border-gray-700">
                    <h2 className="text-xl font-semibold text-gray-800 dark:text-white">{isEditing ? 'Edit Shareholder' : 'Add New Shareholder'}</h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 p-1 rounded-full">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                    </button>
                </div>
                <form onSubmit={handleSubmit}>
                    <div className="p-6 space-y-4">
                        <div>
                            <label htmlFor="shareholderName" className="label">Name *</label>
                            <input type="text" id="shareholderName" value={name} onChange={e => setName(e.target.value)} required className="mt-1 input-field" />
                        </div>
                        <div>
                            <label htmlFor="profitShare" className="label">Profit Share Percentage *</label>
                            <input type="number" id="profitShare" value={profitShare} onChange={e => setProfitShare(e.target.value)} required min="0" max="100" step="0.01" className="mt-1 input-field" />
                        </div>
                        <div>
                            <label htmlFor="capital" className="label">Initial Capital Contribution *</label>
                            <input type="number" id="capital" value={capital} onChange={e => setCapital(e.target.value)} required min="0" step="0.01" className="mt-1 input-field" />
                        </div>
                    </div>
                    <div className="flex justify-between items-center px-6 py-4 bg-gray-50 dark:bg-gray-800/50 border-t dark:border-gray-700">
                        <div>
                            {isEditing && <button type="button" onClick={handleDelete} className="btn-danger">Delete</button>}
                        </div>
                        <div className="flex">
                            <button type="button" onClick={onClose} className="btn-secondary mr-3">Cancel</button>
                            <button type="submit" className="btn-primary">{isEditing ? 'Save Changes' : 'Add Shareholder'}</button>
                        </div>
                    </div>
                </form>
                 <style>{`
                    .label { display: block; margin-bottom: 0.25rem; font-size: 0.875rem; font-weight: 500; color: #4B5563; } .dark .label { color: #D1D5DB; }
                    .input-field { display: block; width: 100%; padding: 0.5rem 0.75rem; border: 1px solid #D1D5DB; border-radius: 0.375rem; } .dark .input-field { background-color: #374151; border-color: #4B5563; color: #E5E7EB; }
                    .btn-primary { padding: 0.5rem 1.25rem; font-weight: 600; color: white; background-image: linear-gradient(to right, #0ea5e9, #06b6d4); border-radius: 0.5rem; transition: all 0.2s; box-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1); } .btn-primary:hover { box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1); filter: brightness(1.05); } .btn-primary:active { transform: scale(0.98); } .btn-primary:disabled { opacity: 0.5; cursor: not-allowed; filter: none; transform: none; box-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1); }
                    .btn-secondary { padding: 0.5rem 1rem; font-weight: 500; border: 1px solid #D1D5DB; border-radius: 0.375rem; } .dark .btn-secondary { background-color: #4B5563; border-color: #6B7280; color: #E5E7EB; }
                    .btn-danger { padding: 0.5rem 1.25rem; font-weight: 500; color: white; background-color: #DC2626; border-radius: 0.375rem; } .btn-danger:hover { background-color: #B91C1C; }
                `}</style>
            </div>
        </div>
    );
};

export default AddShareholderModal;