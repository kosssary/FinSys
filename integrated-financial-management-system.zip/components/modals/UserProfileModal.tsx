
import React, { useState, useEffect } from 'react';
import { useData } from '../../context/DataContext';
import { GlassModal } from '../ui/GlassModal';
import { GlassField } from '../ui/GlassField';
import { GlassButton } from '../ui/GlassButton';
import { User, Lock, Shield } from 'lucide-react';

interface UserProfileModalProps {
    isOpen: boolean;
    onClose: () => void;
}

export const UserProfileModal: React.FC<UserProfileModalProps> = ({ isOpen, onClose }) => {
    const { currentUser, updateProfile } = useData();
    const [name, setName] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    
    useEffect(() => {
        if (isOpen && currentUser) {
            setName(currentUser.name);
            setNewPassword('');
            setConfirmPassword('');
        }
    }, [isOpen, currentUser]);

    const handleSubmit = async () => {
        if (!currentUser) return;
        
        const updates: { name?: string; password?: string } = {};
        
        if (name.trim() !== currentUser.name) {
            updates.name = name.trim();
        }
        
        if (newPassword) {
            if (newPassword !== confirmPassword) {
                alert("Passwords do not match.");
                return;
            }
            updates.password = newPassword;
        }

        if (Object.keys(updates).length === 0) {
            onClose();
            return;
        }

        try {
            await updateProfile(currentUser.id, updates);
            alert("Profile updated successfully.");
            onClose();
        } catch (e) {
            console.error(e);
            alert("Failed to update profile.");
        }
    };

    if (!isOpen || !currentUser) return null;

    return (
        <GlassModal
            isOpen={isOpen}
            onClose={onClose}
            title="My Profile"
            subtitle="Manage your account settings and password."
            footer={
                <div className="flex justify-end gap-3 w-full">
                    <GlassButton variant="secondary" onClick={onClose}>Cancel</GlassButton>
                    <GlassButton variant="primary" onClick={handleSubmit}>Save Changes</GlassButton>
                </div>
            }
        >
            <div className="py-6 space-y-6 max-w-md mx-auto">
                <div className="flex flex-col items-center mb-6">
                    <div className="w-20 h-20 rounded-full bg-gradient-to-br from-sky-400 to-blue-600 flex items-center justify-center text-white text-3xl font-bold shadow-lg mb-3">
                        {currentUser.name.charAt(0).toUpperCase()}
                    </div>
                    <div className="flex items-center gap-2 bg-slate-100 px-3 py-1 rounded-full border border-slate-200">
                        <Shield size={14} className="text-slate-500" />
                        <span className="text-xs font-bold text-slate-600 uppercase tracking-wider">{currentUser.roleName}</span>
                    </div>
                </div>

                <div className="space-y-4">
                    <GlassField 
                        id="profileName" 
                        label="Display Name" 
                        value={name} 
                        onChange={e => setName(e.target.value)} 
                        icon={<User size={16}/>} 
                    />
                    
                    <div className="border-t border-slate-200 my-4 pt-4">
                        <h4 className="text-sm font-bold text-slate-500 mb-4 uppercase tracking-wider">Change Password</h4>
                        <div className="space-y-4">
                            <GlassField 
                                id="newPass" 
                                label="New Password" 
                                type="password" 
                                value={newPassword} 
                                onChange={e => setNewPassword(e.target.value)} 
                                icon={<Lock size={16}/>} 
                            />
                            <GlassField 
                                id="confirmPass" 
                                label="Confirm New Password" 
                                type="password" 
                                value={confirmPassword} 
                                onChange={e => setConfirmPassword(e.target.value)} 
                                icon={<Lock size={16}/>} 
                            />
                        </div>
                    </div>
                </div>
            </div>
        </GlassModal>
    );
};
