
import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { useData } from '../../context/DataContext';
import { Vendor, Account, Bill, BillLine, AccountCategory } from '../../types';
import { GlassModal } from '../ui/GlassModal';
import { GlassField } from '../ui/GlassField';
import { GlassButton } from '../ui/GlassButton';
import { UnifiedSearchableSelect, DataGroup } from '../ui/UnifiedSearchableSelect';
import { SearchableAccountInput } from '../ui/SearchableAccountInput';
import { Building, Calendar, Hash, BookOpen, MessageSquare, DollarSign, Plus, XCircle } from 'lucide-react';
import AddVendorModal from './AddVendorModal';
import { CurrencyInput } from '../ui/CurrencyInput';

interface BillFormModalProps {
    isOpen: boolean;
    onClose: () => void;
    editingBill?: Bill | null;
}

const formatCurrency = (value: number | string) => new Intl.NumberFormat('en-US').format(Number(value) || 0);

const BillFormModal: React.FC<BillFormModalProps> = ({ isOpen, onClose, editingBill }) => {
    const { getVendors, getAccountsList, addBill, updateBill } = useData();
    const [vendors, setVendors] = useState<Vendor[]>([]);
    const [accounts, setAccounts] = useState<Account[]>([]);

    const [vendorId, setVendorId] = useState<string | null>(null);
    const [billNumber, setBillNumber] = useState('');
    const [billDate, setBillDate] = useState('');
    const [dueDate, setDueDate] = useState('');
    const [lines, setLines] = useState<(BillLine & { clientId: string })[]>([]);
    
    const [isVendorModalOpen, setIsVendorModalOpen] = useState(false);
    
    const isEditing = !!editingBill;

    const relevantAccounts = useMemo(() => {
        return accounts.filter(a => a.isPostable && [
            AccountCategory.COGS,
            AccountCategory.OperatingExpense,
            AccountCategory.Asset // For purchasing fixed assets
        ].includes(a.category));
    }, [accounts]);

    const vendorDataGroup: DataGroup[] = useMemo(() => ([{
        type: 'vendor',
        title: 'Vendors',
        items: vendors.map(v => ({ id: v.id, name: v.name, subtext: v.phone || v.address }))
    }]), [vendors]);
    
    useEffect(() => {
        if (isOpen) {
            Promise.all([getVendors(), getAccountsList()]).then(([v, a]) => {
                setVendors(v);
                setAccounts(a);
            });

            if (isEditing && editingBill) {
                setVendorId(editingBill.vendorId);
                setBillNumber(editingBill.billNumber);
                setBillDate(new Date(editingBill.billDate).toISOString().split('T')[0]);
                setDueDate(new Date(editingBill.dueDate).toISOString().split('T')[0]);
                setLines(editingBill.lines.map((l, i) => ({ ...l, clientId: `line-${i}` })));
            } else {
                const today = new Date().toISOString().split('T')[0];
                const futureDate = new Date();
                futureDate.setDate(futureDate.getDate() + 30);
                setVendorId(null);
                setBillNumber('');
                setBillDate(today);
                setDueDate(futureDate.toISOString().split('T')[0]);
                setLines([{ clientId: `line-0-${Date.now()}`, accountId: '', description: '', amount: 0 }]);
            }
        }
    }, [isOpen, editingBill, isEditing, getVendors, getAccountsList]);

    const handleLineChange = (index: number, field: keyof BillLine, value: any) => {
        setLines(prev => prev.map((line, i) => i === index ? { ...line, [field]: value } : line));
    };

    // Currency Helper Integration
    const handleCurrencyConversion = (index: number, iqdAmount: number, rate: number) => {
        setLines(prev => prev.map((l, i) => {
            if (i === index) {
                const note = ` (${iqdAmount.toLocaleString()} IQD @ ${rate})`;
                let currentDesc = l.description || '';
                // Remove previous note if exists to avoid duplication
                currentDesc = currentDesc.replace(/ \(\d{1,3}(,\d{3})* IQD @ \d+\)/g, '').trim();
                return { ...l, description: currentDesc + note };
            }
            return l;
        }));
    };

    const addLine = () => {
        setLines(prev => [...prev, { clientId: `line-${prev.length}-${Date.now()}`, accountId: '', description: '', amount: 0 }]);
    };
    
    const removeLine = (index: number) => {
        if (lines.length > 1) {
            setLines(prev => prev.filter((_, i) => i !== index));
        }
    };
    
    const totalAmount = useMemo(() => lines.reduce((sum, line) => sum + (Number(line.amount) || 0), 0), [lines]);

    const handleSave = async () => {
        const selectedVendor = vendors.find(v => v.id === vendorId);
        if (!selectedVendor || !billNumber || !billDate || !dueDate || lines.some(l => !l.accountId || l.amount <= 0)) {
            alert('Please fill all required fields and ensure all lines have an account and positive amount.');
            return;
        }

        const payload = {
            vendorId: selectedVendor.id,
            vendorName: selectedVendor.name,
            billNumber,
            billDate: new Date(billDate),
            dueDate: new Date(dueDate),
            lines: lines.map(({ clientId, ...rest }) => ({...rest, amount: Number(rest.amount)})),
            notes: '', // Placeholder for notes
        };

        try {
            if (isEditing && editingBill) {
                await updateBill(editingBill.id, payload);
            } else {
                await addBill(payload);
            }
            onClose();
        } catch (error) {
            console.error("Failed to save bill:", error);
            alert(`Error: ${(error as Error).message}`);
        }
    };

    const handleNewVendorAdded = (newVendor: Vendor) => {
        setVendors(prev => [newVendor, ...prev]);
        setVendorId(newVendor.id);
        setIsVendorModalOpen(false);
    };

    return (
        <>
        <GlassModal
            isOpen={isOpen}
            onClose={onClose}
            title={isEditing ? 'Edit Bill' : 'New Supplier Bill'}
            subtitle="Record an invoice received from a supplier."
            footer={
                <div className="w-full flex justify-between items-center">
                    <p className="text-xs text-slate-500">Bill Total: <span className="font-bold font-mono text-base text-sky-700">{formatCurrency(totalAmount)} $</span></p>
                    <div className="flex items-center space-x-3">
                        <GlassButton variant="secondary" onClick={onClose}>Cancel</GlassButton>
                        <GlassButton variant="primary" onClick={handleSave}>{isEditing ? 'Update Bill' : 'Save Bill'}</GlassButton>
                    </div>
                </div>
            }
        >
            <div className="space-y-6">
                {/* Header */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="md:col-span-2">
                        <UnifiedSearchableSelect 
                            value={vendorId}
                            onSelect={(entity) => setVendorId(entity?.id || null)}
                            groups={vendorDataGroup}
                            placeholder="Select Supplier *"
                            icon={<Building size={18}/>}
                            onQuickAdd={() => setIsVendorModalOpen(true)}
                        />
                    </div>
                    <GlassField id="billNumber" label="Bill #" value={billNumber} onChange={e => setBillNumber(e.target.value)} icon={<Hash size={16}/>}/>
                    <div/>
                    <GlassField id="billDate" label="Bill Date" type="date" value={billDate} onChange={e => setBillDate(e.target.value)} icon={<Calendar size={16}/>} />
                    <GlassField id="dueDate" label="Due Date" type="date" value={dueDate} onChange={e => setDueDate(e.target.value)} icon={<Calendar size={16}/>}/>
                </div>

                {/* Lines */}
                <div className="mt-4">
                    <div className="grid grid-cols-12 gap-4 px-2 py-1 text-xs font-semibold text-slate-500 uppercase">
                        <div className="col-span-5">Account</div>
                        <div className="col-span-4">Description</div>
                        <div className="col-span-2 text-right">Amount</div>
                        <div className="col-span-1"></div>
                    </div>
                    <div className="space-y-2">
                        {lines.map((line, index) => (
                            <div key={line.clientId} className="grid grid-cols-12 gap-3 items-center group bg-white/40 p-2 rounded-xl">
                                <div className="col-span-5">
                                    <SearchableAccountInput value={line.accountId} accounts={relevantAccounts} onSelect={acc => handleLineChange(index, 'accountId', acc.id)} placeholder="Select account..." className="input-compact" />
                                </div>
                                <div className="col-span-4">
                                    <input type="text" value={line.description} onChange={e => handleLineChange(index, 'description', e.target.value)} placeholder="Description" className="input-compact"/>
                                </div>
                                <div className="col-span-2 h-10">
                                    <CurrencyInput 
                                        value={line.amount} 
                                        onChange={(val) => handleLineChange(index, 'amount', val)}
                                        onConversion={(iqd, rate) => handleCurrencyConversion(index, iqd, rate)}
                                        compact
                                        wrapperClassName="w-full h-full bg-white/60 border border-slate-300/50 rounded-lg flex items-center overflow-hidden"
                                    />
                                </div>
                                <div className="col-span-1 text-center">
                                    <button onClick={() => removeLine(index)} className="text-slate-400 hover:text-red-500 opacity-50 group-hover:opacity-100 transition-opacity"><XCircle size={16}/></button>
                                </div>
                            </div>
                        ))}
                    </div>
                    <button onClick={addLine} className="flex items-center gap-1 mt-3 text-sm font-semibold text-sky-600 hover:text-sky-800">
                        <Plus size={14}/> Add Line
                    </button>
                </div>
            </div>
             <style>{`.input-compact { width: 100%; height: 38px; background-color: rgba(255,255,255,0.6); border: 1px solid rgba(255,255,255,0.5); border-radius: 0.5rem; padding: 0 0.75rem; font-size: 0.875rem; transition: all 0.2s; } .input-compact:focus { outline: none; box-shadow: 0 0 0 2px #7dd3fc; }`}</style>
        </GlassModal>
        
        <AddVendorModal isOpen={isVendorModalOpen} onClose={() => setIsVendorModalOpen(false)} onSave={handleNewVendorAdded} />
        </>
    );
};

export default BillFormModal;
