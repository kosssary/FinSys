
import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { useData } from '../../context/DataContext';
import { Customer, Account, AccountType, CustomerOrder, Agent } from '../../types';
import AddCustomerModal from './AddCustomerModal';
import { GlassModal } from '../ui/GlassModal';
import { GlassField } from '../ui/GlassField';
import { GlassSearchableSelect } from '../ui/GlassSearchableSelect';
import { GlassTextarea } from '../ui/GlassTextarea';
import { GlassButton } from '../ui/GlassButton';
import { OrderSummaryCard } from '../ui/OrderSummaryCard';
import { UserPlus, Search, Phone, Mail, Link as LinkIcon, Edit3, CircleDollarSign, Calendar, Landmark, Users, Truck, Package } from 'lucide-react';
import { CurrencyInput } from '../ui/CurrencyInput';

const getDefaultDueDate = () => {
    const date = new Date();
    date.setDate(date.getDate() + 18);
    return date.toISOString().split('T')[0];
};

const getDefaultOrderDate = () => new Date().toISOString().split('T')[0];

const initialFormData = {
    selectedCustomer: null as Customer | null,
    selectedAgent: null as Agent | null,
    productLink: '',
    orderDescription: '',
    totalPrice: '',
    paidAmount: '',
    receiptNumber: '',
    logisticsId: '',
    initialDepositAccountId: '',
    orderDate: getDefaultOrderDate(),
    estimatedDueDate: getDefaultDueDate(),
    internalShippingCost: '',
    itemCount: '',
};

interface AddOrderModalProps {
    isOpen: boolean;
    onClose: () => void;
    editingOrder?: CustomerOrder | null;
    onSave: (order: CustomerOrder) => void;
}

const StepHeader: React.FC<{ steps: string[], activeStep: number, onStepClick: (index: number) => void }> = ({ steps, activeStep, onStepClick }) => (
    <div className="flex items-center space-x-4 mb-6">
        {steps.map((step, index) => (
            <button
                key={step}
                type="button"
                onClick={() => onStepClick(index)}
                className="flex items-center space-x-2 group"
            >
                <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold transition-all ${activeStep >= index ? 'bg-sky-500 text-white' : 'bg-white/70 text-slate-500 border border-white/60'}`}>
                    {index + 1}
                </div>
                <span className={`font-semibold text-sm transition-colors ${activeStep >= index ? 'text-slate-800' : 'text-slate-500'}`}>
                    {step}
                </span>
            </button>
        ))}
    </div>
);

const formatCurrency = (value: number) => new Intl.NumberFormat('en-US').format(value);

export const AddOrderModal: React.FC<AddOrderModalProps> = ({ isOpen, onClose, editingOrder, onSave }) => {
    const { addOrder, updateOrder, getAccountsList, getCustomers, getAgents } = useData();
    const [accounts, setAccounts] = useState<Account[]>([]);
    const [customers, setCustomers] = useState<Customer[]>([]);
    const [agents, setAgents] = useState<Agent[]>([]);

    // Form state
    const [formData, setFormData] = useState(initialFormData);

    const [customerSearch, setCustomerSearch] = useState('');
    const [isDropdownOpen, setIsDropdownOpen] = useState(false);
    const [isCustomerModalOpen, setIsCustomerModalOpen] = useState(false);
    const [activeStep, setActiveStep] = useState(0);
    const [errors, setErrors] = useState<Record<string, string>>({});

    const sectionRefs = {
        customer: useRef<HTMLDivElement>(null),
        pricing: useRef<HTMLDivElement>(null),
        order: useRef<HTMLDivElement>(null),
    };

    const isEditing = !!editingOrder;

    const handleStepClick = (index: number) => {
        setActiveStep(index);
        const ref = Object.values(sectionRefs)[index];
        ref.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    };

    useEffect(() => {
        if (isOpen) {
            const fetchData = async () => {
                const [accs, custs, agts] = await Promise.all([getAccountsList(), getCustomers(), getAgents()]);
                const monetaryAccounts = accs.filter(a => a.isPostable && [AccountType.Cash, AccountType.Bank, AccountType.EWallet, AccountType.MobileCredit].includes(a.accountType));
                setAccounts(monetaryAccounts);
                setCustomers(custs);
                setAgents(agts);
                const firstAccount = monetaryAccounts.length > 0 ? monetaryAccounts[0] : null;

                if (isEditing && editingOrder) {
                    const customer = custs.find(c => c.id === editingOrder.customerId);
                    const agent = editingOrder.agentId ? agts.find(a => a.id === editingOrder.agentId) : null;

                    setFormData({
                        selectedCustomer: customer || null,
                        selectedAgent: agent || null,
                        productLink: editingOrder.productLink || '',
                        orderDescription: editingOrder.orderDescription || '',
                        totalPrice: String(editingOrder.totalPrice),
                        paidAmount: String(editingOrder.paidAmount),
                        receiptNumber: editingOrder.receiptNumber || '',
                        logisticsId: editingOrder.logisticsId || '',
                        initialDepositAccountId: firstAccount?.id || '',
                        orderDate: editingOrder.orderDate ? new Date(editingOrder.orderDate).toISOString().split('T')[0] : getDefaultOrderDate(),
                        estimatedDueDate: editingOrder.estimatedDueDate ? new Date(editingOrder.estimatedDueDate).toISOString().split('T')[0] : getDefaultDueDate(),
                        internalShippingCost: editingOrder.internalShippingCost ? String(editingOrder.internalShippingCost) : '',
                        itemCount: editingOrder.itemCount ? String(editingOrder.itemCount) : '',
                    });
                    if (customer) {
                        setCustomerSearch(`${customer.name || `ID: ${customer.id}`} (${customer.phone1})`);
                    }

                } else {
                    setFormData({ ...initialFormData, orderDate: getDefaultOrderDate(), initialDepositAccountId: firstAccount?.id || '' });
                    setCustomerSearch('');
                    setErrors({});
                    setActiveStep(0);
                }
            };
            fetchData();
        }
    }, [isOpen, editingOrder, isEditing, getAccountsList, getCustomers, getAgents]);


    const handleInputChange = (field: keyof typeof formData, value: any) => {
        setFormData(prev => ({ ...prev, [field]: value }));
        if (errors[field]) {
            setErrors(prev => {
                const newErrors = { ...prev };
                delete newErrors[field];
                return newErrors;
            });
        }
    };
    
    // --- CURRENCY HELPER: Append IQD conversion notes ---
    const handleCurrencyConversion = (field: 'totalPrice' | 'paidAmount' | 'internalShippingCost', iqdAmount: number, rate: number) => {
        const label = field === 'totalPrice' ? 'Total Price' : field === 'paidAmount' ? 'Paid Amount' : 'Shipping';
        const note = `(${label}: ${iqdAmount.toLocaleString()} IQD @ ${rate})`;
        
        setFormData(prev => {
            let currentDesc = prev.orderDescription || '';
            // Remove existing note for this specific field if present to avoid duplicates
            // Regex to match pattern like (Total Price: 150,000 IQD @ 1500)
            const regex = new RegExp(`\\(${label}: .*? IQD @ .*?\\)`, 'g');
            currentDesc = currentDesc.replace(regex, '').trim();
            
            return { ...prev, orderDescription: (currentDesc + ' ' + note).trim() };
        });
    };

    const filteredCustomers = useMemo(() => {
        if (!customerSearch || (formData.selectedCustomer && `${formData.selectedCustomer.name || 'N/A'} (${formData.selectedCustomer.phone1})` === customerSearch)) return [];
        const lowerCaseSearch = customerSearch.toLowerCase();
        return customers.filter(c =>
            (c.name && c.name.toLowerCase().includes(lowerCaseSearch)) ||
            c.phone1.includes(customerSearch) ||
            c.id.toLowerCase().includes(lowerCaseSearch)
        );
    }, [customerSearch, customers, formData.selectedCustomer]);

    const handleCustomerSelect = (customer: Customer) => {
        handleInputChange('selectedCustomer', customer);
        setCustomerSearch(`${customer.name || `ID: ${customer.id}`} (${customer.phone1})`);
        setIsDropdownOpen(false);
    };

    const handleNewCustomerAdded = useCallback((newCustomer: Customer) => {
        setCustomers(prev => [newCustomer, ...prev]);
        setIsCustomerModalOpen(false);
        handleCustomerSelect(newCustomer);
    }, []);

    const accountOptions = useMemo(() => accounts.map(acc => ({
        value: acc.id,
        label: `${acc.code} - ${acc.name}`,
        details: formatCurrency(acc.balance)
    })), [accounts]);

    const agentOptions = useMemo(() => agents.map(agt => ({
        value: agt.id,
        label: agt.name,
        details: agt.phone
    })), [agents]);

    const selectedAccountOption = useMemo(() => {
        return accountOptions.find(opt => opt.value === formData.initialDepositAccountId) || null;
    }, [formData.initialDepositAccountId, accountOptions]);

    const selectedAgentOption = useMemo(() => {
        return formData.selectedAgent ? { value: formData.selectedAgent.id, label: formData.selectedAgent.name, details: formData.selectedAgent.phone } : null;
    }, [formData.selectedAgent]);


    const handleAccountSelect = (option: { value: string; label: string; } | null) => {
        handleInputChange('initialDepositAccountId', option ? option.value : '');
    };

    const handleAgentSelect = (option: { value: string; label: string; } | null) => {
        if (option) {
            const agent = agents.find(a => a.id === option.value);
            handleInputChange('selectedAgent', agent || null);
        } else {
            handleInputChange('selectedAgent', null);
        }
    };

    const validateForm = () => {
        const newErrors: Record<string, string> = {};
        if (!formData.selectedCustomer) newErrors.selectedCustomer = 'Customer is required.';
        if (!formData.totalPrice || parseFloat(formData.totalPrice) <= 0) newErrors.totalPrice = 'A valid total price is required.';
        if (!formData.itemCount || parseInt(formData.itemCount) <= 0) newErrors.itemCount = 'Item Quantity is required for Reward calculation.';
        if (!formData.orderDate) newErrors.orderDate = 'Order date is required.';
        if (!formData.estimatedDueDate) newErrors.estimatedDueDate = 'Estimated due date is required.';
        if (parseFloat(formData.paidAmount) > parseFloat(formData.totalPrice)) newErrors.paidAmount = 'Deposit cannot exceed total price.';
        if (parseFloat(formData.paidAmount) > 0 && !formData.receiptNumber) newErrors.receiptNumber = 'Receipt # is required for payments.';

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };
    
    const handleSubmit = async () => {
        if (!validateForm()) return;

        const priceNum = parseFloat(formData.totalPrice);
        const paidNum = parseFloat(formData.paidAmount) || 0;
        const shippingCostNum = parseFloat(formData.internalShippingCost) || 0;
        const itemCountNum = parseInt(formData.itemCount) || 0;
        
        const orderPayload = {
            customerId: formData.selectedCustomer!.id,
            customerName: formData.selectedCustomer!.name || formData.selectedCustomer!.phone1,
            customerPhone: formData.selectedCustomer!.phone1,
            customerPhone2: formData.selectedCustomer!.phone2,
            agentId: formData.selectedAgent?.id,
            agentName: formData.selectedAgent?.name,
            productLink: formData.productLink,
            orderDescription: formData.orderDescription,
            totalPrice: priceNum,
            paidAmount: paidNum,
            receiptNumber: formData.receiptNumber,
            logisticsId: formData.logisticsId,
            initialDepositAccountId: paidNum > 0 ? formData.initialDepositAccountId : undefined,
            orderDate: formData.orderDate ? new Date(formData.orderDate) : undefined,
            estimatedDueDate: formData.estimatedDueDate ? new Date(formData.estimatedDueDate) : undefined,
            internalShippingCost: shippingCostNum,
            itemCount: itemCountNum,
        };

        try {
            let savedOrder: CustomerOrder;
            if (isEditing && editingOrder) {
                savedOrder = await updateOrder(editingOrder.id, orderPayload);
            } else {
                savedOrder = await addOrder(orderPayload);
            }
            onSave(savedOrder);
            onClose();
        } catch (error) {
            console.error(`Failed to ${isEditing ? 'update' : 'add'} order:`, error);
            alert(`Error: Could not save the order.`);
        }
    };

    const isSaveDisabled = !formData.selectedCustomer || !formData.totalPrice || !formData.itemCount || !formData.estimatedDueDate || parseFloat(formData.totalPrice) <= 0;

    return (
        <>
            <GlassModal
                isOpen={isOpen}
                onClose={onClose}
                title={isEditing ? 'Edit Order' : 'Create New Order'}
                subtitle="Fill customer, order, and payment. * shows required."
                footer={
                    <>
                        <p className="text-xs text-slate-500">Nothing is saved until you submit.</p>
                        <div className="flex items-center space-x-3">
                            <GlassButton variant="secondary" onClick={onClose}>Cancel</GlassButton>
                            <GlassButton variant="primary" onClick={handleSubmit} disabled={isSaveDisabled}>
                                {isEditing ? 'Update Order' : 'Save Order'}
                            </GlassButton>
                        </div>
                    </>
                }
            >
                 <div className="grid grid-cols-12 gap-8">
                    {/* Left Form Column */}
                    <div className="col-span-12 lg:col-span-8 space-y-8">
                        <StepHeader steps={['Customer', 'Pricing', 'Order']} activeStep={activeStep} onStepClick={handleStepClick} />

                        {/* Customer Section */}
                        <div ref={sectionRefs.customer}>
                            <h3 className="section-header">Customer & Referral</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div className="relative md:col-span-2">
                                    <GlassField
                                        id="customerSearch"
                                        label="Search or Add Customer *"
                                        value={customerSearch}
                                        onChange={(e) => { setCustomerSearch(e.target.value); setIsDropdownOpen(true); if (formData.selectedCustomer) handleInputChange('selectedCustomer', null); }}
                                        onFocus={() => setIsDropdownOpen(true)}
                                        onBlur={() => setTimeout(() => setIsDropdownOpen(false), 200)}
                                        icon={<Search size={16} />}
                                        error={errors.selectedCustomer}
                                        autoFocus
                                    />
                                    <GlassButton variant="secondary" onClick={() => setIsCustomerModalOpen(true)} className="!absolute right-2 top-2 !h-9 !px-3 !py-1 text-xs">
                                        <UserPlus size={14} className="mr-1" /> New
                                    </GlassButton>
                                     {isDropdownOpen && filteredCustomers.length > 0 && (
                                        <ul className="absolute z-20 w-full bg-white/80 backdrop-blur-md border border-white/50 rounded-xl mt-1 shadow-lg max-h-40 overflow-auto">
                                            {filteredCustomers.map(customer => (
                                                <li key={customer.id} onMouseDown={() => handleCustomerSelect(customer)} className="px-4 py-2 hover:bg-sky-100/50 cursor-pointer">
                                                    <p className="font-semibold text-slate-800">{customer.name} ({customer.id})</p>
                                                    <p className="text-xs text-slate-500">{customer.phone1}</p>
                                                </li>
                                            ))}
                                        </ul>
                                    )}
                                </div>
                                <GlassSearchableSelect
                                    id="agent"
                                    label="Agent / Referral (Optional)"
                                    icon={<Users size={16} />}
                                    options={agentOptions}
                                    selected={selectedAgentOption}
                                    onSelect={handleAgentSelect}
                                />
                                <GlassField id="phone" label="Primary Phone" value={formData.selectedCustomer?.phone1 || ''} readOnly icon={<Phone size={16} />} />
                            </div>
                        </div>

                        {/* Pricing & Payment Section */}
                        <div ref={sectionRefs.pricing}>
                            <h3 className="section-header">Pricing & Payment</h3>
                             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <GlassField id="orderDate" label="Order Date *" type="date" value={formData.orderDate} onChange={(e) => handleInputChange('orderDate', e.target.value)} icon={<Calendar size={16} />} error={errors.orderDate} />
                                <GlassField id="estimatedDueDate" label="Estimated Due Date *" type="date" value={formData.estimatedDueDate} onChange={(e) => handleInputChange('estimatedDueDate', e.target.value)} icon={<Calendar size={16} />} error={errors.estimatedDueDate}/>
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                                <CurrencyInput
                                    value={formData.totalPrice}
                                    onChange={(val) => handleInputChange('totalPrice', val)}
                                    onConversion={(iqd, rate) => handleCurrencyConversion('totalPrice', iqd, rate)}
                                    placeholder="Total Price *"
                                />
                                <CurrencyInput
                                    value={formData.paidAmount}
                                    onChange={(val) => handleInputChange('paidAmount', val)}
                                    onConversion={(iqd, rate) => handleCurrencyConversion('paidAmount', iqd, rate)}
                                    placeholder="Initial Deposit"
                                />
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                                <GlassField 
                                    id="receiptNumber" 
                                    label="Receipt #" 
                                    value={formData.receiptNumber} 
                                    onChange={(e) => handleInputChange('receiptNumber', e.target.value)} 
                                    icon={<Edit3 size={16} />}
                                    error={errors.receiptNumber}
                                    disabled={(parseFloat(formData.paidAmount) || 0) <= 0}
                                />
                                <GlassSearchableSelect
                                    id="depositAccount"
                                    label="Deposit to Account"
                                    icon={<Landmark size={16} />}
                                    options={accountOptions}
                                    selected={selectedAccountOption}
                                    onSelect={handleAccountSelect}
                                    disabled={(parseFloat(formData.paidAmount) || 0) <= 0}
                                />
                            </div>
                            {/* Internal Shipping Cost Field */}
                            <div className="mt-4 p-4 bg-slate-50/50 rounded-xl border border-slate-200/60">
                                <p className="text-xs font-semibold text-slate-500 mb-3 uppercase tracking-wider">Company Expense (Optional)</p>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <CurrencyInput
                                        value={formData.internalShippingCost}
                                        onChange={(val) => handleInputChange('internalShippingCost', val)}
                                        onConversion={(iqd, rate) => handleCurrencyConversion('internalShippingCost', iqd, rate)}
                                        placeholder="Shipping Cost (Company Pays)"
                                    />
                                    <div className="flex items-center text-xs text-slate-500">
                                        Only enter if the company is paying for delivery. This will record an expense and a liability to the courier.
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Order Details Section */}
                        <div ref={sectionRefs.order}>
                            <h3 className="section-header">Order Details</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <GlassField id="productLink" label="Product Link" value={formData.productLink} onChange={(e) => handleInputChange('productLink', e.target.value)} icon={<LinkIcon size={16} />} error={errors.productLink} />
                                <GlassField id="logisticsId" label="Logistics ID" value={formData.logisticsId} onChange={(e) => handleInputChange('logisticsId', e.target.value)} icon={<Edit3 size={16} />} />
                                <GlassField id="itemCount" label="Total Items (Qty) *" type="number" value={formData.itemCount} onChange={(e) => handleInputChange('itemCount', e.target.value)} icon={<Package size={16} />} error={errors.itemCount} placeholder="e.g., 5" />
                                <div className="md:col-span-2">
                                    <GlassTextarea id="orderDescription" label="Order Notes" value={formData.orderDescription} onChange={(e) => handleInputChange('orderDescription', e.target.value)} icon={<Edit3 size={16} />} />
                                </div>
                            </div>
                        </div>

                    </div>
                    {/* Right Summary Column */}
                    <div className="col-span-12 lg:col-span-4">
                        <OrderSummaryCard formData={formData} />
                    </div>
                </div>
            </GlassModal>
             <AddCustomerModal 
                isOpen={isCustomerModalOpen} 
                onClose={() => setIsCustomerModalOpen(false)}
                onSave={handleNewCustomerAdded}
            />
            <style>{`
                .section-header {
                    font-size: 0.875rem; /* text-sm */
                    font-weight: 600; /* font-semibold */
                    color: #475569; /* slate-600 */
                    padding-bottom: 0.5rem; /* pb-2 */
                    margin-bottom: 1rem; /* mb-4 */
                    position: relative;
                }
                .section-header::after {
                    content: '';
                    position: absolute;
                    bottom: 0;
                    left: 0;
                    width: 100%;
                    height: 1px;
                    background-image: linear-gradient(to right, rgba(6, 182, 212, 0.4), rgba(56, 189, 248, 0.4), transparent);
                }
            `}</style>
        </>
    );
};

export default AddOrderModal;
