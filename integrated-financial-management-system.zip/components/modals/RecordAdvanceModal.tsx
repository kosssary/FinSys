
import React, { useState, useEffect, useMemo } from 'react';
import { useData } from '../../context/DataContext';
import { Account, AccountType } from '../../types';
import { CurrencyInput } from '../ui/CurrencyInput';

interface RecordAdvanceModalProps {
    isOpen: boolean;
    onClose: () => void;
    employeeId: string;
    employeeName: string;
}

const RecordAdvanceModal: React.FC<RecordAdvanceModalProps> = ({ isOpen, onClose, employeeId, employeeName }) => {
    const { getAccountsList, recordEmployeeAdvance } = useData();
    const [accounts, setAccounts] = useState<Account[]>([]);
    const [amount, setAmount] = useState('');
    const [paidFromAccountId, setPaidFromAccountId] = useState('');
    const [date, setDate] = useState('');
    const [description, setDescription] = useState('');

    const paymentAccounts = useMemo(() => {
        return accounts.filter(a => a.isPostable && [AccountType.Cash, AccountType.Bank, AccountType.EWallet].includes(a.accountType));
    }, [accounts]);
    
    useEffect(() => {
        if (isOpen) {
            getAccountsList().then(accs => {
                setAccounts(accs);
                const cashAndBank = accs.filter(a => a.isPostable && [AccountType.Cash, AccountType.Bank, AccountType.EWallet].includes(a.accountType));
                if (cashAndBank.length > 0) {
                    setPaidFromAccountId(cashAndBank[0].id);
                }
            });
            setDate(new Date().toISOString().split('T')[0]);
            setAmount('');
            setDescription(''); // Removed default description as per requirement
        }
    }, [isOpen, getAccountsList]);

    // Currency helper callback
    const handleCurrencyConversion = (iqd: number, rate: number) => {
        const note = `(Advance: ${iqd.toLocaleString()} IQD @ ${rate})`;
        setDescription(prev => {
            let current = prev || '';
            current = current.replace(/\(Advance: .*? IQD @ .*?\)/g, '').trim();
            return (current + ' ' + note).trim();
        });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        const numAmount = parseFloat(amount);
        if (!numAmount || numAmount <= 0 || !paidFromAccountId || !date) {
            alert('Please fill all fields with valid values.');
            return;
        }

        try {
            await recordEmployeeAdvance({
                employeeId,
                amount: numAmount,
                paidFromAccountId,
                date: new Date(date),
                description: description || `Advance for ${employeeName}` // Fallback if empty
            });
            alert('Advance recorded successfully!');
            onClose();
        } catch (error) {
            console.error(error);
            alert(`Error: ${(error as Error).message}`);
        }
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-60" onClick={onClose}>
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-md" onClick={e => e.stopPropagation()}>
                <div className="p-4 border-b dark:border-gray-700 flex justify-between items-center">
                    <h2 className="text-lg font-bold text-gray-800 dark:text-white">Record Advance for {employeeName}</h2>
                    <button onClick={onClose} className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700">&times;</button>
                </div>
                <form onSubmit={handleSubmit}>
                    <div className="p-6 space-y-4">
                        <CurrencyInput 
                            value={amount}
                            onChange={setAmount}
                            onConversion={handleCurrencyConversion}
                            placeholder="Amount"
                        />
                        <div><label className="label">Date</label><input type="date" value={date} onChange={e => setDate(e.target.value)} className="input-field" required /></div>
                        <div><label className="label">Paid From Account</label><select value={paidFromAccountId} onChange={e => setPaidFromAccountId(e.target.value)} className="input-field" required><option value="">-- Select --</option>{paymentAccounts.map(acc => <option key={acc.id} value={acc.id}>{acc.code} - {acc.name}</option>)}</select></div>
                        <div><label className="label">Description</label><input type="text" value={description} onChange={e => setDescription(e.target.value)} className="input-field" placeholder="Reason for advance..." /></div>
                    </div>
                    <div className="p-4 bg-gray-50 dark:bg-gray-900/50 border-t dark:border-gray-700 flex justify-end gap-3">
                        <button type="button" onClick={onClose} className="btn-secondary">Cancel</button>
                        <button type="submit" className="btn-primary">Save Advance</button>
                    </div>
                </form>
            </div>
            <style>{`
                 .label { display: block; margin-bottom: 0.25rem; font-size: 0.875rem; font-weight: 500; color: #4B5563; } .dark .label { color: #D1D5DB; }
                .input-field { display: block; width: 100%; padding: 0.5rem 0.75rem; border: 1px solid #D1D5DB; border-radius: 0.375rem; } .dark .input-field { background-color: #374151; border-color: #4B5563; color: #E5E7EB; }
                .btn-primary { padding: 0.5rem 1rem; font-weight: 600; color: white; background-image: linear-gradient(to right, #0ea5e9, #06b6d4); border-radius: 0.5rem; transition: all 0.2s; box-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1); } .btn-primary:hover { box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1); filter: brightness(1.05); } .btn-primary:active { transform: scale(0.98); } .btn-primary:disabled { opacity: 0.5; cursor: not-allowed; filter: none; transform: none; box-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1); }
                .btn-secondary { padding: 0.5rem 1rem; border: 1px solid #D1D5DB; border-radius: 0.375rem; } .dark .btn-secondary { background-color: #4B5563; border-color: #6B7280; color: #E5E7EB; }
            `}</style>
        </div>
    );
};

export default RecordAdvanceModal;
