
import React, { useState, useEffect, useMemo } from 'react';
import { useData } from '../../context/DataContext';
import { Account, AccountType, Payroll } from '../../types';

interface PaySalariesModalProps {
    isOpen: boolean;
    onClose: () => void;
    payroll: Payroll;
}

const PaySalariesModal: React.FC<PaySalariesModalProps> = ({ isOpen, onClose, payroll }) => {
    const { getAccountsList, payPayroll } = useData();
    const [accounts, setAccounts] = useState<Account[]>([]);
    const [paymentAccountId, setPaymentAccountId] = useState('');
    const [paymentDate, setPaymentDate] = useState('');

    const paymentAccounts = useMemo(() => {
        return accounts.filter(a => a.isPostable && [AccountType.Cash, AccountType.Bank, AccountType.EWallet].includes(a.accountType));
    }, [accounts]);

    useEffect(() => {
        if (isOpen) {
            getAccountsList().then(accs => {
                setAccounts(accs);
                const cashAndBank = accs.filter(a => a.isPostable && [AccountType.Cash, AccountType.Bank, AccountType.EWallet].includes(a.accountType));
                if (cashAndBank.length > 0) {
                    setPaymentAccountId(cashAndBank[0].id);
                }
            });
            setPaymentDate(new Date().toISOString().split('T')[0]);
        }
    }, [isOpen, getAccountsList]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!paymentAccountId || !paymentDate) {
            alert('Please select a payment account and date.');
            return;
        }

        if (window.confirm(`This will record a payment of ${formatCurrency(payroll.totalNetSalary)} for ${payroll.period}. Proceed?`)) {
            try {
                await payPayroll(payroll.id, paymentAccountId, new Date(paymentDate));
                alert('Salaries paid successfully!');
                onClose();
            } catch (error) {
                console.error(error);
                alert(`Error: ${(error as Error).message}`);
            }
        }
    };

    const formatCurrency = (value: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value);

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-60" onClick={onClose}>
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-md" onClick={e => e.stopPropagation()}>
                <div className="p-4 border-b dark:border-gray-700 flex justify-between items-center">
                    <h2 className="text-lg font-bold">Pay Salaries for {payroll.period}</h2>
                    <button onClick={onClose} className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700">&times;</button>
                </div>
                <form onSubmit={handleSubmit}>
                    <div className="p-6 space-y-4">
                        <div className="text-center">
                            <p className="text-sm text-gray-500">Total Net Salary to be Paid</p>
                            <p className="text-3xl font-bold text-green-600">{formatCurrency(payroll.totalNetSalary)}</p>
                        </div>
                        <div><label className="label">Payment Date</label><input type="date" value={paymentDate} onChange={e => setPaymentDate(e.target.value)} className="input-field" required /></div>
                        <div><label className="label">Pay From Account</label><select value={paymentAccountId} onChange={e => setPaymentAccountId(e.target.value)} className="input-field" required><option value="">-- Select --</option>{paymentAccounts.map(acc => <option key={acc.id} value={acc.id}>{acc.code} - {acc.name}</option>)}</select></div>
                    </div>
                    <div className="p-4 bg-gray-50 dark:bg-gray-900/50 border-t dark:border-gray-700 flex justify-end gap-3">
                        <button type="button" onClick={onClose} className="btn-secondary">Cancel</button>
                        <button type="submit" className="btn-success" disabled={payroll.status === 'Paid'}>
                            {payroll.status === 'Paid' ? 'Already Paid' : 'Confirm & Pay'}
                        </button>
                    </div>
                </form>
            </div>
             <style>{`
                .label { display: block; margin-bottom: 0.25rem; font-size: 0.875rem; font-weight: 500; }
                .input-field { display: block; width: 100%; padding: 0.5rem 0.75rem; border: 1px solid #D1D5DB; border-radius: 0.375rem; } .dark .input-field { background-color: #374151; border-color: #4B5563; }
                .btn-success { padding: 0.5rem 1rem; color: white; background-color: #16A34A; border-radius: 0.375rem; }
                .btn-success:disabled { background-color: #166534; cursor: not-allowed; }
                .btn-secondary { padding: 0.5rem 1rem; border: 1px solid #D1D5DB; border-radius: 0.375rem; } .dark .btn-secondary { background-color: #4B5563; border-color: #6B7280; }
            `}</style>
        </div>
    );
};

export default PaySalariesModal;
