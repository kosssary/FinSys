
import React, { useState, useEffect } from 'react';
import { useData } from '../../context/DataContext';
import { Vendor } from '../../types';
import { GlassModal } from '../ui/GlassModal';
import { GlassField } from '../ui/GlassField';
import { GlassButton } from '../ui/GlassButton';
import { Building, User, Phone, MapPin } from 'lucide-react';

interface AddVendorModalProps {
    isOpen: boolean;
    onClose: () => void;
    editingVendor?: Vendor | null;
    onSave?: (vendor: Vendor) => void;
}

const AddVendorModal: React.FC<AddVendorModalProps> = ({ isOpen, onClose, editingVendor, onSave }) => {
    const { addVendor, updateVendor } = useData();
    const [name, setName] = useState('');
    const [contactPerson, setContactPerson] = useState('');
    const [phone, setPhone] = useState('');
    const [address, setAddress] = useState('');
    const [errors, setErrors] = useState<Record<string, string>>({});

    const isEditing = !!editingVendor;

    useEffect(() => {
        if (isOpen) {
            if (isEditing && editingVendor) {
                setName(editingVendor.name || '');
                setContactPerson(editingVendor.contactPerson || '');
                setPhone(editingVendor.phone || '');
                setAddress(editingVendor.address || '');
            } else {
                setName('');
                setContactPerson('');
                setPhone('');
                setAddress('');
            }
            setErrors({});
        }
    }, [isOpen, editingVendor, isEditing]);

    const validate = () => {
        const newErrors: Record<string, string> = {};
        if (!name.trim()) newErrors.name = "Vendor name is required.";
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async () => {
        if (!validate()) return;
        
        const vendorData = {
            name: name.trim(),
            contactPerson: contactPerson.trim() || undefined,
            phone: phone.trim() || undefined,
            address: address.trim() || undefined,
        };

        try {
            let savedVendor: Vendor;
            if (isEditing && editingVendor) {
                await updateVendor({ ...editingVendor, ...vendorData });
                savedVendor = { ...editingVendor, ...vendorData };
            } else {
                savedVendor = await addVendor(vendorData);
            }

            if (onSave) {
                onSave(savedVendor);
            }
            onClose();
        } catch (error) {
            console.error("Failed to save vendor:", error);
            alert("Error: Could not save the vendor. Please try again.");
        }
    };

    if (!isOpen) return null;

    return (
        <GlassModal
            isOpen={isOpen}
            onClose={onClose}
            title={isEditing ? "Edit Vendor" : "Add New Vendor"}
            subtitle="Enter the details for the vendor or supplier."
            footer={
                <>
                    <div /> {/* Spacer */}
                    <div className="flex items-center space-x-3">
                        <GlassButton variant="secondary" onClick={onClose}>Cancel</GlassButton>
                        <GlassButton variant="primary" onClick={handleSubmit}>{isEditing ? "Update Vendor" : "Save Vendor"}</GlassButton>
                    </div>
                </>
            }
        >
            <div className="space-y-4 max-w-lg mx-auto py-4">
                <GlassField
                    id="vendorName"
                    label="Vendor Name *"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    icon={<Building size={16} />}
                    error={errors.name}
                    autoFocus
                />
                <GlassField
                    id="contactPerson"
                    label="Contact Person (Optional)"
                    value={contactPerson}
                    onChange={(e) => setContactPerson(e.target.value)}
                    icon={<User size={16} />}
                />
                <GlassField
                    id="phone"
                    label="Phone Number (Optional)"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    icon={<Phone size={16} />}
                />
                <GlassField
                    id="address"
                    label="Address (Optional)"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    icon={<MapPin size={16} />}
                />
            </div>
        </GlassModal>
    );
};

export default AddVendorModal;
