import React, { useState, useEffect } from 'react';
import { useData } from '../../context/DataContext';
import { Agent } from '../../types';
import { GlassModal } from '../ui/GlassModal';
import { GlassField } from '../ui/GlassField';
import { GlassButton } from '../ui/GlassButton';
import { User, Phone, Percent } from 'lucide-react';

interface AddAgentModalProps {
    isOpen: boolean;
    onClose: () => void;
    editingAgent?: Agent | null;
    onSave?: (agent: Agent) => void;
}

const AddAgentModal: React.FC<AddAgentModalProps> = ({ isOpen, onClose, editingAgent, onSave }) => {
    const { addAgent, updateAgent } = useData();
    const [name, setName] = useState('');
    const [phone, setPhone] = useState('');
    const [commissionRate, setCommissionRate] = useState('');
    const [errors, setErrors] = useState<Record<string, string>>({});

    const isEditing = !!editingAgent;

    useEffect(() => {
        if (isOpen) {
            if (isEditing && editingAgent) {
                setName(editingAgent.name || '');
                setPhone(editingAgent.phone || '');
                setCommissionRate(editingAgent.commissionRate ? String(editingAgent.commissionRate) : '');
            } else {
                setName('');
                setPhone('');
                setCommissionRate('');
            }
            setErrors({});
        }
    }, [isOpen, editingAgent, isEditing]);

    const validate = () => {
        const newErrors: Record<string, string> = {};
        if (!name.trim()) newErrors.name = "Agent name is required.";
        if (!phone.trim()) newErrors.phone = "Phone number is required.";
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async () => {
        if (!validate()) return;
        
        const agentData = {
            name: name.trim(),
            phone: phone.trim(),
            commissionRate: commissionRate ? parseFloat(commissionRate) : undefined,
        };

        try {
            let savedAgent: Agent;
            if (isEditing && editingAgent) {
                await updateAgent({ ...editingAgent, ...agentData });
                savedAgent = { ...editingAgent, ...agentData };
            } else {
                savedAgent = await addAgent(agentData);
            }
            
            if (onSave) {
                onSave(savedAgent);
            }
            onClose();
        } catch (error) {
            console.error("Failed to save agent:", error);
            alert("Error: Could not save the agent. Please try again.");
        }
    };

    if (!isOpen) return null;

    return (
        <GlassModal
            isOpen={isOpen}
            onClose={onClose}
            title={isEditing ? "Edit Agent" : "Add New Agent"}
            subtitle="Enter details for the referrer or reseller."
            footer={
                <>
                    <div /> {/* Spacer */}
                    <div className="flex items-center space-x-3">
                        <GlassButton variant="secondary" onClick={onClose}>Cancel</GlassButton>
                        <GlassButton variant="primary" onClick={handleSubmit}>{isEditing ? "Update Agent" : "Save Agent"}</GlassButton>
                    </div>
                </>
            }
        >
            <div className="space-y-4 max-w-lg mx-auto py-4">
                <GlassField
                    id="agentName"
                    label="Agent Name *"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    icon={<User size={16} />}
                    error={errors.name}
                    autoFocus
                />
                <GlassField
                    id="phone"
                    label="Phone Number *"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    icon={<Phone size={16} />}
                    error={errors.phone}
                />
                <GlassField
                    id="commissionRate"
                    label="Commission Rate (%)"
                    type="number"
                    value={commissionRate}
                    onChange={(e) => setCommissionRate(e.target.value)}
                    icon={<Percent size={16} />}
                    adornment="%"
                />
            </div>
        </GlassModal>
    );
};

export default AddAgentModal;