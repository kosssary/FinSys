
import React, { useState, useMemo, useEffect } from 'react';
import { useData } from '../../context/DataContext';
import { Bill, Account, AccountType } from '../../types';
import { GlassModal } from '../ui/GlassModal';
import { GlassField } from '../ui/GlassField';
import { GlassSearchableSelect } from '../ui/GlassSearchableSelect';
import { GlassButton } from '../ui/GlassButton';
import { Calendar, Hash, Landmark } from 'lucide-react';
import { CurrencyInput } from '../ui/CurrencyInput';

interface RecordBillPaymentModalProps {
    isOpen: boolean;
    onClose: () => void;
    bill: Bill;
}

const formatCurrency = (value: number) => new Intl.NumberFormat('en-US').format(value);

const RecordBillPaymentModal: React.FC<RecordBillPaymentModalProps> = ({ isOpen, onClose, bill }) => {
    const { getAccountsList, recordBillPayment } = useData();
    const [accounts, setAccounts] = useState<Account[]>([]);
    
    const [paymentDate, setPaymentDate] = useState('');
    const [amount, setAmount] = useState('');
    const [paymentAccountId, setPaymentAccountId] = useState('');
    const [referenceNumber, setReferenceNumber] = useState('');
    const [notes, setNotes] = useState('');
    
    const balanceDue = bill.totalAmount - bill.paidAmount;

    const paymentAccounts = useMemo(() => {
        return accounts.filter(a => a.isPostable && [AccountType.Cash, AccountType.Bank, AccountType.EWallet].includes(a.accountType));
    }, [accounts]);

    useEffect(() => {
        if (isOpen) {
            getAccountsList().then(setAccounts);
            setPaymentDate(new Date().toISOString().split('T')[0]);
            setAmount(String(balanceDue));
            setReferenceNumber('');
            setNotes('');
            if (paymentAccounts.length > 0) {
                setPaymentAccountId(paymentAccounts[0].id);
            }
        }
    }, [isOpen, getAccountsList, balanceDue]);

    useEffect(() => {
        if (paymentAccounts.length > 0 && !paymentAccountId) {
            setPaymentAccountId(paymentAccounts[0].id);
        }
    }, [paymentAccounts, paymentAccountId]);

    const handleCurrencyConversion = (iqd: number, rate: number) => {
        // Replace existing payment note pattern
        const note = `(Payment: ${iqd.toLocaleString()} IQD @ ${rate})`;
        setNotes(prev => {
            let current = prev || '';
            current = current.replace(/\(Payment: .*? IQD @ .*?\)/g, '').trim();
            return (current + ' ' + note).trim();
        });
    };

    const handleSubmit = async () => {
        const paymentAmount = parseFloat(amount);
        if (!paymentAmount || paymentAmount <= 0 || !paymentAccountId || !paymentDate || !referenceNumber.trim()) {
            alert("Please fill all fields correctly, including the required Payment Reference #.");
            return;
        }
        // Small tolerance for floating point errors
        if (paymentAmount > balanceDue + 0.01) {
            alert("Payment cannot exceed the balance due.");
            return;
        }
        
        try {
            await recordBillPayment([{
                billId: bill.id,
                paymentDate: new Date(paymentDate),
                amount: paymentAmount,
                paymentAccountId,
                referenceNumber: referenceNumber.trim(),
                notes: notes // Pass conversion notes
            }]);
            onClose();
        } catch (error) {
            console.error("Failed to record payment:", error);
            alert(`Error: ${(error as Error).message}`);
        }
    };

    const accountOptions = useMemo(() => paymentAccounts.map(acc => ({
        value: acc.id,
        label: `${acc.code} - ${acc.name}`,
        details: formatCurrency(acc.balance)
    })), [paymentAccounts]);

    const selectedAccount = useMemo(() => accountOptions.find(opt => opt.value === paymentAccountId) || null, [paymentAccountId, accountOptions]);

    return (
        <GlassModal
            isOpen={isOpen}
            onClose={onClose}
            title="Record Payment"
            subtitle={`For Bill #${bill.billNumber} from ${bill.vendorName}`}
            footer={
                <div className="w-full flex justify-between items-center">
                     <p className="text-xs text-slate-500">Balance Due: <span className="font-bold font-mono text-base text-rose-700">{formatCurrency(balanceDue)} $</span></p>
                    <div className="flex items-center space-x-3">
                        <GlassButton variant="secondary" onClick={onClose}>Cancel</GlassButton>
                        <GlassButton variant="primary" onClick={handleSubmit}>Save Payment</GlassButton>
                    </div>
                </div>
            }
        >
            <div className="max-w-lg mx-auto py-6 space-y-4">
                <GlassField
                    id="paymentDate"
                    label="Payment Date *"
                    type="date"
                    value={paymentDate}
                    onChange={e => setPaymentDate(e.target.value)}
                    icon={<Calendar size={16} />}
                />
                <GlassField
                    id="referenceNumber"
                    label="Payment Reference # *"
                    type="text"
                    value={referenceNumber}
                    onChange={e => setReferenceNumber(e.target.value)}
                    icon={<Hash size={16} />}
                    required
                />
                <CurrencyInput
                    value={amount}
                    onChange={setAmount}
                    onConversion={handleCurrencyConversion}
                    placeholder="Amount Paid *"
                />
                <GlassSearchableSelect
                    id="paymentAccount"
                    label="Paid From Account *"
                    icon={<Landmark size={16} />}
                    options={accountOptions}
                    selected={selectedAccount}
                    onSelect={opt => setPaymentAccountId(opt?.value || '')}
                />
                {notes && <p className="text-xs text-emerald-600 italic">{notes}</p>}
            </div>
        </GlassModal>
    );
};

export default RecordBillPaymentModal;
