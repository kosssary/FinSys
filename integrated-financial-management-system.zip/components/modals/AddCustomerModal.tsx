import React, { useState, useEffect, useMemo } from 'react';
import { useData } from '../../context/DataContext';
import { IQ_CITIES } from '../../constants';
import { Customer } from '../../types';
import { GlassModal } from '../ui/GlassModal';
import { GlassField } from '../ui/GlassField';
import { GlassSearchableSelect } from '../ui/GlassSearchableSelect';
import { GlassButton } from '../ui/GlassButton';
import { User, Phone, MapPin, Mail } from 'lucide-react';

interface AddCustomerModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave?: (customer: Customer) => void;
    editingCustomer?: Customer | null;
}

const AddCustomerModal: React.FC<AddCustomerModalProps> = ({ isOpen, onClose, onSave, editingCustomer }) => {
    const { addCustomer, updateCustomer } = useData();
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [phone1, setPhone1] = useState('');
    const [phone2, setPhone2] = useState('');
    const [address, setAddress] = useState(IQ_CITIES[0]);
    const [errors, setErrors] = useState<Record<string, string>>({});

    const isEditing = !!editingCustomer;

    useEffect(() => {
        if (isOpen) {
            if (isEditing && editingCustomer) {
                setName(editingCustomer.name || '');
                setEmail(editingCustomer.email || '');
                setPhone1(editingCustomer.phone1);
                setPhone2(editingCustomer.phone2 || '');
                setAddress(editingCustomer.address);
            } else {
                setName('');
                setEmail('');
                setPhone1('');
                setPhone2('');
                setAddress(IQ_CITIES[0]);
            }
            setErrors({});
        }
    }, [isOpen, editingCustomer, isEditing]);

    const validate = () => {
        const newErrors: Record<string, string> = {};
        if (!phone1.trim()) newErrors.phone1 = "Primary phone is required.";
        if (!address.trim()) newErrors.address = "Address is required.";
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async () => {
        if (!validate()) return;
        
        const formattedName = name.trim().split(' ')
            .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
            .join(' ');
            
        const customerData = {
            name: formattedName || undefined,
            email: email.trim() || undefined,
            phone1: phone1.trim(),
            phone2: phone2.trim() || undefined,
            address,
        };

        try {
            let savedCustomer: Customer;
            if (isEditing && editingCustomer) {
                savedCustomer = { ...editingCustomer, ...customerData };
                await updateCustomer(savedCustomer);
            } else {
                savedCustomer = await addCustomer(customerData);
            }
            
            if (savedCustomer) {
                onSave?.(savedCustomer);
            }
    
            onClose();
        } catch (error) {
            console.error("Failed to save customer:", error);
            alert("Error: Could not save the customer. Please try again.");
        }
    };

    const cityOptions = useMemo(() => IQ_CITIES.map(city => ({ value: city, label: city })), []);
    const selectedCity = useMemo(() => cityOptions.find(opt => opt.value === address) || null, [address, cityOptions]);
    const handleCitySelect = (option: { value: string; label: string; } | null) => {
        const newAddress = option ? option.value : '';
        setAddress(newAddress);
        if (errors.address && newAddress) {
            setErrors(prev => {
                const newErrors = { ...prev };
                delete newErrors.address;
                return newErrors;
            });
        }
    };

    if (!isOpen) return null;

    return (
        <GlassModal
            isOpen={isOpen}
            onClose={onClose}
            title={isEditing ? "Edit Customer" : "Add New Customer"}
            subtitle="Enter the details for the customer."
            footer={
                <>
                    <div /> {/* Spacer */}
                    <div className="flex items-center space-x-3">
                        <GlassButton variant="secondary" onClick={onClose}>Cancel</GlassButton>
                        <GlassButton variant="primary" onClick={handleSubmit}>{isEditing ? "Update Customer" : "Save Customer"}</GlassButton>
                    </div>
                </>
            }
        >
            <div className="space-y-4 max-w-lg mx-auto py-4">
                <GlassField
                    id="customerName"
                    label="Name (Optional)"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    icon={<User size={16} />}
                    autoFocus
                />
                <GlassField
                    id="customerEmail"
                    label="Email (Optional)"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    icon={<Mail size={16} />}
                />
                <GlassField
                    id="phone1"
                    label="Primary Phone *"
                    value={phone1}
                    onChange={(e) => setPhone1(e.target.value)}
                    icon={<Phone size={16} />}
                    error={errors.phone1}
                />
                <GlassField
                    id="phone2"
                    label="Secondary Phone (Optional)"
                    value={phone2}
                    onChange={(e) => setPhone2(e.target.value)}
                    icon={<Phone size={16} />}
                />
                <GlassSearchableSelect
                    id="address"
                    label="Address (City) *"
                    icon={<MapPin size={16} />}
                    options={cityOptions}
                    selected={selectedCity}
                    onSelect={handleCitySelect}
                    error={errors.address}
                />
            </div>
        </GlassModal>
    );
};

export default AddCustomerModal;