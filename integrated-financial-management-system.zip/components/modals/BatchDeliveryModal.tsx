
import React, { useState, useEffect, useMemo } from 'react';
import { useData } from '../../context/DataContext';
import { Vendor } from '../../types';
import { GlassModal } from '../ui/GlassModal';
import { GlassSearchableSelect } from '../ui/GlassSearchableSelect';
import { GlassButton } from '../ui/GlassButton';
import { Truck } from 'lucide-react';

interface BatchDeliveryModalProps {
    isOpen: boolean;
    onClose: () => void;
    onConfirm: (courierVendorId: string) => void;
    selectedCount: number;
}

const BatchDeliveryModal: React.FC<BatchDeliveryModalProps> = ({ isOpen, onClose, onConfirm, selectedCount }) => {
    const { getVendors } = useData();
    const [vendors, setVendors] = useState<Vendor[]>([]);
    const [selectedCourierId, setSelectedCourierId] = useState<string>('');

    useEffect(() => {
        if (isOpen) {
            getVendors().then(setVendors);
            setSelectedCourierId('');
        }
    }, [isOpen, getVendors]);

    const courierOptions = useMemo(() => vendors.map(v => ({
        value: v.id,
        label: v.name,
        details: v.phone
    })), [vendors]);

    const selectedOption = useMemo(() => courierOptions.find(opt => opt.value === selectedCourierId) || null, [selectedCourierId, courierOptions]);

    const handleConfirm = () => {
        if (!selectedCourierId) {
            alert("Please select a courier company.");
            return;
        }
        onConfirm(selectedCourierId);
    };

    if (!isOpen) return null;

    return (
        <GlassModal
            isOpen={isOpen}
            onClose={onClose}
            title="Batch Delivery Handover"
            subtitle={`Hand over ${selectedCount} orders to a courier.`}
            footer={
                <div className="flex items-center justify-end space-x-3 w-full">
                    <GlassButton variant="secondary" onClick={onClose}>Cancel</GlassButton>
                    <GlassButton variant="primary" onClick={handleConfirm} disabled={!selectedCourierId}>Confirm Handover</GlassButton>
                </div>
            }
        >
            <div className="py-6 space-y-6 max-w-md mx-auto">
                <div className="bg-blue-50 border border-blue-100 rounded-xl p-4 text-sm text-blue-800">
                    <p className="font-semibold mb-1">What happens next?</p>
                    <ul className="list-disc list-inside space-y-1 text-blue-700">
                        <li>Orders will be marked as <strong>Delivered</strong>.</li>
                        <li>Outstanding debt will transfer from Customers to the selected Courier.</li>
                        <li>A single Journal Voucher will be created for this batch.</li>
                    </ul>
                </div>
                
                <GlassSearchableSelect
                    id="courierSelect"
                    label="Select Courier Company (Vendor) *"
                    icon={<Truck size={16} />}
                    options={courierOptions}
                    selected={selectedOption}
                    onSelect={(opt) => setSelectedCourierId(opt?.value || '')}
                />
            </div>
        </GlassModal>
    );
};

export default BatchDeliveryModal;
