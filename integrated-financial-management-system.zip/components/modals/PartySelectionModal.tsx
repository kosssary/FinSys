
import React, { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, X } from 'lucide-react';
import { Customer, Vendor, Employee, Shareholder, PartyEntity } from '@/types';

type Party = (Customer | Vendor | Employee | Shareholder) & { balance?: number };

interface PartySelectionModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSelect: (party: PartyEntity) => void;
    partyTypes: ('customer' | 'vendor' | 'employee' | 'shareholder')[];
    data: {
        customers: (Customer & { balance: number })[];
        vendors: (Vendor & { balance: number })[];
        employees: (Employee & { balance?: number })[];
        shareholders: Shareholder[];
    };
}

const PartyList: React.FC<{ items: Party[], onSelect: (item: Party) => void, type: PartyEntity['type'] }> = ({ items, onSelect, type }) => {
    const [query, setQuery] = useState('');
    const [page, setPage] = useState(1);
    const itemsPerPage = 10;

    useEffect(() => { setPage(1); }, [query]);

    const filteredItems = useMemo(() => {
        if (!query) return items;
        const lowerQuery = query.toLowerCase();
        return items.filter(item =>
            (('fullName' in item ? item.fullName : item.name) || '').toLowerCase().includes(lowerQuery) ||
            item.id.toLowerCase().includes(lowerQuery) ||
            ((item as Customer).phone1 && (item as Customer).phone1.includes(lowerQuery))
        );
    }, [query, items]);

    const paginatedItems = useMemo(() => {
        const start = (page - 1) * itemsPerPage;
        return filteredItems.slice(start, start + itemsPerPage);
    }, [filteredItems, page, itemsPerPage]);

    const totalPages = Math.ceil(filteredItems.length / itemsPerPage);

    return (
        <div>
            <div className="relative mb-2">
                <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                    type="text"
                    value={query}
                    onChange={e => setQuery(e.target.value)}
                    placeholder="Search..."
                    className="w-full h-10 bg-white/70 border border-slate-300/70 rounded-lg pl-9 pr-3 text-sm text-slate-800 focus:ring-1 focus:ring-sky-500/80 focus:outline-none"
                />
            </div>
            <div className="min-h-[350px]">
                {paginatedItems.map(item => (
                    <div
                        key={item.id}
                        onClick={() => onSelect(item)}
                        className="flex justify-between items-center p-3 rounded-lg hover:bg-sky-100/50 cursor-pointer"
                    >
                        <div>
                            <p className="font-semibold text-slate-800">{'fullName' in item ? item.fullName : item.name}</p>
                            <p className="text-xs text-slate-500">
                                {type === 'customer' && `ID: ${item.id} | Phone: ${(item as Customer).phone1}`}
                                {type === 'vendor' && `ID: ${item.id} | Phone: ${(item as Vendor).phone}`}
                                {type === 'employee' && `ID: ${item.id} | Position: ${(item as Employee).position}`}
                                {type === 'shareholder' && `ID: ${item.id} | Share: ${(item as Shareholder).profitSharePercentage}%`}
                            </p>
                        </div>
                        {typeof item.balance === 'number' && (
                            <span className={`font-mono text-sm font-semibold ${item.balance >= 0 ? 'text-slate-700' : 'text-red-600'}`}>
                                {new Intl.NumberFormat('en-US').format(item.balance)} $
                            </span>
                        )}
                    </div>
                ))}
                 {filteredItems.length === 0 && (
                    <div className="text-center py-10 text-slate-500">No parties found.</div>
                )}
            </div>
            {totalPages > 1 && (
                <div className="flex justify-between items-center text-xs text-slate-500 pt-2 border-t border-slate-200/80 mt-2">
                    <p>Page {page} of {totalPages}</p>
                    <div className="flex gap-1">
                        <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="px-2 py-1 rounded disabled:opacity-50 hover:bg-slate-200/50">Prev</button>
                        <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages} className="px-2 py-1 rounded disabled:opacity-50 hover:bg-slate-200/50">Next</button>
                    </div>
                </div>
            )}
        </div>
    );
};

const PartySelectionModal: React.FC<PartySelectionModalProps> = ({ isOpen, onClose, onSelect, partyTypes, data }) => {
    const [activeTab, setActiveTab] = useState(partyTypes[0]);

    useEffect(() => {
        if(isOpen) setActiveTab(partyTypes[0]);
    }, [isOpen, partyTypes]);

    const handleSelect = (item: Party, type: PartyEntity['type']) => {
        const name = 'fullName' in item ? item.fullName : (item.name || '');
        onSelect({ id: item.id, name, type });
    };

    const getTabContent = () => {
        switch (activeTab) {
            case 'customer': return <PartyList items={data.customers} onSelect={item => handleSelect(item, 'customer')} type="customer" />;
            case 'vendor': return <PartyList items={data.vendors} onSelect={item => handleSelect(item, 'vendor')} type="vendor" />;
            case 'employee': return <PartyList items={data.employees as Party[]} onSelect={item => handleSelect(item, 'employee')} type="employee" />;
            case 'shareholder': return <PartyList items={data.shareholders} onSelect={item => handleSelect(item, 'shareholder')} type="shareholder" />;
            default: return null;
        }
    };

    const tabTitles: Record<string, string> = {
        customer: 'Customers',
        vendor: 'Vendors',
        employee: 'Employees',
        shareholder: 'Shareholders'
    };

    return (
        <AnimatePresence>
            {isOpen && (
                <motion.div
                    initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                    className="fixed inset-0 z-[100] flex items-center justify-center bg-white/30 backdrop-blur-sm p-4"
                    onClick={onClose}
                >
                    <motion.div
                        initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }}
                        className="bg-white/65 backdrop-blur-xl border border-white/50 rounded-2xl shadow-2xl w-full max-w-2xl flex flex-col max-h-[80vh]"
                        onClick={e => e.stopPropagation()}
                    >
                        <div className="flex justify-between items-center p-4 border-b border-slate-200/80">
                            <h2 className="text-lg font-bold text-slate-800">Select a Party</h2>
                            <button onClick={onClose} className="p-2 rounded-full text-slate-500 hover:bg-slate-200/50"><X size={20}/></button>
                        </div>
                        <div className="flex border-b border-slate-200/80 p-2">
                            {partyTypes.map(type => (
                                <button
                                    key={type}
                                    onClick={() => setActiveTab(type)}
                                    className={`px-4 py-2 text-sm font-semibold rounded-lg transition-colors ${
                                        activeTab === type
                                        ? 'bg-sky-100/70 text-sky-700'
                                        : 'text-slate-500 hover:bg-slate-200/50'
                                    }`}
                                >
                                    {tabTitles[type]}
                                </button>
                            ))}
                        </div>
                        <div className="p-4 overflow-y-auto">
                            {getTabContent()}
                        </div>
                    </motion.div>
                </motion.div>
            )}
        </AnimatePresence>
    );
};

export default PartySelectionModal;