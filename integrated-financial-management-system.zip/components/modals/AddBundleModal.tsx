
import React, { useState, useMemo, useEffect } from 'react';
import { useData } from '../../context/DataContext';
import { CustomerOrder, Account, AccountType, SupplierBundle, OrderStatus } from '../../types';
import { GlassModal } from '../ui/GlassModal';
import { GlassField } from '../ui/GlassField';
import { GlassSearchableSelect } from '../ui/GlassSearchableSelect';
import { GlassButton } from '../ui/GlassButton';
import { Search, Package, Landmark, Hash, CircleDollarSign, CheckSquare, Square, Gift } from 'lucide-react';

interface AddBundleModalProps {
    isOpen: boolean;
    onClose: () => void;
    editingBundle?: SupplierBundle | null;
}

const formatCurrency = (value: number) => new Intl.NumberFormat('en-US').format(value);

const AddBundleModal: React.FC<AddBundleModalProps> = ({ isOpen, onClose, editingBundle }) => {
    const { getOrders, getAccountsList, addBundle, updateBundle, getAccountById } = useData();
    const [accounts, setAccounts] = useState<Account[]>([]);
    const [availableOrders, setAvailableOrders] = useState<CustomerOrder[]>([]);
    const [orderSearch, setOrderSearch] = useState('');
    
    const [name, setName] = useState('');
    const [logisticsReferenceId, setLogisticsReferenceId] = useState('');
    const [paymentAccountId, setPaymentAccountId] = useState('');
    const [selectedOrderIds, setSelectedOrderIds] = useState<Set<string>>(new Set());
    const [recordPayment, setRecordPayment] = useState(true);

    // Reward Logic
    const [rewardAssetBalance, setRewardAssetBalance] = useState(0);
    const [useRewards, setUseRewards] = useState(false);
    const [rewardsAmount, setRewardsAmount] = useState('');
    
    const isEditing = !!editingBundle;

    useEffect(() => {
        if (isOpen) {
            const fetchData = async () => {
                const [accs, allOrders, rewardAcc] = await Promise.all([
                    getAccountsList(), 
                    getOrders(),
                    getAccountById('1180') // Reward Points Asset
                ]);
                
                const monetaryAccounts = accs.filter(a => 
                    a.isPostable && 
                    [AccountType.Cash, AccountType.Bank, AccountType.EWallet, AccountType.MobileCredit].includes(a.accountType)
                );
                setAccounts(monetaryAccounts);
                
                if (rewardAcc) {
                    setRewardAssetBalance(rewardAcc.balance);
                }
                
                const ordersForSelection = allOrders.filter(o => 
                    o.status === OrderStatus.Pending || (isEditing && o.bundleId === editingBundle.id)
                );
                setAvailableOrders(ordersForSelection);

                if (isEditing && editingBundle) {
                    setName(editingBundle.name);
                    setLogisticsReferenceId(editingBundle.logisticsReferenceId);
                    setPaymentAccountId(editingBundle.paymentAccountId);
                    setSelectedOrderIds(new Set(editingBundle.orderIds));
                    setRecordPayment(editingBundle.paymentRecorded);
                    // Editing doesn't support complex reward logic restoration in this MVP, default to off
                } else {
                    setName('');
                    setLogisticsReferenceId('');
                    setSelectedOrderIds(new Set());
                    setOrderSearch('');
                    if (monetaryAccounts.length > 0) {
                        setPaymentAccountId(monetaryAccounts[0].id);
                    }
                    setRecordPayment(true);
                    setUseRewards(false);
                    setRewardsAmount('');
                }
            };
            fetchData();
        }
    }, [isOpen, editingBundle, isEditing, getAccountsList, getOrders, getAccountById]);
    
    const filteredOrders = useMemo(() => {
        if (!orderSearch) return availableOrders;
        const lowerQuery = orderSearch.toLowerCase();
        return availableOrders.filter(o => 
            o.id.toLowerCase().includes(lowerQuery) ||
            o.customerName.toLowerCase().includes(lowerQuery) ||
            o.customerPhone.includes(lowerQuery)
        );
    }, [orderSearch, availableOrders]);

    const totalCost = useMemo(() => {
        return availableOrders
            .filter(order => selectedOrderIds.has(order.id))
            .reduce((sum, order) => sum + order.totalPrice, 0);
    }, [selectedOrderIds, availableOrders]);

    const remainingCashToPay = useMemo(() => {
        const rewards = parseFloat(rewardsAmount) || 0;
        return Math.max(0, totalCost - rewards);
    }, [totalCost, rewardsAmount]);

    const handleOrderSelect = (orderId: string) => {
        setSelectedOrderIds(prev => {
            const newSet = new Set(prev);
            if (newSet.has(orderId)) {
                newSet.delete(orderId);
            } else {
                newSet.add(orderId);
            }
            return newSet;
        });
    };

    const handleRewardsAmountChange = (val: string) => {
        const num = parseFloat(val);
        if (num > rewardAssetBalance) {
            setRewardsAmount(rewardAssetBalance.toString());
        } else if (num > totalCost) {
            setRewardsAmount(totalCost.toString());
        } else {
            setRewardsAmount(val);
        }
    };

    const handleSubmit = async () => {
        if (!name || !logisticsReferenceId || !paymentAccountId || selectedOrderIds.size === 0) {
            alert('Please fill all fields and select at least one order.');
            return;
        }

        const rewardsUsed = useRewards ? (parseFloat(rewardsAmount) || 0) : 0;

        const payload = {
            name,
            logisticsReferenceId,
            paymentAccountId,
            orderIds: [...selectedOrderIds],
            recordPayment,
            rewardsPaymentAmount: rewardsUsed
        };

        try {
            if (isEditing && editingBundle) {
                await updateBundle(editingBundle.id, payload);
            } else {
                await addBundle(payload);
            }
            onClose();
        } catch (error) {
            console.error(`Failed to ${isEditing ? 'update' : 'create'} bundle:`, error);
            alert(`Error: ${(error as Error).message}`);
        }
    };
    
    const accountOptions = useMemo(() => accounts.map(acc => ({
        value: acc.id,
        label: `${acc.code} - ${acc.name}`,
        details: formatCurrency(acc.balance)
    })), [accounts]);

    const selectedAccount = useMemo(() => accountOptions.find(opt => opt.value === paymentAccountId) || null, [paymentAccountId, accountOptions]);

    return (
        <GlassModal
            isOpen={isOpen}
            onClose={onClose}
            title={isEditing ? "Edit Supplier Bundle" : "Create New Supplier Bundle"}
            subtitle="Group orders for a single supplier purchase"
            footer={
                <div className="w-full flex justify-end">
                    <div className="flex items-center space-x-3">
                        <GlassButton variant="secondary" onClick={onClose}>Cancel</GlassButton>
                        <GlassButton variant="primary" onClick={handleSubmit}>{isEditing ? "Update Bundle" : "Create Bundle"}</GlassButton>
                    </div>
                </div>
            }
        >
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-full">
                {/* Left side: Order Selection */}
                <div className="lg:col-span-7 flex flex-col h-full">
                    <div className="relative mb-4">
                        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                        <input type="text" value={orderSearch} onChange={e => setOrderSearch(e.target.value)} placeholder="Search pending orders..." className="w-full h-10 bg-white/60 border border-white/50 rounded-lg shadow-inner pl-9 pr-3 text-sm focus:ring-1 focus:ring-sky-300/60 focus:outline-none" />
                    </div>
                    <div className="flex-1 bg-white/50 border border-white/40 rounded-xl overflow-y-auto">
                        <table className="w-full text-sm">
                            <thead className="sticky top-0 bg-white/70 backdrop-blur-sm z-10">
                                <tr className="border-b border-white/50">
                                    <th className="p-3 w-10"></th>
                                    <th className="p-3 text-left font-semibold text-slate-600">Order</th>
                                    <th className="p-3 text-right font-semibold text-slate-600">Price</th>
                                </tr>
                            </thead>
                            <tbody>
                                {filteredOrders.map(order => (
                                    <tr key={order.id} onClick={() => handleOrderSelect(order.id)} className="border-b border-white/40 hover:bg-sky-100/40 cursor-pointer transition-colors">
                                        <td className="p-3 text-center"><input type="checkbox" checked={selectedOrderIds.has(order.id)} readOnly className="h-4 w-4 rounded border-slate-300 text-sky-500 focus:ring-sky-500" /></td>
                                        <td className="p-3">
                                            <p className="font-semibold text-slate-800">{order.customerName}</p>
                                            <p className="text-xs text-slate-500 font-mono">{order.id}</p>
                                        </td>
                                        <td className="p-3 text-right font-semibold text-slate-800 text-sm">{formatCurrency(order.totalPrice)} $</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                        {availableOrders.length === 0 && <p className="text-center py-10 text-slate-500">No pending orders available.</p>}
                    </div>
                </div>

                {/* Right side: Bundle Details */}
                <div className="lg:col-span-5">
                    <div className="sticky top-0 space-y-5">
                        <GlassField id="bundleName" label="Bundle Name *" value={name} onChange={e => setName(e.target.value)} icon={<Package size={16} />} />
                        <GlassField id="logisticsId" label="Logistics Ref ID *" value={logisticsReferenceId} onChange={e => setLogisticsReferenceId(e.target.value)} icon={<Hash size={16} />} />
                        
                        {/* Payment Section */}
                        <div className="bg-white/40 border border-white/30 rounded-xl p-4 space-y-3">
                            <h4 className="text-sm font-bold text-slate-600 mb-2">Payment Options</h4>
                            
                            <label className="flex items-center space-x-3 p-2 cursor-pointer">
                                {recordPayment ? <CheckSquare size={18} className="text-sky-600"/> : <Square size={18} className="text-slate-400"/>}
                                <span className="text-sm font-medium text-slate-700">Record Payment Now</span>
                                <input type="checkbox" checked={recordPayment} onChange={e => setRecordPayment(e.target.checked)} className="sr-only" />
                            </label>

                            {recordPayment && (
                                <div className="space-y-3 pl-2 border-l-2 border-sky-100 ml-2">
                                    {/* Reward Points Option */}
                                    {rewardAssetBalance > 0 && (
                                        <div className="bg-emerald-50/50 rounded-lg p-3 border border-emerald-100">
                                            <label className="flex items-center justify-between cursor-pointer mb-2">
                                                <div className="flex items-center gap-2">
                                                    <Gift size={16} className="text-emerald-600" />
                                                    <span className="text-sm font-bold text-emerald-800">Use Reward Points</span>
                                                </div>
                                                <input type="checkbox" checked={useRewards} onChange={e => setUseRewards(e.target.checked)} className="accent-emerald-500 w-4 h-4" />
                                            </label>
                                            {useRewards && (
                                                <div>
                                                    <p className="text-xs text-emerald-600 mb-1">Available: {formatCurrency(rewardAssetBalance)}</p>
                                                    <input 
                                                        type="number" 
                                                        value={rewardsAmount} 
                                                        onChange={e => handleRewardsAmountChange(e.target.value)}
                                                        placeholder="Amount from rewards"
                                                        className="w-full h-8 px-2 text-sm border border-emerald-200 rounded bg-white/80 focus:outline-none focus:ring-1 focus:ring-emerald-400"
                                                    />
                                                </div>
                                            )}
                                        </div>
                                    )}

                                    <GlassSearchableSelect id="paymentAccount" label={`Pay ${useRewards ? 'Remaining' : 'Full'} From *`} icon={<Landmark size={16} />} options={accountOptions} selected={selectedAccount} onSelect={opt => setPaymentAccountId(opt?.value || '')} />
                                </div>
                            )}
                        </div>

                        {/* Summary */}
                        <div className="bg-white/60 border border-white/50 rounded-xl p-4 space-y-2 shadow-sm">
                            <div className="flex justify-between text-sm text-slate-600">
                                <span>Total Cost:</span>
                                <span className="font-bold">{formatCurrency(totalCost)}</span>
                            </div>
                            {useRewards && (
                                <div className="flex justify-between text-sm text-emerald-600">
                                    <span>Points Applied:</span>
                                    <span>- {formatCurrency(parseFloat(rewardsAmount) || 0)}</span>
                                </div>
                            )}
                            <div className="flex justify-between text-base font-bold text-slate-800 pt-2 border-t border-slate-200">
                                <span>Cash Payment:</span>
                                <span className="font-mono">{formatCurrency(remainingCashToPay)}</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </GlassModal>
    );
};

export default AddBundleModal;
