import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Save } from 'lucide-react';

interface DescriptionEditModalProps {
    isOpen: boolean;
    onClose: () => void;
    initialValue: string;
    onSave: (newValue: string) => void;
}

const DescriptionEditModal: React.FC<DescriptionEditModalProps> = ({ isOpen, onClose, initialValue, onSave }) => {
    const [value, setValue] = useState(initialValue);

    useEffect(() => {
        if (isOpen) {
            setValue(initialValue);
        }
    }, [isOpen, initialValue]);

    const handleSave = () => {
        onSave(value);
        onClose();
    };

    return (
        <AnimatePresence>
            {isOpen && (
                <motion.div
                    initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                    className="fixed inset-0 z-[101] flex items-center justify-center bg-black/50 backdrop-blur-sm p-4"
                    onClick={onClose}
                >
                    <motion.div
                        initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }}
                        className="bg-white/65 backdrop-blur-xl border border-white/50 rounded-2xl shadow-2xl w-full max-w-lg"
                        onClick={e => e.stopPropagation()}
                    >
                        <div className="flex justify-between items-center p-4 border-b border-slate-200/80">
                            <h2 className="text-lg font-bold text-slate-800">Edit Description</h2>
                            <button onClick={onClose} className="p-2 rounded-full text-slate-500 hover:bg-slate-200/50"><X size={20}/></button>
                        </div>
                        <div className="p-6">
                            <textarea
                                value={value}
                                onChange={e => setValue(e.target.value)}
                                rows={6}
                                className="w-full bg-white/70 border border-slate-300/70 rounded-lg p-3 text-sm text-slate-800 focus:ring-1 focus:ring-sky-500/80 focus:outline-none"
                                autoFocus
                            />
                        </div>
                        <div className="p-4 bg-slate-50/50 border-t border-slate-200/80 flex justify-end gap-3">
                            <button onClick={onClose} className="px-4 py-2 rounded-lg text-sm font-semibold text-slate-700 bg-white/70 border border-slate-300/70 hover:bg-white">Cancel</button>
                            <button onClick={handleSave} className="px-4 py-2 rounded-lg text-sm font-semibold text-white bg-sky-500 hover:bg-sky-600 flex items-center gap-2">
                                <Save size={16} /> Save
                            </button>
                        </div>
                    </motion.div>
                </motion.div>
            )}
        </AnimatePresence>
    );
};

export default DescriptionEditModal;
