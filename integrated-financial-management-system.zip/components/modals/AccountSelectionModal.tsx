import React, { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, X } from 'lucide-react';
import { Account } from '../../types';

interface AccountSelectionModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSelect: (account: Account) => void;
    accounts: Account[];
}

const formatCurrency = (value: number) => new Intl.NumberFormat('en-US').format(value);

const AccountSelectionModal: React.FC<AccountSelectionModalProps> = ({ isOpen, onClose, onSelect, accounts }) => {
    const [query, setQuery] = useState('');
    const [page, setPage] = useState(1);
    const itemsPerPage = 10;

    useEffect(() => { 
        if (isOpen) {
            setQuery('');
            setPage(1);
        }
    }, [isOpen]);

    const filteredItems = useMemo(() => {
        if (!query) return accounts;
        const lowerQuery = query.toLowerCase();
        return accounts.filter(item =>
            item.name.toLowerCase().includes(lowerQuery) ||
            item.code.toLowerCase().includes(lowerQuery) ||
            item.nameKurdish.toLowerCase().includes(lowerQuery)
        );
    }, [query, accounts]);

    const paginatedItems = useMemo(() => {
        const start = (page - 1) * itemsPerPage;
        return filteredItems.slice(start, start + itemsPerPage);
    }, [filteredItems, page, itemsPerPage]);

    const totalPages = Math.ceil(filteredItems.length / itemsPerPage);

    const handleSelect = (account: Account) => {
        onSelect(account);
        onClose();
    };

    return (
        <AnimatePresence>
            {isOpen && (
                <motion.div
                    initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                    className="fixed inset-0 z-[100] flex items-center justify-center bg-white/30 backdrop-blur-sm p-4"
                    onClick={onClose}
                >
                    <motion.div
                        initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }}
                        className="bg-white/65 backdrop-blur-xl border border-white/50 rounded-2xl shadow-2xl w-full max-w-2xl flex flex-col max-h-[80vh]"
                        onClick={e => e.stopPropagation()}
                    >
                        <div className="flex justify-between items-center p-4 border-b border-slate-200/80">
                            <h2 className="text-lg font-bold text-slate-800">Select an Account</h2>
                            <button onClick={onClose} className="p-2 rounded-full text-slate-500 hover:bg-slate-200/50"><X size={20}/></button>
                        </div>
                        <div className="p-4">
                            <div className="relative">
                                <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                                <input
                                    type="text"
                                    value={query}
                                    onChange={e => setQuery(e.target.value)}
                                    placeholder="Search by code or name..."
                                    autoFocus
                                    className="w-full h-10 bg-white/70 border border-slate-300/70 rounded-lg pl-9 pr-3 text-sm text-slate-800 focus:ring-1 focus:ring-sky-500/80 focus:outline-none"
                                />
                            </div>
                        </div>
                        <div className="px-4 pb-2 flex-1 overflow-y-auto">
                            <div className="min-h-[350px]">
                                {paginatedItems.map(item => (
                                    <div
                                        key={item.id}
                                        onClick={() => handleSelect(item)}
                                        className="flex justify-between items-center p-3 rounded-lg hover:bg-sky-100/50 cursor-pointer"
                                    >
                                        <div>
                                            <p className="font-semibold text-slate-800">{item.code} - {item.name}</p>
                                            <p className="text-xs text-slate-500">{item.nameKurdish}</p>
                                        </div>
                                        <span className="font-mono text-sm text-slate-600">{formatCurrency(item.balance)} $</span>
                                    </div>
                                ))}
                                {filteredItems.length === 0 && (
                                    <div className="text-center py-10 text-slate-500">No accounts found.</div>
                                )}
                            </div>
                        </div>
                         {totalPages > 1 && (
                            <div className="flex justify-between items-center text-xs text-slate-500 p-4 border-t border-slate-200/80">
                                <p>Page {page} of {totalPages}</p>
                                <div className="flex gap-1">
                                    <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="px-2 py-1 rounded disabled:opacity-50 hover:bg-slate-200/50">Prev</button>
                                    <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages} className="px-2 py-1 rounded disabled:opacity-50 hover:bg-slate-200/50">Next</button>
                                </div>
                            </div>
                        )}
                    </motion.div>
                </motion.div>
            )}
        </AnimatePresence>
    );
};

export default AccountSelectionModal;