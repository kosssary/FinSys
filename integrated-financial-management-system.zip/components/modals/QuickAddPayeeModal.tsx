

import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { Vendor, Customer, Employee, PartyEntity } from '../../types';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';

interface QuickAddPayeeModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (entity: PartyEntity) => void;
}

const QuickAddPayeeModal: React.FC<QuickAddPayeeModalProps> = ({ isOpen, onClose, onSave }) => {
    const { addVendor, addCustomer, addEmployee } = useData();
    const [name, setName] = useState('');
    const [type, setType] = useState<'vendor' | 'customer' | 'employee'>('vendor');
    const [error, setError] = useState('');

    const handleSubmit = async () => {
        if (!name.trim()) {
            setError('Name is required.');
            return;
        }

        try {
            let savedEntity: Vendor | Customer | Employee;
            let entityType: PartyEntity['type'] = 'vendor';

            switch (type) {
                case 'vendor':
                    savedEntity = await addVendor({ name: name.trim() });
                    entityType = 'vendor';
                    break;
                case 'customer':
                    // A simple customer needs a phone number
                    const phone = `TEMP-${Date.now()}`;
                    savedEntity = await addCustomer({ name: name.trim(), phone1: phone, address: 'N/A' });
                     entityType = 'customer';
                    break;
                case 'employee':
                     savedEntity = await addEmployee({ fullName: name.trim(), position: 'N/A', startDate: new Date(), basicMonthlySalary: 0, paymentMethod: 'Cash' });
                     entityType = 'employee';
                    break;
            }
            
            onSave({
                id: savedEntity.id,
                name: 'fullName' in savedEntity ? savedEntity.fullName : (savedEntity.name || ''),
                type: entityType
            });
            onClose();

        } catch (err) {
            console.error("Quick add failed:", err);
            setError("Failed to save. Please try again.");
        }
    };

    return (
        <AnimatePresence>
            {isOpen && (
                <motion.div
                    initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                    className="fixed inset-0 z-[101] flex items-center justify-center bg-black/50 backdrop-blur-sm p-4"
                    onClick={onClose}
                >
                    <motion.div
                        initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }}
                        className="bg-white/80 dark:bg-slate-800/80 backdrop-blur-xl border border-white/50 rounded-2xl shadow-2xl w-full max-w-sm"
                        onClick={e => e.stopPropagation()}
                    >
                        <div className="flex justify-between items-center p-4 border-b border-slate-200/80 dark:border-slate-700/80">
                            <h2 className="text-lg font-bold text-slate-800 dark:text-white">Quick Add Payee</h2>
                            <button onClick={onClose} className="p-2 rounded-full text-slate-500 hover:bg-slate-200/50 dark:hover:bg-slate-700/50"><X size={20}/></button>
                        </div>
                        <div className="p-6 space-y-4">
                            <div>
                                <label className="text-sm font-semibold text-slate-600 dark:text-slate-300 mb-1 block">Payee Name</label>
                                <input
                                    type="text"
                                    value={name}
                                    onChange={e => setName(e.target.value)}
                                    className="input-field"
                                    autoFocus
                                />
                                {error && <p className="text-xs text-red-500 mt-1">{error}</p>}
                            </div>
                            <div>
                                <label className="text-sm font-semibold text-slate-600 dark:text-slate-300 mb-1 block">Type</label>
                                <select value={type} onChange={e => setType(e.target.value as any)} className="input-field">
                                    <option value="vendor">Vendor</option>
                                    <option value="customer">Customer</option>
                                    <option value="employee">Employee</option>
                                </select>
                            </div>
                        </div>
                        <div className="p-4 bg-slate-50/50 dark:bg-slate-900/50 border-t border-slate-200/80 dark:border-slate-700/80 flex justify-end gap-3">
                            <button onClick={onClose} className="btn-secondary">Cancel</button>
                            <button onClick={handleSubmit} className="btn-primary">Save</button>
                        </div>
                    </motion.div>
                </motion.div>
            )}
        </AnimatePresence>
    );
};

export default QuickAddPayeeModal;