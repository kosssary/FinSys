import React, { useState, useEffect, useMemo } from 'react';
import { useData } from '../../context/DataContext';
import { Account, AccountCategory, AccountType } from '../../types';

interface AddAccountModalProps {
    isOpen: boolean;
    onClose: () => void;
    editingAccount?: Account | null;
    parentAccount?: Account | null;
}

const AddAccountModal: React.FC<AddAccountModalProps> = ({ isOpen, onClose, editingAccount, parentAccount }) => {
    const { getAccountsList, addAccount, updateAccount, deleteAccount } = useData();
    
    const [allAccounts, setAllAccounts] = useState<Account[]>([]);
    const [name, setName] = useState('');
    const [nameKurdish, setNameKurdish] = useState('');
    const [code, setCode] = useState('');
    const [parentId, setParentId] = useState<string | null>(null);
    const [category, setCategory] = useState<AccountCategory>(AccountCategory.Asset);
    const [accountType, setAccountType] = useState<AccountType>(AccountType.Cash);
    const [isDeletable, setIsDeletable] = useState(true);

    const isEditing = useMemo(() => !!editingAccount, [editingAccount]);

    useEffect(() => {
        if (isOpen) {
            getAccountsList().then(setAllAccounts);

            if (isEditing && editingAccount) {
                setName(editingAccount.name);
                setNameKurdish(editingAccount.nameKurdish);
                setCode(editingAccount.code);
                setParentId(editingAccount.parentId);
                setCategory(editingAccount.category);
                setAccountType(editingAccount.accountType);
                setIsDeletable(editingAccount.isDeletable);
            } else if (parentAccount) { // Creating a child
                setName('');
                setNameKurdish('');
                setCode('');
                setParentId(parentAccount.id);
                setCategory(parentAccount.category); // Default to parent's category
                setAccountType(parentAccount.accountType); // Default to parent's type
                setIsDeletable(true);
            } else { // Creating a root account
                setName('');
                setNameKurdish('');
                setCode('');
                setParentId(null);
                setCategory(AccountCategory.Asset);
                setAccountType(AccountType.OtherCurrentAsset);
                setIsDeletable(true);
            }
        }
    }, [isOpen, editingAccount, parentAccount]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!name || !code || !category || !nameKurdish || !accountType) {
            alert('Please fill all required fields.');
            return;
        }

        try {
            if (isEditing && editingAccount) {
                await updateAccount({ id: editingAccount.id, code, name, parentId, category, accountType, isDeletable });
            } else {
                await addAccount({ code, name, nameKurdish, parentId, category, accountType });
            }
            onClose();
        } catch (error) {
            console.error("Failed to save account:", error);
            alert(`Error: ${(error as Error).message}`);
        }
    };
    
    const handleDelete = async () => {
        if (!editingAccount || !isEditing) return;
        if (window.confirm(`Are you sure you want to delete account "${editingAccount.name}"? This cannot be undone.`)) {
            try {
                await deleteAccount(editingAccount.id);
                onClose();
            } catch (error) {
                 console.error("Failed to delete account:", error);
                 const errorMessage = (error as Error).message;
                 let translatedMessage = "Error: Could not delete the account.";
                 if (errorMessage.includes("child accounts")) {
                     translatedMessage = "هەڵە: ناتوانیت حیسابێک بسڕیتەوە کە چایەڵدی هەبێت."; // Error: You cannot delete an account that has children.
                 } else if (errorMessage.includes("transactions")) {
                     translatedMessage = "هەڵە: ناتوانیت حیسابێک بسڕیتەوە کە مامەڵەی تێدا کرابێت."; // Error: You cannot delete an account that has transactions.
                 } else if (errorMessage.includes("protected system account")) {
                     translatedMessage = "هەڵە: ئەم حیسابە پارێزراوە و ناتوانیت بیسڕیتەوە."; // Error: This is a protected account and cannot be deleted.
                 }
                 alert(translatedMessage);
            }
        }
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-60" aria-modal="true" role="dialog">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-md transform transition-all">
                <div className="flex justify-between items-center px-6 py-4 border-b dark:border-gray-700">
                    <h2 className="text-xl font-semibold text-gray-800 dark:text-white">
                        {isEditing ? 'Edit Account' : 'Add New Account'}
                    </h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 p-1 rounded-full transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    </button>
                </div>
                <form onSubmit={handleSubmit}>
                    <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
                        <div>
                            <label htmlFor="code" className="label">Account Code *</label>
                            <input type="text" id="code" value={code} onChange={(e) => setCode(e.target.value)} required className="mt-1 input-field" />
                        </div>
                        <div>
                            <label htmlFor="name" className="label">Account Name (English) *</label>
                            <input type="text" id="name" value={name} onChange={(e) => setName(e.target.value)} required className="mt-1 input-field" />
                        </div>
                         <div>
                            <label htmlFor="nameKurdish" className="label">Account Name (Kurdish) *</label>
                            <input type="text" id="nameKurdish" value={nameKurdish} onChange={(e) => setNameKurdish(e.target.value)} required className="mt-1 input-field" />
                        </div>
                        <div>
                            <label htmlFor="category" className="label">Category *</label>
                            <select id="category" value={category} onChange={(e) => setCategory(e.target.value as AccountCategory)} required className="mt-1 input-field">
                                {Object.values(AccountCategory).map(cat => <option key={cat} value={cat}>{cat}</option>)}
                            </select>
                        </div>
                        <div>
                            <label htmlFor="accountType" className="label">Account Type *</label>
                            <select id="accountType" value={accountType} onChange={(e) => setAccountType(e.target.value as AccountType)} required className="mt-1 input-field">
                                {Object.values(AccountType).map(type => <option key={type} value={type}>{type}</option>)}
                            </select>
                        </div>
                        <div>
                            <label htmlFor="parentId" className="label">Parent Account</label>
                            <select id="parentId" value={parentId ?? ''} onChange={(e) => setParentId(e.target.value || null)} className="mt-1 input-field">
                                <option value="">-- No Parent (Root Account) --</option>
                                {allAccounts.filter(acc => acc.id !== editingAccount?.id).map(acc => (
                                    <option key={acc.id} value={acc.id}>{acc.code} - {acc.name} ({acc.nameKurdish})</option>
                                ))}
                            </select>
                        </div>
                         {isEditing && (
                            <div className="flex items-center">
                                <input type="checkbox" id="isDeletable" checked={isDeletable} onChange={(e) => setIsDeletable(e.target.checked)} className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
                                <label htmlFor="isDeletable" className="ml-2 block text-sm text-gray-900 dark:text-gray-300">This account can be deleted</label>
                            </div>
                         )}
                    </div>
                    <div className="flex justify-between items-center px-6 py-4 bg-gray-50 dark:bg-gray-800/50 border-t dark:border-gray-700">
                        <div>
                             {isEditing && isDeletable && <button type="button" onClick={handleDelete} className="btn-danger">Delete</button>}
                        </div>
                        <div className="flex items-center">
                            <button type="button" onClick={onClose} className="btn-secondary mr-3">Cancel</button>
                            <button type="submit" className="btn-primary">Save Account</button>
                        </div>
                    </div>
                </form>
                <style>{`
                    .label { display: block; margin-bottom: 0.25rem; font-size: 0.875rem; font-weight: 500; color: #4B5563; } .dark .label { color: #D1D5DB; }
                    .input-field { display: block; width: 100%; padding: 0.5rem 0.75rem; border: 1px solid #D1D5DB; border-radius: 0.375rem; } .dark .input-field { background-color: #374151; border-color: #4B5563; color: #E5E7EB; }
                    .btn-primary { padding: 0.5rem 1.25rem; font-weight: 600; color: white; background-image: linear-gradient(to right, #0ea5e9, #06b6d4); border-radius: 0.5rem; transition: all 0.2s; box-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1); } .btn-primary:hover { box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1); filter: brightness(1.05); } .btn-primary:active { transform: scale(0.98); } .btn-primary:disabled { opacity: 0.5; cursor: not-allowed; filter: none; transform: none; box-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1); }
                    .btn-secondary { padding: 0.5rem 1rem; font-weight: 500; border: 1px solid #D1D5DB; border-radius: 0.375rem; } .dark .btn-secondary { background-color: #4B5563; border-color: #6B7280; color: #E5E7EB; }
                    .btn-danger { padding: 0.5rem 1.25rem; font-weight: 500; color: white; background-color: #DC2626; border-radius: 0.375rem; } .btn-danger:hover { background-color: #B91C1C; }
                `}</style>
            </div>
        </div>
    );
};

export default AddAccountModal;