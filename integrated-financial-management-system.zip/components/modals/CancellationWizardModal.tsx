
import React, { useState, useMemo } from 'react';
import { useData } from '../../context/DataContext';
import { CustomerOrder } from '../../types';
import { GlassModal } from '../ui/GlassModal';
import { GlassButton } from '../ui/GlassButton';
import { AlertTriangle, Package, ArrowLeftRight, CheckCircle2, Info, ExternalLink } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface CancellationWizardModalProps {
    isOpen: boolean;
    onClose: () => void;
    order: CustomerOrder;
}

type Scenario = 'before_purchase' | 'stocked' | 'returned';

const formatCurrency = (value: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value);

const ScenarioCard: React.FC<{
    id: Scenario;
    title: string;
    description: string;
    icon: React.ReactNode;
    isSelected: boolean;
    onSelect: (id: Scenario) => void;
}> = ({ id, title, description, icon, isSelected, onSelect }) => (
    <div 
        onClick={() => onSelect(id)}
        className={`cursor-pointer rounded-xl border-2 p-4 transition-all duration-200 flex flex-col gap-3
        ${isSelected ? 'border-sky-500 bg-sky-50 dark:bg-sky-900/20' : 'border-slate-200 hover:border-sky-300 bg-white/60 dark:border-slate-700 dark:bg-slate-800/60'}
        `}
    >
        <div className={`p-2 rounded-full w-fit ${isSelected ? 'bg-sky-100 text-sky-600' : 'bg-slate-100 text-slate-500'}`}>
            {icon}
        </div>
        <div>
            <h4 className={`font-bold text-sm mb-1 ${isSelected ? 'text-sky-900 dark:text-sky-100' : 'text-slate-700 dark:text-slate-300'}`}>{title}</h4>
            <p className="text-xs text-slate-500 dark:text-slate-400">{description}</p>
        </div>
        <div className="flex justify-end mt-auto">
            <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${isSelected ? 'border-sky-500 bg-sky-500 text-white' : 'border-slate-300'}`}>
                {isSelected && <CheckCircle2 size={14} />}
            </div>
        </div>
    </div>
);

export const CancellationWizardModal: React.FC<CancellationWizardModalProps> = ({ isOpen, onClose, order }) => {
    const { processOrderCancellation } = useData();
    const navigate = useNavigate();
    const [selectedScenario, setSelectedScenario] = useState<Scenario>('before_purchase');
    const [isSuccess, setIsSuccess] = useState(false);
    const [jvId, setJvId] = useState<string | null>(null);

    // Reset state when opening a new order
    React.useEffect(() => {
        if (isOpen) {
            setIsSuccess(false);
            setJvId(null);
            setSelectedScenario('before_purchase');
        }
    }, [isOpen, order.id]);

    const handleConfirm = async () => {
        try {
            const voucherNumber = await processOrderCancellation(order.id, selectedScenario);
            setJvId(voucherNumber);
            setIsSuccess(true);
        } catch (error) {
            alert(`Error: ${(error as Error).message}`);
        }
    };

    const previewData = useMemo(() => {
        const price = order.totalPrice;
        const common = [
            { account: '4101 - Sales Revenue', debit: price, credit: 0, type: 'Debit' },
            { account: '1501 - Customer Receivables', debit: 0, credit: price, type: 'Credit' }
        ];

        if (selectedScenario === 'before_purchase') {
            return common;
        } 
        
        if (selectedScenario === 'stocked') {
            return [
                ...common,
                { account: '1620 - Warehouse Inventory', debit: price, credit: 0, type: 'Debit' },
                { account: '1601 - Goods in Transit', debit: 0, credit: price, type: 'Credit' }
            ];
        }

        if (selectedScenario === 'returned') {
            return [
                ...common,
                { account: '1620 - Warehouse Inventory', debit: price, credit: 0, type: 'Debit' },
                { account: '5001 - Purchase Cost (COGS)', debit: 0, credit: price, type: 'Credit' }
            ];
        }
        return [];
    }, [selectedScenario, order.totalPrice]);

    if (!isOpen) return null;

    return (
        <GlassModal
            isOpen={isOpen}
            onClose={onClose}
            title="Manage Order Cancellation / Return"
            subtitle={`Processing Order #${order.id} - ${order.customerName}`}
            footer={
                !isSuccess ? (
                    <div className="w-full flex justify-between items-center">
                        <p className="text-xs text-slate-500">Action cannot be undone.</p>
                        <div className="flex items-center space-x-3">
                            <GlassButton variant="secondary" onClick={onClose}>Cancel</GlassButton>
                            <GlassButton variant="primary" onClick={handleConfirm} className="bg-red-500 hover:bg-red-600 border-red-500">
                                Confirm & Post
                            </GlassButton>
                        </div>
                    </div>
                ) : (
                    <div className="w-full flex justify-end">
                        <GlassButton variant="primary" onClick={onClose}>Close</GlassButton>
                    </div>
                )
            }
        >
            {!isSuccess ? (
                <div className="space-y-8 max-w-4xl mx-auto py-4">
                    {/* Step 1: Selection */}
                    <section>
                        <h3 className="text-sm font-bold text-slate-600 uppercase tracking-wider mb-4">1. Select Scenario</h3>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <ScenarioCard
                                id="before_purchase"
                                title="Cancelled Before Purchase"
                                description="We haven't bought the item yet. Just reverse the sale."
                                icon={<AlertTriangle size={20}/>}
                                isSelected={selectedScenario === 'before_purchase'}
                                onSelect={setSelectedScenario}
                            />
                            <ScenarioCard
                                id="stocked"
                                title="Cancelled After Purchase"
                                description="Item bought but not shipped/sold. Move from 'In Transit' to 'Stock'."
                                icon={<Package size={20}/>}
                                isSelected={selectedScenario === 'stocked'}
                                onSelect={setSelectedScenario}
                            />
                            <ScenarioCard
                                id="returned"
                                title="Returned by Customer"
                                description="Customer received and returned item. Reverse Sale & COGS. Restock item."
                                icon={<ArrowLeftRight size={20}/>}
                                isSelected={selectedScenario === 'returned'}
                                onSelect={setSelectedScenario}
                            />
                        </div>
                    </section>

                    {/* Step 2: Preview */}
                    <section className="bg-slate-50/50 dark:bg-slate-800/30 rounded-xl p-6 border border-slate-200/60">
                        <div className="flex items-center gap-2 mb-4">
                            <Info size={16} className="text-sky-600"/>
                            <h3 className="text-sm font-bold text-slate-600 uppercase tracking-wider">2. Proposed Journal Entry Preview</h3>
                        </div>
                        
                        <div className="overflow-hidden rounded-lg border border-slate-200 dark:border-slate-700">
                            <table className="w-full text-sm text-left">
                                <thead className="bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 font-semibold">
                                    <tr>
                                        <th className="px-4 py-2">Account</th>
                                        <th className="px-4 py-2 text-right">Debit</th>
                                        <th className="px-4 py-2 text-right">Credit</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-200 dark:divide-slate-700 bg-white dark:bg-slate-800">
                                    {previewData.map((row, idx) => (
                                        <tr key={idx}>
                                            <td className="px-4 py-2 font-medium text-slate-700 dark:text-slate-300">{row.account}</td>
                                            <td className="px-4 py-2 text-right font-mono text-slate-600">{row.debit > 0 ? formatCurrency(row.debit) : '-'}</td>
                                            <td className="px-4 py-2 text-right font-mono text-slate-600">{row.credit > 0 ? formatCurrency(row.credit) : '-'}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </section>
                </div>
            ) : (
                <div className="flex flex-col items-center justify-center py-16 space-y-6 text-center">
                    <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mb-2">
                        <CheckCircle2 size={48} />
                    </div>
                    <h2 className="text-2xl font-bold text-slate-800">Cancellation Processed Successfully</h2>
                    <p className="text-slate-500 max-w-md">
                        The order status has been updated and the financial journal entry has been posted.
                    </p>
                    {jvId && (
                        <button 
                            onClick={() => { onClose(); navigate('/journal-vouchers', { state: { search: jvId } }); }}
                            className="flex items-center gap-2 text-sky-600 hover:text-sky-700 font-semibold bg-sky-50 px-4 py-2 rounded-lg border border-sky-200 transition-all hover:shadow-md"
                        >
                            <ExternalLink size={16} />
                            View Journal Voucher ({jvId})
                        </button>
                    )}
                </div>
            )}
        </GlassModal>
    );
};
