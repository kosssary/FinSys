
import React, { useState, useEffect } from 'react';
import { useData } from '../../context/DataContext';
import { GlassModal } from '../ui/GlassModal';
import { GlassField } from '../ui/GlassField';
import { GlassButton } from '../ui/GlassButton';
import { User, Briefcase, Calendar, DollarSign, CreditCard } from 'lucide-react';

interface AddEmployeeModalProps {
    isOpen: boolean;
    onClose: () => void;
}

const AddEmployeeModal: React.FC<AddEmployeeModalProps> = ({ isOpen, onClose }) => {
    const { addEmployee } = useData();
    const [fullName, setFullName] = useState('');
    const [position, setPosition] = useState('');
    const [startDate, setStartDate] = useState('');
    const [salary, setSalary] = useState('');
    const [paymentMethod, setPaymentMethod] = useState('Cash');

    useEffect(() => {
        if (isOpen) {
            setFullName('');
            setPosition('');
            setStartDate(new Date().toISOString().split('T')[0]);
            setSalary('');
            setPaymentMethod('Cash');
        }
    }, [isOpen]);

    const handleSubmit = async () => {
        if (!fullName || !position || !startDate || !salary) {
            alert('Please fill all required fields.');
            return;
        }
        try {
            await addEmployee({
                fullName,
                position,
                startDate: new Date(startDate),
                basicMonthlySalary: parseFloat(salary),
                paymentMethod,
            });
            onClose();
        } catch (error) {
            console.error("Failed to add employee:", error);
            alert("Error: Could not add the employee.");
        }
    };

    if (!isOpen) return null;

    return (
        <GlassModal
            isOpen={isOpen}
            onClose={onClose}
            title="Add New Employee"
            subtitle="Enter the personal and financial details for the new staff member."
            footer={
                <>
                    <div /> {/* Spacer */}
                    <div className="flex items-center space-x-3">
                        <GlassButton variant="secondary" onClick={onClose}>Cancel</GlassButton>
                        <GlassButton variant="primary" onClick={handleSubmit}>Save Employee</GlassButton>
                    </div>
                </>
            }
        >
            <div className="space-y-4 max-w-lg mx-auto py-4">
                <GlassField
                    id="fullName"
                    label="Full Name *"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    icon={<User size={16} />}
                    autoFocus
                />
                <GlassField
                    id="position"
                    label="Position / Title *"
                    value={position}
                    onChange={(e) => setPosition(e.target.value)}
                    icon={<Briefcase size={16} />}
                />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <GlassField
                        id="startDate"
                        label="Start Date *"
                        type="date"
                        value={startDate}
                        onChange={(e) => setStartDate(e.target.value)}
                        icon={<Calendar size={16} />}
                    />
                    <GlassField
                        id="salary"
                        label="Basic Monthly Salary ($) *"
                        type="number"
                        value={salary}
                        onChange={(e) => setSalary(e.target.value)}
                        icon={<DollarSign size={16} />}
                        min="0"
                    />
                </div>
                
                {/* Custom Glass Select for Payment Method */}
                <div className="relative group">
                    <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-sky-500 transition-colors pointer-events-none z-10">
                        <CreditCard size={16} />
                    </div>
                    <select
                        id="paymentMethod"
                        value={paymentMethod}
                        onChange={(e) => setPaymentMethod(e.target.value)}
                        className="peer w-full h-14 bg-white/70 border border-white/60 rounded-xl shadow-inner pl-10 pr-4 pt-4 text-slate-800 text-sm font-medium focus:ring-2 focus:ring-sky-300/60 focus:outline-none transition appearance-none"
                    >
                        <option value="Cash">Cash</option>
                        <option value="Bank Transfer">Bank Transfer</option>
                    </select>
                    <label
                        htmlFor="paymentMethod"
                        className="absolute left-10 top-3 text-xs text-slate-500 pointer-events-none transition-all"
                    >
                        Payment Method
                    </label>
                </div>
            </div>
        </GlassModal>
    );
};

export default AddEmployeeModal;
